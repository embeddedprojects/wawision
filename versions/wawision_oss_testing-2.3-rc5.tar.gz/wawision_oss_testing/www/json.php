<?php

$newarray[] = array ('huhu','jjj','kkk','lllll','ooo');
$newarray[] = array ('huhu','jjj','kkk','lllll','ooo');
$newarray[] = array ('huhu','jjj','kkk','lllll','ooo');
$newarray[] = array ('huhu','jjj','kkk','lllll','ooo');
$newarray[] = array ('huhu','jjj','kkk','lllll','ooo');

echo json_encode($newarray);
    exit;

?>
