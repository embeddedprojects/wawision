<?php
class Ajax {
  var $app;
  
  function Ajax($app) {
    $this->app=&$app;

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("filter","AjaxFilter");
    $this->app->ActionHandler("table","AjaxTable");
    $this->app->ActionHandler("ansprechpartner","AjaxAnsprechpartner");
    $this->app->ActionHandler("lieferadresse","AjaxLieferadresse");
    $this->app->ActionHandler("tooltipsuche","AjaxTooltipSuche");
    $this->app->ActionHandler("tableposition","AjaxTablePosition");


    $this->app->ActionHandlerListen($app);

    $this->app = $app;
  }

  function AjaxTooltipSuche()
  {
    $term = $this->app->Secure->GetGET("term");

    if(is_numeric($term))
    {
      $rechnung = $this->app->DB->SelectArr("SELECT id,belegnr,soll,ist FROM rechnung WHERE belegnr='$term'");
      $gutschrift = $this->app->DB->SelectArr("SELECT id,belegnr,soll,ist FROM gutschrift WHERE belegnr='$term'");
      $auftrag = $this->app->DB->SelectArr("SELECT id,belegnr FROM auftrag WHERE belegnr='$term'");
      $internet = $this->app->DB->SelectArr("SELECT id,belegnr FROM auftrag WHERE internet='$term'");
      $kunde = $this->app->DB->SelectArr("SELECT id,name FROM adresse WHERE kundennummer='$term'");
    }
    if(is_array($rechnung))
    {
      foreach($rechnung as $value){
	echo "<table width=\"500\"><tr><td>Rechnung ".$value[belegnr]." SOLL:".$value[soll]." IST:".$value[ist]."</td></tr></table>";
      }
    }




    if(is_array($auftrag))
    {
      foreach($auftrag as $value){
	echo "Auftrag ".$value[belegnr];
      }
    }



    if(is_array($internet))
    {
      foreach($internet as $value){
	echo "Internet Auftrag ".$value[belegnr];
      }
    }


    if($internetnummer)
      echo "Internetnummer";


    if(is_array($kunde))
    {
      foreach($kunde as $value){
	echo "Kunde ".$value[name];
      }
    }

   
    echo "ENDE ";

    exit;

  }

	function AjaxLieferadresse()
	{
		$id = $this->app->Secure->GetGET("id");	


		//name	abteilung		unterabteilung	land	strasse		ort		plz

		$values = $this->app->DB->SelectArr("SELECT * FROM lieferadressen WHERE id='$id' LIMIT 1");

  	echo $values[0][name].":".$values[0][abteilung].":".$values[0][unterabteilung].":".$values[0][land].":".$values[0][strasse].":".$values[0][ort].":".$values[0][plz].":".$values[0][adresszusatz].":".$values[0][ansprechpartner];
		exit;

	}



	function AjaxAnsprechpartner()
	{
		$id = $this->app->Secure->GetGET("id");	

		$values = $this->app->DB->SelectArr("SELECT * FROM ansprechpartner WHERE id='$id' LIMIT 1");

  	echo $values[0][name].":".$values[0][email].":".$values[0][telefon].":".$values[0][telefax].":".$values[0][abteilung].":".$values[0][unterabteilung];
		exit;

	}


  function AjaxFilter()
  {
    $term = $this->app->Secure->GetGET("term");
    $filtername = $this->app->Secure->GetGET("filtername");

		$term = trim($term);

    switch($filtername)
    {
	case "adressename":
		$arr = $this->app->DB->SelectArr("SELECT name FROM adresse WHERE firma='".$this->app->User->GetFirma()."' AND (email LIKE '%$term%' OR name LIKE '%$term%') ORDER BY email LIMIT 20");
		for($i=0;$i<count($arr);$i++)
			$newarr[] = "{$arr[$i]['name']}";
	break;


	case "artikelname":
	  $arr = $this->app->DB->SelectArr("SELECT name_de FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND (name_de LIKE '%$term%' OR nummer LIKE '%$term%') AND geloescht=0 ORDER by name_de LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name_de'];
	break;

	case "artikelgruppe":
	  $arr = $this->app->DB->SelectArr("SELECT DISTINCT typ FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND typ LIKE '%$term%' ORDER by typ");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['typ'];
	break;


	case "hersteller":
	  $arr = $this->app->DB->SelectArr("SELECT DISTINCT hersteller FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND hersteller LIKE '%$term%' ORDER by hersteller");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['hersteller'];
	break;


	case "auftrag_zahlungseingang":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(r.belegnr,' ',a.name,' ',r.internet,' GESAMT: ',r.gesamtsumme,' (Kunde ',a.kundennummer,') vom ',DATE_FORMAT(r.datum,'%d.%m.%Y')) as name
	    FROM auftrag r LEFT JOIN adresse a ON a.id=r.adresse WHERE r.belegnr>0 AND r.firma='".$this->app->User->GetFirma()."' 
	      AND (a.name LIKE '%$term%' OR r.belegnr LIKE '%$term%' OR a.kundennummer LIKE '%$term%' ) ORDER by r.belegnr  DESC LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "rechnung_zahlungseingang":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(r.belegnr,' SOLL: ',r.soll,' IST:',r.ist,' ',a.name,' (Kunde ',a.kundennummer,') vom ',DATE_FORMAT(r.datum,'%d.%m.%Y')) as name
	    FROM rechnung r LEFT JOIN adresse a ON a.id=r.adresse WHERE r.belegnr>0 AND r.firma='".$this->app->User->GetFirma()."' AND (a.name LIKE '%$term%' OR r.belegnr LIKE '%$term%' OR a.kundennummer LIKE '%$term%') AND r.zahlungsstatus!='bezahlt' ORDER by r.belegnr DESC LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "gutschrift_zahlungseingang":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(r.belegnr,' SOLL: ',r.soll,' IST:',r.ist,' ',a.name,' (Kunde ',a.kundennummer,') vom ',DATE_FORMAT(r.datum,'%d.%m.%Y')) as name
	    FROM gutschrift r LEFT JOIN adresse a ON a.id=r.adresse WHERE r.belegnr>0 AND r.firma='".$this->app->User->GetFirma()."' AND (a.name LIKE '%$term%' OR r.belegnr LIKE '%$term%' OR a.kundennummer LIKE '%$term%') ORDER by r.belegnr DESC LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "angebot":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(belegnr,' ',name,' ',DATE_FORMAT(datum,'%Y-%m-%d')) as name 
	    FROM angebot WHERE belegnr>0 AND firma='".$this->app->User->GetFirma()."' AND (name LIKE '%$term%' OR belegnr LIKE '%$term%' OR DATE_FORMAT(datum,'%Y-%m-%d') LIKE '%$term%')  ORDER by belegnr LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "auftrag":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(belegnr,' ',name,' ',DATE_FORMAT(datum,'%Y-%m-%d')) as name 
	    FROM auftrag WHERE belegnr>0 AND firma='".$this->app->User->GetFirma()."' AND (name LIKE '%$term%' OR belegnr LIKE '%$term%' OR DATE_FORMAT(datum,'%Y-%m-%d') LIKE '%$ter    m%') ORDER by belegnr LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "lieferschein":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(belegnr,' ',name,' ',DATE_FORMAT(datum,'%Y-%m-%d')) as name 
	    FROM lieferschein WHERE belegnr>0 AND firma='".$this->app->User->GetFirma()."' AND (name LIKE '%$term%' OR belegnr LIKE '%$term%' OR DATE_FORMAT(datum,'%Y-%m-%d') LIKE '%$ter    m%') ORDER by belegnr LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "rechnung":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(belegnr,' ',name,' ',DATE_FORMAT(datum,'%Y-%m-%d')) as name 
	    FROM rechnung WHERE belegnr>0 AND firma='".$this->app->User->GetFirma()."' AND (name LIKE '%$term%' OR belegnr LIKE '%$term%' OR DATE_FORMAT(datum,'%Y-%m-%d') LIKE '%$ter    m%') ORDER by belegnr LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;



	case "vpeartikel":
	  $arr = $this->app->DB->SelectArr("SELECT DISTINCT vpe FROM verkaufspreise WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND vpe LIKE '%$term%' ORDER by vpe");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['vpe'];
	break;



	case "herstellerlink":
	  $arr = $this->app->DB->SelectArr("SELECT DISTINCT herstellerlink FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND herstellerlink LIKE '%$term%' ORDER by herstellerlink");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['herstellerlink'];
	break;


	case "lagerplatz":
	  $arr = $this->app->DB->SelectArr("SELECT kurzbezeichnung FROM lager_platz WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND kurzbezeichnung LIKE '%$term%' ORDER by kurzbezeichnung");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['kurzbezeichnung'];
	break;



	case "artikelnummer":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(nummer,' ',name_de) as name FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND nummer LIKE '%$term%' OR name_de LIKE '%$term%' AND geloescht=0 LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "lagerartikelnummer":
		$arr = $this->app->DB->SelectArr("SELECT CONCAT(nummer,' ',name_de) as name 
																			FROM artikel WHERE lagerartikel='1' AND firma='".$this->app->User->GetFirma()."' AND (nummer LIKE '%$term%' OR name_de LIKE '%$term%') AND geloescht=0 LIMIT 20");
		for($i=0;$i<count($arr);$i++)
      $newarr[] = $arr[$i]['name'];
	break;


	case "artikelnummerprojekt":
	  $arr = $this->app->DB->SelectArr("SELECT DISTINCT CONCAT(a.nummer,' ',a.name_de,' (',if(a.projekt,(SELECT p.abkuerzung FROM projekt p WHERE p.id=a.projekt),'KEIN PROJEKT' ),if(a.lagerartikel=1,'',''),')') as name FROM artikel a WHERE a.geloescht=0  AND (a.nummer LIKE '%$term%' OR a.name_de LIKE '%$term%')  LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "lagerartikelnummerprojekt":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(a.nummer,' ',a.name_de,' (',p.abkuerzung,')') as name FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.geloescht=0 AND a.porto=0 AND a.firma='".$this->app->User->GetFirma()."' 
	  AND (a.nummer LIKE '%$term%' OR a.name_de LIKE '%$term%') LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;



	case "einkaufartikelnummerprojekt":
	  $adresse = $this->app->Secure->GetGET("adresse");

	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(a.nummer,' ', a.name_de,' | Bezeichnung bei Lieferant ',e.bestellnummer,' ',e.bezeichnunglieferant,' | ',' ab Menge ',e.ab_menge, ' | Preis ',e.preis) as name FROM artikel a 
	    LEFT JOIN projekt p ON p.id=a.projekt LEFT JOIN einkaufspreise e ON e.artikel=a.id WHERE a.geloescht=0 AND a.firma='".$this->app->User->GetFirma()."' AND e.adresse='$adresse' 
	  AND (a.nummer LIKE '%$term%' OR a.name_de LIKE '%$term%') GROUP by a.nummer, e.ab_menge LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;



	case "lieferantname":
	  $arr = $this->app->DB->SelectArr("SELECT name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lieferantennummer!=0 AND name LIKE '%$term%' order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "lieferant":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(lieferantennummer,' ',name) as name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lieferantennummer!=0 AND (name LIKE '%$term%' OR lieferantennummer LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "adresse":
	  $arr = $this->app->DB->SelectArr("SELECT if(lieferantennummer,CONCAT(id,' ',name,' (Kdr: ',kundennummer,' Liefr: ',lieferantennummer,')'),CONCAT(id,' ',name,' (Kdr: ',kundennummer,')')) as name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."'  AND (name LIKE '%$term%' OR kundennummer LIKE '%$term%' OR lieferantennummer LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;


	case "kunde":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(kundennummer,' ',name) as name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND kundennummer!=0 AND (name LIKE '%$term%' OR kundennummer LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "mitarbeiter":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(mitarbeiternummer,' ',name) as name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND mitarbeiternummer!=0 AND (name LIKE '%$term%' OR mitarbeiternummer LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "mitarbeitername":
	  $arr = $this->app->DB->SelectArr("SELECT name FROM adresse WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND mitarbeiternummer!=0 AND (name LIKE '%$term%' OR mitarbeiternummer LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	case "emailname":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(name,' <',email,'>') as name FROM ansprechpartner WHERE (name LIKE '%$term%' OR email LIKE '%$term%') order by name LIMIT 20");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;




	case "shopname":
	  $arr = $this->app->DB->SelectArr("SELECT bezeichnung FROM shopexport WHERE firma='".$this->app->User->GetFirma()."' AND bezeichnung LIKE '%$term%'");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['bezeichnung'];
	break;



	case "projektname":
	  $arr = $this->app->DB->SelectArr("SELECT CONCAT(abkuerzung,' ',name) as name FROM projekt WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND (name LIKE '%$term%' OR abkuerzung LIKE '%$term%')");
	  for($i=0;$i<count($arr);$i++)
	    $newarr[] = $arr[$i]['name'];
	break;

	default: ;
    }


    echo json_encode($newarr);
    exit;
  }

  function AjaxTablePosition()
  {

  $iDisplayStart = $this->app->Secure->GetGET("iDisplayStart");
  $iDisplayLength = $this->app->Secure->GetGET("iDisplayLength");
  $iSortCol_0 = $this->app->Secure->GetGET("iSortCol_0");
  $iSortingCols = $this->app->Secure->GetGET("iSortingCols");
  $sSearch = $this->app->Secure->GetGET("sSearch");
  $sEcho = $this->app->Secure->GetGET("sEcho");
  $cmd = $this->app->Secure->GetGET("cmd");

  $sLimit = "";
  if ( isset($iDisplayStart) )
  {
    $sLimit = "LIMIT ".mysql_real_escape_string( $iDisplayStart ).", ".
      mysql_real_escape_string( $iDisplayLength );
  }
  
  /* Ordering */
  if ( isset( $iSortCol_0 ) )
  {
    $sOrder = "ORDER BY  ";
    for ( $i=0 ; $i<mysql_real_escape_string( $iSortingCols ) ; $i++ )
    {
      $iSortingCols_tmp = $this->app->Secure->GetGET("iSortCol_".$i);
      $sSortDir_tmp = $this->app->Secure->GetGET("sSortDir_".$i);

      $sOrder .= $this->fnColumnToFieldPosition(mysql_real_escape_string( $iSortingCols_tmp ))."
	".mysql_real_escape_string( $sSortDir_tmp ) .", ";
    }
    $sOrder = substr_replace( $sOrder, "", -2 );
  }
  
  /* Filtering - NOTE this does not match the built-in DataTables filtering which does it
   * word by word on any field. It's possible to do here, but concerned about efficiency
   * on very large tables, and MySQL's regex functionality is very limited
   */


  $sWhere = "";
  $where = $this->app->YUI->TablePositionSearch("",$cmd,"where");
  if ( $sSearch != "" )
  {
/*
      $sWhere = "WHERE a.nummer LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ".
		     "p.abkuerzung LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ".
                    "a.name_de LIKE '%".mysql_real_escape_string( $sSearch )."%'";
*/
      $searchsql = $this->app->YUI->TablePositionSearch("",$cmd,"searchsql");

      if($where=="")
	$sWhere = " WHERE (";
      else
      {
	if(count($searchsql) >0)
	  $sWhere = " WHERE $where AND (";
	else
	  $sWhere = " WHERE $where ";
      }

      for($i=0;$i<count($searchsql)-1;$i++)
      {
	$sWhere .= $searchsql[$i]." LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ";	
      }
      $sWhere .= $searchsql[$i]." LIKE '%".mysql_real_escape_string( $sSearch )."%')";	

  } else {
      if($where!="")
	$sWhere = " WHERE $where ";
  } 
  
      $tmp = $this->app->YUI->TablePositionSearch("",$cmd,"sql");
      //$sQuery = $sWhere." ".$sOrder." ". $sLimit;


  $sQuery = "
    $tmp
    $sWhere 
    $sOrder
    $sLimit
  ";
  $rResult = mysql_query( $sQuery);
  
  $sQuery = "
    SELECT FOUND_ROWS()
  ";
  $rResultFilterTotal = mysql_query( $sQuery);
  $aResultFilterTotal = mysql_fetch_array($rResultFilterTotal);
  $iFilteredTotal = $aResultFilterTotal[0];

/*    
  $sQuery = "
    SELECT COUNT(id)
    FROM   artikel
  ";
*/
  $sQuery = $this->app->YUI->TablePositionSearch("",$cmd,"count");
  $rResultTotal = mysql_query( $sQuery);
  $aResultTotal = mysql_fetch_array($rResultTotal);
  $iTotal = $aResultTotal[0];
  
      
  $heading = count($this->app->YUI->TablePositionSearch("",$cmd,"heading"));
  $menu = $this->app->YUI->TablePositionSearch("",$cmd,"menu");

  $sOutput = '{';
  $sOutput .= '"sEcho": '.intval($sEcho).', ';
  $sOutput .= '"iTotalRecords": '.$iTotal.', ';
  $sOutput .= '"iTotalDisplayRecords": '.$iFilteredTotal.', ';
  $sOutput .= '"aaData": [ ';
  while ( $aRow = mysql_fetch_array( $rResult ) )
  {
    $sOutput .= "[";
    for($i=1;$i<$heading;$i++) 
      $sOutput .= '"'.addslashes($aRow[$i]).'",';

    $sOutput .= '"'.addslashes(str_replace('%value%',$aRow[$i],$menu)).'"';

    $sOutput .= "],";

  }
  $sOutput = substr_replace( $sOutput, "", -1 );
  $sOutput .= '] }';
  
  echo $sOutput;
exit;
  
  }

  function AjaxTable()
  {
  $iDisplayStart = $this->app->Secure->GetGET("iDisplayStart");
  $iDisplayLength = $this->app->Secure->GetGET("iDisplayLength");
  $iSortCol_0 = $this->app->Secure->GetGET("iSortCol_0");
  $iSortingCols = $this->app->Secure->GetGET("iSortingCols");
  $sSearch = $this->app->Secure->GetGET("sSearch");
  $sEcho = $this->app->Secure->GetGET("sEcho");
  $cmd = $this->app->Secure->GetGET("cmd");

  $sSearch = trim($sSearch);

  $sLimit = "";
  if ( isset($iDisplayStart) )
  {
    $sLimit = "LIMIT ".mysql_real_escape_string( $iDisplayStart ).", ".
      mysql_real_escape_string( $iDisplayLength );
  }
  /* Ordering */
  if ( isset( $iSortCol_0 ) )
  {
    $sOrder = "ORDER BY  ";
    for ( $i=0 ; $i<mysql_real_escape_string( $iSortingCols ) ; $i++ )
    {
      $iSortingCols_tmp = $this->app->Secure->GetGET("iSortCol_".$i);
      $sSortDir_tmp = $this->app->Secure->GetGET("sSortDir_".$i);

      $sOrder .= $this->fnColumnToField(mysql_real_escape_string( $iSortingCols_tmp ))."
	".mysql_real_escape_string( $sSortDir_tmp ) .", ";
    }
    $sOrder = substr_replace( $sOrder, "", -2 );
  }

 else {
    //standard einstellung nach datum absteigend wenn datumsspalte vorhanden
    $defaultorder = $this->app->YUI->TableSearch("",$cmd,"defaultorder");
    $defaultorderdesc = $this->app->YUI->TableSearch("",$cmd,"defaultorderdesc");
		
		if($defaultorderdesc=="1") $defaultorderdesc = " DESC"; else $defaultorderdesc="";

    if($defaultorder >=0 && is_numeric($defaultorder))
      $sOrder = "ORDER BY $defaultorder $defaultorderdesc";
    //$cmd = $this->app->Secure->GetGET("cmd");
    //if($cmd=="auftraege")
    //  $sOrder = " ORDER BY 1,2 ";
    //$findcolstmp = $this->app->YUI->TableSearch("",$cmd,"findcols");
    //if (in_array("vom", $findcolstmp)) {
    //  $sOrder = "ORDER BY vom DESC";
  //  }

  }



  
  /* Filtering - NOTE this does not match the built-in DataTables filtering which does it
   * word by word on any field. It's possible to do here, but concerned about efficiency
   * on very large tables, and MySQL's regex functionality is very limited
   */
	//echo "FUUUU";

  $sWhere = "";
  $where = $this->app->YUI->TableSearch("",$cmd,"where");
	//echo $where;
  if ( $sSearch != "" )
  {
/*
      $sWhere = "WHERE a.nummer LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ".
		     "p.abkuerzung LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ".
                    "a.name_de LIKE '%".mysql_real_escape_string( $sSearch )."%'";
*/
      $searchsql = $this->app->YUI->TableSearch("",$cmd,"searchsql");

      if($where=="")
	$sWhere = " WHERE (";
      else
      {
	if(count($searchsql) >0)
	  $sWhere = " WHERE $where AND (";
	else
	  $sWhere = " WHERE $where ";
      }

      for($i=0;$i<count($searchsql)-1;$i++)
      {
	$sWhere .= $searchsql[$i]." LIKE '%".mysql_real_escape_string( $sSearch )."%' OR ";	
      }
      $sWhere .= $searchsql[$i]." LIKE '%".mysql_real_escape_string( $sSearch )."%')";	

  } else {
      if($where!="")
	$sWhere = " WHERE $where ";
  } 
  
      $tmp = $this->app->YUI->TableSearch("",$cmd,"sql");
      //$sQuery = $sWhere." ".$sOrder." ". $sLimit;



  $sQuery = "
    $tmp
    $sWhere 
    $sOrder
    $sLimit
  ";

	// TABLEOUT
	//echo $sQuery;

  $rResult = mysql_query( $sQuery);
  
  $sQuery = "
    SELECT FOUND_ROWS()
  ";
  $rResultFilterTotal = mysql_query( $sQuery);
  $aResultFilterTotal = mysql_fetch_array($rResultFilterTotal);
  $iFilteredTotal = $aResultFilterTotal[0];

/*    
  $sQuery = "
    SELECT COUNT(id)
    FROM   artikel
  ";
*/
  $sQuery = $this->app->YUI->TableSearch("",$cmd,"count");
  $rResultTotal = mysql_query( $sQuery);
  $aResultTotal = mysql_fetch_array($rResultTotal);
  $iTotal = $aResultTotal[0];
  
      
  $heading = count($this->app->YUI->TableSearch("",$cmd,"heading"));
  $menu = $this->app->YUI->TableSearch("",$cmd,"menu");

  $sOutput = '{';
  $sOutput .= '"sEcho": '.intval($sEcho).', ';
  $sOutput .= '"iTotalRecords": '.$iTotal.', ';
  $sOutput .= '"iTotalDisplayRecords": '.$iFilteredTotal.', ';
  $sOutput .= '"aaData": [ ';
  while ( $aRow = mysql_fetch_array( $rResult ) )
  {
    $sOutput .= "[";
    for($i=1;$i<$heading;$i++) 
    {
      $aRow[$i] = trim(str_replace("'","",$aRow[$i]));
      $sOutput .= '"'.addslashes($aRow[$i]).'",';
    }

    $sOutput .= '"'.addslashes(str_replace('%value%',$aRow[$i],$menu)).'"';

    $sOutput .= "],";

  }
  $sOutput = substr_replace( $sOutput, "", -1 );
  $sOutput .= '] }';
  
  echo $sOutput;
exit;
  
  }
   
  function fnColumnToFieldPosition( $i )
  {
    $cmd = $this->app->Secure->GetGET("cmd");
    $findcols = $this->app->YUI->TablePositionSearch("",$cmd,"findcols");

    return $findcols[$i];
  }

  function fnColumnToField( $i )
  {
    $cmd = $this->app->Secure->GetGET("cmd");
    $findcols = $this->app->YUI->TableSearch("",$cmd,"findcols");

    return $findcols[$i];

    if ( $i == 0 )
      return "nummer";
    else if ( $i == 1 )
      return "name_de";
    else if ( $i == 2 )
      return "projekt";
    else if ( $i == 3 )
      return "id";

  }




}

?>
