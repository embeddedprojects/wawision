<?php
class Welcome 
{

  function Welcome(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("login","WelcomeLogin");
    $this->app->ActionHandler("main","WelcomeMain");
    $this->app->ActionHandler("list","TermineList");
    $this->app->ActionHandler("help","WelcomeHelp");
    $this->app->ActionHandler("info","WelcomeInfo");
    $this->app->ActionHandler("vorgang","VorgangAnlegen");
    $this->app->ActionHandler("removevorgang","VorgangEntfernen");
    $this->app->ActionHandler("editvorgang","VorgangEdit");
    $this->app->ActionHandler("logout","WelcomeLogout");
    $this->app->ActionHandler("start","WelcomeStart");

    $this->app->DefaultActionHandler("login");
    
    $this->app->ActionHandlerListen($app);
  }


  function WelcomeStart()
  {
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Ihre Startseite");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT2,"[BENUTZER]");
    $this->app->erp->MenuEintrag("index.php?module=aufgaben&action=list","Aufgaben");
    $this->app->erp->MenuEintrag("index.php?module=kalender&action=list","Kalender");
    $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=create","Zeiterfassung");
    $this->app->Tpl->Set(TABTEXT,"Ihre Startseite");

		$module = $this->app->Secure->GetGET("module");

		//$this->Termine("TERMINE");
		//$this->Aufgaben("AUFGABEN");

    //fenster rechts offene vorgaenge ***
    $this->app->Tpl->Set(SUBSUBHEADING,"Vorg&auml;nge");
    $arrVorgaenge = $this->app->DB->SelectArr("SELECT * FROM offenevorgaenge WHERE adresse='{$this->app->User->GetAdresse()}' ORDER by id DESC");
    $this->app->Tpl->Set(INHALT,"");
//    $this->app->Tpl->Set(VORGAENGELINK,"<a href=\"#\" onclick=\"var ergebnistext=prompt('Offener Vorgang:','".ucfirst($module)."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=vorgang&titel='+ergebnistext;\">Aktuelle Stelle merken</a>");
    if(count($arrVorgaenge) > 0)
    {
      for($i=0;$i<count($arrVorgaenge);$i++)
      {

  $this->app->Tpl->Add(VORGAENGE,"<tr><td>".substr(ucfirst($arrVorgaenge[$i]['titel']),0,100)."</td><td align=\"right\"><img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"7\" border=\"0\" align=\"right\">
  <a href=\"index.php?".$arrVorgaenge[$i]['href']."\"><img src=\"./themes/[THEME]/images/right.png\" border=\"0\" align=\"right\" title=\"Erledigen\"></a>&nbsp;
  <a href=\"index.php?module=welcome&action=removevorgang&vorgang={$arrVorgaenge[$i]['id']}\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\" align=\"right\" title=\"Erledigt\"></a>&nbsp;
<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"3\" border=\"0\" align=\"right\">
<a href=\"javascript: var ergebnistext=prompt('Offenen Vorgang umbenennen:','".ucfirst($arrVorgaenge[$i]['titel'])."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=editvorgang&vorgang={$arrVorgaenge[$i]['id']}&titel='+ergebnistext;\"><img src=\"./themes/[THEME]/images/edit.png\" alt=\"Bearbeiten\" title=\"Bearbeiten\" border=\"0\" align=\"right\"></a></td></tr>");

      }
    }


    $this->app->Tpl->Parse(STARTSEITE,"lesezeichen.tpl");

		$this->app->Tpl->Set('TERMINE', $this->Termine($this->app->DB->Select("SELECT CURDATE();")));
		$this->app->Tpl->Set('TERMINEMORGEN', $this->Termine($this->app->DB->Select("SELECT DATE_ADD(CURDATE(), INTERVAL 1 DAY);")));


		// Wiki-Einträge
		//$data = $this->app->DB->SelectArr("SELECT * FROM accordion ORDER BY position");
	

		$this->app->Tpl->Set(USERNAME,$this->app->User->GetName());
		
		$tmp = $this->app->DB->SelectArr("SELECT * FROM aufgabe WHERE adresse='".$this->app->User->GetAdresse()."' AND startseite='1' AND status='offen' ORDER by prio DESC");
		//TODOFORUSER

		for($i=0;$i<count($tmp);$i++)
		{
				$name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='".$tmp[$i]['initiator']."' LIMIT 1");
				$high="";
				if($tmp[$i]['initiator']!=$tmp[$i]['adresse']) $additional = "<br><font style=\"font-size:8pt\">von ".$name."</font>"; else $additional="";


				if($tmp[$i]['prio']=="1") { $class="noteit_highprio"; $high="&nbsp;(Prio)"; }
				else $class="noteit";


				$this->app->Tpl->Add(TODOFORUSER,"<div class=\"$class\">".$tmp[$i]['aufgabe'].$additional."$high</div>");
		}

		if($i<=0)
				$this->app->Tpl->Add(TODOFORUSER,"Keine Aufgaben f&uuml;r Startseite");

		$tmp = $this->app->DB->SelectArr("SELECT * FROM aufgabe WHERE initiator='".$this->app->User->GetAdresse()."' AND adresse!='".$this->app->User->GetAdresse()."' AND startseite='1' AND status='offen' ORDER by prio DESC");

		for($i=0;$i<count($tmp);$i++)
		{
				$name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='".$tmp[$i]['adresse']."' LIMIT 1");
				$high="";
				if($tmp[$i]['prio']=="1") { $class="noteit_highprio"; $high="&nbsp;(Prio)"; }
				else $class="noteit";


				$this->app->Tpl->Add(TODOFORMITARBEITER,"<div class=\"$class\">".$tmp[$i]['aufgabe']."$high<br><font style=\"font-size:8pt\">f&uuml;&nbsp;".$name."</font></div>");
		}
		if($i<=0)
				$this->app->Tpl->Add(TODOFORMITARBEITER,"Keine Aufgaben f&uuml;r Startseite");



		$this->app->Tpl->Set('ACCORDION', $this->Accordion());
    $this->app->Tpl->Parse(TAB1,"startseite.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

	function Accordion()
	{
		// check if accordion is empty

		$data = $this->app->DB->SelectArr("SELECT * FROM accordion ORDER BY position");
		
		if(count($data)<=0)
		{
			$this->app->DB->Insert("INSERT INTO accordion (id,name,target,position) VALUES ('','Startseite','StartseiteWiki','1')");

			$check_startseite = $this->app->DB->Select("SELECT name FROM wiki WHERE name='StartseiteWiki' LIMIT 1");
			if($check_startseite == "")
			{
				$this->app->DB->Insert("INSERT INTO wiki (id,name,content) VALUES ('','StartseiteWiki','=waWision - webbasierte Warenwirtschaft und mehr=

Herzlich Willkommen in Ihrem waWision,

wir freuen uns Sie als waWision Benutzer begrüßen zu dürfen. Mit waWision organisieren Sie Ihre Firma schnell und einfach. Sie haben alle wichtigen Zahlen und Vorgänge im Überblick.

Für Einsteiger sind die folgenden Thema wichtig:

* [index.php?module=firmendaten&action=edit Firmendaten] (dort richten Sie Ihr Briefpapier ein)
* [index.php?module=adresse&action=list Stammdaten / Adressen] (Kunden und Lieferanten angelen)
* [index.php?module=artikel&action=list Artikel anlegen] (Ihr Artikelstamm)
* [index.php?module=angebot&action=list Angebot] / [index.php?module=auftrag&action=list Auftrag] (Alle Dokumente für Ihr Geschäft)
* [index.php?module=rechnung&action=list Rechnung] / [index.php?module=gutschrift&action=list Gutschrift]
* [index.php?module=lieferschein&action=list Lieferschein]


Kennen Sie unsere Zusatzmodule die Struktur und Organisation in das tägliche Geschäft bringen?

* [index.php?module=kalender&action=list Kalender]
* [index.php?module=wiki&action=list Wiki]
')");
			}
			$data = $this->app->DB->SelectArr("SELECT * FROM accordion ORDER BY position");
		}

		
		$out = '';
		for($i=0;$i<count($data);$i++) 
		{
			$entry = '';
			$edit = '';
			if($data[$i]['target']!='') {
				$edit = "<a id=\"wiki_startseite_edit\" href=\"index.php?module=wiki&action=edit&name={$data[$i]['target']}\">Seite editieren</a>";

				$wikipage_exists = $this->app->DB->Select("SELECT '1' FROM wiki WHERE name='{$data[$i]['target']}' LIMIT 1");
				if($wikipage_exists!='1')
					$this->app->DB->Insert("INSERT INTO wiki (name) VALUES ('{$data[$i]['target']}')");
				$wikipage_content = $this->app->DB->Select("SELECT content FROM wiki WHERE name='{$data[$i]['target']}' LIMIT 1");

				$wikiparser = new WikiParser();
    		$content = $wikiparser->parse($wikipage_content);

				$this->app->Tpl->Set('ACCORDIONENTRY'.$i, $content);
				$entry = "[ACCORDIONENTRY$i]";
			}	
			$out .= "<h3><a href=\"#\">{$data[$i]['name']}</a></h3>
							 <div><div class=\"wiki\">$edit<br/>$entry</div></div>";
		}
		return $out;
	}
	

	function Termine($date)
	{
		$userid = $this->app->User->GetID();

		if(is_numeric($userid)) {
			$termine = $this->app->DB->SelectArr("SELECT * FROM kalender_user AS ka
																						RIGHT JOIN kalender_event AS ke ON ka.event=ke.id
																						WHERE (ka.userid='$userid' OR ke.public='1') AND DATE(von)='$date'
																						ORDER BY von");
			$out = '';
			foreach($termine AS $t) {
				$von = date('G:i', strtotime($t['von']));
				$bis = date('G:i', strtotime($t['bis']));

				if($t['allDay']=='1') {
					$von = 'Ganztags';
					$bis = '';
				}else {
					if($von==$bis)
						$bis = '';
					else if($von < $bis)
						$bis = '- '.$bis;
				}
				
				$color = (($t['color']!='') ? "style='background-color: {$t['color']};border-color: {$t['color']};'" : '');

				$out .= "<li $color><span class=\"description\">{$t['bezeichnung']}</span><span style=\"float:right\">$von $bis</span></li>";
			}
	
			if(count($termine)==0) $out = 'Keine Termine vorhanden';

			return $out;
		}
	}



	function Aufgaben($parse)
	{
		$userid = $this->app->User->GetAdresse();

    if(is_numeric($userid))
    {


		}

	}

  function WelcomeHelp()
  {
  }

  function WelcomeInfo()
  {

    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Informationen zur Software");

    $this->app->Tpl->Set(TABTEXT,"Informationen zur Software");
		
    if($this->app->erp->Version()=="com")
		{
			$this->app->Tpl->Set(TAB1,"Sie benutzen die kommerzielle Version von waWision. Alle Rechte vorbehalten. Beachten Sie die Nutzungsbedinungen.<br><br>&copy; Copyright by embedded projects GmbH Augsburg");
		}
		else {
    $this->app->Tpl->Set(TAB1,"Sie benutzen die Open-Source Version von waWision. Die Software steht unter der GNU/AGPL.<br><br><div class=\"info\">Das Logo und der Link zur Homepage <a href=\"http://www.wawision.de\" target=\"_blank\">http://www.wawision.de</a> d&uuml;rfen
    nicht entfernt werden.</div><br>&copy; Copyright by embedded projects GmbH Augsburg");
		}
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }


  function WelcomeMenu()
  {

/*	
    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE1]\">Stammdaten</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=list\">Adresse</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=artikel&action=list\">Artikel</a></li>");


    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE2]\">Verkauf & Einkauf</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=angebot&action=list\">Angebote</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=auftrag&action=list\">Auftr&auml;ge</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=lieferschein&action=list\">Lieferscheine</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=rechnung&action=list\">Rechnungen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=gutschrift&action=list\">Gutschrift</a></li>");
    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE3]\">Versand & Logistik</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=ticket&action=list\">Tickets</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=versanderzeugen&action=offene\">Versand starten</a></li>");
    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE4]\">Buchhaltung</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=zahlungseingang&action=list\">Zahlungseingang</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=rechnung&action=mahnwesen\">Mahnwesen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE5]\">Einstellungen</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=einstellungen&action=list\">Allgemein</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=einstellungen&action=firma\">Firma</a></li>");
    
    $this->app->erp->MenuEintrag("index.php?module=lager&action=list","zur&uuml;ck zur &Uuml;bersicht");
    
*/
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"<h2>Startseite</h2>");

  }


  function WelcomeMain()
  {

    $this->app->Tpl->Set(UEBERSCHRIFT,"Herzlich Willkommen ".$this->app->User->GetDescription()."!");
    $this->WelcomeMenu();

    // muss jeder sehen
    $this->app->erp->LagerAusgehend(ARTIKEL);

    if($this->app->User->GetType()=="admin")
    {
    /*
 $table = new EasyTable($this->app);
    $table->Query("SELECT a.name, betrag, rechnung, DATE_FORMAT(zahlbarbis,'%d.%m.%Y') as bis,skonto, DATE_FORMAT(skontobis,'%d.%m.%Y') as skonbis, verbindlichkeit.id FROM verbindlichkeit, adresse a WHERE verbindlichkeit.adresse = a.id AND verbindlichkeit.bezahlt!=1 
      AND zahlbarbis <= NOW() AND freigabe=1 AND status!='bezahlt' OR (verbindlichkeit.skontobis!=0 AND verbindlichkeit.skonto > 0 AND verbindlichkeit.adresse = a.id AND status!='bezahlt')  order by zahlbarbis");
    $table->Display(VERBINDLICHKEITEN);
*/
/*
    //TICKETS
    $table->Query("SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y %H:%i') as empfang, CONCAT(LEFT(tn.betreff,30),'...') as betreff,t.warteschlange, 
      CONCAT('<font color=\"red\"><b>',TIMEDIFF(NOW(),tn.zeit),'</b></font>') as wartezeit, 
      tn.id FROM ticket t LEFT JOIN ticket_nachricht tn ON tn.ticket=t.schluessel WHERE tn.status!='beantwortet' AND tn.status!='spam' AND t.inbearbeitung=0 order by tn.zeit ASC");

    $table->DisplayNew(TICKETS,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\"><img src=\"./themes/[THEME]/images/arrow.png\" width=\"20\" border=\"0\"></a>");
*/
/*
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.name, betrag, rechnung, DATE_FORMAT(zahlbarbis,'%d.%m.%Y') as bis,skonto, DATE_FORMAT(skontobis,'%d.%m.%Y') as skonbis, verbindlichkeit.id FROM verbindlichkeit, adresse a WHERE verbindlichkeit.adresse = a.id AND verbindlichkeit.bezahlt!=1 
      AND zahlbarbis <= NOW() AND freigabe=1 AND status!='bezahlt' OR (verbindlichkeit.skontobis!=0 AND verbindlichkeit.skonto > 0 AND verbindlichkeit.adresse = a.id AND status!='bezahlt')  order by zahlbarbis");
    $table->Display(VERBINDLICHKEITEN);


    $table->Query("SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y %H:%i') as empfang, CONCAT(LEFT(tn.betreff,30),'...') as betreff,t.warteschlange, 
      CONCAT('<font color=\"red\"><b>',TIMEDIFF(NOW(),tn.zeit),'</b></font>') as wartezeit, 
      tn.id FROM ticket t LEFT JOIN ticket_nachricht tn ON tn.ticket=t.schluessel WHERE tn.status!='beantwortet' AND tn.status!='spam' AND t.inbearbeitung=0 order by tn.zeit ASC");
*/
   // $table->DisplayNew(TICKETS,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\"><img src=\"./themes/[THEME]/images/arrow.png\" width=\"20\" border=\"0\"></a>");



/*
    $this->app->Tpl->Set(SUBHEADING,"Termine Heute");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT '23.11.2009' as datum, '15:00' as zeit, aufgabe,id FROM aufgabe LIMIT 3,3");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(TERMINE,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"Aufgaben Heute");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT '23.11.2009' as datum, '15:00' as zeit, aufgabe,id FROM aufgabe LIMIT 3");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(AUFGABEN,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"Wichtige Tickets zum Beantworten");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);

    $key = 'technik';
    $table->Query("SELECT DATE_FORMAT(t.zeit,'%d.%m.%Y') as zeit, t.prio, t.betreff, t.kunde, 
        CONCAT('<font color=\"red\"><b>',TIMEDIFF(NOW(),t.zeit),'</b></font>') as wartezeit, 
        t.id FROM ticket as t, ticket_nachricht as tn WHERE t.schluessel=tn.ticket AND tn.status!='beantwortet' AND t.zugewiesen=1 
	AND (t.warteschlange='$key')
        AND inbearbeitung!='1'
        ORDER by t.prio, tn.zeit");

    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(TICKETS,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"offene Arbeitspakete");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT '23.11.2009' as datum, '15:00' as zeit, ticket,id FROM ticket LIMIT 3");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(ARBEITSPAKETE,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"Bitte freigeben durch ".$this->app->User->GetDescription());
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT '23.11.2009' as datum, '15:00' as zeit, ticket,id FROM ticket LIMIT 3");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(FREIGABEN,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");


    $this->app->Tpl->Set(SUBHEADING,"offene Ausgaben");
    $this->app->Tpl->Set(INHALT,"Tabelle ");
    $this->app->Tpl->Parse(AUSGABEN,"rahmen.tpl");

    $this->app->Tpl->Set(SUBHEADING,"");

*/
    //$this->app->Tpl->Parse(STAT,"welcome_stat.tpl");
 //   $this->app->YUI->ChartAdd("#4040FF",array(5, 10, 20, 10, 40, 52, 68, 70, 30, 20));
 //   $this->app->YUI->ChartAdd("red",array(12, 20, 10, 60, 70, 82, 28, 70, 30, 20));
 //   $this->app->YUI->Chart(STAT,array('ab', 'cd', 'wed', 'thu', 'fri', 'sat', 'sun', 'mon', 'tue', 'wed'));
  

    }
    $this->app->Tpl->Parse(PAGE,"welcome_main.tpl");
    //$this->app->BuildNavigation=false;
    //$this->app->Tpl->Parse(PAGE,"welcome_stat.tpl");


  }



  function WelcomeLogin()
  {
    if($this->app->User->GetID()!="")
      {
      //$this->WelcomeMain();
			header("Location: index.php?module=welcome&action=start\r\n");
//<a href=\"index.php?module=welcome&action=start\">HUHU</a>";
			exit;
      }
    else
      {
	//pruefe ob es bereits daten gibt
	if($this->app->DB->Select("SELECT COUNT(id) FROM adresse")<=0)
	{
	  $sql = 'INSERT INTO `wawision`.`adresse` (`id`, `typ`, `marketingsperre`, `trackingsperre`, `rechnungsadresse`, `sprache`, `name`, `abteilung`, `unterabteilung`, `ansprechpartner`, `land`, `strasse`, `ort`, `plz`, `telefon`, `telefax`, `mobil`, `email`, `ustid`, `ust_befreit`, `passwort_gesendet`, `sonstiges`, `adresszusatz`, `kundenfreigabe`, `steuer`, `logdatei`, `kundennummer`, `lieferantennummer`, `mitarbeiternummer`, `konto`, `blz`, `bank`, `inhaber`, `swift`, `iban`, `waehrung`, `paypal`, `paypalinhaber`, `paypalwaehrung`, `projekt`, `partner`, `geloescht`, `firma`) VALUES (NULL, \'\', \'\', \'\', \'\', \'\', \'Administrator\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', NOW(), \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'1\', \'\', \'\', \'1\');';
	  $this->app->DB->InsertWithoutLog($sql);

	  $sql = 'INSERT INTO `wawision`.`firma` (`id`, `name`, `standardprojekt`) VALUES (NULL, \'Musterfirma\', \'1\');';
	  $this->app->DB->InsertWithoutLog($sql);

	  $sql = 'INSERT INTO `wawision`.`user` (`id`, `username`, `password`, `repassword`, `description`, `settings`, `parentuser`, `activ`, `type`, `adresse`, `standarddrucker`, `firma`, `logdatei`) VALUES (NULL, \'admin\', ENCRYPT(\'admin\'), \'\', NULL, \'\', NULL, \'1\', \'admin\', \'1\', \'\', \'1\', NOW());';
	  $this->app->DB->InsertWithoutLog($sql);


	  $sql = 'INSERT INTO `wawision`.`projekt` (`id`, `name`, `abkuerzung`, `verantwortlicher`, `beschreibung`, `sonstiges`, `aktiv`, `farbe`, `autoversand`, `checkok`, `checkname`, `zahlungserinnerung`, `zahlungsmailbedinungen`, `folgebestaetigung`, `kundenfreigabe_loeschen`, `autobestellung`, `firma`, `logdatei`) VALUES (NULL, \'Hauptprojekt\', \'HAUPTPROJEKT\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'1\', \'\');';
	  $this->app->DB->InsertWithoutLog($sql);
      } 
      $this->app->Tpl->Set(UEBERSCHRIFT,"wawision &middot; Enterprise Warehouse Management");
      $this->app->acl->Login();
      }
  }

  function WelcomeLogout()
  {
    $this->app->acl->Logout();
    //$this->app->WF->ReBuildPageFrame();
    //$this->WelcomeMain();
  }

  function VorgangAnlegen()
  {
    //print_r($_SERVER['HTTP_REFERER']);
    $titel = $this->app->Secure->GetGET("titel");

    $url = parse_url($_SERVER['HTTP_REFERER']);
    //$url = parse_url("http://dev.eproo.de/~sauterbe/eprooSystem-2009-11-21/webroot/index.php?module=ticket&action=edit&id=1");

    //module=ticket&action=edit&id=1
    //$url['query']
    $params = split("&",$url['query']);
    foreach($params as $value){
      $attribut = split("=",$value);
      $arrPara[$attribut[0]] = $attribut[1];
    }

    $adresse = $this->app->User->GetAdresse();
    if($titel=="")
    $titel = ucfirst($arrPara['module'])." ".$arrPara['id'];
    $href = $url['query'];
    $this->app->erp->AddOffenenVorgang($adresse, $titel, $href);

    header("Location: ".$_SERVER['HTTP_REFERER']);
  }


  function VorgangEdit()
  {
    $vorgang = $this->app->Secure->GetGET("vorgang");
    $titel = $this->app->Secure->GetGET("titel");
    $this->app->erp->RenameOffenenVorgangID($vorgang,$titel);
    header("Location: ".$_SERVER['HTTP_REFERER']);
    exit;
  } 

  function VorgangEntfernen()
  {
    $vorgang = $this->app->Secure->GetGET("vorgang");
    $this->app->erp->RemoveOffenenVorgangID($vorgang);
    header("Location: ".$_SERVER['HTTP_REFERER']);
    exit;
  } 


}
?>
