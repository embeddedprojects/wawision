<?php

class Shopimport 
{

  function Shopimport(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("login","ShopimportLogin");
    $this->app->ActionHandler("main","ShopimportMain");
    $this->app->ActionHandler("list","ShopimportList");
    $this->app->ActionHandler("alle","ShopimportAlle");
    $this->app->ActionHandler("import","ShopimportImport");
    $this->app->ActionHandler("navigation","ShopimportNavigation");
    $this->app->ActionHandler("logout","ShopimportLogout");
    $this->app->ActionHandler("archiv","ShopimportArchiv");
  
    $this->app->DefaultActionHandler("list");


    $this->app->Tpl->Set(UEBERSCHRIFT,"Shop Import");
    $this->app->ActionHandlerListen($app);
  }

  function ShopimportList()
  {
    //$this->app->Tpl->Add(TABS,"<li><h2 style=\"background-color: [FARBE5];\">Shopimport</h2></li>");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Shopimport");
    $this->app->erp->MenuEintrag("index.php?module=shopimport&action=alle","Alle importieren");
    //$this->app->Tpl->Set(SUBHEADING,"Imports");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT ae.bezeichnung,p.abkuerzung, 
      ae.id FROM shopexport ae LEFT JOIN projekt p ON p.id=ae.projekt");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=shopimport&action=import&id=%value%\">Import</a>&nbsp;<a href=\"index.php?module=shopimport&action=archiv&id=%value%\">Archiv</a>");
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"");
    $this->app->Tpl->Parse(PAGE,"shopexportuebersicht.tpl");
  }


	function ShopimportArchiv()
	{
    $id = $this->app->Secure->GetGET("id");
    $more = $this->app->Secure->GetGET("more");
    $datum = $this->app->Secure->GetGET("datum");
	
    $this->app->Tpl->Set(TABTEXT,"Shopimport - Archiv");

		
		//$this->app->YUI->TableSearch(TAB1,"shopimportarchiv");

    //$this->app->Tpl->Set(TAB1,"Shopimport - Archiv");

		if($datum=="") $datum = date('Y-m-d');

		$result = $this->app->DB->SelectArr("SELECT * FROM shopimport_auftraege WHERE DATE_FORMAT(logdatei,'%Y-%m-%d') = '$datum'");


		$table = "<table border=\"1\" width=\"100%\">";

		if(is_array($result))
		{
			foreach($result as $key=>$row)
			{
					//$table = $row['imported'];
					$warenkorb = unserialize(base64_decode($row['warenkorb']));


					$table .= "<tr><td>".$warenkorb["onlinebestellnummer"]."</td><td>".$warenkorb["name"]."</td><td>".$warenkorb["email"]."</td><td>".$warenkorb["gesamtsumme"]."</td><td>
						<a href=\"index.php?module=shopimport&action=archiv&id=$id&more=".$row['id']."&datum=$datum\">mehr Informationen</a></td></tr>";

			}	
		}

		$table .= "</table>";

		if($more > 0)
		{
			$result = $this->app->DB->Select("SELECT warenkorb FROM shopimport_auftraege WHERE id='$more' LIMIT 1");

			$warenkorb = unserialize(base64_decode($result));

			ob_start();
			var_dump($warenkorb);
			$var_dump_result = ob_get_clean();

			$table .="<pre>".$var_dump_result."</pre>";

			

		}


		
    $this->app->Tpl->Set(TAB1,$table);

		


    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
	}


  function ShopimportAlle()
  {

    $shops = $this->app->DB->SelectArr("SELECT ae.id as id FROM shopexport ae LEFT JOIN projekt p ON p.id=ae.projekt");

    for($i=0;$i<count($shops)-1;$i++)
    {
      $this->ShopimportImport($shops[$i]['id']);
    }

    $lastshop=$shops[$i]['id'];
    if(is_numeric($lastshop))
      header("Location: index.php?module=shopimport&action=import&id=$lastshop");
    else
      header("Location: index.php?module=shopimport&action=list");
    exit;
  }
  


  function ShopimportImport($id="")
  {
    if(!is_numeric($id))
      $id = $this->app->Secure->GetGET("id");
    $projekt = $this->app->DB->Select("SELECT projekt FROM shopexport WHERE id='$id'");

    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Shopimport");
    $this->app->erp->MenuEintrag("index.php?module=shopimport&action=list","Zur&uuml;ck zur &Uuml;bersicht");


    //name, strasse, ort, plz und kundenummer, emailadresse  oder bestellung kam von login account ==> Kunde aus DB verwenden
   
    //ACHTUNG Lieferadresse immer aus Auftrag!!! aber Lieferadresse extra bei Kunden anlegen 
    if($this->app->Secure->GetPOST("submit")!="")
    {
      $auftraege = $this->app->Secure->GetPOST("auftrag");
      $kundennummer = $this->app->Secure->GetPOST("kundennummer");
      $import= $this->app->Secure->GetPOST("import");
      for($i=0;$i<count($auftraege);$i++)
      {
	$shopimportid =  $auftraege[$i];

	if($import[$shopimportid]=="warten")
        {

        }
	else if($import[$shopimportid]=="muell")
	{
	  $this->app->DB->Update("UPDATE shopimport_auftraege SET trash='1' WHERE id='$shopimportid' LIMIT 1");
	} else {


	  $arr = $this->app->DB->SelectArr("SELECT * FROM shopimport_auftraege WHERE imported='0' AND trash='0' AND id='$shopimportid' LIMIT 1");
	  $warenkorb = unserialize(base64_decode($arr[0][warenkorb]));

		// alle leerzeichen am amfang und ende entfernen + umbrueche komplett entfernen
		$warenkorb = $this->app->erp->CleanDataBeforImport($warenkorb);


	  $projekt = $arr[0][projekt];

	  if($warenkorb[name]!="" && $warenkorb[ort]!="")
	  {

	    if($kundennummer[$shopimportid]=="1")
	    { // rot
	      //echo "import auf Kunde $shopimportid<br>";
              $validkundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE kundennummer='".$warenkorb[kundennummer]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
              if($validkundennummer==$warenkorb[kundennummer])
              {
	        $adresse = $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='{$warenkorb[kundennummer]}' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
              }
              else {  // blau
              $warenkorb[kundennummer] = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE name='".$warenkorb[name]."' 
                AND strasse='".$warenkorb[strasse]."' AND plz='".$warenkorb[plz]."' AND ort='".$warenkorb[ort]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	        $adresse = $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='{$warenkorb[kundennummer]}' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
              }
	    } 
            else {
	      //echo "import als Neu-Kunde $shopimportid<br>";
	      $typ = $warenkorb[adresse];
	      $name= $warenkorb[name];
	      $abteilung = $warenkorb[abteilung];
	      $unterabteilung = $warenkorb[unterabteilung];
	      $ansprechpartner = $warenkorb[ansprechpartner];
	      $adresszusatz = $warenkorb[adresszusatz];
	      $strasse = $warenkorb[strasse];
	      $land = $warenkorb[land];
	      $plz = $warenkorb[plz];
	      $ort = $warenkorb[ort];
	      $email = $warenkorb[email];
	      $telefon = $warenkorb[telefon];
	      $telefax = $warenkorb[telefax];
	      $ustid = $warenkorb[ustid];
	      $partner = $warenkorb[affiliate_ref];


              // denn fall das es kunde 1:1 schon gibt = alte Kundennummer verwenden kommt vor allem vor, wenn ein Kunde an einem Tag oefters bestellt hat

	      $adresse = $this->app->erp->KundeAnlegen($typ,$name,$abteilung,$unterabteilung,$ansprechpartner,$adresszusatz,$strasse,$land,$plz,$ort,$email,$telefon,$telefax,$ustid,$partner,$projekt);

				// abweichende lieferadresse gleich angelegen?

				if(strlen($warenkorb[lieferadresse_ansprechpartner])>3)
				{
					$this->app->DB->Insert("INSERT INTO lieferadressen (typ,name,abteilung,unterabteilung,land,strasse,ort,plz,adresszusatz,adresse) VALUES
					('','{$warenkorb[lieferadresse_ansprechpartner]}','{$warenkorb[lieferadresse_abteilung]}','{$warenkorb[lieferadresse_unterabteilung]}','{$warenkorb[lieferadresse_land]}',
					'{$warenkorb[lieferadresse_strasse]}','{$warenkorb[lieferadresse_ort]}','{$warenkorb[lieferadresse_plz]}','{$warenkorb[lieferadresse_adresszusatz]}','$adresse')");
				}


	    }

	    //imort auf kunde 
	    $this->app->erp->ImportAuftrag($adresse,$warenkorb,$projekt);
	    $this->app->DB->Update("UPDATE shopimport_auftraege SET imported='1' WHERE id='$shopimportid' LIMIT 1");
            
	  }
	}
      }
    }

    

    $pageContents = $this->app->remote->RemoteConnection($id);
    if($pageContents=="success")
    {
      //$anzahl = $this->app->remote->RemoteSendArtikelgruppen($id);
      //$anzahl = $this->app->remote->RemoteSendNavigation($id);
       $gesamtanzahl = $this->app->remote->RemoteGetAuftraegeAnzahl($id);

      for($i=0;$i<$gesamtanzahl;$i++)
      {
	//import au
	$result = $this->app->remote->RemoteGetAuftrag($id);
	$auftrag = $result[0][id];
	$sessionid = $result[0][sessionid];
	$warenkorb = $result[0][warenkorb];
	$logdatei = $result[0][logdatei];
	$this->app->DB->Insert("INSERT INTO shopimport_auftraege (id,extid,sessionid,warenkorb,imported,projekt,bearbeiter,logdatei) 
	  VALUES('','$auftrag','$sessionid','$warenkorb','0','$projekt','".$this->app->User->GetName()."','$logdatei')");
	$this->app->remote->RemoteDeleteAuftrag($id,$auftrag);
      }
    } else {
      $this->app->Tpl->Set(IMPORT,"<div class=\"error\">Verbindungsprobleme! Bitte Administrator kontaktieren!</div>");
    }

    $this->app->Tpl->Set(SUBSUBHEADING,"Auftragsimport");
    //$this->app->Tpl->Add(INHALT,"<table border=\"1\"><tr><td></td><td>Internet</td><td>Kunde</td><td>Land</td><td>Betrag</td></tr>");
    // Tabelle mit Radiobuttons
    $htmltable = new HTMLTable(0,"100%","",3,1,"font-size:85%");
    $htmltable->AddRowAsHeading(array('Import','M&uuml;ll','Noch nicht','Internet','Name','Strasse','PLZ','Ort','Kd.Nr.','Kunde','Land','Betrag','Offen','Zahlung','Partner'));
    $htmltable->ChangingRowColors('#e0e0e0','#fff');


    $arr = $this->app->DB->SelectArr("SELECT * FROM shopimport_auftraege WHERE imported='0' AND trash='0' ORDER BY logdatei");
    for($i=0;$i<count($arr);$i++)
    {
      $warenkorb = unserialize(base64_decode($arr[$i][warenkorb]));
      foreach($warenkorb as $key=>$value)
      	$warenkorb[$key] = trim($warenkorb[$key]);

      $checkid = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE name='".$warenkorb[name]."' AND email='".$warenkorb[email]."' AND abteilung='".$warenkorb[abteilung]."'
        AND strasse='".$warenkorb[strasse]."' AND plz='".$warenkorb[plz]."' AND ort='".$warenkorb[ort]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");


      $validkundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE kundennummer='".$warenkorb[kundennummer]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      if(is_numeric($warenkorb[kundennummer]) && $validkundennummer==$warenkorb[kundennummer])
      {
	$kdrnummer = $warenkorb[kundennummer];
	//$kdr_name = "<br><i style=\"color:red\">".$this->app->DB->Select("SELECT name FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";
	$kdr_name = $this->app->DB->Select("SELECT name FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	$parts= explode("\n", wordwrap($kdr_name, 20, "\n"));
	$kdr_name = $parts[0];
	$kdr_name = "<br><i style=\"color:red\">".$kdr_name."</i>";

	$kdr_strasse = $this->app->DB->Select("SELECT strasse FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	$parts= explode("\n", wordwrap($kdr_strasse, 20, "\n"));
	$kdr_strasse = $parts[0];
	$kdr_strasse = "<br><i style=\"color:red\">".$kdr_strasse."</i>";

	$kdr_plz = "<br><i style=\"color:red\">".$this->app->DB->Select("SELECT plz FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";
	$kdr_ort = "<br><i style=\"color:red\">".$this->app->DB->Select("SELECT ort FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";
        $checked="";
      } elseif (is_numeric($checkid))
      {
        $checked="checked";
        $kdrnummer = $checkid;
        //$kdr_name = "<br><i style=\"color:blue\">".$this->app->DB->Select("SELECT name FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";
        $kdr_name = $this->app->DB->Select("SELECT name FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
        $parts= explode("\n", wordwrap($kdr_name, 20, "\n"));
        $kdr_name = $parts[0];
        $kdr_name = "<br><i style=\"color:blue\">".$kdr_name."</i>";

        $kdr_strasse = $this->app->DB->Select("SELECT strasse FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
        $parts= explode("\n", wordwrap($kdr_strasse, 20, "\n"));
        $kdr_strasse = $parts[0];
        $kdr_strasse = "<br><i style=\"color:blue\">".$kdr_strasse."</i>";

        $kdr_plz = "<br><i style=\"color:blue\">".$this->app->DB->Select("SELECT plz FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";
        $kdr_ort = "<br><i style=\"color:blue\">".$this->app->DB->Select("SELECT ort FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1")."</i>";

      } else {
        $checked="";
        $kdrnummer="";
	$kdr_name="";$kdr_strasse="";$kdr_plz="";$kdr_ort="";
      }
      $kdr_addresse_id  = $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='$kdrnummer' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      $warenkorb[name]  = $this->app->erp->LimitWord($warenkorb[name],20);
      $warenkorb[strasse]  = $this->app->erp->LimitWord($warenkorb[strasse],20);

      $htmltable->NewRow();
      $htmltable->AddCol('<input type="hidden" name="auftrag[]" value="'.$arr[$i][id].'"><input type="radio" name="import['.$arr[$i][id].']" value="import" checked>');
      $htmltable->AddCol('<input type="radio" name="import['.$arr[$i][id].']" value="muell">');
      $htmltable->AddCol('<input type="radio" name="import['.$arr[$i][id].']" value="warten">');
      $htmltable->AddCol($warenkorb[onlinebestellnummer]);
      $htmltable->AddCol($warenkorb[name].$kdr_name);
      $htmltable->AddCol($warenkorb[strasse].$kdr_strasse);
      $htmltable->AddCol($warenkorb[plz].$kdr_plz);
      $htmltable->AddCol($warenkorb[ort].$kdr_ort);
      $htmltable->AddCol($warenkorb[kundennummer]."<br>".$kdrnummer);
      $htmltable->AddCol('<input type="checkbox" '.$checked.' name="kundennummer['.$arr[$i][id].']" value="1">');
      //$htmltable->AddCol('<input type="text" size="8" value="'.$warenkorb[kundennummer].'">&nbsp;<img src="./themes/[THEME]/images/zoom_in.png" border="0">');
      $htmltable->AddCol($warenkorb[land]);
      $htmltable->AddCol($warenkorb[gesamtsumme]);
      $saldo_kunde = $this->app->erp->SaldoAdresse($kdr_addresse_id);
      if($saldo_kunde >0)
        $saldo_kunde = "<b style=\"color:red\">$saldo_kunde</b>";
      else
        $saldo_kunde = "-";
      $htmltable->AddCol($saldo_kunde);
      $htmltable->AddCol($warenkorb[zahlungsweise]);
      $htmltable->AddCol($warenkorb[affiliate_ref]);
      //$htmltable->AddCol('<a href="">Einzelimport</a>&nbsp;<a href="">verwerfen</a>');
      $warenkorb[gesamtsumme] = str_replace(".","",$warenkorb[gesamtsumme]);
      $gesamtsumme = $gesamtsumme + str_replace(",",".",$warenkorb[gesamtsumme]);

      //$this->app->Tpl->Add(INHALT,"<tr><td><input type=\"checkbox\" name=\"\" value=\"1\" checked></td><td>{$warenkorb[onlinebestellnummer]}</td><td>{$warenkorb[name]}</td><td>{$warenkorb[land]}</td><td>{$warenkorb[gesamtsumme]}</td></tr>");
    }


    $htmltable->NewRow();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol();
    $htmltable->AddCol($gesamtsumme);
    $htmltable->AddCol();
    $htmltable->AddCol();
    
    
    $this->app->Tpl->Add(INHALT,$htmltable->Get());
    
    $this->app->Tpl->Set(EXTEND,"<input type=\"submit\" value=\"Auftr&auml;ge importieren\" name=\"submit\">");  
    $this->app->Tpl->Parse(IMPORT,"rahmen70.tpl");
    

    $this->app->Tpl->Parse(PAGE,"shopimport_import.tpl");
  }



  function ShopimportNavigation()
  {
    $id = $this->app->Secure->GetGET("id");
    $tmp = new Navigation($this->app);
    $this->app->Tpl->Set(ID,$id);
    $this->app->Tpl->Set(INHALT,$tmp->Get());

    $this->app->Tpl->Set(SUBSUBHEADING,"Navigationsstruktur Online-Shop");
    $this->app->Tpl->Parse(PAGE,"rahmen_ohne_form.tpl");
    $this->app->BuildNavigation=false;
  }


}
?>
