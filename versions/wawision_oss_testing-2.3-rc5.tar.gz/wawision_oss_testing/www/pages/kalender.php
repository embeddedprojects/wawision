<?php

class Kalender {
  var $app;
  
  function Kalender(&$app) {
    //parent::GenKalender($app);
    $this->app=$app;

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("list","KalenderList");
    $this->app->ActionHandler("data","KalenderData");
    $this->app->ActionHandler("eventdata","KalenderEventData");
    $this->app->ActionHandler("update","KalenderUpdate");
    $this->app->ActionHandler("delete","KalenderDelete");
	

    $this->app->ActionHandlerListen($app);

    $this->app = $app;
  }

	function KalenderList()
	{
		$this->app->Tpl->Set(KURZUEBERSCHRIFT,"Kalender");
    $this->app->Tpl->Set(TABTEXT,"Kalender");

		$submit = $this->app->Secure->GetPOST("submitForm");
    $mode = $this->app->Secure->GetPOST("mode");
    $eventid = $this->app->Secure->GetPOST("eventid");

		$titel = $this->app->Secure->GetPOST("titel");
    $datum = $this->app->Secure->GetPOST("datum");
    $allday = $this->app->Secure->GetPOST("allday");
    $von = $this->app->Secure->GetPOST("von");
    $bis = $this->app->Secure->GetPOST("bis");

    $personen = $this->app->Secure->GetPOST("personen");
    $color = $this->app->Secure->GetPOST("color");

		if($submit!="") {
			$von_datum =  $this->app->String->Convert("$datum $von", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
      $bis_datum =  $this->app->String->Convert("$datum $bis", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
			
			if($allday=='1') {
        $von_datum = $this->app->String->Convert("$datum 00:00", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
        $bis_datum = $von_datum;
      }
	
				
			if($mode=="new") {
				$this->app->DB->Insert("INSERT INTO kalender_event (bezeichnung, von, bis, allDay, color) VALUES ('$titel', '$von_datum', '$bis_datum', '$allday', '$color')");
      	$event = $this->app->DB->GetInsertID();
			}

			if($mode=="edit" && is_numeric($eventid)) {
				$this->app->DB->Update("UPDATE kalender_event SET bezeichnung='$titel', von='$von_datum', bis='$bis_datum', allDay='$allday', color='$color' WHERE id='$eventid' LIMIT 1");
				$this->app->DB->Delete("DELETE FROM kalender_user WHERE event='$eventid'");
				$event = $eventid;
			}

			if($mode=="delete" && is_numeric($eventid)) {
				$this->app->DB->Delete("DELETE FROM kalender_event WHERE id='$eventid' LIMIT 1");		
				$this->app->DB->Delete("DELETE FROM kalender_user WHERE event='$eventid'");
			}

			if($mode=="copy" && is_numeric($eventid)) {
				$cData = $this->app->DB->SelectArr("SELECT * FROM kalender_event WHERE id='$eventid' LIMIT 1");
				$this->app->DB->Insert("INSERT INTO kalender_event (bezeichnung, von, bis, allDay, color) 
																VALUES ('{$cData[0][bezeichnung]}', '{$cData[0][von]}', '{$cData[0][bis]}', '{$cData[0][allDay]}', '{$cData[0][color]}')");
				$event = $this->app->DB->GetInsertID();
			}

			// Schreibe Personen	
			if(is_numeric($event) && is_array($personen) && count($personen) && $mode!="delete") {
				for($p=0;$p<count($personen);$p++)
          $this->app->DB->Insert("INSERT INTO kalender_user (event, userid) VALUES ('$event', '{$personen[$p]}')");
			}
		}

		// Personen Auswahl
		$user = $this->app->User->GetID();
    $users = $this->app->DB->SelectArr("SELECT id, description FROM user WHERE activ='1' ORDER BY username");
    for($i=0; $i<count($users);$i++){ 
			$select = (($user==$users[$i]['id']) ? "selected" : "");
      $user_out .= "<option value=\"{$users[$i]['id']}\" $select>{$users[$i]['description']}</option>";
		}
    $this->app->Tpl->Set('PERSONEN', $user_out);


		$this->app->Tpl->Set('COLORS', $this->ColorPicker());
		$this->app->Tpl->Parse(TAB1,"kalender.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
    $this->app->erp->StartseiteMenu();
	}




	function ColorPicker() {
		$colors = array('#004704','#C40046','#832BA8','#FF8128','#7592A0');
		
		$out = "<option value=\"\" style=\"background-color: #FFFFFF\" onclick=\"this.parentElement.style.background='#FFFFFF'\">Keine</option>";
		for($i=0;$i<count($colors);$i++) 
			$out .= "<option value=\"{$colors[$i]}\" style=\"background-color: {$colors[$i]}\" onclick=\"this.parentElement.style.background='{$colors[$i]}'\">&nbsp;</option>";
		
		return $out;
	}


	function KalenderData()
	{
		$user = $this->app->User->GetID();
		$start = date("Y-m-d H:i:s", $this->app->Secure->GetGET('start'));
		$end = date("Y-m-d H:i:s", $this->app->Secure->GetGET('end'));

/*		$data = $this->app->DB->SelectArr("SELECT id, bezeichnung AS title, von AS start, bis AS end, allDay, color 
																			 FROM kalender_event WHERE '$start'<=von AND bis<='$end'"); */

		$data = $this->app->DB->SelectArr("SELECT ke.id, bezeichnung AS title, von AS start, bis AS end, allDay, color
																			 FROM kalender_user AS ku
																			 LEFT JOIN kalender_event AS ke ON ke.id=ku.event
																			 WHERE ku.userid='$user' AND '$start'<=von AND bis<='$end'");

		for($i=0;$i<count($data);$i++)
		{
			$data[$i]['start'] = $data[$i]['start'];
			$data[$i]['end'] = $data[$i]['end'];
			$data[$i]['allDay'] = (($data[$i]['allDay']=='1')?true:false);
		}
		header('Content-type: application/json');		
		echo json_encode($data);
		exit;
	}

	function KalenderUpdate() 
	{
		$id = $this->app->Secure->GetGET("id");
		$start = $this->app->Secure->GetGET("start");
		$end = $this->app->Secure->GetGET("end");
		
		$this->app->DB->Update("UPDATE kalender_event SET von='$start', bis='$end' WHERE id='$id' LIMIT 1");

		exit;
	}

	function KalenderEventData() 
	{
		$event = $this->app->Secure->GetGET("id");
		if(is_numeric($event) && $event>0){
			$data = $this->app->DB->SelectArr("SELECT id, bezeichnung AS titel, von, bis, allDay, color FROM kalender_event WHERE id='$event' LIMIT 1");
			$personen = $this->app->DB->SelectArr("SELECT DISTINCT ku.userid, u.description FROM kalender_user AS ku
																						 LEFT JOIN user AS u ON u.id=ku.userid WHERE ku.event='$event' ORDER BY u.username ");
		}

		$data[0]['allDay'] = (($data[0]['allDay']=='1')?true:false);
		$data[0]['personen'] = $personen;
		$data = $data[0];	

		header('Content-type: application/json');
    echo json_encode($data);
   	exit;
	}
}

?>
