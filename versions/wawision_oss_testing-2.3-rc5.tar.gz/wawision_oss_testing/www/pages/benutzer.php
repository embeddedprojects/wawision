<?php
class Benutzer 
{
  function Benutzer(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","UserCreate");
    $this->app->ActionHandler("edit","UserEdit");
    $this->app->ActionHandler("list","UserList");
    $this->app->ActionHandler("chrights","UserChangeRights");

    $this->app->DefaultActionHandler("login");
    
		$this->Templates = $this->GetTemplates();


    $this->app->ActionHandlerListen($app);
  }

	function UserList()
	{
		$this->app->Tpl->Add(KURZUEBERSCHRIFT,"Benutzer");
		$this->app->erp->MenuEintrag("index.php?module=benutzer&action=create","Benutzer anlegen");
		$this->app->erp->MenuEintrag("index.php?module=einstellungen&action=list","Zur&uuml;ck zur &Uuml;bersicht");

		$table = new EasyTable($this->app);
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"User");
    $table->Query("SELECT description as beschreibung, username as login, if(activ,'ja','-') as aktiv,  if(externlogin,'erlaubt','-') as extern, if(hwtoken,hwtoken,'') as 'Hardware', id FROM user ");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=benutzer&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=benutzer&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        ");
    $this->app->Tpl->Parse(USER_TABLE,"rahmen70.tpl");
		$this->app->Tpl->Parse(PAGE, "benutzer_list.tpl");

	}
	
	function UserCreate()
	{
		$this->app->Tpl->Add(KURZUEBERSCHRIFT,"Benutzer");
		$this->app->erp->MenuEintrag("index.php?module=benutzer&action=list","Zur&uuml;ck zur &Uuml;bersicht");

		$input = $this->GetInput();
		$submit = $this->app->Secure->GetPOST('submituser');
	
		if($submit!='') {
			$error = '';
			if($input['username']=='') $error .= 'Geben Sie bitte einen Benutzernamen ein.<br>';		
			if($input['password']=='') $error .= 'Geben Sie bitte ein Passwort ein.<br>';		
			if($input['repassword']=='') $error .= 'Wiederholen Sie bitte Ihr Passwort.<br>';		
			if($input['password'] != $input['repassword']) $error .= 'Die eingegebenen Passw&ouml;rter stimmen nicht &uuml;berein.<br>';
			if($this->app->DB->Select("SELECT '1' FROM user WHERE username='{$input['username']}' LIMIT 1")=='1')
				$error .= "Es existiert bereits ein Benutzer mit diesem Namen";


			if($error!='')
				$this->app->Tpl->Set('MESSAGE', "<div class=\"error\">$error</div>");
			else {
				$settings = base64_encode(serialize($input['settings']));
				$firma = $this->app->User->GetFirma();
			
				// wenn adresse mitarbeiter nummer + String dann hole adresse!
    		$input['adresse'] = $this->app->erp->ReplaceMitarbeiter($input['adresse'],$input['adresse'],1);


				$this->app->DB->Insert("INSERT INTO user (username, password, description, settings, parentuser,activ, type, adresse, fehllogins, standarddrucker, 
																									startseite, hwtoken, hwkey, hwcounter, hwdatablock, motppin, motpsecret, externlogin, firma)
																VALUES ('{$input['username']}', ENCRYPT('{$input['password']}'), '{$input['description']}', '{$settings}', '0','{$input['activ']}', 
																				'{$input['type']}', '{$input['adresse']}', '{$input['fehllogins']}', '{$input['standarddrucker']}', '{$input['startseite']}',
																				'{$input['hwtoken']}', '{$input['hwkey']}', '{$input['hwcounter']}','{$input['hwdatablock']}', '{$input['motppin']}', '{$input['motpsecret']}', 
																				'{$input['externlogin']}', '$firma')");

				$this->app->Tpl->Set('MESSAGE', "<div class=\"success\">Der Benutzer wurde erfolgreich angelegt</div>");
			}
		}
		
		$this->SetInput($input);
		$this->app->Tpl->Parse(PAGE, "benutzer_create.tpl");
	}

	function UserEdit()
	{
		$this->app->Tpl->Add(KURZUEBERSCHRIFT,"Benutzer");
		$this->app->erp->MenuEintrag("index.php?module=benutzer&action=list","Zur&uuml;ck zur &Uuml;bersicht");

		$id = $this->app->Secure->GetGET('id');
		$input = $this->GetInput();
    $submit = $this->app->Secure->GetPOST('submituser');

    if(is_numeric($id) && $submit!='') {
			$error = '';
      if($input['username']=='') $error .= 'Geben Sie bitte einen Benutzernamen ein.<br>';
      if($input['password'] != $input['repassword']) $error .= 'Die eingegebenen Passw&ouml;rter stimmen nicht &uuml;berein.<br>';
			
			if($error!='')
        $this->app->Tpl->Set('MESSAGE', "<div class=\"error\">$error</div>");
      else {
        $settings = base64_encode(serialize($input['settings']));
				$firma = $this->app->User->GetFirma();
    		$input['adresse'] = $this->app->erp->ReplaceMitarbeiter(1,$input['adresse'],1);

				$this->app->DB->Update("UPDATE user SET username='{$input['username']}', description='{$input['description']}', settings='{$settings}',
																activ='{$input['activ']}', type='{$input['type']}', adresse='{$input['adresse']}', 
																fehllogins='{$input['fehllogins']}', standarddrucker='{$input['standarddrucker']}',
																startseite='{$input['startseite']}', hwtoken='{$input['hwtoken']}', hwkey='{$input['hwkey']}', 
																hwcounter='{$input['hwcounter']}', hwdatablock='{$input['hwdatablock']}', motppin='{$input['motppin']}',
																motpsecret='{$input['motpsecret']}', externlogin='{$input['externlogin']}', firma='$firma' WHERE id='$id' LIMIT 1");

				if($input['password']!='' && $input['password']!='***************')
					$this->app->DB->Update("UPDATE user SET password=ENCRYPT('{$input['password']}') WHERE id='$id' LIMIT 1");
				
				$this->app->Tpl->Set('MESSAGE', "<div class=\"success\">Die Einstellungen wurden erfolgreich &uuml;bernommen.</div>");
			}	
    }

		$data = $this->app->DB->SelectArr("SELECT * FROM user WHERE id='$id' LIMIT 1");
		if(is_array($data[0])) {
			$data[0]['password'] = '***************';
			$data[0]['repassword'] = '***************';
//			$data[0]['motpsecret']	= $this->app->DB->Select("SELECT DECRYPT('{$input[0]['motpsecret']}')");
//			$data[0]['hwkey']	= $this->app->DB->Select("SELECT DECRYPT('{$input[0]['hwkey']}')");
			$data[0]['settings'] = unserialize(base64_decode($data[0]['settings']));
		}
    $this->SetInput($data[0]);

		$this->UserRights();
    $this->app->Tpl->Parse(PAGE, "benutzer_create.tpl");
	}

	function GetInput()
	{
		$input = array();
		$input['description'] = $this->app->Secure->GetPOST('description');
		$input['type'] = $this->app->Secure->GetPOST('type');
		$input['username'] = $this->app->Secure->GetPOST('username');
		$input['adresse'] = $this->app->Secure->GetPOST('adresse');
		$input['externlogin'] = $this->app->Secure->GetPOST('externlogin');
		$input['activ'] = $this->app->Secure->GetPOST('activ');
		$input['startseite'] = $this->app->Secure->GetPOST('startseite');
		$input['fehllogins'] = $this->app->Secure->GetPOST('fehllogins');
		$input['password'] = $this->app->Secure->GetPOST('password');
		$input['repassword'] = $this->app->Secure->GetPOST('repassword');
		$input['hwtoken'] = $this->app->Secure->GetPOST('hwtoken');
		$input['motppin'] = $this->app->Secure->GetPOST('motppin');
		$input['motpsecret'] = $this->app->Secure->GetPOST('motpsecret');
		$input['hwkey'] = $this->app->Secure->GetPOST('hwkey');
		$input['hwcounter'] = $this->app->Secure->GetPOST('hwcounter');
		$input['hwdatablock'] = $this->app->Secure->GetPOST('hwdatablock');
		$input['standarddrucker'] = $this->app->Secure->GetPOST('standarddrucker');
		$input['settings'] = $this->app->Secure->GetPOST('settings');
		return $input;
	}

	function SetInput($input)
	{
		$this->app->Tpl->Set('DESCRIPTION', $input['description']);
		$this->app->Tpl->Set('TYPESELECT', $this->TypeSelect($input['type']));
		$this->app->Tpl->Set('USERNAME', $input['username']);
		$this->app->Tpl->Set('ADRESSE', $this->app->erp->ReplaceMitarbeiter(0,$input['adresse'],0));

		$this->app->YUI->AutoComplete("adresse","mitarbeiter");

		if($input['externlogin']=='1') $this->app->Tpl->Set('EXTERNLOGINCHECKED', 'checked');
		if($input['activ']=='1') $this->app->Tpl->Set('ACTIVCHECKED', 'checked');

		$this->app->Tpl->Set('STARTSEITE', $input['startseite']);
		$this->app->Tpl->Set('FEHLLOGINS', $input['fehllogins']);
		$this->app->Tpl->Set('PASSWORD', $input['password']);
		$this->app->Tpl->Set('REPASSWORD', $input['repassword']);
		$this->app->Tpl->Set('TOKENSELECT', $this->TokenSelect($input['hwtoken']));
		$this->app->Tpl->Set('MOTPPIN', $input['motppin']);
		$this->app->Tpl->Set('MOTPSECRET', $input['motpsecret']);
		$this->app->Tpl->Set('HWKEY', $input['hwkey']);
		$this->app->Tpl->Set('HWCOUNTER', $input['hwcounter']);
		$this->app->Tpl->Set('HWDATABLOCK', $input['hwdatablock']);
		$this->app->Tpl->Set('STANDARDDRUCKER', $input['standarddrucker']);
		$this->app->Tpl->Set('SETTINGS', $input['settings']);
	}

	function TypeSelect($select='admin')
	{
		$data = array('admin'=>'Administrator', 'verwaltung'=>'Verwaltung', 'vollzugriff'=>'Vollzugriff', 'mitarbeiter'=>'Mitarbeiter', 'produktion'=>'Produktion');

		$out = "";
		foreach($data as $key=>$value) {
			$selected = (($select==$key) ? 'selected' : '');
			$out .= "<option value=\"$key\" $selected>$value</option>";
		}
		return $out;
	}

	function TokenSelect($select='0')
  {
    $data = array('0'=>'Benutzername + Passwort', '1'=>'Benutzername + mOTP', '2'=>'Benutzername + Passwort + Picosafe Login');

    $out = "";
    foreach($data as $key=>$value) {
      $selected = (($select==$key) ? 'selected' : '');
      $out .= "<option value=\"$key\" $selected>$value</option>";
    }
    return $out;
  }

	function UserRights()
	{
		$id = $this->app->Secure->GetGET('id');
		$template = $this->app->Secure->GetPOST('usertemplate');

		$modules = $this->ScanModules();

		if($template!='') {
			$mytemplate = $this->app->Conf->WFconf[permissions][$template];
			$this->app->DB->Delete("DELETE FROM userrights WHERE user='$id'");
			$sql = 'INSERT INTO userrights (user, module, action, permission) VALUES ';

			$modulecount = count($modules);
			$curModule = 0;
			foreach($modules as $module=>$actions) {
				$lower_m = strtolower($module);	
				$curModule++;
				$actioncount = count($actions);
				for($i=0;$i<$actioncount;$i++) {
					$delimiter = (($curModule<$modulecount || $i+1<$actioncount) ? ', ' : ';');  
					$active = ((isset($mytemplate[$lower_m]) && in_array($actions[$i], $mytemplate[$lower_m])) ? '1' : '0');
					$sql .= "('$id', '$lower_m', '{$actions[$i]}', '$active')$delimiter";
				}
			}
			$this->app->DB->Query($sql);
		}

		$dbrights = $this->app->DB->SelectArr("SELECT module, action, permission FROM userrights WHERE user='$id' ORDER BY module");
		$group = $this->app->DB->Select("SELECT type FROM user WHERE id='$id' LIMIT 1");

		$rights = $this->app->Conf->WFconf[permissions][$group];
		if(is_array($dbrights) && count($dbrights)>0) 
			$rights = $this->AdaptRights($dbrights, $rights, $group);
			 
		$modules = $this->ScanModules();
		$table = $this->CreateTable($id, $modules, $rights);	
		

		$this->app->Tpl->Set('USERTEMPLATES', $this->TemplateSelect());	
		$this->app->Tpl->Set('MODULES', $table);
	}

	function UserChangeRights()
	{
		$user = $this->app->Secure->GetGET('b_user');
		$module = $this->app->Secure->GetGET('b_module');
		$action = $this->app->Secure->GetGET('b_action');
		$value = $this->app->Secure->GetGET('b_value');

		if(is_numeric($user) && $module!='' && $action!='' && $value!='') {
			$id = $this->app->DB->Select("SELECT id FROM userrights WHERE user='$user' AND module='$module' AND action='$action' LIMIT 1");
			if(is_numeric($id) && $id>0)
				$this->app->DB->Update("UPDATE userrights SET permission='$value' WHERE id='$id' LIMIT 1");
			else
				$this->app->DB->Insert("INSERT INTO userrights (user, module, action, permission) VALUES ('$user', '$module', '$action', '$value')");
		}
		
		echo $this->app->DB->Select("SELECT permission FROM userrights WHERE user='$user' AND module='$module' AND action='$action' LIMIT 1");

		exit;
	}



	function AdaptRights($dbarr, $rights) 
	{
		$cnt = count($dbarr);
		for($i=0;$i<$cnt;$i++) {
			$module = $dbarr[$i]['module'];
			$action = $dbarr[$i]['action'];
			$perm = $dbarr[$i]['permission'];

			if(isset($rights[$module])) {
				if($perm=='1' && !in_array($action, $rights[$module])) 
						$rights[$module][] = $action;

				if($perm=='0' && in_array($action, $rights[$module])) {
						$index = array_search($action, $rights[$module]);
						unset($rights[$module][$index]);
						$rights[$module] = array_values($rights[$module]);
				}
			}else if($perm=='1') $rights[$module][] = $action;
		}
		return $rights;
	}
	
	function CreateTable($user, $modules, $rights) 
	{
		$maxcols = 6;
		$width = 100 / $maxcols;
		$out = '';
		foreach($modules as $key=>$value) {
      $out .= "<tr><td class=\"name\">$key</td></tr>";
			
			$out .= "<tr><td><table class=\"action\">";
			$module = strtolower($key); 
			for($i=0;$i<$maxcols || $i<count($value);$i++) {
				if($i%$maxcols==0) $out .= "<tr>";
				
				if(isset($value[$i]) && in_array($value[$i], $rights[$module])) {
					$class = 'class="blue"';
					$active = '1';
				}else{
					$class = 'class="grey"';
					$active = 0;
				}
				$class = ((isset($value[$i])) ? $class : '');
					
				$action = ((isset($value[$i])) ? strtolower($value[$i]) : '');
				$onclick = ((isset($value[$i])) ? "onclick=\"ChangeRights(this, '$user','$module','$action')\"" : '');
				$out .= "<td width=\"$width%\" $class value=\"$active\" $onclick>{$action}</td>";

				if($i%$maxcols==($maxcols-1)) $out .= "</tr>";
			}
			$out .= "</table></td></tr>";
    }

		return $out;
	}

	function ScanModules()
	{
		$files = glob('./pages/*.php');
		
		$modules = array();
		foreach($files as $page) {
			$name = ucfirst(basename($page,'.php'));
			
			$content = file_get_contents($page);		

			$foundItems = preg_match_all('/ActionHandler\(\"[[:alnum:]].*\",/', $content, $matches);
			if($foundItems > 0) {
				$action = str_replace(array('ActionHandler("','",'),'', $matches[0]);
				for($i=0;$i<count($action);$i++)
					$modules[$name][] = $action[$i];	
				sort($modules[$name]);
			}
		}
		return $modules;	
	}

	function TemplateSelect()
	{
		$options = "<option value=\"\">-- Bitte auswählen --</option>";
		foreach($this->Templates as $key=>$value) {
			$options .= "<option value=\"$key\">".ucfirst($key)."</option>";
		}

		return $options;
	}

	function GetTemplates()
	{
		return $this->app->Conf->WFconf[permissions];
	}
}
?>
