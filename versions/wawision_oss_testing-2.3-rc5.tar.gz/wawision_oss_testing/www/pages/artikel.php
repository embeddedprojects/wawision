<?php
include ("_gen/artikel.php");

class Artikel extends GenArtikel {
  var $app;
 
  function Artikel($app) {
    //parent::GenArtikel($app);
    $this->app=&$app;

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","ArtikelCreate");
    $this->app->ActionHandler("edit","ArtikelEdit");
    $this->app->ActionHandler("list","ArtikelList");
    $this->app->ActionHandler("newlist","ArtikelNewList");
    $this->app->ActionHandler("stueckliste","ArtikelStueckliste");
    $this->app->ActionHandler("delstueckliste","DelStueckliste");
    $this->app->ActionHandler("upstueckliste","UpStueckliste");
    $this->app->ActionHandler("downstueckliste","DownStueckliste");
    $this->app->ActionHandler("editstueckliste","ArtikelStuecklisteEditPopup");
    $this->app->ActionHandler("verkauf","ArtikelVerkauf");
    $this->app->ActionHandler("copy","ArtikelCopy");
    $this->app->ActionHandler("schliessen","ArtikelSchliessen");
    $this->app->ActionHandler("verkaufeditpopup","ArtikelVerkaufEditPopup");
    $this->app->ActionHandler("verkaufcopy","ArtikelVerkaufCopy");
    $this->app->ActionHandler("verkaufdelete","ArtikelVerkaufDelete");
    $this->app->ActionHandler("verkaufdisable","ArtikelVerkaufDisable");
    $this->app->ActionHandler("einkauf","ArtikelEinkauf");
    $this->app->ActionHandler("einkaufdelete","ArtikelEinkaufDelete");
    $this->app->ActionHandler("einkaufdisable","ArtikelEinkaufDisable");
    $this->app->ActionHandler("einkaufcopy","ArtikelEinkaufCopy");
    $this->app->ActionHandler("einkaufeditpopup","ArtikelEinkaufEditPopup");
    $this->app->ActionHandler("projekte","ArtikelProjekte");
    $this->app->ActionHandler("lager","ArtikelLager");
    $this->app->ActionHandler("seriennummern","ArtikelSeriennummern");
    $this->app->ActionHandler("wareneingang","ArtikelWareneingang");
    $this->app->ActionHandler("offenebestellungen","ArtikelOffeneBestellungen");
    $this->app->ActionHandler("statistik","ArtikelStatistik");
    $this->app->ActionHandler("offeneauftraege","ArtikelOffeneAuftraege");
    $this->app->ActionHandler("dateien","ArtikelDateien");
    $this->app->ActionHandler("provision","Artikelprovision");
    $this->app->ActionHandler("delete","ArtikelDelete");
    $this->app->ActionHandler("auslagern","ArtikelAuslagern");
    $this->app->ActionHandler("ausreservieren","ArtikelAusreservieren");
    $this->app->ActionHandler("etiketten","ArtikelEtiketten");
    $this->app->ActionHandler("reservierung","ArtikelReservierung");
    $this->app->ActionHandler("onlineshop","ArtikelOnlineShop");
    $this->app->ActionHandler("ajaxwerte","ArtikelAjaxWerte");
    $this->app->ActionHandler("profisuche","ArtikelProfisuche");
    $this->app->ActionHandler("lagerlampe","ArtikelLagerlampe");
    $this->app->ActionHandler("shopexport","ArtikelShopexport");
    $this->app->ActionHandler("stuecklisteetiketten","ArtikelStuecklisteEtiketten");

    $id = $this->app->Secure->GetGET("id");
    $nummer = $this->app->Secure->GetPOST("nummer");
   
    if(is_numeric($id)) 
      $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$id' LIMIT 1");
    else
      $artikel = $nummer; 
    if($artikel!="")
      $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);
    else $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel");
    $this->app->Tpl->Set(FARBE,"[FARBE1]");


    $this->app->ActionHandlerListen($app);

    $this->app = $app;
  }


	function Preisrechner()
	{
		$this->app->Tpl->Set(PREISRECHNER,"<br><input type=\"button\" value=\"+19\" onclick=\"this.form.preis.value=parseFloat(this.form.preis.value.split(',').join('.'))*1.19;\">");
		$this->app->Tpl->Add(PREISRECHNER,"<input type=\"button\" value=\"-19\" onclick=\"this.form.preis.value=parseFloat(this.form.preis.value.split(',').join('.'))/1.19;\">");
		$this->app->Tpl->Add(PREISRECHNER,"<input type=\"button\" value=\"+7\" onclick=\"this.form.preis.value=parseFloat(this.form.preis.value.split(',').join('.'))*1.07;\">");
		$this->app->Tpl->Add(PREISRECHNER,"<input type=\"button\" value=\"-7\" onclick=\"this.form.preis.value=parseFloat(this.form.preis.value.split(',').join('.'))/1.07;\">");

	}

  function ArtikelShopexport()
  {
    $id = $this->app->Secure->GetGET("id"); 
    $artikel = array($id);

    $shop = $this->app->DB->Select("SELECT shop FROM artikel WHERE id='$id' LIMIT 1");
    if($this->app->remote->remoteSendArticleList($shop,$artikel))
    $msg = base64_encode("<div class=info>Der Artikel wurde im Shop aktualisiert!</div>"); 
     else 
    $msg = base64_encode("<div class=error2>Es gab einen Fehler beim Aktualisieren des Artikels im Shop!</div>"); 

    header("Location: index.php?module=artikel&action=edit&id=$id&msg=$msg#tabs-1");
    exit;
  }

  function ArtikelStuecklisteEtiketten()
  {
 	$id = $this->app->Secure->GetGET("id"); 
	$artikel = $this->app->DB->SelectArr("SELECT * FROM stueckliste WHERE stuecklistevonartikel='$id'");                    
 	for($i=0;$i<count($artikel);$i++)                                                                            
 	{                                                                                                   
 		$artikelid = $artikel[$i]['artikel'];     
 		$name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikelid' LIMIT 1");
 		$name_de = base64_encode($name_de);
 		$nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikelid' LIMIT 1");
 		HttpClient::quickGet("http://192.168.0.178/druck.php?nr=$nummer&ch=0&anzahl=1&etikett=klein&beschriftung=$name_de");
 		      
 	} 
 	header("Location: index.php?module=artikel&action=stueckliste&id=$id");
 	exit;
  }
 
  function ArtikelSchliessen()                                                                       
  {
        $id = $this->app->Secure->GetGET("id");                                                              
        if($id > 0 && is_numeric($id))
          $this->app->DB->Update("UPDATE bestellung_position SET abgeschlossen='1' WHERE artikel='$id'");
        
        header("Location: ".$_SERVER['HTTP_REFERER']);
        exit;
  }

  function ArtikelLagerlampe()
  {
    $jetztnichtlagernd = $this->app->Secure->GetPOST("jetztnichtlagernd");
    $jetztnichtlagerndrot = $this->app->Secure->GetPOST("jetztnichtlagerndrot");
    $jetztlagernd = $this->app->Secure->GetPOST("jetztlagernd");
    $tab3gruen = $this->app->Secure->GetPOST("tab3gruen");
    $neuweg = $this->app->Secure->GetPOST("neuweg");
    $artikelmarkiert = $this->app->Secure->GetPOST("artikelmarkiert");
    
    if($jetztlagernd!="" || $tab3gruen!="" )
    {
      for($i=0;$i < count($artikelmarkiert); $i++)
      	$this->app->DB->Update("UPDATE artikel SET lieferzeit='lager',ausverkauft='0' WHERE id='".$artikelmarkiert[$i]."'  LIMIT 1");
    }
  
    else if($neuweg!="")
    {
      for($i=0;$i < count($artikelmarkiert); $i++)
      	$this->app->DB->Update("UPDATE artikel SET neu='0' WHERE id='".$artikelmarkiert[$i]."' LIMIT 1");
    } 

    else if($jetztnichtlagernd!="")
    {
      for($i=0;$i < count($artikelmarkiert); $i++)
      	$this->app->DB->Update("UPDATE artikel SET lieferzeit='bestellt' WHERE id='".$artikelmarkiert[$i]."' LIMIT 1");
    } 
    else if($jetztnichtlagerndrot!="")
    {
      for($i=0;$i < count($artikelmarkiert); $i++)
      	$this->app->DB->Update("UPDATE artikel SET lieferzeit='nichtlieferbar' WHERE id='".$artikelmarkiert[$i]."' LIMIT 1");
    } 
    
//    $this->app->erp->MenuEintrag("index.php?module=artikel&action=create","Neuen Artikel anlegen");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=list","zur&uuml;ck zur &Uuml;bersicht");

    $this->app->Tpl->Set(TAB1,"<div class=\"info\">Hier werden alle Artikel die als nicht lagernd Online-Shop markierten Artikel angezeigt.</div>");
    $this->app->Tpl->Set(TAB2,"<div class=\"info\">Hier werden alle Artikel die als lagernd im Online-Shop markiert sind jedoch nicht im Lager liegen.</div>");
    $this->app->Tpl->Set(TAB3,"<div class=\"info\">Hier werden alle Artikel die als ausverkauf im Online-Shop markierten sind jedoch im Lager liegen.</div>");

    $this->app->YUI->TableSearch(TAB1,"artikeltabellenichtlagernd");                                                  
    $this->app->YUI->TableSearch(TAB2,"artikeltabellelagerndabernichtlagernd");                                                  
    $this->app->YUI->TableSearch(TAB3,"artikeltabellehinweisausverkauft");                                                  
    $this->app->YUI->TableSearch(TAB4,"artikeltabelleneu");                                                  
    
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Lagerlampen berechnen");
    $this->app->Tpl->Set(TABTEXT,"Lagerlampen berechnen");
  
    $this->app->Tpl->Parse(PAGE,"lagerlampen.tpl");
  }


  function ArtikelProfisuche()
  {
    
    $id = $this->app->Secure->GetGET("id"); // abhaengig von cmd
    $cmd = $this->app->Secure->GetGET("cmd");
    $anlegen = $this->app->Secure->GetPOST("anlegen");

    $projekt = $this->app->Secure->GetPOST("projekt");
    $adresse = $this->app->Secure->GetPOST("adresse");
    $menge = $this->app->Secure->GetPOST("menge");
    $preis = $this->app->Secure->GetPOST("preis");
    $bestellnummer = $this->app->Secure->GetPOST("bestellnummer");
    $bezeichnunglieferant = $this->app->Secure->GetPOST("bezeichnunglieferant");
    $typ = $this->app->Secure->GetPOST("typ");
    $name_de = $this->app->Secure->GetPOST("name_de");
    $kurztext_de = $this->app->Secure->GetPOST("kurztext_de");
    $umsatzsteuerklasse = $this->app->Secure->GetPOST("umsatzsteuerklasse");
    $internerkommentar = $this->app->Secure->GetPOST("internerkommentar");


    $insert = $this->app->Secure->GetGET("insert");

    if($insert=="true")
    {
	// hole alles anhand der verkaufspreis id

	$id = $this->app->Secure->GetGET("sid");
	$vid = $this->app->Secure->GetGET("id");
	$cmd = $this->app->Secure->GetGET("cmd");

	if($cmd!="bestellung")
	{
	  $artikel_id = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$vid' LIMIT 1");
	  $menge = $this->app->DB->Select("SELECT ab_menge FROM verkaufspreise WHERE id='$vid' LIMIT 1");
	  $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$vid' LIMIT 1");
	  $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$vid' LIMIT 1");
	} else {
	  $artikel_id = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$vid' LIMIT 1");
	  $menge = $this->app->DB->Select("SELECT ab_menge FROM einkaufspreise WHERE id='$vid' LIMIT 1");
	  $preis = $this->app->DB->Select("SELECT preis FROM einkaufspreise WHERE id='$vid' LIMIT 1");
	  $projekt = $this->app->DB->Select("SELECT projekt FROM einkaufspreise WHERE id='$vid' LIMIT 1");
	}
	$lieferdatum = "0000-00-00";
	$waehrung = "EUR";
	$vpe = "";
	$bezeichnung = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel_id' LIMIT 1");
	$nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel_id' LIMIT 1");
	$umsatzsteuerklasse = $this->app->DB->Select("SELECT umsatzsteuer FROM artikel WHERE id='$artikel_id' LIMIT 1");

	$sort = $this->app->DB->Select("SELECT MAX(sort) FROM {$cmd}_position WHERE {$cmd}='$id' LIMIT 1");
        $sort = $sort + 1;

	

	if($cmd=="lieferschein")
	{
	  $this->app->DB->Insert("INSERT INTO lieferschein_position (id,{$cmd},artikel,bezeichnung,beschreibung,nummer,menge,sort,lieferdatum, status,projekt,vpe)
          VALUES ('','$id','$artikel_id','$bezeichnung','$kurztext_de','$nummer','$menge','$sort','$lieferdatum','angelegt','$projekt','$vpe')");
	} 
	else if($cmd=="bestellung")
	{
	  $bestellnummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE id='$vid' LIMIT 1");
	  $bezeichnunglieferant = $this->app->DB->Select("SELECT bezeichnunglieferant FROM einkaufspreise WHERE id='$vid' LIMIT 1");
 
	  $this->app->DB->Insert("INSERT INTO bestellung_position (id,{$cmd},artikel,beschreibung,menge,sort,lieferdatum, status,projekt,vpe,bestellnummer,bezeichnunglieferant,preis,waehrung,umsatzsteuer)
	  VALUES ('','$id','$artikel_id','$kurztext_de','$menge','$sort','$lieferdatum','angelegt','$projekt','$vpe','$bestellnummer','$bezeichnunglieferant','$preis','$waehrung','$umsatzsteuerklasse')");
	}
	else {
	  $this->app->DB->Insert("INSERT INTO {$cmd}_position (id,{$cmd},artikel,bezeichnung,beschreibung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe)
          VALUES ('','$id','$artikel_id','$bezeichnung','$kurztext_de','$nummer','$menge','$preis','$waehrung','$sort','$lieferdatum','$umsatzsteuerklasse','angelegt','$projekt','$vpe')");
	}


	header("Location: index.php?module={$cmd}&action=positionen&id=$id");
        exit;
    }

    if($anlegen!="")
    {
      // speichern ??
      //echo "speichern";

      if($cmd=="lieferschein")
      {
	if($name_de=="" || $menge=="")
	{
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Artikel (Deutsch) und Menge sind Pflichtfelder!</div>");
	  $error = 1;
	}
      } else {
	if($name_de=="" || $menge=="" || $preis=="")
	{
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Artikel (Deutsch), Preis und Menge sind Pflichtfelder!</div>");
	  $error = 1;
	}
      }
      if($error!=1)
      {
	$sort = $this->app->DB->Select("SELECT MAX(sort) FROM {$cmd}_position WHERE {$cmd}='$id' LIMIT 1");
        $sort = $sort + 1;


	$tmp = trim($adresse);
        $rest = substr($tmp, 0, 5);
	if($rest > 0)
        $adresse =  $this->app->DB->Select("SELECT id FROM adresse WHERE lieferantennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	else $adresse="";

	$artikelart = $typ;
	$lieferant = $adresse;
	$bezeichnung = $name_de;
	$waehrung = "EUR";
	$lieferdatum = "00.00.0000";
	$vpe = "";
	$preis = str_replace(",",".",$preis);

	if($projekt!="") 
	$projekt = $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$projekt' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	else $projekt="";

	$neue_nummer = $this->app->erp->NeueArtikelNummer($artikelart);

        // anlegen als artikel
        $this->app->DB->Insert("INSERT INTO artikel (id,typ,nummer,projekt,name_de,kurztext_de,umsatzsteuer,adresse,firma)
         VALUES ('','$artikelart','$neue_nummer','$projekt','$bezeichnung','$kurztext_de','$umsatzsteuerklasse','$lieferant','".$this->app->User->GetFirma()."')");

        $artikel_id = $this->app->DB->GetInsertID();
        // einkaufspreis anlegen
	
        $lieferdatum = $this->app->String->Convert($lieferdatum,"%1.%2.%3","%3-%2-%1");

	if($cmd=="lieferschein")
	{
	  $this->app->DB->Insert("INSERT INTO lieferschein_position (id,{$cmd},artikel,bezeichnung,beschreibung,nummer,menge,sort,lieferdatum, status,projekt,vpe)
          VALUES ('','$id','$artikel_id','$bezeichnung','$kurztext_de','$neue_nummer','$menge','$sort','$lieferdatum','angelegt','$projekt','$vpe')");
	}
	else if($cmd=="bestellung")
	{
	  if($bezeichnunglieferant=="") $bezeichnunglieferant=$bezeichnung;
	  $this->app->DB->Insert("INSERT INTO bestellung_position (id,{$cmd},artikel,beschreibung,menge,sort,lieferdatum, status,projekt,vpe,bestellnummer,bezeichnunglieferant,preis,waehrung,umsatzsteuer)
          VALUES ('','$id','$artikel_id','$kurztext_de','$menge','$sort','$lieferdatum','angelegt','$projekt','$vpe','$bestellnummer','$bezeichnunglieferant','$preis','$waehrung','$umsatzsteuerklasse')");

	  $this->app->DB->Insert("INSERT INTO einkaufspreise (id,artikel,adresse,objekt,projekt,preis,ab_menge,angelegt_am,bearbeiter,bestellnummer,bezeichnunglieferant)
          VALUES ('','$artikel_id','$lieferant','Standard','$projekt','$preis','$menge',NOW(),'".$this->app->User->GetName()."','$bestellnummer','$bezeichnunglieferant')");

	} else { // angebot auftrag rechnung gutschrift
	  $this->app->DB->Insert("INSERT INTO verkaufspreise (id,artikel,adresse,objekt,projekt,preis,ab_menge,angelegt_am,bearbeiter)
          VALUES ('','$artikel_id','$lieferant','Standard','$projekt','$preis','$menge',NOW(),'".$this->app->User->GetName()."')");

	  $this->app->DB->Insert("INSERT INTO {$cmd}_position (id,{$cmd},artikel,bezeichnung,beschreibung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe)
          VALUES ('','$id','$artikel_id','$bezeichnung','$kurztext_de','$neue_nummer','$menge','$preis','$waehrung','$sort','$lieferdatum','$umsatzsteuerklasse','angelegt','$projekt','$vpe')");
	}

        header("Location: index.php?module={$cmd}&action=positionen&id=$id");
        exit;
      } 
    }

    $this->app->Tpl->Set(PROJEKT,$projekt);
    $this->app->Tpl->Set(ADRESSE,$adresse);
    $this->app->Tpl->Set(MENGE,$menge);
    $this->app->Tpl->Set(PREIS,$preis);
    $this->app->Tpl->Set(BESTELLNUMMER,$bestellnummer);
    $this->app->Tpl->Set(BEZEICHNUNGLIEFERANT,$bezeichnunglieferant);
    $this->app->Tpl->Set(NAME_DE,$name_de);
    $this->app->Tpl->Set(KURZTEXT_DE,$kurztext_de);
    $this->app->Tpl->Set(INTERNERKOMMENTAR,$internerkommentar);


    $this->app->YUI->AutoComplete("projekt","projektname",1);
    $this->app->YUI->AutoComplete("adresse","lieferant");




    if($cmd=="auftrag" || $cmd=="rechnung" || $cmd=="lieferschein" || $cmd=="angebot" || $cmd=="gutschrift")
    {
      $adresse = $this->app->DB->Select("SELECT adresse FROM {$cmd} WHERE id='$id' LIMIT 1");
      $kunde = $this->app->DB->Select("SELECT CONCAT(name,' (',kundennummer,')') FROM adresse WHERE id='$adresse' LIMIT 1");
    } else if ($cmd=="bestellung") {
      $adresse = $this->app->DB->Select("SELECT adresse FROM {$cmd} WHERE id='$id' LIMIT 1");
      $kunde = $this->app->DB->Select("SELECT CONCAT(name,' (',lieferantennummer,')') FROM adresse WHERE id='$adresse' LIMIT 1");
    }


    if($cmd=="lieferschein")
      $this->app->YUI->ParserVarIf(LIEFERSCHEIN,1);
    else
      $this->app->YUI->ParserVarIf(LIEFERSCHEIN,0);


    $this->app->Tpl->Set(KUNDE,$kunde);

    if($cmd=="bestellung")
      $this->app->YUI->TableSearch(ARTIKEL,"lieferantartikelpreise");
    else
      $this->app->YUI->TableSearch(ARTIKEL,"kundeartikelpreise");


    $this->app->Tpl->Set(PAGE,"<br><center><a href=\"index.php?module=$cmd&action=positionen&id=$id\"><img src=\"./themes/{$this->app->Conf->WFconf[defaulttheme]}/images/back.png\" border=\"0\"></a></center>");

    if ($cmd=="bestellung") 
    $this->app->Tpl->Parse(PAGE,"aarlg_artikelbestellungneu.tpl");
    else
    $this->app->Tpl->Parse(PAGE,"aarlg_artikelneu.tpl");

    $this->app->BuildNavigation=false;

  }





  function ArtikelAjaxWerte()
  {
    $id = $this->app->Secure->GetGET("id");
    $sid = $this->app->Secure->GetGET("sid");
    $smodule = $this->app->Secure->GetGET("smodule");
    $menge = $this->app->Secure->GetGET("menge");


    $cmd = $this->app->Secure->GetGET("cmd");
    $adresse = $this->app->Secure->GetGET("adresse");
 
    if($smodule=="bestellung")
    { 
			$tmp_id = $id;
      $id = substr($id,0,6);
      if(!is_numeric($id))
				exit;
			if(strlen($tmp_id) > 6)
			{
			// hole ab menge aus
			$start_pos = strpos ($tmp_id, "ab Menge ");
			$tmp_id = substr($tmp_id,$start_pos + strlen("ab Menge "));
			$end_pos = strpos ($tmp_id, " ");
			$menge = trim(substr($tmp_id,0,$end_pos));
			}
   
      $id = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$id' LIMIT 1");

      $adresse = $this->app->DB->Select("SELECT adresse FROM $smodule WHERE id='$sid' LIMIT 1");

      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $bestellnummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 LIMIT 1");
      $bezeichnunglieferant = $this->app->DB->Select("SELECT bezeichnunglieferant FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT p.abkuerzung FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.id='$id' LIMIT 1");
      $projekt_id = $this->app->DB->Select("SELECT projekt FROM artikel WHERE id='$id' LIMIT 1");
      $ab_menge = $this->app->DB->Select("SELECT ab_menge FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 LIMIT 1");
      $ek = $this->app->DB->Select("SELECT preis FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND ab_menge<='$menge' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 ORDER by ab_menge DESC LIMIT 1");


      echo "$name:$nummer:$projekt:$ek:$menge:$bestellnummer:$bezeichnunglieferant";
    } else {
      $id = substr($id,0,6);
      if(!is_numeric($id))
	exit;
   
      $id = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$id' LIMIT 1");

      $adresse = $this->app->DB->Select("SELECT adresse FROM $smodule WHERE id='$sid' LIMIT 1");

 
      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT p.abkuerzung FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.id='$id' LIMIT 1");
      $projekt_id = $this->app->DB->Select("SELECT projekt FROM artikel WHERE id='$id' LIMIT 1");

      $ab_menge = $this->app->DB->Select("SELECT ab_menge FROM verkaufspreise WHERE artikel='$id' AND ab_menge=1  AND geloescht=0 LIMIT 1");
      $ab_menge = $menge;

      // gibt es spezial preis?
      $vk = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND ab_menge<=$menge AND (gueltig_bis>NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 ORDER by ab_menge DESC LIMIT 1");
    
      if($vk <= 0)
      {
	$vk = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE artikel='$id' AND ab_menge<=$menge AND (adresse='0' OR adresse='') AND (gueltig_bis>NOW() OR gueltig_bis='0000-00-00') AND geloescht=0 ORDER by ab_menge DESC LIMIT 1");
      }
      echo "$name:$nummer:$projekt:$vk:$ab_menge";
    }
    exit;
  }

  function ArtikelWareneingang()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Wareneingang)");
    $this->ArtikelMenu();
    $this->app->Tpl->Set(PAGE,"wareneingang");
  }

  function ArtikelReservierung()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Reservierungen)");
    $this->ArtikelMenu();
    $this->app->Tpl->Set(PAGE,"reservierung");
  }


  function ArtikelOffeneAuftraege()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Add(TABTEXT,"Auftr&auml;ge");
    $this->ArtikelMenu();

    $this->app->Tpl->Set(TAB1,"<h2>Offene Auftr&auml;ge</h2>");
    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.belegnr, DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.status, a.zahlungsweise, adr.kundenfreigabe as freigabe, CONCAT(a.name,'<br>', a.email) as Kunde, a.zahlungsweise, ap.menge, ap.geliefert_menge as gelieferte, FORMAT(ap.preis,2) as preis  FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag, adresse adr WHERE adr.id=a.adresse AND ap.artikel='$id' AND ap.geliefert_menge < ap.menge AND a.status='freigegeben'");
    //$table->DisplayNew(INHALT,"<a href=\"index.php?module=bestellung&action=edit&id=%value%\">Bestellung</a>");
    $table->DisplayNew(TAB1,"Gelieferte","noAction");

    $summe = $this->app->DB->Select("SELECT SUM(ap.menge)-SUM(ap.geliefert_menge) FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$id' AND ap.geliefert_menge < ap.menge AND a.status='freigegeben'");
    $euro= $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$id' AND ap.geliefert_menge < ap.menge AND a.status='freigegeben'");

    $this->app->Tpl->Add(TAB1,"<table width=\"100%\"><tr><td align=\"right\">Summe offen: $summe St&uuml;ck (Summe EUR: $euro EUR)</td></tr></table><h2>Die letzten 10 Auftr&auml;ge</h2>[TAB2]");

    $table = new EasyTable($this->app);
    $table->Query("SELECT a.belegnr, DATE_FORMAT(a.datum,'%d.%m.%Y') as datum2, a.status, a.zahlungsweise, CONCAT(a.name,'<br>', a.email) as Kunde, a.zahlungsweise, ap.menge, ap.geliefert_menge as gelieferte, FORMAT(ap.preis,2) as preis  FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag, adresse adr WHERE adr.id=a.adresse AND ap.artikel='$id' AND a.status='abgeschlossen' ORDER by a.datum DESC LIMIT 10");
    $table->DisplayNew(TAB2,"Gelieferte","noAction");



    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function ArtikelDateien()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ArtikelMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Dateien)");
    $this->app->YUI->DateiUpload(PAGE,"Artikel",$id);
  }

  function ArtikelVerkauf()
  {
		// rechne gueltig_bis gestern aus
		// erstelle array objekt, adressse, ab_menge,preis
		// wenn es doppelte gibt rote meldung!!!
		//$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Achtung es gibt f&uuml;r eine Kundengruppe bei einer gleichen Menge den Preis &ouml;fters! Deaktvieren oder l&ouml;schen Sie doppelte Preise!</div>");
	  	


    $this->app->Tpl->Add(UEBERSCHRIFT," (Verkauf)");
    $this->app->Tpl->Set(SUBSUBHEADING,"Verkaufspreise");
    $this->ArtikelMenu();
    $this->Preisrechner();
    $id = $this->app->Secure->GetGET("id");
    // neues arbeitspaket
    $widget = new WidgetVerkaufspreise($this->app,TAB2);
    $this->app->Tpl->Set(TMPSCRIPT,"<script type=\"text/javascript\">$(document).ready(function(){ $('#tabs').tabs('select', 1); });</script>");
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=verkauf&id=$id#tabs-1");


    $widget->Create();


     $this->app->YUI->TableSearch(TAB1,"verkaufspreise");

    $this->app->Tpl->Parse(PAGE,"verkaufspreiseuebersicht.tpl");
  }

  
  function ArtikelVerkaufDisable()
  {

    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Update("UPDATE verkaufspreise SET gueltig_bis=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=verkauf&id=".$sid);
    exit;
  }


  function ArtikelVerkaufDelete()
  {

    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Update("UPDATE verkaufspreise SET geloescht='1', gueltig_bis=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=verkauf&id=".$sid);
    exit;
  }


  function ArtikelVerkaufCopy()
  {
    $id = $this->app->Secure->GetGET("id");

    $id = $this->app->DB->MysqlCopyRow("verkaufspreise","id",$id);
    $this->app->DB->Update("UPDATE verkaufspreise SET geloescht='0', gueltig_bis='0000-00-00' WHERE id='$id' LIMIT 1");

    $sid = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=verkauf&id=".$sid);
    exit;
  }



   function ArtikelVerkaufEditPopup()
  {
    $id = $this->app->Secure->GetGET("id");
		$this->app->Tpl->Set(OPENDISABLE,"<!--");
    $this->app->Tpl->Set(CLOSEDISABLE,"-->");


    $this->Preisrechner();
    $sid = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$id' LIMIT 1");
    $this->ArtikelMenu($sid);
    $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$sid' LIMIT 1");
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);
    $this->app->Tpl->Add(UEBERSCHRIFT," (Verkauf)");

    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=artikel&action=verkauf&id=$sid';\">");

    $widget = new WidgetVerkaufspreise($this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=artikel&action=verkauf&id=$sid&&22#tabs-1");
    $widget->Edit();

    $this->app->Tpl->Add(TAB2,"Sie bearbeiten gerade einen Verkaufspreis. Erst nach dem Speichern k&ouml;nnen neue Preise angelegt werden.");
    $this->app->Tpl->Add(TAB3,"Sie bearbeiten gerade einen Verkaufspreis. Erst nach dem Speichern k&ouml;nnen Statistiken betrachtet werden.");
    $this->app->Tpl->Parse(PAGE,"verkaufspreiseuebersicht.tpl");
  }

  function ArtikelEinkauf()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Einkauf)");
    $this->app->Tpl->Set(SUBSUBHEADING,"Einkaufspreise");

		// rechne gueltig_bis gestern aus
		//$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Achtung es gibt f&uuml;r diesen Artikel bei einem Lieferanten bei gleiche Menge den Preis &ouml;fters! Deaktvieren oder l&ouml;schen Sie doppelte Preise!</div>");

    $this->Preisrechner();
    $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");

    $stueckliste = $this->app->DB->Select("SELECT stueckliste FROM artikel WHERE id='$id' LIMIT 1");

    // neues arbeitspaket
    $widget = new WidgetEinkaufspreise($this->app,TAB2);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=einkauf&id=$id#tabs-1");
		$this->app->Tpl->Set(TMPSCRIPT,"<script type=\"text/javascript\">$(document).ready(function(){ $('#tabs').tabs('select', 1); });</script>");

    $widget->Create();

    if($this->app->Secure->GetPOST("objekt")!="")
      $this->app->Tpl->Set(AKTIV_TAB2,"selected");
    else
      $this->app->Tpl->Set(AKTIV_TAB1,"selected");


    if(!$stueckliste)
    {
      // easy table mit arbeitspaketen YUI als template 
      $this->app->YUI->TableSearch(TAB1,"einkaufspreise");
      $adresse = $this->app->DB->Select("SELECT adresse FROM artikel WHERE id='$id' LIMIT 1"); 
      $hauptlieferant = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
      $this->app->Tpl->Add(TAB1,"<div class=\"info\">Der Hauptlieferant ist <b>$hauptlieferant</b></div>");
      $min_preis = $this->app->DB->Select("SELECT FORMAT(MIN(preis),2) FROM verkaufspreise WHERE artikel='$id' AND objekt='Standard' AND adresse='' LIMIT 1");
      $min_preis = $min_preis/(($this->app->erp->GetStandardMarge()/100)+1);
      $this->app->Tpl->Add(TAB1,"<div class=\"warning\">Empfohlener max. Standard Einkaufspreis bei Menge 1: <b>$min_preis EUR</b>!</div>");
      $this->app->Tpl->Parse(PAGE,"einkaufspreiseuebersicht.tpl");
    } else { 

      $table = new EasyTable($this->app);
      $table->Query("SELECT a.name_de as Artikel, a.nummer, s.menge, s.place, s.layer, REPLACE(
	if(a.stueckliste,(SELECT MIN(v.preis) FROM verkaufspreise v WHERE v.artikel=s.artikel AND (v.objekt='Standard' OR v.objekt=''))*s.menge,(SELECT MIN(e.preis) FROM einkaufspreise e WHERE e.artikel=s.artikel AND e.objekt='Standard')*s.menge),'.',',') as Preis, s.id
        FROM stueckliste s
        LEFT JOIN artikel a ON a.id=s.artikel 
        WHERE s.stuecklistevonartikel='$id' ORDER by s.sort");
      $table->DisplayNew(INHALT,"",""); 

      $sql = "SELECT FORMAT(SUM( 
	(SELECT MIN(e.preis) FROM einkaufspreise e WHERE e.artikel=s.artikel AND e.objekt='Standard')*s.menge)
          ,2)
        FROM stueckliste s
        LEFT JOIN artikel a ON a.id=s.artikel 
        WHERE s.stuecklistevonartikel='$id'";

      $preis = $this->app->DB->Select($sql);
      $sql = "SELECT FORMAT(SUM(
        (SELECT MIN(v.preis) FROM verkaufspreise v WHERE v.artikel=s.artikel AND a.stueckliste=1 AND (v.objekt='Standard' OR v.objekt=''))*s.menge)
          ,2)
        FROM stueckliste s
        LEFT JOIN artikel a ON a.id=s.artikel
        WHERE s.stuecklistevonartikel='$id'";

      $preis = $preis + $this->app->DB->Select($sql);

      $this->app->Tpl->Add(INHALT,"<div class=\"info\">St&uuml;cklisten Grundpreis bei Menge 1: <b>$preis EUR</b></div>");
      $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
      $this->app->Tpl->Parse(PAGE,"einkaufspreiseuebersicht_stueckliste.tpl");
    }

  }
  
 
  function ArtikelEinkaufEditPopup()
  {
    //$frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(OPENDISABLE,"<!--");
    $this->app->Tpl->Set(CLOSEDISABLE,"-->");
    $this->Preisrechner();


    $sid = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$id' LIMIT 1");
    $this->ArtikelMenu($sid);
    $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$sid' LIMIT 1");
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);
    $this->app->Tpl->Add(UEBERSCHRIFT," (Einkauf)");

    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=artikel&action=einkauf&id=$sid';\">");

    $widget = new WidgetEinkaufspreise($this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("close_refresh",
	"index.php?module=artikel&action=einkauf&id=$sid#tabs-1");
    $widget->Edit();
    


    $this->app->Tpl->Add(TAB2,"Sie bearbeiten gerade einen Einkaufspreis. Erst nach dem Speichern k&ouml;nnen neue Preise angelegt werden.");
    $this->app->Tpl->Add(TAB3,"Sie bearbeiten gerade einen Einkaufspreis. Erst nach dem Speichern k&ouml;nnen Statistiken betrachtet werden.");
/*
    $widget = new WidgetEinkaufspreise(&$this->app,TAB2);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=einkauf&id=$id");
    $widget->Create();
*/
    $this->app->Tpl->Parse(PAGE,"einkaufspreiseuebersicht.tpl");
  }

  function ArtikelEinkaufDisable()
  {
 //   $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");


    $this->app->DB->Update("UPDATE einkaufspreise SET gueltig_bis=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=einkauf&id=".$sid);
    exit;


  }

  function ArtikelEinkaufDelete()
  {
//    $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");


    $this->app->DB->Update("UPDATE einkaufspreise SET geloescht='1',gueltig_bis=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=einkauf&id=".$sid);
    exit;


  }



  function ArtikelEinkaufCopy()
  {
    $id = $this->app->Secure->GetGET("id");

    $id = $this->app->DB->MysqlCopyRow("einkaufspreise","id",$id);
    $this->app->DB->Update("UPDATE einkaufspreise SET geloescht='0', gueltig_bis='0000-00-00' WHERE id='$id' LIMIT 1");


    //$this->app->DB->Update("UPDATE einkaufspreise SET geloescht='1' WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=artikel&action=einkauf&id=".$sid);
    exit;


  }


  function ArtikelCopy()
  {
    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->MysqlCopyRow("artikel","id",$id);
    
    $idnew = $this->app->DB->GetInsertID();
    $this->app->DB->Update("UPDATE artikel SET nummer='' WHERE id='$idnew' LIMIT 1");
    
    // wenn stueckliste
    $stueckliste = $this->app->DB->Select("SELECT stueckliste FROM artikel WHERE id='$id' LIMIT 1");
    if($stueckliste==1)
    {
    
    	$artikelarr = $this->app->DB->SelectArr("SELECT * FROM stueckliste WHERE stuecklistevonartikel='$id'");
    	for($i=0;$i<count($artikelarr);$i++)
    	{
    		$sort = $artikelarr[$i]['sort'];	
    		$artikel = $artikelarr[$i]['artikel'];	
    		$referenz = $artikelarr[$i]['referenz'];	
    		$place = $artikelarr[$i]['place'];	
    		$layer = $artikelarr[$i][layer];	
    		$stuecklistevonartikel = $idnew;	
    		$menge = $artikelarr[$i][menge];
    		$firma = $artikelarr[$i][firma];
    		 
    		$this->app->DB->Insert("INSERT INTO stueckliste (id,sort,artikel,referenz,place,layer,stuecklistevonartikel,menge,firma) VALUES
    		('','$sort','$artikel','$referenz','$place','$layer','$stuecklistevonartikel','$menge','$firma')");	

    	}
   	 
    }


		//TODO hinweis es wuren keine Preise kopiert


		// artikelbilder kopieren



    // eventuell einkaufspreise verkaufspreise und stueckliste kopieren?
    $msg = base64_encode("<div class=error>Sie befinden sich in der neuen Kopie des Artikel. Bitte legen Sie Verkaufs- und Einkaufspreise und Bilder bzw. Dateien an! Dies wurden nicht kopiert!</div>"); 
    header("Location: index.php?module=artikel&action=edit&msg=$msg&id=".$idnew);
    exit;

  }





  function ArtikelProjekte()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Projekte)");
    $this->ArtikelMenu();
    $this->app->Tpl->Set(PAGE,"hier sieht man in welchen projekten es verwendet wird");
  }

  function ArtikelLager()
  {
    $id = $this->app->Secure->GetGET("id");
    $msg = $this->app->Secure->GetGET("msg");

    $msg = base64_decode($msg);
    $this->app->Tpl->Set(MESSAGE,$msg);

    $this->ArtikelMenu();
    $this->app->Tpl->Add(TAB1,"<h2>Lagerbestand</h2>");

    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT lp.kurzbezeichnung, lpi.menge as menge, lpi.vpe as VPE,p.abkuerzung as projekt, 
      lpi.id FROM lager_platz_inhalt lpi LEFT JOIN lager_platz as lp ON lpi.lager_platz=lp.id LEFT JOIN projekt p ON lpi.projekt=p.id  WHERE lpi.artikel='$id' ");

    if($this->app->User->GetType()=="admin")
    $table->DisplayNew(INHALT,"<a onclick=\"var menge =  prompt('St&uuml;ckzahl der Artikel die aus diesem Regal genommen werden sollen:',1); var grund =  prompt('Auslagerungsgrund:','Muster'); if(menge > 0) window.location.href='index.php?module=artikel&action=auslagern&id=$id&lid=%value%&menge='+menge+'&grund='+grund;\" href=\"#\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>");
    else
    $table->DisplayNew(INHALT,"");

    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBSUBHEADING,"Reservierungen Stand ".date('d.m.Y'));
    $this->app->Tpl->Add(TAB1,"<h2>Reservierungen</h2>");

    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT adr.name as kunde, a.name_de as Artikel,r.menge,p.abkuerzung as projekt,r.grund, r.id FROM lager_reserviert r LEFT JOIN artikel a ON a.id=r.artikel LEFT JOIN projekt p ON 
        p.id=r.projekt LEFT JOIN adresse adr ON r.adresse=adr.id WHERE r.firma='{$this->app->User->GetFirma()}' AND a.id='$id'");


    $summe = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$id'");
    $reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='$id' AND datum >= NOW()");
    if($this->app->User->GetType()=="admin")
    $table->DisplayNew(INHALT,"<a onclick=\"var menge =  prompt('Anzahl Artikel aus Reservierung entfernen:',1); if(menge > 0) window.location.href='index.php?module=artikel&action=ausreservieren&id=$id&lid=%value%&menge='+menge;\" href=\"#\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>");
    else
    $table->DisplayNew(INHALT, "");
    
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $auftraege = $this->app->DB->Select("SELECT SUM(ap.menge) menge,ap.bezeichnung FROM auftrag_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE a.id='$id' AND a.lagerartikel=1");
    $liefern= $this->app->DB->Select("SELECT SUM(ap.menge) menge,ap.bezeichnung FROM auftrag_position ap, auftrag aa, artikel a WHERE a.id=ap.artikel AND aa.id = ap.auftrag AND a.id='$id' AND a.lagerartikel=1 AND aa.status='freigegeben'");


    $rest = $summe - $liefern;

    if($reserviert=="") $reserviert =0;

    $this->app->Tpl->Add(TAB1,"Lagerbestand: $summe &nbsp;| &nbsp;Reserviert: $reserviert &nbsp;|&nbsp;Gesamt in Auftr&auml;gen: $auftraege&nbsp;|&nbsp;Noch liefern: $liefern&nbsp;|&nbsp;Restbestand: $rest<br><br>");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Add(TAB1,"<h2>Lagerplatz Bewegungen</h2>");
    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(lpi.zeit,'%d.%m.%Y') as datum, lp.kurzbezeichnung, lpi.menge as menge, lpi.vpe as VPE, if(lpi.eingang,'Eingang','Ausgang') as Richtung, substring(lpi.referenz,1,40) as referenz, lpi.bearbeiter as bearbeiter, p.abkuerzung as projekt, 
      lpi.id FROM lager_bewegung lpi LEFT JOIN lager_platz as lp ON lpi.lager_platz=lp.id LEFT JOIN projekt p ON lpi.projekt=p.id  WHERE lpi.artikel='$id' order by lpi.zeit");
    //$table->DisplayNew(INHALT,"<a href=\"index.php?module=bestellung&action=edit&id=%value%\">Bestellung</a>");
    $table->DisplayNew(INHALT,"");
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(TABTEXT,"Lagerbestand");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function ArtikelSeriennumern()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Seriennummern)");
    $this->ArtikelMenu();
    $this->app->Tpl->Set(PAGE,"Seriennummern?");
  }

  function ArtikelStueckliste()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (St&uuml;ckliste)");
    $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");

    if($this->app->Secure->GetPOST("artikel")!="")
      $this->app->Tpl->Set(AKTIV_TAB2,"selected");
    else
      $this->app->Tpl->Set(AKTIV_TAB1,"selected");

    // neues arbeitspaket
    $widget = new WidgetStueckliste($this->app,TAB2);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=stueckliste&id=$id");
    $this->app->Tpl->Set(TMPSCRIPT,"<script type=\"text/javascript\">$(document).ready(function(){ $('#tabs').tabs('select', 1); });</script>");
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=stueckliste&id=$id#tabs-1");



    $widget->Create();


    $this->app->YUI->TableSearch(TAB1,"stueckliste");
  
    // gehe stueckliste durch und schaue ob es maximal artikel ist 
    $artikel = $this->app->DB->SelectArr("SELECT * FROM stueckliste WHERE stuecklistevonartikel='$id'");
    $stueck = 0;

    $kleinste_max_menge = 0;
    for($i=0;$i<count($artikel);$i++)
    {
   	$artikelid = $artikel[$i]['artikel']; 
   	$mengeimlage = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikelid'"); 
   	$mengereserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='$artikelid'"); 
   	
   	$mengefrei = $mengeimlage - $mengereserviert;
   	
   	$max_menge = floor($mengefrei/$artikel[$i]['menge']);
        $collect[] = $max_menge;

    }
    if(is_array($collect))
    {
      sort($collect);
      $stueck = $collect[0];
    } else 
      $stueck = 0;
    
    $this->app->Tpl->Add(TAB1,"<div class=\"info\">Aktuell k&ouml;nnen $stueck St&uuml;ck produziert werden (<a href=\"index.php?module=artikel&action=stuecklisteetiketten&id=".$id."\">Etiketten f&uuml;r St&uuml;ckliste drucken</a>)</div>");

/*
    // child table einfuegen
   
    $menu = array(//"up"=>"upstueckliste",
		  //"down"=>"downstueckliste",
		  //"add"=>"addstueckliste",
		  "edit"=>"editstueckliste",
		  "del"=>"delstueckliste");

    $sql = "SELECT a.name_de as Artikel, a.nummer, s.menge, s.place, s.layer, s.id 
	FROM stueckliste s
        LEFT JOIN artikel a ON a.id=s.artikel 
        WHERE stuecklistevonartikel='$id'";   
 
    $this->app->YUI->SortList(INHALT,&$this,$menu,$sql);
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
*/
    $this->app->Tpl->Parse(PAGE,"stuecklisteuebersicht.tpl");
  }

  function UpStueckliste()
  {
    $this->app->YUI->SortListEvent("up","stueckliste","stuecklistevonartikel");
    $this->ArtikelStueckliste();
  }

  function DownStueckliste()
  {
    $this->app->YUI->SortListEvent("down","stueckliste","stuecklistevonartikel");
    $this->ArtikelStueckliste();
  }


  function DelStueckliste()
  {
    $id = $this->app->Secure->GetGET("id");
    $sort = $this->app->DB->Select("SELECT sort FROM stueckliste WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT stuecklistevonartikel FROM stueckliste WHERE id='$id' LIMIT 1");

    $this->app->DB->Delete("DELETE FROM stueckliste WHERE id='$id' LIMIT 1");

    $this->app->DB->Delete("UPDATE stueckliste SET sort=sort-1 WHERE stuecklistevonartikel='$sid' AND sort > $sort LIMIT 1");

    header("Location: index.php?module=artikel&action=stueckliste&id=".$sid);
    exit;

  }



  function ArtikelStuecklisteEditPopup()
  {
    $id = $this->app->Secure->GetGET("id");

    $sid = $this->app->DB->Select("SELECT stuecklistevonartikel FROM stueckliste WHERE id='$id' LIMIT 1");
    $this->ArtikelMenu($sid);
    $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$sid' LIMIT 1");
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);
    $this->app->Tpl->Add(UEBERSCHRIFT," (St&uuml;ckliste)");

    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=artikel&action=stueckliste&id=$sid';\">");

    $widget = new WidgetStueckliste($this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("close_refresh",
	"index.php?module=artikel&action=stueckliste&id=$sid#tabs-1");
    $widget->Edit();

    $this->app->Tpl->Add(TAB2,"Sie bearbeiten gerade einen Position der St&uuml;ckliste. Erst nach dem Speichern k&ouml;nnen neue Positionen angelegt werden.");
    //$this->app->Tpl->Add(TAB3,"Sie bearbeiten gerade einen Verkaufspreis. Erst nach dem Speichern k&ouml;nnen Statistiken betrachtet werden.");
    $this->app->Tpl->Parse(PAGE,"stuecklisteuebersicht.tpl");
  }



  function ArtikelStatistik()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ArtikelMenu();

    $this->app->Tpl->Set(TABTEXT,"Statistik");
    $this->app->Tpl->Set(TAB1,"<h2>Abgeschlossene Auftr&auml;ge</h2>");
    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT  EXTRACT(YEAR FROM a.datum) as jahr,  EXTRACT(MONTH FROM a.datum) as monat, SUM(ap.menge) as menge
	FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$id' AND a.status='abgeschlossen' GROUP By monat,jahr ORDER by jahr DESC, monat DESC");
    //$table->DisplayNew(INHALT,"<a href=\"index.php?module=bestellung&action=edit&id=%value%\">Bestellung</a>");
    $table->DisplayNew(TAB1,"Gelieferte","noAction");


    $gesamt = $this->app->DB->Select("SELECT SUM(ap.menge) as menge
        FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$id' AND a.status='abgeschlossen' ");
    $this->app->Tpl->Add(TAB1,"Gesamt: $gesamt St&uuml;ck");


    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }



  function ArtikelOffeneBestellungen()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABTEXT,"Bestellungen");
    $this->ArtikelMenu();

    // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(b.datum,'%d.%m.%Y') as datum, CONCAT('<a href=\"index.php?module=bestellung&action=edit&id=',b.id,'\" target=\"_blank\">',b.belegnr,'</a>') as 'bestellung Nr.', bp.bestellnummer as Nummer, bp.menge, bp.geliefert, bp.vpe as VPE, a.name as lieferant, b.status as status_Bestellung, bp.bestellung
      FROM bestellung_position bp LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN adresse a ON b.adresse=a.id
      WHERE artikel='$id' ORDER by b.datum DESC");
    $table->DisplayNew(TAB1,"<a href=\"index.php?module=bestellung&action=pdf&id=%value%\"><img src=\"./themes/new/images/pdf.png\" border=\"0\"></a>&nbsp;
      <a href=\"index.php?module=bestellung&action=edit&id=%value%\"><img src=\"./themes/new/images/edit.png\" border=\"0\"></a>");

    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

  function ArtikelAuslagern()
  {
    $id = $this->app->Secure->GetGET("id");
    $lid = $this->app->Secure->GetGET("lid");
    $menge = $this->app->Secure->GetGET("menge");
    $grund = $this->app->Secure->GetGET("grund");

    // menge holen in lagerregaplplatz
    $menge_lager = $this->app->DB->Select("SELECT menge FROM lager_platz_inhalt WHERE id='$lid' LIMIT 1");
    $lager_platz = $this->app->DB->Select("SELECT lager_platz FROM lager_platz_inhalt WHERE id='$lid' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM lager_platz_inhalt WHERE id='$lid' LIMIT 1");

    $neuemenge = $menge_lager - $menge;

//echo "menge_lager = $menge_lager; menge raus = $menge; neuemenge = $neuemenge; lid=$lid";

    if($menge_lager <= $menge)
      $this->app->DB->Delete("DELETE FROM lager_platz_inhalt WHERE id='$lid' LIMIT 1");
    else 
      $this->app->DB->Update("UPDATE lager_platz_inhalt SET menge='$neuemenge' WHERE id='$lid' LIMIT 1");

    // protokoll eintrag in bewegung
    $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz,artikel,menge,eingang,zeit,referenz,bearbeiter,firma,projekt) 
	VALUES ('','$lager_platz','$id','$menge','0',NOW(),'Manuell Bestand angepasst (".$grund.")','".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$projekt')");

    if($menge_lager < $menge) $menge = $menge_lager;

   
    $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
    $msg = base64_encode("<div class=\"error\">Der Artikel \"$name_de\" wurde $menge mal ausgelagert.</div>");

    header("Location: index.php?module=artikel&action=lager&id=$id&msg=$msg");
    exit;
  }

  function ArtikelAusreservieren()                                                                                                                                                                                   
    {                                                                                                                                                                   
        $id = $this->app->Secure->GetGET("id");                                                                                                                           
	$lid = $this->app->Secure->GetGET("lid");                                                                                                                         
	$menge = $this->app->Secure->GetGET("menge");                                                                                                                                                               
	// menge holen in lagerregaplplatz                                                                                                                                                                          
	$menge_lager = $this->app->DB->Select("SELECT menge FROM lager_reserviert WHERE id='$lid' LIMIT 1");                                                                                                      
	$neuemenge = $menge_lager - $menge;                                                                                                                           
	//echo "menge_lager = $menge_lager; menge raus = $menge; neuemenge = $neuemenge; lid=$lid";                                                                                                                     
	if($menge_lager <= $menge)                                                                                                                                                                                  
	$this->app->DB->Delete("DELETE FROM lager_reserviert WHERE id='$lid' LIMIT 1");                                                                                                                         
	else                                                                                                                                                                                                        
	$this->app->DB->Update("UPDATE lager_reserviert SET menge='$neuemenge' WHERE id='$lid' LIMIT 1");                                                                                                       
	if($menge_lager < $menge) $menge = $menge_lager;                                                                                                                                                            

	$name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");                                                                                                                    
	$msg = base64_encode("<div class=\"error\">Die Reservierung \"$name_de\" wurde $menge mal entfernt.</div>");                                                                                                  
	header("Location: index.php?module=artikel&action=lager&id=$id&msg=$msg");                                                                                                                                  
	exit;                                                                                                                                                                                                       
}

  function ArtikelDelete()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->DB->Update("UPDATE artikel SET geloescht='1' WHERE id='$id' LIMIT 1");
    $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Der Artikel \"$name_de\" wurde gel&ouml;scht</div>");

    $this->ArtikelList();
  }
 
  function ArtikelCreate()
  {
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel (Neu anlegen)");

		if($this->app->Secure->GetPOST("name_de")=="")
		$this->app->Tpl->Set(MESSAGE,"<div class=\"info\">M&ouml;chten Sie den <a href=\"index.php?module=wizard&action=create\">Artikel-Assistent</a> zum Anlegen werden?</div>");

    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=artikel&action=list';\">");
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Artikel anlegen");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=list","Zur&uuml;ck zur &Uuml;bersicht");
    parent::ArtikelCreate();
  }

  function ArtikelList()
  {

    //$this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=wizard&action=create","Artikel-Assistent");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=create","Neuen Artikel anlegen");
//    $this->app->erp->MenuEintrag("index.php?module=artikel&action=lagerlampe","Lagerlampen berechnen");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikelsuche");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Artikelsuche");

    $this->app->YUI->TableSearch(TAB1,"artikeltabelle");
    $this->app->Tpl->Parse(PAGE,"artikeluebersicht.tpl");


  }

  
  function ArtikelMenu($id="")
  {
    if(!is_numeric($id))
      $id = $this->app->Secure->GetGET("id");

    $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id=$id LIMIT 1"); 
    $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id=$id LIMIT 1"); 

    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Artikel $nummer");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT2,$this->app->erp->LimitChar($name_de,30));


    $tmp = $this->app->DB->SelectArr("SELECT * FROM artikel WHERE id='$id' LIMIT 1");

    $this->app->erp->MenuEintrag("index.php?module=artikel&action=edit&id=$id","Details");

    if($tmp[0][stueckliste]==1)
      $this->app->erp->MenuEintrag("index.php?module=artikel&action=stueckliste&id=$id","St&uuml;ckliste");

    $this->app->erp->MenuEintrag("index.php?module=artikel&action=dateien&id=$id","Dateien");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=einkauf&id=$id","Einkauf");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=verkauf&id=$id","Verkauf");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=statistik&id=$id","Statistik");


    if($tmp[0][lagerartikel]=="1")
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=lager&id=$id","Lagerbestand");

//    if($tmp[0][seriennummern]!="keine")
//    $this->app->erp->MenuEintrag("index.php?module=artikel&action=seriennummern&id=$id","Seriennummern");


  //  if($tmp[0][provisionsartikel]=="1")
  //  $this->app->erp->MenuEintrag("index.php?module=artikel&action=provisionen&id=$id","Provisionen");

//    if($tmp[0][lagerartikel]=="1")
      $this->app->erp->MenuEintrag("index.php?module=artikel&action=etiketten&id=$id","Etiketten");

    $this->app->erp->MenuEintrag("index.php?module=artikel&action=offenebestellungen&id=$id","Bestellungen");

    $this->app->erp->MenuEintrag("index.php?module=artikel&action=offeneauftraege&id=$id","Auftr&auml;ge");

  //  if($tmp[0][lagerartikel]=="1")
  //    $this->app->erp->MenuEintrag("index.php?module=artikel&action=reservierung&id=$id","Reservierungen");

 //   if($tmp[0][stueckliste]!="1")
 //     $this->app->erp->MenuEintrag("index.php?module=artikel&action=wareneingang&id=$id","Wareneingang");

//    if($tmp[0][endmontage]=="1")
//      $this->app->erp->MenuEintrag("index.php?module=artikel&action=wareneingang&id=$id","Produktion");

 //   $this->app->erp->MenuEintrag("index.php?module=artikel&action=projekte&id=$id","Projekte");
//    $this->app->erp->MenuEintrag("index.php?module=artikel&action=create","Neuen Artikel anlegen");

    $this->app->erp->MenuEintrag("index.php?module=artikel&action=list","Zur&uuml;ck zur &Uuml;bersicht");
  }


  function ArtikelEdit()
  {
    $id = $this->app->Secure->GetGET("id"); 

    $msg = $this->app->Secure->GetGET("msg"); 
    $msg = base64_decode($msg);

		$this->app->Tpl->Set(MESSAGE,$msg);

		$mark = $this->app->Secure->GetPOST('bookmark');
		if($mark!='' && !in_array($id, $_SESSION['bookmarked'])) {
			$_SESSION['bookmarked'][] = $id; 
		}

	
    $juststueckliste= $this->app->DB->Select("SELECT juststueckliste FROM artikel WHERE id='$id' LIMIT 1");
    $lagerartikel= $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='$id' LIMIT 1");
    $shop= $this->app->DB->Select("SELECT shop FROM artikel WHERE id='$id' LIMIT 1");

    if($shop > 0)
    {
      $this->app->Tpl->Set(SHOPEXPORBUTTON,'
    <script>
  $(function() {
  $( "#aktualisieren").button();
  });
  </script>

  <a id="aktualisieren" style="font-size: 8pt; " href="index.php?module=artikel&action=shopexport&id='.$id.'" title="Artikel im Shop aktualisieren">Artikel im Shop aktualisieren</a>');

    }

    if($lagerartikel=="1" && $juststueckliste=="1")
    {
      $this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Dieser Artikel ist als Lagerartikel und als Just-In-Time Stückliste markiert. Dies macht keinen Sinn. Bitte passen Sie den Artikel an!</div>");
    }

 
    
    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=artikel&action=list';\">");

    $anzahl_verkaufspreise = $this->app->DB->Select("SELECT SUM(id) FROM verkaufspreise WHERE artikel='$id' AND geloescht='0' AND (gueltig_bis='0000-00-00' OR gueltig_bis >=NOW())");
    if($anzahl_verkaufspreise<1)
				$this->app->Tpl->Add(MESSAGE,"<div class=\"success\">Achtung: Der Artikel hat noch keinen Verkaufspreis!</div>");

//		$this->app->erp->Standardprojekt("artikel",$id);

    //$this->app->erp->SeitenSperrInfo("Diese Seite wird soeben von Benedikt Sauter bearbeitet.<br><br>Bitte sprechen Sie sich vor &Auml;nderungen an dieser Seite entsprechend ab.");

    $this->app->Tpl->Set(OPTIONEN,'

    <script>
  $(function() {
  $( "#mehr").button();
  });
  </script>

  <a id="mehr" style="font-size: 8pt; " href="index.php?module=artikel&action=onlineshop&id='.$id.'" class="popup" title="Warengruppen / Bildauswahl">Warengruppen/Bildauswahl</a>');

    parent::ArtikelEdit();

    /* anzeige formular */ 
    $this->ArtikelMenu();
    $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);


    /* automatische nummern vergabe */
    $nummer_db = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");

    if($nummer_db=="")
    {
      header("Location: index.php?module=artikel&action=edit&id=$id&msg=$msg");
      exit;
    } 

		if($this->app->Secure->GetPOST("speichern")!="")
    {
      if($this->app->Secure->GetGET("msg")=="")
      {
        $msg = $msg.$this->app->Tpl->Get(MESSAGE);
        $msg = base64_encode($msg);
      } else {
        $msg = base64_encode($msg);
      }

      header("Location: index.php?module=artikel&action=edit&id=$id&msg=$msg");
      exit;
    } 


    /* sperrmeldung */
    $intern_gesperrt = $this->app->DB->Select("SELECT intern_gesperrt FROM artikel WHERE id='$id' LIMIT 1");
    if($intern_gesperrt)
    {
      if($this->app->erp->CheckSamePage())
      {
	$intern_gesperrtgrund = $this->app->DB->Select("SELECT intern_gesperrtgrund FROM artikel WHERE id='$id' LIMIT 1");
	$this->app->erp->SeitenSperrAuswahl("Wichtiger Hinweis",$intern_gesperrtgrund);
      }
    }
  }



  function ArtikelEtiketten()
  {
    $this->app->Tpl->Add(UEBERSCHRIFT," (Etiketten)");
    $id = $this->app->Secure->GetGET("id");
    $menge = $this->app->Secure->GetPOST("menge");
    $this->ArtikelMenu();
    $this->app->Tpl->Set(TAB1,"<form action=\"\" method=\"post\"><input type=\"text\" name=\"menge\">&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Drucken\"></form><br>");

    $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$id' LIMIT 1");

    if($standardbild=="")
      $standardbild = $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE subjekt='Shopbild' AND objekt='Artikel' AND parameter='$id' LIMIT 1");




    $this->app->Tpl->Add(TAB1,"<img src=\"index.php?module=dateien&action=send&id=$standardbild\" width=\"200\">");

    if($menge!="")
    {
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
      $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $name_de = base64_encode($name_de);

      $ch=0;
      $etiketten ="klein";
      if(is_numeric($menge))$druckanzahl=$menge;
      HttpClient::quickGet("http://192.168.0.178/druck.php?nr=$nummer&ch=$ch&anzahl=$druckanzahl&etikett=$etiketten&beschriftung=$name_de");
    }

      $this->app->Tpl->Set(TABTEXT,"Etiketten");
      $this->app->Tpl->Parse(PAGE,"tabview.tpl");
/*
    $barcode = $this->app->DB->Select("SELECT barcode FROM artikel WHERE id='{$id}' LIMIT 1");
    $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='{$id}' LIMIT 1");

    $tmp = new etiketten(&$app);
    $tmp->Artikel($barcode,$nummer,65);
    $tmp->Druck();
    exit;
*/
  }
 
  function ArtikelOnlineShop()
  {
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
    //if($frame=="false")
    //{
      // hier nur fenster größe anpassen
    //  $this->app->YUI->IframeDialog(500,400);
    //} else {
      // nach page inhalt des dialogs ausgeben
//      $sid = $this->app->DB->Select("SELECT artikel FROM artikel_artikelgruppe WHERE id='$id' LIMIT 1");
      //$widget = new WidgetVerkaufspreise(&$this->app,PAGE);
      //$widget->form->SpecialActionAfterExecute("close_refresh",
      //	"index.php?module=artikel&action=verkauf&id=$sid");


      // neue warengruppe hinzugefuegt
      $artikelgruppe = $this->app->Secure->GetPOST("artikelgruppe");
      $ok= $this->app->Secure->GetPOST("ok");
      if($artikelgruppe!="" && $ok=="") $this->app->DB->Insert("INSERT INTO artikel_artikelgruppe (id,artikel,artikelgruppe) VALUES ('','$id','$artikelgruppe')");


      //warengruppe geloescht
      $sid= $this->app->Secure->GetGET("sid");
      $cmd= $this->app->Secure->GetGET("cmd");
      if($sid!="" && $cmd=="del") $this->app->DB->DELETE("DELETE FROM artikel_artikelgruppe WHERE id='$sid' LIMIT 1");
      if($sid!="" && $cmd=="image") $this->app->DB->DELETE("UPDATE artikel SET standardbild='$sid' WHERE id='$id' LIMIT 1");

      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
      $this->app->Tpl->Set(SUBSUBHEADING,"Online-Shop Attribute: $name ($nummer)");
      $this->app->Tpl->Set(AKTIV_TAB1,"selected");

      //Warengruppen
      $tmp = new EasyTable($this->app);
      $tmp->Query("SELECT a.bezeichnung, aa.id FROM artikel_artikelgruppe aa LEFT JOIN artikelgruppen a ON a.id=aa.artikelgruppe WHERE artikel='$id'");
      $tmp->DisplayNew(WARENGRUPPEN,"<a href=\"#\" onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=artikel&cmd=del&action=onlineshop&id=$id&sid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>");

      $shop = $this->app->DB->Select("SELECT shop FROM artikel WHERE id='$id' LIMIT 1");

      $arr = $this->app->DB->SelectArr("SELECT bezeichnung,id FROM artikelgruppen WHERE shop='$shop'");

      foreach($arr as $key=>$value)
	$html.="<option value=\"{$value[id]}\">{$value[bezeichnung]}</option>";
 
      $this->app->Tpl->Add(WARENGRUPPEN,"<center><select name=\"artikelgruppe\">$html</select>");
      $this->app->Tpl->Add(WARENGRUPPEN,"<input type=submit value=\"hinzuf&uuml;gen\"></center>");

      // standard bild
      $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$id'");
      $tmp = new EasyTable($this->app);
      $tmp->Query("SELECT d.titel, d.id FROM datei d LEFT JOIN datei_stichwoerter s ON d.id=s.datei  
      LEFT JOIN datei_version v ON v.datei=d.id
      WHERE s.objekt='Artikel' AND s.parameter='$id' AND s.subjekt='Shopbild' AND d.geloescht=0");

      $tmp->DisplayNew(HAUPTBILD,
	"<a href=\"#\" onclick=\"if(!confirm('Als Standard definieren?')) return false; else window.location.href='index.php?module=artikel&action=onlineshop&cmd=image&id=$id&sid=%value%';\"><img src=\"./themes/[THEME]/images/ack.png\" border=\"0\"></a>");

      $standardbild_name = $this->app->DB->Select("SELECT titel FROM datei WHERE id='$standardbild'");
      $this->app->Tpl->Add(HAUPTBILD,"<br>Standardbild: <b>$standardbild_name</b>");





      $this->app->Tpl->Parse(PAGE,"onlineshop.tpl");

      $this->app->BuildNavigation=false;
    //}
  }

  function ArtikelNewList()
  {

    $this->app->Tpl->Parse(PAGE,"datatable.tpl");

  }

}

?>
