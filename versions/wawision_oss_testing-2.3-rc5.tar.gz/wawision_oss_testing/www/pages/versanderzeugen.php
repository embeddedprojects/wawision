<?php

class Versanderzeugen 
{

  function Versanderzeugen(&$app)
  {
    $this->app=&$app; 
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("main","VersanderzeugenMain");
    $this->app->ActionHandler("list","VersanderzeugenList");
    $this->app->ActionHandler("offene","VersanderzeugenOffene");
    $this->app->ActionHandler("einzel","VersanderzeugenEinzel");
    $this->app->ActionHandler("delete","VersanderzeugenDelete");
    $this->app->ActionHandler("frankieren","VersanderzeugenFrankieren");
  
    $this->app->DefaultActionHandler("list");

    
		$this->app->Tpl->Set(KURZUEBERSCHRIFT,"Versand");
    $this->app->ActionHandlerListen($app);
  }

  function VersanderzeugenDelete()
  {
    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Delete("DELETE FROM versand WHERE id='$id' LIMIT 1");

    header("Location: index.php?module=versanderzeugen&action=offene");
    exit;
  }


	function VersandMenu()
	{
    $this->app->erp->MenuEintrag("index.php?module=versanderzeugen&action=offene","Zur&uuml;ck zur &Uuml;bersicht");

	}

  function VersanderzeugenEinzel()
  {
    $id = $this->app->Secure->GetGET("id");

		$this->VersandMenu();


    $name = $this->app->DB->Select("SELECT r.name FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.ansprechpartner FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.abteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.unterabteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.adresszusatz FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.strasse FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT CONCAT(r.land,'-',r.plz,' ',r.ort) FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");

    $name = $this->app->DB->Select("SELECT l.name FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.ansprechpartner FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.abteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.unterabteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.adresszusatz FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.strasse FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT CONCAT(l.land,'-',l.plz,' ',l.ort) FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");


    $name = $this->app->DB->Select("SELECT r.zahlungsweise FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    $versandart = $this->app->DB->Select("SELECT l.versandart FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");

    //if($name=="nachnahme") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Nachnahme Lieferung!</div><script type=\"text/javascript\">alert('ACHTUNG NACHNAHME!');</script>");
    if($name=="nachnahme") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Nachnahme Lieferung!</div>");
    if($name=="bar") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung Barzahlung!</div>");
    if($versandart=="selbstabholer") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung Selbstaboler!</div>");
    if($versandart=="packstation") $this->app->Tpl->Add(INFORMATION,"<div class=\"warnung\">Achtung Packstation!</div>");



    $this->app->Tpl->Parse(TAB1,"versandeinzel.tpl");

    $artikel = $this->app->Secure->GetPOST("artikel");
    $posold= $this->app->Secure->GetPOST("posold");
    $seriennummer  = $this->app->Secure->GetPOST("seriennummer");
    $lieferschein = $this->app->DB->Select("SELECT lieferschein FROM versand WHERE id='$id' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $rechnung = $this->app->DB->Select("SELECT rechnung FROM versand WHERE id='$id' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $auftrag= $this->app->DB->Select("SELECT auftrag FROM lieferschein WHERE id='$lieferschein' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $land = $this->app->DB->Select("SELECT land  FROM lieferschein WHERE id='$lieferschein' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $auftragid= $this->app->DB->Select("SELECT id FROM auftrag WHERE belegnr='$auftrag' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $auftragsart= $this->app->DB->Select("SELECT art FROM auftrag WHERE belegnr='$auftrag' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $artikelid = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$artikel' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $seriennummern= $this->app->DB->Select("SELECT seriennummern FROM artikel WHERE id='$artikelid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='$artikelid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

    //wenn seriennummer dann update und weiter mit naechsten artikel
    if($seriennummer!="")
    {
	//oder tabelle seriennummern
	$tmpseriennummer = $this->app->DB->Select("SELECT seriennummer FROM lieferschein_position WHERE lieferschein='$lieferschein' AND artikel='$artikelid' AND geliefert<=menge LIMIT 1");
	if($tmpseriennummer!="")$tmpseriennummer = $tmpseriennummer .' '.$seriennummer;	 else $tmpseriennummer=$seriennummer;
	$this->app->DB->Update("UPDATE lieferschein_position SET seriennummer='$tmpseriennummer' WHERE id='$posold' AND lieferschein='$lieferschein' AND artikel='$artikelid'");

	$adresse = $this->app->DB->Select("SELECT adresse FROM versand WHERE id='$id' LIMIT 1");
	$name_de= $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikelid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
	$this->app->DB->Insert("INSERT INTO seriennummern (id,seriennummer,adresse,artikel,beschreibung,lieferung,lieferschein,bearbeiter,logdatei)
	  VALUES ('','$seriennummer','$adresse','$artikelid','$name_de',DATE_FORMAT(NOW(),'%Y-%m-%d'),'$lieferschein','".$this->app->User->GetName()."',NOW())");
    } else {

    // wenn artikel pass in lieferschein und auftrag erhoehen und aus zwischenlager nehmen
    $pos = $this->app->DB->Select("SELECT id FROM lieferschein_position WHERE lieferschein='$lieferschein' AND artikel='$artikelid' AND geliefert<menge LIMIT 1");
    $posauftrag = $this->app->DB->Select("SELECT id FROM auftrag_position WHERE auftrag='$auftragid' AND artikel='$artikelid' AND geliefert_menge<menge LIMIT 1");
    if($pos > 0)
    {
      // immer einzeln scannen
      //artikel kann wieder 1 - n mal bei 1 - m positionen vorkommen!!!
      $tmpgeliefert  = $this->app->DB->Select("SELECT geliefert FROM lieferschein_position WHERE lieferschein='$lieferschein' AND artikel='$artikelid' AND geliefert<menge LIMIT 1");
      $tmpgeliefert++;
      $this->app->DB->Update("UPDATE lieferschein_position SET geliefert='$tmpgeliefert' WHERE id='$pos' AND lieferschein='$lieferschein' AND artikel='$artikelid' LIMIT 1");


      $tmpgeliefertauftrag  = $this->app->DB->Select("SELECT geliefert_menge FROM auftrag_position WHERE auftrag='$auftrag' AND artikel='$artikelid' AND geliefert_menge<menge LIMIT 1");
      $tmpgeliefertauftrag++;
      $this->app->DB->Update("UPDATE auftrag_position SET geliefert_menge='$tmpgeliefertauftrag' WHERE id='$posauftrag' AND auftrag='$auftragid' AND artikel='$artikelid' LIMIT 1");

      $this->app->DB->Update("UPDATE auftrag_position SET geliefert='1' WHERE auftrag='$auftragid' AND artikel='$artikelid' AND geliefert_menge=menge AND geliefert!='1' LIMIT 1");
      //echo "artikel kommt in lieferung vor";

      //artikel aus zwischenlager nehmen!!!!
      $zwischenlagerid = $this->app->DB->Select("SELECT id FROM zwischenlager WHERE objekt='lieferung' AND artikel='$artikelid' AND menge > 0 LIMIT 1");
      $zwischenlagermenge = $this->app->DB->Select("SELECT menge FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
      $zwischenlagermenge = $zwischenlagermenge -1;
      $this->app->DB->Update("UPDATE zwischenlager SET menge='$zwischenlagermenge' WHERE id='$zwischenlagerid' LIMIT 1");
      $this->app->DB->Delete("DELETE FROM zwischenlager WHERE menge='0'");

    } 
    else { $artikelfalsch=1; }


    } 
    $summemenge = $this->app->DB->Select("SELECT SUM(lp.menge) FROM lieferschein_position lp, artikel a 
	WHERE a.id=lp.artikel AND lp.lieferschein='$lieferschein' AND (a.lagerartikel=1 OR a.porto=0) AND a.juststueckliste=0");
    $summegeliefert = $this->app->DB->Select("SELECT SUM(lp.geliefert) FROM lieferschein_position lp, artikel a 
	WHERE a.id=lp.artikel AND lp.lieferschein='$lieferschein' AND (a.lagerartikel=1 OR a.porto=0) AND a.juststueckliste=0");
    if($summegeliefert>=$summemenge)
      $komplett = 1;
 
    
    if(($seriennummern=="eigene" || $seriennummern=="vomprodukt") && $artikel!="" && $seriennummer=="")
    {
      $this->app->Tpl->Add(TAB1,"<form action=\"\" method=\"post\">
	<div class=\"warning\">Bitte Seriennummer eingeben und auf weiter klicken: <input type=\"text\" size=\"30\" name=\"seriennummer\" id=\"erstes\"><input type=\"hidden\" name=\"artikel\" value=\"$artikel\">
	  <input type=\"hidden\" name=\"posold\" value=\"$pos\">&nbsp;<input type=\"submit\" value=\"weiter\"></div></form>");
	$this->app->Tpl->Add(TAB1,"<script type=\"text/javascript\">document.getElementById(\"erstes\").focus(); </script>");
    } 
    else if($artikelfalsch && $artikel!="" && $posold=="")
    {
      $this->app->Tpl->Add(TAB1,"<div class=\"error\" align=\"center\">Artikel ist in Lieferung nicht enthalten, bzw. befindet sich der Artikel bereits in der Lieferung!&nbsp;
	<input type=\"button\" onclick=\"window.location.href='index.php?module=versanderzeugen&action=einzel&id=$id';\" value=\"anderen Artikel scannen\"></div>");
    }
    else 
    {
      if($komplett)
      {
	$adresse = $this->app->DB->Select("SELECT adresse FROM versand WHERE id='$id' LIMIT 1");
	$projekt = $this->app->DB->Select("SELECT projekt FROM versand WHERE id='$id' LIMIT 1");
	$versandart = $this->app->DB->Select("SELECT l.versandart FROM versand v LEFT JOIN lieferschein l ON v.lieferschein=l.id WHERE v.id='$id' LIMIT 1");
	//  hier rechnung drucken
	//  hier lieferschein drucken
	$druckercode = 3; // standard = 3 // 2 buchhaltung  // 1 empfang


	if($lieferschein >0)
	{
	$Brief = new LieferscheinPDF($this->app,$projekt);
	$Brief->GetLieferschein($lieferschein);
	$tmpfile = $Brief->displayTMP();
	$this->app->printer->Drucken($druckercode,$tmpfile);
	unlink($tmpfile);
	}

	if($versandart=="selbstabholer")
	{
	  if($lieferschein >0)
	  {
	  $Brief = new LieferscheinPDF($this->app,$projekt);
	  $Brief->GetLieferschein($lieferschein,"-Doppel","Unterschrift Ware erhalten:");
	  $tmpfile = $Brief->displayTMP();
	  $this->app->printer->Drucken($druckercode,$tmpfile);
	  unlink($tmpfile);
	  }
	}


	  if($lieferschein >0)
	  {
	// Lieferschein auf versendet stellen!!!!
	$this->app->DB->Update("UPDATE lieferschein SET status='versendet',versendet='1' WHERE id='$lieferschein' LIMIT 1");
	$this->app->DB->Insert("INSERT INTO dokumente_send 
	  (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner) VALUES ('','lieferschein',NOW(),'".$this->app->User->GetName()."',
	  '$adresse','$lieferschein','versand','Mitgesendet bei Lieferung','','$projekt','')");
	  }
	//if($auftragsart=="standardauftrag" || $auftragsart==""||$auftragsart=="rma")
	if($rechnung >= 0 && is_numeric($rechnung))//$auftragsart=="standardauftrag" || $auftragsart==""||$auftragsart=="rma")
	{
	  //demodruck
	  if($rechnung>0)
	  {
	  $Brief = new RechnungPDF($this->app);
	  $Brief->GetRechnung($rechnung);
	  $tmpfile = $Brief->displayTMP();
	  $this->app->printer->Drucken($druckercode,$tmpfile);
	  unlink($tmpfile);
	// Rechnung auf versendet stellen!!!!
	
	  $this->app->DB->Insert("INSERT INTO dokumente_send 
	  (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner) VALUES ('','rechnung',NOW(),'".$this->app->User->GetName()."',
	  '$adresse','$rechnung','versand','Mitgesendet bei Lieferung','','$projekt','')");

	  $this->app->DB->Update("UPDATE rechnung SET status='versendet', versendet='1' WHERE id='$rechnung' LIMIT 1");
	  }
	}

	header("Location: index.php?module=versanderzeugen&action=frankieren&id=$id&land=$land");
	exit;

      } else {

	// TODO wenn es lagerartikel ist barcode scannen
	// sonst menge bestätigen
	if($lagerartikel==1)
	{
	$this->app->Tpl->Add(TAB1,"<form action=\"\" method=\"post\">
	  <div class=\"error\" align=\"center\">Bitte Lager-Artikel scannen: <input type=\"text\" name=\"artikel\" id=\"erstes\" size=\"30\">&nbsp;<input type=\"submit\" value=\"Artikel erfassen\" name=\"artikelerfassen\"></div></form>");
	} else 
	{
	$this->app->Tpl->Add(TAB1,"<form action=\"\" method=\"post\">
	  <div class=\"error\" align=\"center\">Bitte Artikel scannen: <input type=\"text\" name=\"artikel\" id=\"erstes\" size=\"30\">&nbsp;<input type=\"submit\" value=\"Artikel erfassen\" name=\"artikelerfassen\"></div></form>");
	}
	$this->app->Tpl->Add(TAB1,"<script type=\"text/javascript\">document.getElementById(\"erstes\").focus(); </script>");
      }
    }

    $namekunde = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
    $this->app->Tpl->Set(TABTEXT,"Versand Kunde: ".$namekunde);
      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $this->app->Tpl->Set(SUBHEADING,"Artikel Lieferungen");
    $table->Query("SELECT lp.bezeichnung, lp.nummer, lp.menge as soll, geliefert as ist
      FROM versand v LEFT JOIN lieferschein_position lp ON  v.lieferschein=lp.lieferschein WHERE v.id='$id'");
      //FROM versand v LEFT JOIN lieferschein_position lp ON  v.lieferschein=lp.lieferschein WHERE v.id='$id' AND lp.nummer!='200000' AND lp.nummer!='200001' AND lp.nummer!='200002'");
    $table->DisplayNew(INHALT,"Ist","noAction");
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }



  function VersanderzeugenFrankieren()
  {
		$this->VersandMenu();
    $id = $this->app->Secure->GetGET("id");
    $land = $this->app->Secure->GetGET("land");
    $adresse = $this->app->DB->Select("SELECT adresse FROM versand WHERE id='$id' and firma='".$this->app->User->GetFirma()."'");
    $namekunde = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
/*
    $markeadresse = $this->app->DB->SelectArr("SELECT l.name as name, l.adresszusatz as adresszusatz, 
	l.strasse as strasse,l.ort as ort,l.land as land,r.soll as betrag FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");


    $markeadresse = $markeadresse[0];

    $dhl= $this->app->Secure->GetPOST("dhl");
    if($drucken!="")
    {
      //drucke lieferscheinadresse
      $this->app->erp->EasylogPaketmarke($markeadresse['name'],$markeadresse['adresszusatz'],$markeadresse['strasse'],$markeadresse['plzi'],$markeadresse['ort'],$markeadresse['land'],1);
    }


    $nachnahme= $this->app->Secure->GetPOST("nachnahme");
    if($nachnahme!="")
    {
      //drucke lieferscheinadresse nachnahme mit rechnungssumme
      $this->app->erp->EasylogPaketmarke($markeadresse['name'],$markeadresse['adresszusatz'],$markeadresse['strasse'],$markeadresse['plzi'],$markeadresse['ort'],$markeadresse['land'],1,$markeadresse['betrag']);
    }

*/


 $versandart = $this->app->DB->Select("SELECT l.versandart FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");

    $submit = $this->app->Secure->GetPOST("submit");
    if($submit!="" && $versandart != "dhl")
    {
        $versand = $this->app->Secure->GetPOST("versand");
        $tracking= $this->app->Secure->GetPOST("tracking_$versand");

        $this->app->DB->Update("UPDATE versand SET versandunternehmen='$versand', tracking='$tracking',versendet_am=NOW(),abgeschlossen='1' WHERE id='$id' LIMIT 1");

        //versand mail an kunden
        $this->app->erp->Versandmail($id); 

        if($versand=="rma")
        {


        }

      	header("Location: index.php?module=versanderzeugen&action=offene");
    }

	

    $name = $this->app->DB->Select("SELECT r.name FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.ansprechpartner FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.abteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.unterabteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.adresszusatz FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT r.strasse FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT CONCAT(r.land,'-',r.plz,' ',r.ort) FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(ADRESSE,$name."&nbsp;<br>");

    $name = $this->app->DB->Select("SELECT l.name FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.ansprechpartner FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.abteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.unterabteilung FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.adresszusatz FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT l.strasse FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");
    $name = $this->app->DB->Select("SELECT CONCAT(l.land,'-',l.plz,' ',l.ort) FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    if($name!="") $this->app->Tpl->Add(LIEFERUNG,$name."&nbsp;<br>");

    $name = $this->app->DB->Select("SELECT r.zahlungsweise FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");
    $versandart = $this->app->DB->Select("SELECT l.versandart FROM versand v LEFT JOIN rechnung r ON r.id=v.rechnung LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.id='$id' LIMIT 1");

    if($name=="nachnahme") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Nachnahme Lieferung!</div>");
    if($name=="bar") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung Barzahlung!</div>");
    if($versandart=="selbstabholer") { $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung Selbstabholer!</div>"); $this->app->Tpl->Set(SELBSTABHOLER,"checked"); }
    if($versandart=="packstation") $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung Packstation!</div>");
    if($versandart=="DHL") $this->app->Tpl->Add(INFORMATION,"<div class=\"info\">DHL Versand</div>");
    if($versandart=="rma") { $this->app->Tpl->Add(INFORMATION,"<div class=\"error\">Achtung RMA!</div>");  $this->app->Tpl->Set(RMA,"checked"); }

    $this->app->Tpl->Parse(TAB1,"versandeinzel.tpl");

    $this->app->Tpl->Set(TABTEXT,"Versand Kunde: ".$namekunde);

    $this->app->Tpl->Set(DHL,"checked");
    $this->app->Tpl->Set(VORSCHLAG,"DHL");


    if($versandart=="packstation" || $versandart=="versandunternehmen" || $versandart=="DHL") 
      $this->app->erp->PaketmarkeDHLEmbedded(TAB1,"versand");
    else
      $this->app->Tpl->Parse(TAB1,"versandfrankieren.tpl");

    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }


  /*

wir haben die Easylog Software an unsere Wawi angebunden (CAO-Faktura) Ich habe im CAO Forum auch den SQL Code hierfür bereitgestellt. Die Trackingnummer bekommt der Kunde dann per Email aus der Easylogsoftware. Findet man unter "System" "Speziallösungen" und dann bei Sendungsbenachrichtigung. Damit der Kunde die Trackingnummer dann per Klick nachverfolgen kann musst Du folgende systax in der Email vorlage verwenden:

*/

  //http://nolp.dhl.de/nextt-online-public/report_popup.jsp?lang=de&zip=<Empf. PLZ>&idc=<Identcode>


  


  function VersanderzeugenOffene()
  {
    $this->app->Tpl->Set(HEADING,"Versandfertige Lieferungen");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Versandfertige Lieferungen");


    // suche ob es etwas im zwischenlager gibt mit lieferung
    $zaehlen = $this->app->DB->Select("SELECT COUNT(id) FROM zwischenlager WHERE objekt='lieferung'");
    $versand = $this->app->DB->Select("SELECT COUNT(id) FROM versand WHERE abgeschlossen!='1'");
   
    
    if($zaehlen<=0 && $versand > 0)
      $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Es gibt keine zu versendenden Artikel im Zwischenlager! Bitte erst Artikel aus Lager buchen!</div>");
    else if ($versand<=0)
      $this->app->Tpl->Set(MESSAGE,"<div class=\"info\">Es gibt aktuell keine zu versendenden Auftr&auml;ge!</div>");
      
      


    $projektearr = $this->app->DB->SelectArr("SELECT id FROM projekt WHERE autoversand='1' AND firma='".$this->app->User->GetFirma()."'");

    $projektearr[]=0;
    
    // start projekt schleife
    for($w=0;$w<count($projektearr);$w++)
    {
      $projekt = $projektearr[$w][id];
      $projektName=$this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$projekt' LIMIT 1");

      if($projekt==0 || $projekt=="")
	$projektName="Ohne Projekt";
  

      $resultversendet = $this->app->DB->SelectArr("SELECT DATE_FORMAT(l.datum,'%d.%m.%Y') as datum, a.name, l.land, l.versandart, v.id 
        FROM versand v LEFT JOIN adresse a ON a.id=v.adresse LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.freigegeben='1' AND v.abgeschlossen='0' AND v.projekt='$projekt' ORDER by v.id ASC");
        

      if(count($resultversendet)<=0)
       continue;


      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
      $table = new EasyTable($this->app);

      $this->app->Tpl->Set(SUBHEADING,"<h2>$projektName: Lieferungen bitte versenden</h2>");

      $table->Query("SELECT DATE_FORMAT(l.datum,'%d.%m.%Y') as datum, a.name, l.land, l.versandart, v.id 
	FROM versand v LEFT JOIN adresse a ON a.id=v.adresse LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.freigegeben='1' AND v.abgeschlossen='0' AND v.projekt='$projekt' ORDER by v.id ASC");
    
      if($this->app->User->GetType()=="admin") 
	$delete = "<a href=\"#\" onclick=\"if(!confirm('Auftrag wirklich aus dem Versand nehmen?')) return false; else window.location.href='index.php?module=versanderzeugen&action=delete&id=%value%';\"><img src=\"./themes/[THEME]/images/loeschen.png\" border=\"0\"></a>";

      $table->DisplayNew(INHALT,"<a href=\"index.php?module=versanderzeugen&action=einzel&id=%value%\"><img src=\"./themes/[THEME]/images/einlagern.png\" border=\"0\"></a>&nbsp;$delete");
      
      $this->app->Tpl->Parse(TAB1,"rahmen.tpl");
      $this->app->Tpl->Set(INHALT,"");
    }




    // start projekt schleife
    for($w=0;$w<count($projektearr);$w++)
    {
      $projekt = $projektearr[$w][id];
      $projektName=$this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$projekt' LIMIT 1");

      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
      $table = new EasyTable($this->app);

     $resultversendet = $this->app->DB->SelectArr("SELECT DATE_FORMAT(v.versendet_am,'%d.%m.%Y') as datum, a.name, v.versandunternehmen as per, v.tracking, l.land, v.id 
        FROM versand v LEFT JOIN adresse a ON a.id=v.adresse LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.freigegeben='1' AND v.abgeschlossen='1' AND v.projekt='$projekt' AND v.versendet_am=DATE_FORMAT(NOW(),'%Y-%m-%d')");

      if(count($resultversendet)<=0)
       continue;


      $this->app->Tpl->Set(SUBHEADING,"<h2>$projektName: Heute versendete Lieferungen</h2>");

      $table->Query("SELECT DATE_FORMAT(v.versendet_am,'%d.%m.%Y') as datum, a.name, v.versandunternehmen as per, v.tracking, l.land, v.id 
	FROM versand v LEFT JOIN adresse a ON a.id=v.adresse LEFT JOIN lieferschein l ON l.id=v.lieferschein WHERE v.freigegeben='1' AND v.abgeschlossen='1' AND v.projekt='$projekt' AND v.versendet_am=DATE_FORMAT(NOW(),'%Y-%m-%d')");

      $table->DisplayNew(INHALT,"<a href=\"index.php?module=versanderzeugen&action=einzel&id=%value%\"><img src=\"./themes/[THEME]/images/einlagern.png\" border=\"0\"></a>");
      $this->app->Tpl->Parse(TAB2,"rahmen.tpl");
      $this->app->Tpl->Set(INHALT,"");

    }
    
    	
    $this->app->Tpl->Set(SUBHEADING,"");
    $this->app->Tpl->Parse(PAGE,"versanderzeugen_offene.tpl");

  }


  function VersanderzeugenLogin()
  {
    if($this->app->User->GetID()!="")
      {
      $this->VersanderzeugenMain();
      }
    else
      {
      $this->app->Tpl->Set(HEADING,"embedded projects GmbH Verwaltung ");
      $this->app->acl->Login();
      }
  }

  function VersanderzeugenLogout()
  {
    $this->app->acl->Logout();
    //$this->app->WF->ReBuildPageFrame();
    //$this->VersanderzeugenMain();
  }

  function VorgangAnlegen()
  {
    //print_r($_SERVER['HTTP_REFERER']);

    $url = parse_url($_SERVER['HTTP_REFERER']);
    //$url = parse_url("http://dev.eproo.de/~sauterbe/eprooSystem-2009-11-21/webroot/index.php?module=ticket&action=edit&id=1");

    //module=ticket&action=edit&id=1
    //$url['query']
    $params = split("&",$url['query']);
    foreach($params as $value){
      $attribut = split("=",$value);
      $arrPara[$attribut[0]] = $attribut[1];
    }

    $adresse = $this->app->User->GetAdresse();
    $titel = ucfirst($arrPara['module'])." ".$arrPara['id'];
    $href = $url['query'];
    $this->app->erp->AddOffenenVorgang($adresse, $titel, $href);

    header("Location: ".$_SERVER['HTTP_REFERER']);
  }


  function VorgangEntfernen()
  {
    $vorgang = $this->app->Secure->GetGET("vorgang");
    $this->app->erp->RemoveOffenenVorgangID($vorgang);
    header("Location: ".$_SERVER['HTTP_REFERER']);
  } 


}
?>
