<?php

class Firmendaten  {
  var $app;
  
  function Firmendaten($app) {
    $this->app=&$app;

    $this->app->ActionHandlerInit($this);
    $this->app->ActionHandler("edit","FirmendatenEdit");
    $this->app->ActionHandler("briefpapier","FirmendatenBriefpapierDownload");
    $this->app->ActionHandler("logo","FirmendatenLogoDownload");


    $this->app->ActionHandlerListen($app);

    $this->app->Tpl->Set(UEBERSCHRIFT,"Einstellungen");
    $this->app->Tpl->Set(FARBE,"[FARBE5]");


    $this->app = $app;
  }


	function FirmendatenLogoDownload()
	{

    $id = $this->app->DB->Select("SELECT MAX(id) FROM firma LIMIT 1");
    $logo = $this->app->DB->Select("SELECT logo FROM firmendaten WHERE firma='$id'");
    $logo_type = $this->app->DB->Select("SELECT logo_type FROM firmendaten WHERE firma='$id'");
		header('Content-type: '.$logo_type);

		$endung = str_replace("image/","",$logo_type);	

		header('Content-Disposition: attachment; filename="logo.'.$endung.'"');

    echo base64_decode($logo);

	}


	function FirmendatenBriefpapierDownload()
	{

    $id = $this->app->DB->Select("SELECT MAX(id) FROM firma LIMIT 1");
    $briefpapier = $this->app->DB->Select("SELECT briefpapier FROM firmendaten WHERE firma='$id'");
		header('Content-type: application/pdf');

		header('Content-Disposition: attachment; filename="briefpapier.pdf"');

    echo base64_decode($briefpapier);

	}

  function FirmendatenEdit()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Firmendaten");
    $this->app->erp->MenuEintrag("index.php?module=einstellungen&action=list","Zur&uuml;ck zur &Uuml;bersicht");

    $id = $this->app->DB->Select("SELECT MAX(id) FROM firma LIMIT 1");

    $this->app->YUI->AutoComplete("projekt","projektname",1);

    
    // Hole Post-Daten
    $data = $this->getPostData();

    $testmail = $this->app->Secure->GetPOST("testmail");
    $submit = $this->app->Secure->GetPOST("submitFirmendaten");


    if($submit!="")
    {
      $error = "";
      $logo_error = "";
      $briefpapier_error = ""; 

      if($data[hintergrund] == "logo")
      {
				if($_FILES[logo][size]>0)
				{
	  			$logo_error = $this->app->erp->checkImage($_FILES[logo]);
	  			if($logo_error=="")
	  			{
	    			$logo = $this->app->erp->uploadImageIntoDB($_FILES[logo]);	  
	  				$this->app->DB->Update("UPDATE firmendaten SET logo='{$logo[image]}', logo_type='{$logo[type]}' WHERE firma='$id' LIMIT 1");
	  			}
	  			else
	    			$error .= "$logo_error<br>";
	}else
	{
	  //pruefe ob logo vorhanden
	  $logo = $this->app->DB->Select("SELECT logo FROM firmendaten WHERE firma=$id LIMIT 1");
	  if(strlen($logo)<10)
	    $error .= "Geben Sie bitte ein Logo zum Hochladen an.<br>";
	}
      }

      if($data[hintergrund] == "briefpapier")
      {
        if($_FILES[briefpapier][size]>0)
        {
	  			$briefpapier_error = $this->app->erp->checkFile($_FILES[briefpapier],"application/pdf");
          if($briefpapier_error=="")
          {
            $briefpapier = $this->app->erp->uploadFileIntoDB($_FILES[briefpapier]);
            $this->app->DB->Update("UPDATE firmendaten SET briefpapier='{$briefpapier['file']}', briefpapier_type='{$briefpapier[type]}' WHERE firma='$id'");
          }
          else
            $error .= "$briefpapier_error<br>";
        }else
	  $briefpapier = $this->app->DB->Select("SELECT briefpapier FROM firmendaten WHERE firma=$id LIMIT 1");
	  if($briefpapier=="")
          $error .= "Geben Sie bitte das Briefpapier zum Hochladen an.<br>";
      }

      if($data[benutzername]=="")
	  $error .= "Geben Sie bitte einen E-Mail-Benutzername an.<br>";

      if($data[passwort]=="")
          $error .= "Geben Sie bitte ein E-Mail-Passwort an.<br>";

      if($data[host]=="")
          $error .= "Geben Sie bitte einen E-Mail-Host an.<br>";

      if($data[port]=="")
          $error .= "Geben Sie bitte einen E-Mail-Port (Standard 25) an.<br>";

      if($data[email]=="")
          $error .= "Geben Sie bitte einen E-Mail Adresse an.<br>";
      
      if($error=="")
      {
	$vorhanden = $this->app->DB->Select("SELECT id FROM firmendaten WHERE firma='$id' LIMIT 1");
      
	if(!is_numeric($vorhanden)) $this->app->DB->Insert("INSERT INTO firmendaten (firma) VALUES ('$id')");

	// Update Bilder

	//suche projekt ID von abkuerzung
	
  $data[projekt] = $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='{$data[projekt]}' LIMIT 1");


	$this->app->DB->Update("UPDATE firmendaten SET absender='{$data[absender]}', sichtbar='{$data[sichtbar]}', barcode='{$data[barcode]}', schriftgroesse='{$data[schriftgroesse]}',
				betreffszeile='{$data[betreffszeile]}', dokumententext='{$data[dokumententext]}', tabellenbeschriftung='{$data[tabellenbeschriftung]}', 
				tabelleninhalt='{$data[tabelleninhalt]}', zeilenuntertext='{$data[zeilenuntertext]}', freitext='{$data[freitext]}', infobox='{$data[infobox]}', brieftext='{$data[brieftext]}',
				spaltenbreite='{$data[spaltenbreite]}', footer_0_0='{$data[footer][0][0]}', footer_0_1 ='{$data[footer][0][1]}', footer_0_2 ='{$data[footer][0][2]}', 
				footer_0_3 ='{$data[footer][0][3]}', footer_0_4 ='{$data[footer][0][4]}', footer_0_5 ='{$data[footer][0][5]}', footer_1_0 ='{$data[footer][1][0]}', 
				footer_1_1 ='{$data[footer][1][1]}', footer_1_2 ='{$data[footer][1][2]}', footer_1_3 ='{$data[footer][1][3]}', footer_1_4 ='{$data[footer][1][4]}', 
				footer_1_5 ='{$data[footer][1][5]}', footer_2_0 ='{$data[footer][2][0]}', footer_2_1 ='{$data[footer][2][1]}', footer_2_2 ='{$data[footer][2][2]}', 
				footer_2_3 ='{$data[footer][2][3]}', footer_2_4 ='{$data[footer][2][4]}', footer_2_5 ='{$data[footer][2][5]}', footer_3_0 ='{$data[footer][3][0]}', 
				footer_3_1 ='{$data[footer][3][1]}', footer_3_2 ='{$data[footer][3][2]}', footer_3_3 ='{$data[footer][3][3]}', footer_3_4 ='{$data[footer][3][4]}', 
				footer_3_5 ='{$data[footer][3][5]}', footersichtbar='{$data[footersichtbar]}', hintergrund='{$data[hintergrund]}', benutzername='{$data[benutzername]}', 
				passwort='{$data[passwort]}',  host='{$data[host]}', port='{$data[port]}', mailssl='{$data[ssl]}', signatur='{$data[signatur]}',email='{$data[email]}',
				absendername='{$data[absendername]}',bcc1='{$data[bcc1]}',bcc2='{$data[bcc2]}',firmenfarbe='{$data[firmenfarbe]}',
				name='{$data[name]}',strasse='{$data[strasse]}',plz='{$data[plz]}',ort='{$data[ort]}',
				steuernummer='{$data[steuernummer]}', projekt='{$data[projekt]}' WHERE firma='$id' LIMIT 1");


	$this->app->DB->Update("UPDATE firma SET name='{$data[name]}', standardprojekt='{$data[projekt]}' WHERE id='$id' LIMIT 1");
	
	$this->app->Tpl->Set(MESSAGE, "<div class=\"error2\">Ihre Daten wurden erfolgreich gespeichert.</div>");
	$this->FillFormFromDB($id); 
     }else 
      {
	// Im Fehlerfall sollen das Formular mit den POST-Daten gefuellt werden
	$this->app->Tpl->Set(MESSAGE, "<div class=\"error\">$error</div>");
	$this->fillForm($data);
      }
    }else
      $this->FillFormFromDB($id);

    $this->app->Tpl->Set(TABTEXT,"Firmendaten Einstellungen");
    $this->app->Tpl->Parse(TAB1,"firmendaten.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function fillFormFromDB($id)
  {
    $vorhanden = $this->app->DB->Select("SELECT id FROM firmendaten WHERE firma='$id' LIMIT 1");

    if(!is_numeric($vorhanden))
    {
      // Falls das Formular zum ersten mal aufgerufen wird
      $this->app->Tpl->Set(SICHTBAR , "checked");
      $this->app->Tpl->Set(HINTERGRUNDKEIN, "checked");
    }else
    {
      // Lade Formular aus DB
      $data = $this->app->DB->SelectArr("SELECT * FROM firmendaten WHERE firma='$id' LIMIT 1");

      //Brief Absender
      $this->app->Tpl->Set(ABSENDER , $data[0][absender]);    
      $this->app->Tpl->Set(SICHTBAR , $this->parseCheckbox($data[0][sichtbar]));

      //Formatierung
      $this->app->Tpl->Set(BARCODE , $this->parseCheckbox($data[0][barcode]));    
      $this->app->Tpl->Set(SCHRIFTGROESSE , ($data[0][schriftgroesse]));    
      $this->app->Tpl->Set(BETREFFSZEILE , ($data[0][betreffszeile]));    
      $this->app->Tpl->Set(DOKUMENTENTEXT , ($data[0][dokumententext]));    
      $this->app->Tpl->Set(TABELLENBESCHRIFTUNG , ($data[0][tabellenbeschriftung]));    
      $this->app->Tpl->Set(TABELLENINHALT , ($data[0][tabelleninhalt]));    
      $this->app->Tpl->Set(ZEILENUNTERTEXT , ($data[0][zeilenuntertext]));    
      $this->app->Tpl->Set(FREITEXT , ($data[0][freitext]));    
      $this->app->Tpl->Set(BRIEFTEXT , ($data[0][brieftext]));    
      $this->app->Tpl->Set(INFOBOX , ($data[0][infobox]));    
      $this->app->Tpl->Set(SPALTENBREITE , ($data[0][spaltenbreite]));

      // Footer
      $this->app->Tpl->Set(FOOTER00 , $data[0][footer_0_0]);
      $this->app->Tpl->Set(FOOTER01 , $data[0][footer_0_1]);
      $this->app->Tpl->Set(FOOTER02 , $data[0][footer_0_2]);
      $this->app->Tpl->Set(FOOTER03 , $data[0][footer_0_3]);
      $this->app->Tpl->Set(FOOTER04 , $data[0][footer_0_4]);
      $this->app->Tpl->Set(FOOTER05 , $data[0][footer_0_5]);
      $this->app->Tpl->Set(FOOTER10 , $data[0][footer_1_0]);
      $this->app->Tpl->Set(FOOTER11 , $data[0][footer_1_1]);
      $this->app->Tpl->Set(FOOTER12 , $data[0][footer_1_2]);
      $this->app->Tpl->Set(FOOTER13 , $data[0][footer_1_3]);
      $this->app->Tpl->Set(FOOTER14 , $data[0][footer_1_4]);
      $this->app->Tpl->Set(FOOTER15 , $data[0][footer_1_5]);
      $this->app->Tpl->Set(FOOTER20 , $data[0][footer_2_0]);
      $this->app->Tpl->Set(FOOTER21 , $data[0][footer_2_1]);
      $this->app->Tpl->Set(FOOTER22 , $data[0][footer_2_2]);
      $this->app->Tpl->Set(FOOTER23 , $data[0][footer_2_3]);
      $this->app->Tpl->Set(FOOTER24 , $data[0][footer_2_4]);
      $this->app->Tpl->Set(FOOTER25 , $data[0][footer_2_5]);
      $this->app->Tpl->Set(FOOTER30 , $data[0][footer_3_0]);
      $this->app->Tpl->Set(FOOTER31 , $data[0][footer_3_1]);
      $this->app->Tpl->Set(FOOTER32 , $data[0][footer_3_2]);
      $this->app->Tpl->Set(FOOTER33 , $data[0][footer_3_3]);
      $this->app->Tpl->Set(FOOTER34 , $data[0][footer_3_4]);
      $this->app->Tpl->Set(FOOTER35 , $data[0][footer_3_5]);
      $this->app->Tpl->Set(FOOTERSICHTBAR , $this->parseCheckbox($data[0][footersichtbar]));

      //Briefpapier Hintergrund
      if($data[0][hintergrund]=="logo")
      {
	$this->app->Tpl->Set(HINTERGRUNDLOGO, "checked");
	$this->app->Tpl->Set(HINTERGRUNDTEXT, "Logo (<a href=\"index.php?module=firmendaten&action=logo\">Download</a>)");
      }else if($data[0][hintergrund]=="briefpapier")
      {
	$this->app->Tpl->Set(HINTERGRUNDBRIEFPAPIER, "checked");
	$this->app->Tpl->Set(HINTERGRUNDTEXT, "Briefpapier (<a href=\"index.php?module=firmendaten&action=briefpapier\">Download</a>)");
      }else
	$this->app->Tpl->Set(HINTERGRUNDKEIN, "checked");

      //Versand E-Mail
      $this->app->Tpl->Set(BENUTZERNAME , $data[0][benutzername]);
      $this->app->Tpl->Set(PASSWORT , $data[0][passwort]);
      $this->app->Tpl->Set(HOST , $data[0][host]);
      $this->app->Tpl->Set(PORT , $data[0][port]);
      $this->app->Tpl->Set(SSL , $this->parseCheckbox($data[0][mailssl]));

      // Signatur
      $this->app->Tpl->Set(SIGNATUR , base64_decode($data[0][signatur]));
      $this->app->Tpl->Set(EMAIL , $data[0][email]);
      $this->app->Tpl->Set(ABSENDERNAME , $data[0][absendername]);
      $this->app->Tpl->Set(BCC1 , $data[0][bcc1]);
      $this->app->Tpl->Set(FIRMENFARBE , $data[0][firmenfarbe]);
      $this->app->Tpl->Set(NAME , $data[0][name]);
      $this->app->Tpl->Set(STRASSE , $data[0][strasse]);
      $this->app->Tpl->Set(PLZ , $data[0][plz]);
      $this->app->Tpl->Set(ORT , $data[0][ort]);
      $this->app->Tpl->Set(STEUERNUMMER , $data[0][steuernummer]);

			$data[0][projekt] = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='{$data[0][projekt]}' LIMIT 1");
      $this->app->Tpl->Set(PROJEKT , $data[0][projekt]);
    }
  }


  function fillForm($data)
  {
    //Brief Absender
    $this->app->Tpl->Set(ABSENDER , $data[absender]);    
    $this->app->Tpl->Set(SICHTBAR , $this->parseCheckbox($data[sichtbar]));


    //Formatierung
    $this->app->Tpl->Set(BARCODE , $this->parseCheckbox($data[barcode]));    
    $this->app->Tpl->Set(SCHRIFTGROESSE , ($data[schriftgroesse]));    
    $this->app->Tpl->Set(BETREFFSZEILE , ($data[betreffszeile]));    
    $this->app->Tpl->Set(DOKUMENTENTEXT , ($data[dokumententext]));    
    $this->app->Tpl->Set(TABELLENBESCHRIFTUNG , ($data[tabellenbeschriftung]));    
    $this->app->Tpl->Set(TABELLENINHALT , ($data[tabelleninhalt]));    
    $this->app->Tpl->Set(ZEILENUNTERTEXT , ($data[zeilenuntertext]));    
    $this->app->Tpl->Set(FREITEXT , ($data[freitext]));    
    $this->app->Tpl->Set(BRIFTEXT , ($data[brieftext]));    
    $this->app->Tpl->Set(INFOBOX , ($data[infobox]));    
    $this->app->Tpl->Set(SPALTENBREITE , ($data[spaltenbreite]));    
 
    //Footer
    for($x=0; $x < 4; $x++)
	for($y=0; $y < 6; $y++)
	  $this->app->Tpl->Set("FOOTER$x$y" ,$data[footer][$x][$y]);
    $this->app->Tpl->Set(FOOTERSICHTBAR , $this->parseCheckbox($data[footersichtbar]));    


    //Briefpapier Hintergrund
    if($data[hintergrund]=="logo")
    {
      $this->app->Tpl->Set(HINTERGRUNDLOGO, "checked");
      $this->app->Tpl->Set(HINTERGRUNDTEXT, "Logo");
    }else if($data[hintergrund]=="briefpapier")
    {
      $this->app->Tpl->Set(HINTERGRUNDBRIEFPAPIER, "checked");
      $this->app->Tpl->Set(HINTERGRUNDTEXT, "Briefpapier");
    }else
      $this->app->Tpl->Set(HINTERGRUNDKEIN, "checked");


    //Versand E-Mail
    $this->app->Tpl->Set(BENUTZERNAME , $data[benutzername]);    
    $this->app->Tpl->Set(PASSWORT , $data[passwort]);    
    $this->app->Tpl->Set(HOST , $data[host]);    
    $this->app->Tpl->Set(PORT , $data[port]);    
    $this->app->Tpl->Set(SSL , $this->parseCheckbox($data[ssl]));    
    
    // Signatur
    $this->app->Tpl->Set(SIGNATUR , base64_decode($data[signatur]));    
    $this->app->Tpl->Set(EMAIL , $data[email]);    
    $this->app->Tpl->Set(ABSENDERNAME , $data[absendername]);    
    $this->app->Tpl->Set(BCC1 , $data[bcc1]);    
    $this->app->Tpl->Set(BCC2 , $data[bcc2]);    
    $this->app->Tpl->Set(FIRMENFARBE , $data[firmenfarbe]);    
    $this->app->Tpl->Set(NAME , $data[name]);    
    $this->app->Tpl->Set(STRASSE , $data[strasse]);    
    $this->app->Tpl->Set(PLZ , $data[plz]);    
    $this->app->Tpl->Set(ORT , $data[ort]);    
    $this->app->Tpl->Set(STEUERNUMMER , $data[steuernummer]);    
  }



  function getPostData()
  {
    $data = array();


    // Brief Absender
    $data[absender] = $this->app->Secure->GetPOST("absender");
    $data[sichtbar] = $this->parseCheckbox($this->app->Secure->GetPOST("sichtbar"));
  

    // Formatierung
    $data[barcode] = $this->parseCheckbox($this->app->Secure->GetPOST("barcode"));
    $data[schriftgroesse] = ($this->app->Secure->GetPOST("schriftgroesse"));
    $data[betreffszeile] = ($this->app->Secure->GetPOST("betreffszeile"));
    $data[dokumententext] = ($this->app->Secure->GetPOST("dokumententext"));
    $data[tabellenbeschriftung] = ($this->app->Secure->GetPOST("tabellenbeschriftung"));
    $data[tabelleninhalt] = ($this->app->Secure->GetPOST("tabelleninhalt"));
    $data[zeilenuntertext] = ($this->app->Secure->GetPOST("zeilenuntertext"));
    $data[freitext] = ($this->app->Secure->GetPOST("freitext"));
    $data[brieftext] = ($this->app->Secure->GetPOST("brieftext"));
    $data[infobox] = ($this->app->Secure->GetPOST("infobox"));
    $data[spaltenbreite] = ($this->app->Secure->GetPOST("spaltenbreite"));

    // Footer
    $data[footer] = $this->app->Secure->GetPOST("footer");
    $data[footersichtbar] = $this->parseCheckbox($this->app->Secure->GetPOST("footersichtbar"));

    // Briefpapier Hintergrund
    $data[logo] = $this->app->Secure->GetPOST("logo");
    $data[briefpapier] = $this->app->Secure->GetPOST("briefpapier");
    $data[hintergrund] = $this->app->Secure->GetPOST("hintergrund");

    // Versand E-Mail
    $data[benutzername] = $this->app->Secure->GetPOST("benutzername");
    $data[passwort] = $this->app->Secure->GetPOST("passwort");
    $data[host] = $this->app->Secure->GetPOST("host");
    $data[port] = $this->app->Secure->GetPOST("port");
    $data[ssl] = $this->parseCheckbox($this->app->Secure->GetPOST("ssl"));

    // Signatur
    $data[signatur] = base64_encode($this->app->Secure->POST["signatur"]);
    $data[email] = ($this->app->Secure->POST["email"]);
    $data[absendername] = ($this->app->Secure->POST["absendername"]);
    $data[bcc1] = ($this->app->Secure->POST["bcc1"]);
    $data[bcc2] = ($this->app->Secure->POST["bcc2"]);
    $data[name] = ($this->app->Secure->POST["name"]);
    $data[firmenfarbe] = ($this->app->Secure->POST["firmenfarbe"]);
    $data[strasse] = ($this->app->Secure->POST["strasse"]);
    $data[plz] = ($this->app->Secure->POST["plz"]);
    $data[ort] = ($this->app->Secure->POST["ort"]);
    $data[steuernummer] = ($this->app->Secure->POST["steuernummer"]);
    $data[projekt] = ($this->app->Secure->POST["projekt"]);

    return $data;
  }

  function parseCheckBox($checkbox)
  {
    if($checkbox=='0')
      return '';

    if($checkbox=='1')
      return 'checked';

    if($checkbox=='on')
      return 1;
    
    if($checkbox=='')
      return 0;
  }


}

?>
