<?php
include ("_gen/widget.gen.prozessstarter.php");

class WidgetProzessstarter extends WidgetGenProzessstarter 
{
  private $app;
  function WidgetProzessstarter($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenProzessstarter($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
/*
    $this->form->ReplaceFunction("adresse",$this,"ReplaceAdresse");
    $this->form->ReplaceFunction("datum",$this,"ReplaceDatum");
    $this->form->ReplaceFunction("betrag",$this,"ReplaceDecimal");
    $this->form->ReplaceFunction("projekt",$this,"ReplaceProjekt");


    $this->app->YUI->AutoComplete(ADRESSEAUTO,"adresse",array('name'),"name","adresse");
    $this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");

    // liste zuweisen
    $this->app->Secure->POST["datum"]=date('Y-m-d');
    $field = new HTMLInput("datum","text",date('Y-m-d'));
    $this->form->NewField($field);

    // liste zuweisen
    $this->app->Secure->POST["bearbeiter"]=$this->app->User->GetName();
    $field = new HTMLInput("bearbeiter","hidden",$this->app->User->GetName());
    $this->form->NewField($field);
*/
    //firma
    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);

    $this->app->Tpl->Set(DATUM_BUCHUNG,
        "<img src=\"./themes/[THEME]/images/kalender.png\" onclick=\"displayCalendar(document.forms[0].datum,'dd.mm.yyyy',this)\">");

  }
  function ReplaceProjekt($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  function ReplaceDecimal($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden

    return str_replace(",",".",$value);
  }

  function ReplaceDatum($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(strpos($value,'-') > 0) $dbformat = 1;

    // wenn ziel datenbank
    if($db)
    { 
      if($dbformat) return $value;
      else return $this->app->String->Convert($value,"%1.%2.%3","%3-%2-%1");
    }
    // wenn ziel formular
    else
    { 
      if($dbformat) return $this->app->String->Convert($value,"%1-%2-%3","%3.%2.%1");
      else return $value;
    }
  }

  function ReplaceAdresse($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM adresse WHERE name='$value' AND geloescht=0 LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  public function Table()
  {

    $table = new EasyTable($this->app);  
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Prozessstarter");
    $table->Query("SELECT bezeichnung, art,periode,if(aktiv,'ja','-') as aktiviert, letzteausfuerhung as 'letzte Ausf&uuml;hrung', typ,parameter, id FROM prozessstarter WHERE firma='".$this->app->User->GetFirma()."'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=prozessstarter&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=prozessstarter&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        ");

    /*$this->app->Tpl->Set(EXTEND,"<input type=\"button\" value=\"Prozessstarter exportieren\" onclick=\"window.location.href='index.php?module=prozessstarter&action=exportieren'\">");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Prozessstarter exportiert");
    $table->Query("SELECT a.name, betrag, auswahl as typ, grund FROM prozessstarter, adresse a WHERE prozessstarter.adresse = a.id AND prozessstarter.exportiert=1");
    $table->DisplayNew(INHALT, "Grund","noAction");
    */
    $this->app->Tpl->Set(EXTEND,"");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

  }



  public function Search()
  {
    //$this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }


}
?>
