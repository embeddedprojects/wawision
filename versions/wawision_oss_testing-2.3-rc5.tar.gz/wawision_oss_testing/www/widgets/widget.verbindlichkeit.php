<?php
include ("_gen/widget.gen.verbindlichkeit.php");

class WidgetVerbindlichkeit extends WidgetGenVerbindlichkeit 
{
  private $app;
  function WidgetVerbindlichkeit($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenVerbindlichkeit($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {

    $this->form->ReplaceFunction("adresse",$this,"ReplaceLieferant");
    $this->form->ReplaceFunction("zahlbarbis",$this,"ReplaceDatum");
    $this->form->ReplaceFunction("skontobis",$this,"ReplaceDatum");
    $this->form->ReplaceFunction("betrag",$this,"ReplaceDecimal");
    $this->form->ReplaceFunction("summenormal",$this,"ReplaceDecimal");
    $this->form->ReplaceFunction("summeermaessigt",$this,"ReplaceDecimal");

		$this->app->YUI->AutoComplete("adresse","lieferant");


    //firma
    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);

		$this->app->YUI->DatePicker("zahlbarbis");
		$this->app->YUI->DatePicker("skontobis");



  }
  function ReplaceProjekt($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  function ReplaceDecimal($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden

    return str_replace(",",".",$value);
  }

  function ReplaceDatum($db,$value,$fromform)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(strpos($value,'-') > 0) $dbformat = 1;

    // wenn ziel datenbank
    if($db)
    { 
      if($dbformat) return $value;
      else return $this->app->String->Convert($value,"%1.%2.%3","%3-%2-%1");
    }
    // wenn ziel formular
    else
    { 
      if($dbformat) return $this->app->String->Convert($value,"%1-%2-%3","%3.%2.%1");
      else return $value;
    }
  }
 function ReplaceLieferant($db,$value,$fromform)
  {
    return $this->app->erp->ReplaceLieferant($db,$value,$fromform);
  }

  public function Table()
  {
    $table = new EasyTable($this->app);  
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Verbindlichkeiten mit Skonto");
//    $table->Query("SELECT a.name, verbindlichkeit.betrag, verbindlichkeit.rechnung, DATE_FORMAT(verbindlichkeit.skontobis,'%d.%m.%Y') as bis,verbindlichkeit.id FROM verbindlichkeit, adresse a WHERE verbindlichkeit.adresse = a.id AND verbindlichkeit.bezahlt!=1 AND verbindlichkeit.skontobis <= NOW() AND verbindlichkeit.status!='bezahlt' AND verbindlichkeit.skonto > 0 order by verbindlichkeit.skontobis");

    $table->Query("SELECT a.name, verbindlichkeit.betrag, verbindlichkeit.rechnung, DATE_FORMAT(verbindlichkeit.skontobis,'%d.%m.%Y') as bis,verbindlichkeit.id FROM verbindlichkeit LEFT JOIN adresse a ON verbindlichkeit.adresse = a.id WHERE verbindlichkeit.skontobis!=0 AND verbindlichkeit.status!='bezahlt' AND verbindlichkeit.skonto > 0 ");

 
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=verbindlichkeit&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich als bezahlt markieren?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=bezahlt&id=%value%';\">
        <img src=\"./themes/[THEME]/images/ack.png\" border=\"0\"></a>
        ");

    $this->app->Tpl->Parse($this->parsetarget,"rahmen70red.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"F&auml;llige Verbindlichkeiten");
    $table->Query("SELECT a.name, betrag, rechnung, DATE_FORMAT(zahlbarbis,'%d.%m.%Y') as bis,verbindlichkeit.id FROM verbindlichkeit, adresse a WHERE verbindlichkeit.adresse = a.id AND verbindlichkeit.bezahlt!=1 AND zahlbarbis <= NOW() AND status!='bezahlt' order by zahlbarbis");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=verbindlichkeit&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich als bezahlt markieren?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=bezahlt&id=%value%';\">
        <img src=\"./themes/[THEME]/images/ack.png\" border=\"0\"></a>
        ");




    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Offene Verbindlichkeiten");
    $table->Query("SELECT a.name, betrag, rechnung, DATE_FORMAT(zahlbarbis,'%d.%m.%Y') as bis,verbindlichkeit.id FROM verbindlichkeit, adresse a WHERE verbindlichkeit.adresse = a.id AND verbindlichkeit.bezahlt!=1 AND zahlbarbis > NOW() AND status!='bezahlt' order by zahlbarbis");
 $table->DisplayNew(INHALT, "<a href=\"index.php?module=verbindlichkeit&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich als bezahlt markieren?')) return false; else window.location.href='index.php?module=verbindlichkeit&action=bezahlt&id=%value%';\">
        <img src=\"./themes/[THEME]/images/ack.png\" border=\"0\"></a>
        ");



    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

  }



  public function Search()
  {
    //$this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }


}
?>
