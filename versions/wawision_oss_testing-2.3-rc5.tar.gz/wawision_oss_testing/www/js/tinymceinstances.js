tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  encoding : "xml",
  elements : "beschreibung_de,beschreibung_en,uebersicht_de,uebersicht_en,links_de,links_en,startseite_de,startseite_en, l,inks_v,beschreibung_v,uebersicht_v,name_vi",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  elements : "uebersichtstext",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  encoding : "xml",
  elements : "html",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen,image,table",
  theme_advanced_buttons2 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  elements : "ticket_nachricht",
  visual : false,
  readonly : 1,
  theme_advanced_buttons1 : "",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  elements : "le_uebersicht",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  elements : "le_beschreibung",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

tinyMCE.init({
  theme: "advanced",
  mode : "exact",
  elements : "le_links",
  plugins : "",
  theme_advanced_buttons1 : "bold,italic,forecolor,formatselect,link,unlink,bullist,numlist",
  theme_advanced_buttons1_add : "removeformat,code,fullscreen",
  theme_advanced_buttons2 : "",
  theme_advanced_buttons3 : ""
});

