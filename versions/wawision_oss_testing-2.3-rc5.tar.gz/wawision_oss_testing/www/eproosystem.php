<?php
/* Author: Benedikt Sauter <sauter@sistecs.de> 2007
 *
 * Hier werden alle Plugins, Widgets usw instanziert die
 * fuer die Anwendung benoetigt werden.
 * Diese Klasse ist von class.application.php abgleitet.
 * Das hat den Vorteil, dass man dort bereits einiges starten kann,
 * was man eh in jeder Anwendung braucht.
 * - DB Verbindung
 * - Template Parser
 * - Sicherheitsmodul
 * - String Plugin
 * - usw....
 */
require("../phpwf/class.application.php");

require("widgets/artikeltable.php");
require("widgets/widget.aufgabe.php");
require("widgets/widget.arbeitspaket.php");
require("widgets/widget.verkaufspreise.php");
require("widgets/widget.einkaufspreise.php");
require("widgets/widget.lieferadressen.php");
require("widgets/widget.ansprechpartner.php");
require("widgets/widget.brief.php");
require("widgets/widget.email.php");
require("widgets/widget.stueckliste.php");
require("widgets/widget.lieferantvorlage.php");
require("widgets/widget.kundevorlage.php");
require("widgets/widget.bestellung_position.php");
require("widgets/widget.rechnung_position.php");
require("widgets/widget.angebot_position.php");
require("widgets/widget.auftrag_position.php");
require("widgets/widget.lieferschein_position.php");
require("widgets/widget.auftrag_artikel.php");
require("widgets/widget.abrechnungsartikel.php");
require("widgets/widget.webmail_mails.php");
require("widgets/widget.lager_platz.php");
require("widgets/widget.adresse_rolle.php");
require("widgets/widget.shopexport_kampange.php");

require('lib/pdf/fpdf_final.php');
//require('lib/dokumente/class.superfpdf.php');
define('FPDF_FONTPATH','lib/pdf/font/');

require("lib/dokumente/class.superfpdf.php");
require("lib/dokumente/class.etikett.php");
require("lib/dokumente/class.briefpapier.php");

require("lib/dokumente/class.brief.php");
require("lib/dokumente/class.korrespondenz.php");
require("lib/dokumente/class.bestellung.php");
require("lib/dokumente/class.angebot.php");
require("lib/dokumente/class.auftrag.php");
require("lib/dokumente/class.rechnung.php");
require("lib/dokumente/class.gutschrift.php");
require("lib/dokumente/class.lieferschein.php");
require("lib/dokumente/class.katalog.php");
require("lib/dokumente/class.produktion.php");

require("lib/class.erpapi.php");
require("lib/class.printer.php");
require("lib/class.ustid.php");
require("plugins/phpmailer/class.phpmailer.php");
require("plugins/class.wikiparser.php");
require("plugins/simple_html_dom.php");
  
require("lib/class.httpclient.php");
require("lib/class.aes.php");
require("lib/class.remote.php");
require("lib/class.help.php");

require("lib/class.navigation_edit.php");

include("function_exists.php");

class erpooSystem extends Application
{
  public $obj;
  public $starttime;
  public $endtime;

  public function __construct($config,$group="") 
  {
    $this->starttime = microtime(); 
    parent::Application($config,$group);

    // objekt api laden
    //$this->obj = new ObjConductor(&$this);
    
    // hier kann man standard plugins auch einstellen
    // $this->FormHandler->DefaultErrorClass("spezielleklasse");
    
    // hier koennte man extra plugins laden
    // $this->meinplugin = new MeinPlugin(&$this);

    $this->erp = new erpAPI($this);
    $this->remote = new Remote($this);
    $this->printer= new Printer($this);

    $this->help = new Help($this);

    $this->Tpl->Set(FARBE1,"#66CDAA");
    $this->Tpl->Set(FARBE2,"#8DB6CD");
    $this->Tpl->Set(FARBE3,"#FFD39B");
    $this->Tpl->Set(FARBE4,"#FAFAD2");
    $this->Tpl->Set(FARBE5,"#B8860B");
    $this->Tpl->Set(YEAR,date('Y'));
    
    $firmendatenid = $this->DB->Select("SELECT MAX(id) FROM firmendaten LIMIT 1");
       
    $benutzername = $this->DB->Select("SELECT benutzername FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");
    $passwort = $this->DB->Select("SELECT passwort FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");
    $host = $this->DB->Select("SELECT host FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");
    $port = $this->DB->Select("SELECT port FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");
    $mailssl = $this->DB->Select("SELECT mailssl FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");
                                                                                                                                                                                                                                     


    $this->mail = new PHPMailer();
    $this->mail->PluginDir="plugins/phpmailer/";
    $this->mail->IsSMTP();
    $this->mail->SMTPAuth   = true;                  // enable SMTP authentication
    if($mailssl) $this->mail->SMTPSecure = "tls";                 // sets the prefix to the servier
    $this->mail->Host       = $host;

    $this->mail->Port       = $port;                   // set the SMTP port for the GMAIL server

    $this->mail->Username   = $benutzername;  // GMAIL username
    $this->mail->Password   = $passwort;            // GMAIL password

    // templates laden

    $module = $this->Secure->GetGET("module");
    if($module!="ajax")
    {
      $this->Tpl->ReadTemplatesFromPath("widgets/templates/_gen/");
      $this->Tpl->ReadTemplatesFromPath("widgets/templates/");
      $this->Tpl->ReadTemplatesFromPath("themes/".$this->Conf->WFconf[defaulttheme]."/templates/");
      $this->Tpl->ReadTemplatesFromPath("pages/content/_gen/");
      $this->Tpl->ReadTemplatesFromPath("pages/content/");
    }

    $this->Tpl->Set(THEME, $this->Conf->WFconf[defaulttheme]);

    if($module=="produktion" || $module=="angebot" || $module=="artikel" || $module=="backup" ||$module=="adresse" || $module=="auftrag" || $module=="gutschrift" || $module=="lieferschein" ||$module=="rechnung"
				|| $module=="bestellung" || $module=="emailbackup" || $module=="geschaeftsbrief_vorlagen" || $module=="konten" || $module=="projekt" || $module=="wizard" || $module=="bestellvorschlag")
		{
			$this->Tpl->Add(QUICKICONS,"<table width=100%><tr><td align=center><a  href=\"index.php?module=$module&action=create\"><img src=\"./themes/new/images/document-new.png\" border=\"0\" title=\"Neu anlegen\"></a></td>");
			$this->Tpl->Add(QUICKICONS,"<td align=center><a  href=\"index.php?module=$module&action=list\"><img src=\"./themes/new/images/document-list.png\" border=\"0\" title=\"&Uuml;bersicht\"></a></td></tr></table>");
		} else {
			$this->Tpl->Set(QUICKICONSDISABLEOPEN,"<!--");
			$this->Tpl->Set(QUICKICONSDISABLECLOSE,"//-->");

		}


		
		$this->help->Run(); 
/*
    if($module=="angebot" || $module=="artikel" || $module=="backup" ||$module=="adresse" || $module=="auftrag" || $module=="gutschrift" || $module=="lieferschein" ||$module=="rechnung"
				|| $module=="bestellung" || $module=="emailbackup" || $module=="geschaeftsbrief_vorlagen" || $module=="konten" || $module=="projekt" || $module=="wizard" || $module=="bestellvorschlag")
		{
			$this->Tpl->Add(HELP,"so gehts");
		} else {
			$this->Tpl->Set(HELPDISABLEOPEN,"<!--");
			$this->Tpl->Set(HELPDISABLECLOSE,"-->");
		}
 
*/

    
    // liegt hier cookie? sonst benutzer
    //$this->Tpl->Set(HAUPTMENU,'<td Style="background-color: #999999;" align="center">waWision Open-Source ERP</td>');

      $this->Tpl->Set(TMPSCRIPT,"");

    $msg = $this->Secure->GetGET("msg");
    $msg = base64_decode($msg);
    if($msg!="")
      $this->Tpl->Add(MESSAGE,$msg);


    $module = $this->Secure->GetGET("module");
    $this->Tpl->Set(MODULE,$module);
    if($module == "")
      $module = "welcome";
    $this->Tpl->Set(ICON,$module);
    
    $id = $this->Secure->GetGET("id");
    $this->Tpl->Set(KID,$id);
    
    // pruefe welche version vorliegt
    include("../version.php");
   
    $this->Tpl->Set(REVISION,$this->erp->Revision());

		if($this->erp->Version()=="com")
    $this->Tpl->Set(VERSION,"Nutzungsbedinungen");
		else
    $this->Tpl->Set(VERSION,"Open-Source GNU/AGPL");
    //$this->Tpl->Set(BRANCH,$branch);

	$this->Tpl->Set(TIMESTAMP,time());

    $this->Tpl->Set(THEME,$this->Conf->WFconf[defaulttheme]);
    $this->Tpl->Set(AKTIV_GEN_TAB1,"selected");
  }


  function calledWhenAuth($type)
  {
    $id = $this->Secure->GetGET("id");
    $lid = $this->Secure->GetGET("lid");
    $module = $this->Secure->GetGET("module");
    $action  = $this->Secure->GetGET("action");
    


		if($module=="adresse" || $module=="artikel" || $module=="angebot" || $module=="rechnung" || $module=="auftrag" || $module=="gutschrift" || $module=="lieferschein" 
				|| $module=="onlineshops" || $module=="geschaeftsbrief_vorlagen" ||  $module=="emailbackup" || $module=="ticket_vorlage")
		{
			// module auf richtige tabellen mappen
			if($module=="onlineshops") $this->erp->Standardprojekt("shopexport",$id);
			else $this->erp->Standardprojekt($module,$id);
	
		}


    $this->HauptMenu();

    $this->Tpl->Set(KALENDERKNOPF,"
      <b>Persoenliche Tools</b><table width=\"100%\">
    <tr>
      <td><a href=\"./index.php?module=wdcalendar&action=list\" target=\"_blank\"
	title=\"Kalender\">Kalender</a></td>
     <td><a href=\"\" onclick=\"window.open('http://web2.0rechner.de/','Popupfenster', 'width=320,height=355,resizable=no,location=no,status=no');\"
	title=\"Kalender\">Taschenrechner</a></td>
    </tr></table>
<br><br>
      <b>Freie Dienste</b><table width=\"100%\">
   <tr>
  <td><a href=\"http://openrouteservice.org/\" target=\"_blank\"
	title=\"Kalender\">Route</a></td>

      <td><a href=\"http://metager2.de/\" target=\"_blank\"
	title=\"Kalender\">Suchmaschine</a></td>
    </tr>



      </tr></table>");


    /*********** select field for projekt ***************/
    if($this->Secure->GetPOST("projekt")=="")
      $selectid = $this->DB->Select("SELECT projekt FROM `$module` WHERE id='$id' LIMIT 1");
    else
      $selectid = $this->Secure->GetPOST("projekt");

    $options = $this->erp->GetProjektSelect($selectid,$color_selected); 
    $this->Tpl->Set(EPROO_SELECT_PROJEKT,"<select name=\"projekt\" 
      style=\"background-color:$color_selected;\"
      onChange=\"this.style.backgroundColor=this.options[this.selectedIndex].style.backgroundColor\">$options</select>");
    //$this->Tpl->Set(EPROO_SELECT_PROJEKT,"<select name=\"projekt\" onChange=\"fillUnterprojekt();\">$options</select>");
    //$this->Tpl->Set(EPROO_SELECT_UNTERPROJEKT,"<select name=\"unterprojekt\"><option>Einkauf Olimex</option></select>");
    $this->Tpl->Set(EPROO_SELECT_UNTERPROJEKT,"<div id=\"selectunterprojekt\">
    <select name=\"unterprojekt\">
    </select>
    </div>");


	$this->Tpl->Set(LESEZEICHEN,'<a title="Angebot" href="index.php?module=angebot&action=search">Angebotssuche</a>&nbsp;');
	$this->Tpl->Add(LESEZEICHEN,'<a title="Auftrag" href="index.php?module=auftrag&action=search">Auftragssuche</a>&nbsp;');
	$this->Tpl->Add(LESEZEICHEN,'<a title="Rechnung" href="index.php?module=rechnung&action=search">Rechnungssuche</a>&nbsp;');
	$this->Tpl->Add(LESEZEICHEN,'<a title="Adresse" href="index.php?module=adresse&action=search">Adressensuche</a>&nbsp;');
	$this->Tpl->Add(LESEZEICHEN,'<a title="Adresse" href="index.php?module=wareneingang&action=paketannahme">Paket Annahme</a>');


		if($this->Secure->GetGET("top")!="")
			$this->User->SetParameter("top",$this->Secure->GetGET("top"));


		$top = $this->User->GetParameter("top");
		if($top!="") $this->Tpl->Set(TOPHEADING,base64_decode($top));
		else $this->Tpl->Set(TOPHEADING,"waWision");


    /*********** select field for projekt ***************/
    if($this->Secure->GetPOST("land")=="" && $this->Secure->GetGET("land")=="")
		{
      $selectid = $this->DB->Select("SELECT land FROM `$module` WHERE id='$id' LIMIT 1");
			//if($selectid<=0 && $module=="lieferadressepopup") $this->DB->Select("SELECT land FROM `lieferadressen` WHERE id='$id' LIMIT 1");
			if($selectid<=0 && $selectid=="") { $selectid = $this->DB->Select("SELECT land FROM `lieferadressen` WHERE id='$lid' LIMIT 1"); }
		}
    else if($this->Secure->GetGET("land")!="")
      $selectid = $this->Secure->GetGET("land");
    else
      $selectid = $this->Secure->GetPOST("land");


    $this->Tpl->Set(EPROO_SELECT_LAND,"<select name=\"land\">".$this->SelectLaenderliste($selectid)."</select>");
    $this->Tpl->Set(EPROO_SELECT_LIEFERLAND,"<select name=\"lieferland\">".$this->SelectLaenderliste($selectid)."</select>");

    if($this->Secure->GetPOST("lieferland")=="")
      $selectid = $this->DB->Select("SELECT lieferland FROM `$module` WHERE id='$id' LIMIT 1");
    else
      $selectid = $this->Secure->GetPOST("lieferland");

    $this->Tpl->Set(EPROO_SELECT_LIEFERLAND,"<select name=\"lieferland\">".$this->SelectLaenderliste($selectid)."</select>");


    $this->Tpl->Set(VORGAENGELINK,"<a href=\"#\" onclick=\"var ergebnistext=prompt('Lesezeichen:','".ucfirst($module)."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=vorgang&titel='+ergebnistext;\">*</a>");


/*
    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(SUBSUBHEADING,"Artikelsuche");
    $this->Tpl->Set(INHALT,"<form action=\"index.php?module=artikel&action=list\" method=\"post\"><table><tr height=\"20\" valign=\"top\"><td>&nbsp;</td><td>Artikel:</td><td nowrap><input type=\"text\" name=\"suchwort\" size=\"10\">&nbsp;<input type=\"submit\" name=\"suche\" value=\"Suchen\"></td></tr></table></form>");
    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein_empty.tpl");


    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(SUBSUBHEADING,"Auftragssuche");
    $this->Tpl->Set(INHALT,"<form action=\"index.php?module=auftrag&action=search\" method=\"post\"><table><tr height=\"20\" valign=\"top\"><td>&nbsp;</td><td>Suche:</td><td nowrap><input type=\"text\" name=\"suchwort\" size=\"10\">&nbsp;<input type=\"submit\" name=\"suche\" value=\"Suchen\"></td></tr></table></form>");
    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein_empty.tpl");


    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(SUBSUBHEADING,"Adressensuche");
    $this->Tpl->Set(INHALT,"<form action=\"index.php?module=adresse&action=list\" method=\"post\"><table><tr height=\"20\" valign=\"top\"><td>&nbsp;</td><td>Suche:</td><td nowrap><input type=\"text\" name=\"name\" size=\"10\">&nbsp;<input type=\"submit\" name=\"suche\" value=\"Suchen\"></td></tr></table></form>");
    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein_empty.tpl");

    $this->Tpl->Set(INHALT,"");

*/

/*

    $this->Tpl->Set(SUBSUBHEADING,"Lesezeichen");
    $arrVorgaenge = $this->DB->SelectArr("SELECT * FROM offenevorgaenge WHERE adresse='{$this->User->GetAdresse()}' ORDER by id DESC LIMIT 5");
    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(LINK,"<a href=\"#\" onclick=\"var ergebnistext=prompt('Offener Vorgang:','".ucfirst($arrVorgaenge[$i]['titel'])."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=vorgang&titel='+ergebnistext;\">Aktuelle Stelle merken</a>");
    if(count($arrVorgaenge) > 0)
    {
      for($i=0;$i<count($arrVorgaenge);$i++)
      {

	$this->Tpl->Add(PRELINK,"<li>".substr(ucfirst($arrVorgaenge[$i]['titel']),0,12)."<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"7\" border=\"0\" align=\"right\">
  <a href=\"index.php?".$arrVorgaenge[$i]['href']."\"><img src=\"./themes/[THEME]/images/right.png\" border=\"0\" align=\"right\" title=\"Erledigen\"></a>&nbsp;
  <a href=\"index.php?module=welcome&action=removevorgang&vorgang={$arrVorgaenge[$i]['id']}\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\" align=\"right\" title=\"Erledigt\"></a>&nbsp;
<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"3\" border=\"0\" align=\"right\">
<a href=\"\" onclick=\"var ergebnistext=prompt('Offenen Vorgang umbenennen:','".ucfirst($arrVorgaenge[$i]['titel'])."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=editvorgang&vorgang={$arrVorgaenge[$i]['id']}&titel='+ergebnistext;\"><img src=\"./themes/[THEME]/images/edit.png\" alt=\"Bearbeiten\" title=\"Bearbeiten\" border=\"0\" align=\"right\"></a></li>");
      }
    }

    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein.tpl");


*/
/*
    //fenster rechts offene vorgaenge ***
    $this->Tpl->Set(SUBSUBHEADING,"Vorg&auml;nge");
    $arrVorgaenge = $this->DB->SelectArr("SELECT * FROM offenevorgaenge WHERE adresse='{$this->User->GetAdresse()}' ORDER by id DESC");
    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(LINK,"<a href=\"#\" onclick=\"var ergebnistext=prompt('Offener Vorgang:','".ucfirst($arrVorgaenge[$i]['titel'])."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=vorgang&titel='+ergebnistext;\">Aktuelle Stelle merken</a>");
    if(count($arrVorgaenge) > 0)
    {
      for($i=0;$i<count($arrVorgaenge);$i++)
      {

	$this->Tpl->Add(PRELINK,"<li>".substr(ucfirst($arrVorgaenge[$i]['titel']),0,12)."<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"7\" border=\"0\" align=\"right\">
  <a href=\"index.php?".$arrVorgaenge[$i]['href']."\"><img src=\"./themes/[THEME]/images/right.png\" border=\"0\" align=\"right\" title=\"Erledigen\"></a>&nbsp;
  <a href=\"index.php?module=welcome&action=removevorgang&vorgang={$arrVorgaenge[$i]['id']}\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\" align=\"right\" title=\"Erledigt\"></a>&nbsp;
<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"3\" border=\"0\" align=\"right\">
<a href=\"\" onclick=\"var ergebnistext=prompt('Offenen Vorgang umbenennen:','".ucfirst($arrVorgaenge[$i]['titel'])."'); if(ergebnistext!='' && ergebnistext!=null) window.location.href='index.php?module=welcome&action=editvorgang&vorgang={$arrVorgaenge[$i]['id']}&titel='+ergebnistext;\"><img src=\"./themes/[THEME]/images/edit.png\" alt=\"Bearbeiten\" title=\"Bearbeiten\" border=\"0\" align=\"right\"></a></li>");
      }
    }

    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein.tpl");
*/
/*
    if($module!="webmail")
    {
    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(SUBSUBHEADING,"Webmail");

    $adresse = $this->User->GetAdresse();

    $sql = "SELECT   id, 
                     sender, 
                     subject, 
                     gelesen,
                     DATE_FORMAT(empfang, '%d.%m %H:%i' ) eingang
            FROM     emailbackup_mails 
            WHERE    webmail IN (SELECT id FROM emailbackup WHERE emailbackup.adresse = '$adresse') AND spam!='1' AND gelesen=0
            ORDER BY empfang DESC LIMIT 5";


    $arrVorgaenge = $this->DB->SelectArr($sql);

    $this->Tpl->Set(INHALT,"");
    $this->Tpl->Set(PRELINK,"");
    $this->Tpl->Set(LINK,"<a href=\"index.php?module=webmail&action=list\">zum E-Mail Programm</a>");
    if(count($arrVorgaenge) > 0)
    {
      for($i=0;$i<count($arrVorgaenge);$i++)
      {

	$this->Tpl->Add(PRELINK,"<li>".substr(ucfirst($arrVorgaenge[$i]['sender']),0,15)."<img src=\"./themes/[THEME]/images/1x1t.gif\" width=\"20\" border=\"0\" align=\"right\">
  <a href=\"index.php?module=webmail&action=view&id=".$arrVorgaenge[$i]['id']."\"><img src=\"./themes/[THEME]/images/right.png\" border=\"0\" align=\"right\" title=\"Erledigen\"></a>&nbsp;</li>");
  }
} 
    $this->Tpl->Parse(FENSTERRECHTS,"rahmen_klein.tpl");
    }
*/
     //ende fenster rechts offene vorgaenge ***

   $this->Tpl->Set(BENUTZER,$this->User->GetName());
   $this->Tpl->Set(VERSIONUNDSTATUS,"Server: ".$_SERVER["SERVER_NAME"]."&nbsp;|&nbsp;Client: ".$_SERVER [ REMOTE_ADDR ]."&nbsp;|&nbsp;User: ".$this->User->GetDescription());
    $this->Tpl->Set(SERVERDATE,"Serverzeit: ".date('d.m.Y H:i')." Uhr");

    $this->Tpl->Set(MODUL,ucfirst($module));
 
    $this->Tpl->Set(HTMLTITLE,"waWision | [MODUL] ");
    $firmenname = $this->DB->Select("SELECT name FROM firmendaten WHERE firma='".$this->User->GetFirma()."' LIMIT 1");
    $firmenfarbe = $this->DB->Select("SELECT firmenfarbe FROM firmendaten WHERE firma='".$this->User->GetFirma()."' LIMIT 1");
    $this->Tpl->Set(FIRMENNAME,$firmenname);
    $this->Tpl->Set(FIRMENFARBE,$firmenfarbe);


  }


  function SelectLaenderliste($selected="")
  {
    if($selected=="") $selected="DE";

    $laender = array(
    'Afghanistan'  => 'AF',
    '&Auml;gypten'  => 'EG',
    'Albanien'  => 'AL',
    'Algerien'  => 'DZ',
    'Andorra'  => 'AD',
    'Angola'  => 'AO',
    'Anguilla'  => 'AI',
    'Antarktis'  => 'AQ',
    'Antigua und Barbuda'  => 'AG',
    '&Auml;quatorial Guinea'  => 'GQ',
    'Argentinien'  => 'AR',
    'Armenien'  => 'AM',
    'Aruba'  => 'AW',
    'Aserbaidschan'  => 'AZ',
    '&Auml;thiopien'  => 'ET',
    'Australien'  => 'AU',
    'Bahamas'  => 'BS',
    'Bahrain'  => 'BH',
    'Bangladesh'  => 'BD',
    'Barbados'  => 'BB',
    'Belgien'  => 'BE',
    'Belize'  => 'BZ',
    'Benin'  => 'BJ',
    'Bermudas'  => 'BM',
    'Bhutan'  => 'BT',
    'Birma'  => 'MM',
    'Bolivien'  => 'BO',
    'Bosnien-Herzegowina'  => 'BA',
    'Botswana'  => 'BW',
    'Bouvet Inseln'  => 'BV',
    'Brasilien'  => 'BR',
    'Britisch-Indischer Ozean'  => 'IO',
    'Brunei'  => 'BN',
    'Bulgarien'  => 'BG',
    'Burkina Faso'  => 'BF',
    'Burundi'  => 'BI',
    'Chile'  => 'CL',
    'China'  => 'CN',
    'Christmas Island'  => 'CX',
    'Cook Inseln'  => 'CK',
    'Costa Rica'  => 'CR',
    'D&auml;nemark'  => 'DK',
    'Deutschland'  => 'DE',
    'Djibuti'  => 'DJ',
    'Dominika'  => 'DM',
    'Dominikanische Republik'  => 'DO',
    'Ecuador'  => 'EC',
    'El Salvador'  => 'SV',
    'Elfenbeink&uuml;ste'  => 'CI',
    'Eritrea'  => 'ER',
    'Estland'  => 'EE',
    'Falkland Inseln'  => 'FK',
    'F&auml;r&ouml;er Inseln'  => 'FO',
    'Fidschi'  => 'FJ',
    'Finnland'  => 'FI',
    'Frankreich'  => 'FR',
    'Franz&ouml;sisch Guyana'  => 'GF',
    'Franz&ouml;sisch Polynesien'  => 'PF',
    'Franz&ouml;sisches S&uuml;d-Territorium'  => 'TF',
    'Gabun'  => 'GA',
    'Gambia'  => 'GM',
    'Georgien'  => 'GE',
    'Ghana'  => 'GH',
    'Gibraltar'  => 'GI',
    'Grenada'  => 'GD',
    'Griechenland'  => 'GR',
    'Gr&ouml;nland'  => 'GL',
    'Großbritannien'  => 'UK',
    'Großbritannien (UK)'  => 'GB',
    'Guadeloupe'  => 'GP',
    'Guam'  => 'GU',
    'Guatemala'  => 'GT',
    'Guinea'  => 'GN',
    'Guinea Bissau'  => 'GW',
    'Guyana'  => 'GY',
    'Haiti'  => 'HT',
    'Heard und McDonald Islands'  => 'HM',
    'Honduras'  => 'HN',
    'Hong Kong'  => 'HK',
    'Indien'  => 'IN',
    'Indonesien'  => 'ID',
    'Irak'  => 'IQ',
    'Iran'  => 'IR',
    'Irland'  => 'IE',
    'Island'  => 'IS',
    'Israel'  => 'IL',
    'Italien'  => 'IT',
    'Jamaika'  => 'JM',
    'Japan'  => 'JP',
    'Jemen'  => 'YE',
    'Jordanien'  => 'JO',
    'Jugoslawien'  => 'YU',
    'Kaiman Inseln'  => 'KY',
    'Kambodscha'  => 'KH',
    'Kamerun'  => 'CM',
    'Kanada'  => 'CA',
    'Kap Verde'  => 'CV',
    'Kasachstan'  => 'KZ',
    'Kenia'  => 'KE',
    'Kirgisistan'  => 'KG',
    'Kiribati'  => 'KI',
    'Kokosinseln'  => 'CC',
    'Kolumbien'  => 'CO',
    'Komoren'  => 'KM',
    'Kongo'  => 'CG',
    'Kongo, Demokratische Republik'  => 'CD',
    'Kroatien'  => 'HR',
    'Kuba'  => 'CU',
    'Kuwait'  => 'KW',
    'Laos'  => 'LA',
    'Lesotho'  => 'LS',
    'Lettland'  => 'LV',
    'Libanon'  => 'LB',
    'Liberia'  => 'LR',
    'Libyen'  => 'LY',
    'Liechtenstein'  => 'LI',
    'Litauen'  => 'LT',
    'Luxemburg'  => 'LU',
    'Macao'  => 'MO',
    'Madagaskar'  => 'MG',
    'Malawi'  => 'MW',
    'Malaysia'  => 'MY',
    'Malediven'  => 'MV',
    'Mali'  => 'ML',
    'Malta'  => 'MT',
    'Marianen'  => 'MP',
    'Marokko'  => 'MA',
    'Marshall Inseln'  => 'MH',
    'Martinique'  => 'MQ',
    'Mauretanien'  => 'MR',
    'Mauritius'  => 'MU',
    'Mayotte'  => 'YT',
    'Mazedonien'  => 'MK',
    'Mexiko'  => 'MX',
    'Mikronesien'  => 'FM',
    'Mocambique'  => 'MZ',
    'Moldavien'  => 'MD',
    'Monaco'  => 'MC',
    'Mongolei'  => 'MN',
    'Montserrat'  => 'MS',
    'Namibia'  => 'NA',
    'Nauru'  => 'NR',
    'Nepal'  => 'NP',
    'Neukaledonien'  => 'NC',
    'Neuseeland'  => 'NZ',
    'Nicaragua'  => 'NI',
    'Niederlande'  => 'NL',
    'Niederl&auml;ndische Antillen'  => 'AN',
    'Niger'  => 'NE',
    'Nigeria'  => 'NG',
    'Niue'  => 'NU',
    'Nord Korea'  => 'KP',
    'Norfolk Inseln'  => 'NF',
    'Norwegen'  => 'NO',
    'Oman'  => 'OM',
    '&Ouml;sterreich'  => 'AT',
    'Pakistan'  => 'PK',
    'Pal&auml;stina'  => 'PS',
    'Palau'  => 'PW',
    'Panama'  => 'PA',
    'Papua Neuguinea'  => 'PG',
    'Paraguay'  => 'PY',
    'Peru'  => 'PE',
    'Philippinen'  => 'PH',
    'Pitcairn'  => 'PN',
    'Polen'  => 'PL',
    'Portugal'  => 'PT',
    'Puerto Rico'  => 'PR',
    'Qatar'  => 'QA',
    'Reunion'  => 'RE',
    'Ruanda'  => 'RW',
    'Rum&auml;nien'  => 'RO',
    'Ru&szlig;land'  => 'RU',
    'Saint Lucia'  => 'LC',
    'Sambia'  => 'ZM',
    'Samoa'  => 'AS',
    'Samoa'  => 'WS',
    'San Marino'  => 'SM',
    'Sao Tome'  => 'ST',
    'Saudi Arabien'  => 'SA',
    'Schweden'  => 'SE',
    'Schweiz'  => 'CH',
    'Senegal'  => 'SN',
    'Seychellen'  => 'SC',
    'Sierra Leone'  => 'SL',
    'Singapur'  => 'SG',
    'Slowakei -slowakische Republik-'  => 'SK',
    'Slowenien'  => 'SI',
    'Solomon Inseln'  => 'SB',
    'Somalia'  => 'SO',
    'South Georgia, South Sandwich Isl.'  => 'GS',
    'Spanien'  => 'ES',
    'Sri Lanka'  => 'LK',
    'St. Helena'  => 'SH',
    'St. Kitts Nevis Anguilla'  => 'KN',
    'St. Pierre und Miquelon'  => 'PM',
    'St. Vincent'  => 'VC',
    'S&uuml;d Korea'  => 'KR',
    'S&uuml;dafrika'  => 'ZA',
    'Sudan'  => 'SD',
    'Surinam'  => 'SR',
    'Svalbard und Jan Mayen Islands'  => 'SJ',
    'Swasiland'  => 'SZ',
    'Syrien'  => 'SY',
    'Tadschikistan'  => 'TJ',
    'Taiwan'  => 'TW',
    'Tansania'  => 'TZ',
    'Thailand'  => 'TH',
    'Timor'  => 'TP',
    'Togo'  => 'TG',
    'Tokelau'  => 'TK',
    'Tonga'  => 'TO',
    'Trinidad Tobago'  => 'TT',
    'Tschad'  => 'TD',
    'Tschechische Republik'  => 'CZ',
    'Tunesien'  => 'TN',
    'T&uuml;rkei'  => 'TR',
    'Turkmenistan'  => 'TM',
    'Turks und Kaikos Inseln'  => 'TC',
    'Tuvalu'  => 'TV',
    'Uganda'  => 'UG',
    'Ukraine'  => 'UA',
    'Ungarn'  => 'HU',
    'Uruguay'  => 'UY',
    'Usbekistan'  => 'UZ',
    'Vanuatu'  => 'VU',
    'Vatikan'  => 'VA',
    'Venezuela'  => 'VE',
    'Vereinigte Arabische Emirate'  => 'AE',
    'Vereinigte Staaten von Amerika'  => 'US',
    'Vietnam'  => 'VN',
    'Virgin Island (Brit.)'  => 'VG',
    'Virgin Island (USA)'  => 'VI',
    'Wallis et Futuna'  => 'WF',
    'Wei&szlig;ru&szlig;land'  => 'BY',
    'Westsahara'  => 'EH',
    'Zentralafrikanische Republik'  => 'CF',
    'Zimbabwe'  => 'ZW',
    'Zypern'  => 'CY'
    );

    foreach ($laender as $land => $kuerzel) {
      $options = $options."<option value=\"$kuerzel\"";
        if ($selected == $kuerzel) $options = $options." selected";
	  $options = $options.">$land</option>\n";
    } 
    return $options;
  }




  function HauptMenu()
  {

    //pruefe ob es cookie am rechner gibt   
    if(0){


    } else {
      $this->BuildHauptMenu();

    }


  }

  function BuildHauptMenu($usergroup="")
  {
    if($usergroup=="")
      $usergroup = $this->User->GetType();

    $user = $this->User->GetName();

    // Allgemeine Regel
    $datastruct = $this->DB->Select("SELECT datastruct FROM navigationcache WHERE user='".$this->User->GetID()."' AND usergroup='$usergroup' AND firma='".$this->User->GetFirma()."'");

    if($datastruct=="")
      $datastruct = $this->DB->Select("SELECT datastruct FROM navigationcache WHERE user='0' AND usergroup='$usergroup' AND firma='".$this->User->GetFirma()."'");


    $menu = unserialize(base64_decode($datastruct));

    $anzahl = count($menu);
    $width = 100 / $anzahl;
    $rowcount = 0;


if(is_array($menu))   
    foreach($menu as $hauptmenu=>$hauptmenuuntergruppe)
    {
      $label = $hauptmenuuntergruppe[0][0];
      $color = $hauptmenuuntergruppe[0][2];
      $this->Tpl->Add(HAUPTMENU,"<td width=\"$width%\"style=\"background-color: $color\" align=\"center\"><a href=\"#\" onclick=\"setVisibility('hauptmenurow".$rowcount."')\">$label</a></td>");
      if($rowcount < $anzahl /2) $posleft = 240; else $posleft=413;
      $this->Tpl->Add(HAUPTMENUDIV,'<div id="hauptmenurow'.$rowcount.'" style="display: none; visibility: hidden; background-color: '.$color.'; 
	  position:absolute; top:40px; left:'.$posleft.'px; width: 800; height: 300; z-index: 1000;"><table width="800" height="300"><tr valign="top"><td>[HAUPTSUBMENU'.$rowcount.']</tr>
	  <tr height="20"><td align="right" colspan="'.$anzahl.'"><a href="#" onclick="setVisibility(\'hidden\');">Men&uuml; ausblenden</a></td></table></div>');
      $this->Tpl->Add(HAUPTMENUJS,'document.getElementById("hauptmenurow'.$rowcount.'").style.visibility = "hidden";
        document.getElementById("hauptmenurow'.$rowcount.'").style.display = "none";
	');

      // untermenu

      for($i=1;$i<=count($hauptmenuuntergruppe[0]);$i++)
      {

	$this->Tpl->Add(HAUPTSUBMENU.$rowcount, "<td>");
	$this->Tpl->Add(HAUPTSUBMENU.$rowcount, "<h3>".$hauptmenuuntergruppe[$i][0][0]."</h3>");
	$this->Tpl->Add(HAUPTSUBMENU.$rowcount, "<ul>");

	for($j=1;$j<=count($hauptmenuuntergruppe[$i]);$j++)
	{
	  $label = $hauptmenuuntergruppe[$i][$j][0];
	  $link = $hauptmenuuntergruppe[$i][$j][1];
	  $this->Tpl->Add(HAUPTSUBMENU.$rowcount,"<li><a href=\"$link\">$label</a></li>"); 
	}

	$this->Tpl->Add(HAUPTSUBMENU.$rowcount, "</ul>");
	$this->Tpl->Add(HAUPTSUBMENU.$rowcount, "</td>");

      }


      $rowcount++;
    }
  } 
}





?>
