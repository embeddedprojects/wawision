<?php
// pdf generieren und lokal speichern
exec('perl ../printpdf.pl > /dev/null');

?>
