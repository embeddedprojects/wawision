<?php


class AuftragPDF extends Briefpapier {
  public $doctype;
  
  function AuftragPDF($app,$proforma="")
  {
    $this->app=&$app;
    //parent::Briefpapier();
    if($proforma=="")
    {
    $this->doctypeOrig="Auftrag";
    $this->doctype="auftrag";
    }
    else
    { 
    $this->doctypeOrig="Proformarechnung";
    $this->doctype="proforma";
    }
    parent::Briefpapier(&$this->app);
  } 


  function GetAuftrag($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$id' LIMIT 1");
      //$this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"auftrag");


      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM auftrag WHERE id='$id' LIMIT 1");
      $anfrage= $this->app->DB->Select("SELECT angebot FROM auftrag WHERE id='$id' LIMIT 1");
      $vertrieb= $this->app->DB->Select("SELECT vertrieb FROM auftrag WHERE id='$id' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM auftrag WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM auftrag WHERE id='$id' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM auftrag WHERE id='$id' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM auftrag WHERE id='$id' LIMIT 1");
      $keinsteuersatz = $this->app->DB->Select("SELECT keinsteuersatz FROM auftrag WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM auftrag WHERE id='$id' LIMIT 1");


      $telefax= $this->app->DB->Select("SELECT telefax FROM adresse WHERE id='$adresse' LIMIT 1");

      if($belegnr<=0) $belegnr = "- Entwurf";
      if($this->doctype=="auftrag")
      $this->doctypeOrig="Auftragsbestätigung $belegnr";
      else
      $this->doctypeOrig="Proformarechnung $belegnr";

      if($auftrag=="") $auftrag = "-";
      if($kundennummer=="") $kundennummer= "-";


      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM auftrag WHERE id='$id' LIMIT 1");


$zahlungsweise = ucfirst($zahlungsweise);
      $zahlungstext = "\nZahlungsweise: $zahlungsweise ";
      if($zahlungszieltage >0) $zahlungstext .= "zahlbar innerhalb $zahlungszieltage Tagen.";
      else
        $zahlungstext .= "zahlbar sofort.";

      if($zahlungszielskonto>0) $zahlungstext .= "\nSkonto $zahlungszielskonto% innerhalb $zahlungszieltageskonto Tagen";



      
      if($telefax!="" && $telefax!=0)
	$this->setCorrDetails(array("Angebot"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Auftragsdatum"=>$datum,"Vertrieb"=>$vertrieb,"Ihre Faxnummer"=>$telefax));
      else
	$this->setCorrDetails(array("Angebot"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Auftragsdatum"=>$datum,"Vertrieb"=>$vertrieb));
/*
      if($this->doctype=="auftrag")
      {
      $this->setTextDetails(array(
	  "body"=>"Sehr geehrte Damen und Herren,\n\nvielen Dank für Ihren Auftrag.", 
	  "footer"=>"$freitext\n\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig."));
      } else {
*/
	if(!$this->app->erp->AuftragMitUmsatzeuer($id) && $keinsteuersatz!="1") $steuerzeile = "Steuerfrei nach § 4 Nr. 1b i.V.m. § 6 a UStG. Ihre USt-IdNr. $ustid Land: $land";
	  $this->setTextDetails(array(
	  "body"=>"Sehr geehrte Damen und Herren,\n\nvielen Dank für Ihren Auftrag.", 
	  "footer"=>"$freitext\n\n$zahlungstext\n\n$steuerzeile"));


 //     }


      if(!$this->app->erp->AuftragMitUmsatzeuer($id)) $this->ust_befreit=true;
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id' ORDER By sort");

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM auftrag_position WHERE auftrag='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
       // if($value[umsatzsteuer] == "" || $value[umsatzsteuer] ==0) $value[umsatzsteuer] = "normal";
        if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";

	//if(!$this->app->erp->AuftragMitUmsatzeuer($id)) $value[umsatzsteuer] = ""; 
	$this->addItem(array('currency'=>$value[waehrung],'amount'=>$value[menge],'price'=>$value[preis],'tax'=>$value[umsatzsteuer],'itemno'=>$value[nummer],'desc'=>$value[beschreibung],
	  "name"=>$value[bezeichnung]));
      }
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id'");

      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id' AND (umsatzsteuer='normal' or umsatzsteuer='')")/100 * 19;
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
      
      if($this->app->erp->AuftragMitUmsatzeuer($id))
      {
	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else
      $this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM auftrag WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
      $tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      $tmp_name = str_replace('.','',$tmp_name);

      if($this->doctype=="auftrag")
      $this->filename = $datum."_AB".$belegnr.".pdf";
      else
      $this->filename = $datum."_PR".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
