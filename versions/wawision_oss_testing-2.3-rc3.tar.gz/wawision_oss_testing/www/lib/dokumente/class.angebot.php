<?php


class AngebotPDF extends Briefpapier {
  public $doctype;
  
  function AngebotPDF($app)
  {
    $this->app=&$app;
    //parent::Briefpapier();
    $this->doctype="angebot";
    $this->doctypeOrig="Angebot";
    parent::Briefpapier(&$this->app);
  } 


  function GetAngebot($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM angebot WHERE id='$id' LIMIT 1");
      //$this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"angebot");
            
      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM angebot WHERE id='$id' LIMIT 1");
      $ustid= $this->app->DB->Select("SELECT ustid FROM angebot WHERE id='$id' LIMIT 1");
      $keinsteuersatz= $this->app->DB->Select("SELECT keinsteuersatz FROM angebot WHERE id='$id' LIMIT 1");
      $land= $this->app->DB->Select("SELECT land FROM angebot WHERE id='$id' LIMIT 1");
      $anfrage= $this->app->DB->Select("SELECT anfrage FROM angebot WHERE id='$id' LIMIT 1");
      $vertrieb= $this->app->DB->Select("SELECT vertrieb FROM angebot WHERE id='$id' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM angebot WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM angebot WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM angebot WHERE id='$id' LIMIT 1");

			$zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM angebot WHERE id='$id' LIMIT 1");



			$zahlungsweise = ucfirst($zahlungsweise);	

			$zahlungstext = "\nZahlungsweise: $zahlungsweise ";
			if($zahlungszieltage >0) $zahlungstext .= "zahlbar innerhalb $zahlungszieltage Tagen.";
			else
				$zahlungstext .= "zahlbar sofort.";

			if($zahlungszielskonto>0) $zahlungstext .= "\nSkonto $zahlungszielskonto% innerhalb $zahlungszieltageskonto Tagen";	

      if($belegnr<=0) $belegnr = "- Entwurf";

      $this->doctypeOrig="Angebot $belegnr";

      if($angebot=="") $angebot = "-";
      if($kundennummer=="") $kundennummer= "-";

      $this->setCorrDetails(array("Anfrage"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Bestelldatum"=>$datum,"Vertrieb"=>$vertrieb));
      if(!$this->app->erp->AngebotMitUmsatzeuer($id) && $ustid!=""  && $keinsteuersatz!="1")
      {
        //$steuer = "\nSteuerfreie innergemeinschaftliche Lieferung. Ihre USt-IdNr. $ustid Land: $land";
        $steuer = "\nSteuerfrei nach § 4 Nr. 1b i.V.m. § 6 a UStG. Ihre USt-IdNr. $ustid Land: $land";
      }




      $this->setTextDetails(array(
	  "body"=>"Sehr geehrte Damen und Herren,\n\nhiermit bieten wir Ihnen an:", 
	  "footer"=>"$freitext\n\n$zahlungstext\n$steuer\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig"));
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM angebot_position WHERE angebot='$id' ORDER By sort");
      if(!$this->app->erp->AngebotMitUmsatzeuer($id)) $this->ust_befreit=true;

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM angebot_position WHERE angebot='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
//	if($value[umsatzsteuer] == "") $value[umsatzsteuer] = "normal";
        if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";

	   $this->addItem(array('currency'=>$value[waehrung],'amount'=>$value[menge],'price'=>$value[preis],'tax'=>$value[umsatzsteuer],'itemno'=>$value[nummer],'desc'=>$value[beschreibung],
	    "name"=>$value[bezeichnung]));
      }
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id'");

      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id' AND (umsatzsteuer='normal' or umsatzsteuer='')")/100 * 19;
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
      
      if($this->app->erp->AngebotMitUmsatzeuer($id))
      {
	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else
	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM angebot WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
      //$tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      //$tmp_name = str_replace('.','',$tmp_name);

      $this->filename = $datum."_AN".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
