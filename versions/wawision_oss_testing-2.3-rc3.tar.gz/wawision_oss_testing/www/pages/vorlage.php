<?

class Wiki {
  var $app;
  
  function Wiki($app) {
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","WikiCreate");
    $this->app->ActionHandler("edit","WikiEdit");
    $this->app->ActionHandler("list","WikiList");

    $this->app->DefaultActionHandler("list");

    $this->app->ActionHandlerListen(&$app);
  }


  function WikiCreate()
  {
  }

  function WikiList()
  {

    $this->app->Tpl->Add(TABS,"<a class=\"tab\" href=\"index.php?module=artikel&action=create\">Neue Verbindlichkeit anlegen</a>");
    $this->app->Tpl->Add(TABS,"<a class=\"tab\" href=\"index.php?module=artikel&action=search\">Verbindlichkeit suchen</a>");

  }

  function WikiMenu()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Wiki");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=list","Zur&uuml;ck zur &Uuml;bersicht");
  }


  function WikiEdit()
  {
  }





}

?>
