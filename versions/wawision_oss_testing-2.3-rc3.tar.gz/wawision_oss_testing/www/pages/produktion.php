<?php
include ("_gen/produktion.php");

class Produktion extends GenProduktion
{

  function Produktion(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("list","ProduktionList");
    $this->app->ActionHandler("create","ProduktionCreate");
    $this->app->ActionHandler("positionen","ProduktionPositionen");
    $this->app->ActionHandler("addposition","ProduktionAddPosition");
    $this->app->ActionHandler("upproduktionposition","UpProduktionPosition");
    $this->app->ActionHandler("delproduktionposition","DelProduktionPosition");
    $this->app->ActionHandler("downproduktionposition","DownProduktionPosition");
    $this->app->ActionHandler("positioneneditpopup","ProduktionPositionenEditPopup");
    $this->app->ActionHandler("checkdisplay","ProduktionCheckDisplayPopup");
    $this->app->ActionHandler("edit","ProduktionEdit");
    $this->app->ActionHandler("tracking","ProduktionTracking");
    $this->app->ActionHandler("ausversand","ProduktionDeleteAusVersand");
    $this->app->ActionHandler("search","ProduktionSuche");
    $this->app->ActionHandler("berechnen","AuftraegeBerechnen");
    $this->app->ActionHandler("uststart","ProduktionUstStart");
    $this->app->ActionHandler("delete","ProduktionDelete");
    $this->app->ActionHandler("abschluss","ProduktionAbschluss");
    $this->app->ActionHandler("copy","ProduktionCopy");
    $this->app->ActionHandler("verfuegbar","ProduktionVerfuegbar");
    $this->app->ActionHandler("rechnung","ProduktionRechnung");
    $this->app->ActionHandler("lieferschein","ProduktionLieferschein");
    $this->app->ActionHandler("teillieferung","ProduktionTeillieferung");
    $this->app->ActionHandler("nachlieferung","ProduktionNachlieferung");
    $this->app->ActionHandler("versand","ProduktionVersand");
    $this->app->ActionHandler("freigabe","ProduktionFreigabe");
    $this->app->ActionHandler("abschicken","ProduktionAbschicken");
    $this->app->ActionHandler("pdf","ProduktionPDF");
    $this->app->ActionHandler("proforma","ProduktionProforma");
    $this->app->ActionHandler("versand","ProduktionVersand");
    $this->app->ActionHandler("zahlungsmail","ProduktionZahlungsmail");
    $this->app->ActionHandler("reservieren","ProduktionReservieren");
    $this->app->ActionHandler("nachlieferung","ProduktionNachlieferung");
    $this->app->ActionHandler("protokoll","ProduktionProtokoll");
    $this->app->ActionHandler("minidetail","ProduktionMiniDetail");
    $this->app->ActionHandler("editable","ProduktionEditable");
    $this->app->ActionHandler("livetabelle","ProduktionLiveTabelle");
    $this->app->ActionHandler("zahlungsmahnungswesen","ProduktionZahlungMahnungswesen");


  
    $this->app->DefaultActionHandler("list");
 
    $id = $this->app->Secure->GetGET("id");
    $nummer = $this->app->Secure->GetPOST("adresse");

    if($nummer=="")
      $adresse= $this->app->DB->Select("SELECT a.name FROM produktion b LEFT JOIN adresse a ON a.id=b.adresse WHERE b.id='$id' LIMIT 1");
    else
      $adresse = $nummer;

    $nummer = $this->app->DB->Select("SELECT b.belegnr FROM produktion b LEFT JOIN adresse a ON a.id=b.adresse WHERE b.id='$id' LIMIT 1");
    if($nummer=="" || $nummer==0) $nummer="ohne Nummer";

    $this->app->Tpl->Set(UEBERSCHRIFT,"Produktion:&nbsp;".$adresse." (".$nummer.")");
    $this->app->Tpl->Set(FARBE,"[FARBE2]");

    
    $this->app->ActionHandlerListen(&$app);
  }


  function ProduktionTracking()
  {
      $tracking = $this->app->Secure->GetGET("tracking");
    // Wir werden eine PDF Datei ausgeben
header('Content-type: application/html');

// Es wird downloaded.pdf benannt
header('Content-Disposition: attachment; filename="'.$tracking.'.html"');

// Die originale PDF Datei heißt original.pdf
if(is_file('/var/data/userdata/tracking/'.$tracking.'.html'))
readfile('/var/data/userdata/tracking/'.$tracking.'.html');
  exit;

  }


  function ProduktionZahlungMahnungswesen()
  {

    $this->ProduktionMenu();
    $id = $this->app->Secure->GetGET("id");

    $this->app->Tpl->Set(TABTEXT,"Zahlung-/Mahnungswesen");
    $this->ProduktionMiniDetail(TAB1,true);

    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function ProduktionZahlung($return=false)
  {
    $id = $this->app->Secure->GetGET("id");

    $rechnungArr = $this->app->DB->SelectArr("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, belegnr, gesamtsumme FROM produktion WHERE id='$id' LIMIT 1");

    // suche rechnungen fuer produktion 
    $rechnungen = $this->app->DB->SelectArr("SELECT id FROM rechnung WHERE produktionid='$id'");
    for($i=0;$i<count($rechnungen);$i++)
    {
      $filter .=" OR (ke.objekt='rechnung' AND ke.parameter='{$rechnungen[$i][id]}')";
    } 

    $produktionid = $id;
    $eingang ="<tr><td colspan=\"3\"><b>Zahlungen</b></td></tr>";

// produktionszeile
    $eingang .="<tr><td class=produktion_cell>".$rechnungArr[0][datum]."</td><td class=produktion_cell>AB ".$rechnungArr[0][belegnr]."</td><td class=produktion_cell align=right>".$this->app->erp->EUR($rechnungArr[0][gesamtsumme])." EUR</td></tr>";


    // bei produktion auch rechnungszahlungen zu der rechnung des produktions suchen

    $eingangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, k.id as kontoauszuege, ke.betrag as betrag,k.id as zeile FROM kontoauszuege_zahlungseingang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='produktion' AND ke.parameter='$produktionid') $filter");
    for($i=0;$i<count($eingangArr);$i++)
      $eingang .="<tr><td class=produktion_cell>".$eingangArr[$i][datum]."</td><td class=produktion_cell>".$eingangArr[$i][konto]."&nbsp;(<a href=\"index.php?module=zahlungseingang&action=editzeile&id=".$eingangArr[$i][zeile]."\">zur Buchung</a>)</td><td class=produktion_cell align=right>".$this->app->erp->EUR($eingangArr[$i][betrag])." EUR</td></tr>";

    $ausgangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, ke.betrag as betrag, k.id as zeile FROM kontoauszuege_zahlungsausgang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='produktion' AND ke.parameter='$produktionid') $filter");

    for($i=0;$i<count($ausgangArr);$i++)
      $ausgang .="<tr><td class=produktion_cell>".$ausgangArr[$i][datum]."</td><td class=produktion_cell>".$ausgangArr[$i][konto]."&nbsp;(<a href=\"index.php?module=zahlungseingang&action=editzeile&id=".$ausgangArr[$i][zeile]."\">zur Buchung</a>)</td><td class=produktion_cell align=right>-".$this->app->erp->EUR($ausgangArr[$i][betrag])." EUR</td></tr>";

    $saldo = $this->app->erp->EUR($this->app->erp->ProduktionSaldo($id));

    if($saldo < 0) $saldo = "<b style=\"color:red\">$saldo</b>";

    $eingangende .="<tr><td class=produktion_cell></td><td class=produktion_cell align=right>Saldo</td><td class=produktion_cell align=right>$saldo EUR</td></tr>";

    if($return)return "<table width=100% border=0 class=produktion_cell cellpadding=0 cellspacing=0>".$eingang." ".$ausgang." $eingangende</table>";

  }


  function ProduktionLiveTabelle()
  {
    $id = $this->app->Secure->GetGET("id");
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");

    $table = new EasyTable($this->app);

    if($status=="freigegeben")
    {
    $table->Query("SELECT SUBSTRING(ap.bezeichnung,1,20) as artikel, ap.nummer as Nummer, ap.menge as M,
      if(a.lagerartikel,if(a.porto,'-',if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel) > ap.menge,(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),
      if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel)>0,CONCAT('<font color=red><b>',(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),'</b></font>'),
      '<font color=red><b>aus</b></font>'))),'-') as L
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew("return","A","noAction");
    } else {
      $table->Query("SELECT SUBSTRING(ap.bezeichnung,1,20) as artikel, ap.nummer as Nummer, if(a.lagerartikel,ap.menge,'-') as M
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew("return","Menge","noAction");
    }
    echo $artikel;
    exit;
  }




  function ProduktionEditable()
  {
    $this->app->YUI->AARLGEditable();
  }


  function ProduktionIconMenu($id)
  {
    $menu ="
	<a href=\"index.php?module=produktion&action=pdf&id=%value%\" title=\"PDF\"><img border=\"0\" src=\"./themes/new/images/pdf.png\"></a>";
/*
	<a href=\"index.php?module=produktion&action=proforma&id=%value%\" title=\"Proforma Rechnung\"><img border=\"0\" src=\"./themes/new/images/proforma.gif\"></a>
	<a href=\"index.php?module=produktion&action=edit&id=%value%\" title=\"Bearbeiten\"><img border=\"0\" src=\"./themes/new/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich stornieren?')) return false; else window.location.href='index.php?module=produktion&action=delete&id=%value%';\" title=\"Stornieren\">
          <img src=\"./themes/new/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich kopieren?')) return false; else window.location.href='index.php?module=produktion&action=copy&id=%value%';\" title=\"Kopieren\">
        <img src=\"./themes/new/images/copy.png\" border=\"0\"></a>
     <a onclick=\"if(!confirm('Wirklich als Lieferschein weiterf&uuml;hren?')) return false; else window.location.href='index.php?module=produktion&action=lieferschein&id=%value%';\" title=\"weiterf&uuml;hren als Lieferschein\">
        <img src=\"./themes/new/images/lieferung.png\" border=\"0\"></a>
     <a onclick=\"if(!confirm('Wirklich als Rechnung weiterf&uuml;hren?')) return false; else window.location.href='index.php?module=produktion&action=rechnung&id=%value%';\" title=\"weiterf&uuml;hren als Rechnung\">
        <img src=\"./themes/new/images/rechnung.png\" border=\"0\"></a>
*/
	$menu .="
     <a onclick=\"if(!confirm('Wirklich als Produktion abschlie&szlig;en?')) return false; else window.location.href='index.php?module=produktion&action=versand&id=%value%';\" title=\"weiterf&uuml;hren als Produktion\">
        <img src=\"./themes/new/images/versand.png\" border=\"0\" alt=\"weiterf&uuml;hren als Produktion\"></a>";

      //$tracking = $this->ProduktionTrackingTabelle($id);

    $menu = str_replace('%value%',$id,$menu);
    return $menu;
  }
  function ProduktionZahlungsweiseTabelle($id)
  {
// START
    $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM produktion WHERE id='$id' LIMIT 1");
    if($this->app->Secure->GetPOST("zahlungsweise")!="") $zahlungsweise = $this->app->Secure->GetPOST("zahlungsweise");
    $zahlungsweise = strtolower($zahlungsweise);
    $this->app->Tpl->Set(RECHNUNG,"none");
    $this->app->Tpl->Set(KREDITKARTE,"none");
    $this->app->Tpl->Set(VORKASSE,"none");
    $this->app->Tpl->Set(PAYPAL,"none");
    $this->app->Tpl->Set(EINZUGSERMAECHTIGUNG,"none");
    if($zahlungsweise=="rechnung") $this->app->Tpl->Set(RECHNUNG,"");
    if($zahlungsweise=="paypal") $this->app->Tpl->Set(PAYPAL,"");
    if($zahlungsweise=="kreditkarte") $this->app->Tpl->Set(KREDITKARTE,"");
    if($zahlungsweise=="einzugsermaechtigung" || $zahlungsweise=="lastschrift") $this->app->Tpl->Set(EINZUGSERMAECHTIGUNG,"");
    if($zahlungsweise=="vorkasse" || $zahlungsweise=="kreditkarte" || $zahlungsweise=="paypal" || $zahlungsweise=="bar") $this->app->Tpl->Set(VORKASSE,"");
   

    $vorkasse_ok = $this->app->DB->Select("SELECT vorkasse_ok FROM produktion WHERE id='$id' LIMIT 1");
    if($vorkasse_ok==1){
      if($zahlungsweise=="vorkasse" || $zahlungsweise=="paypal" || $zahlungsweise=="kreditkarte" || $zahlungsweise=="bar") $tpl_vorkassezahlung ="Produktion wurde komplett bezahlt";
      if($zahlungsweise=="bar") $tpl_vorkassezahlung = "Produktion soll bar bezahlt werden";
    }
    else  {
      if($zahlungsweise=="vorkasse" || $zahlungsweise=="paypal" || $zahlungsweise=="kreditkarte" || $zahlungsweise=="bar") $tpl_vorkassezahlung ="Vorkasse noch nicht abgeschlossen!";
    }


    if($zahlungsweise=="paypal" || $zahlungsweise=="kreditkarte" || $zahlungsweise=="vorkasse")
    {

    //ZAHLUNGSEINGANG // wenn einer der reicht dann text sonst tabelle
    $adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
    $table = new EasyTable(&$this->app);
    $table->Query("SELECT DATE_FORMAT(kz.datum,'%d.%m.%Y') as eingang, kz.betrag, ko.bezeichnung as konto,kz.abgeschlossen as komplett FROM kontoauszuege_zahlungseingang kz LEFT JOIN kontoauszuege k ON kz.kontoauszuege=k.id LEFT JOIN konten ko ON ko.id=k.konto WHERE kz.adresse='$adresse' AND kz.objekt='produktion' AND kz.parameter='$id'");
    $tpl_zahlungseingang = $table->DisplayNew("return","Komplett","noAction");


    //nur wenn zahlungsausgaenge vorhanden sind!!!
    $tmp = $this->app->DB->SelectArr("SELECT DATE_FORMAT(kz.datum,'%d.%m.%Y') as ausgang, kz.betrag, ko.bezeichnung as konto,kz.abgeschlossen as komplett FROM kontoauszuege_zahlungsausgang kz LEFT JOIN kontoauszuege k ON kz.kontoauszuege=k.id LEFT JOIN konten ko ON ko.id=k.konto WHERE kz.adresse='$adresse' AND kz.objekt='produktion' AND kz.parameter='$id'");

    if(count($tmp)>0)
    {
      $table->Query("SELECT DATE_FORMAT(kz.datum,'%d.%m.%Y') as ausgang, kz.betrag, ko.bezeichnung as konto,
	kz.abgeschlossen as komplett FROM kontoauszuege_zahlungsausgang kz LEFT JOIN kontoauszuege k ON kz.kontoauszuege=k.id LEFT JOIN konten ko ON ko.id=k.konto WHERE kz.adresse='$adresse' AND kz.objekt='produktion' AND kz.parameter='$id'");
      $tpl_zahlungseingang .= $table->DisplayNew("return","Komplett","noAction");
    }

    $summe_zahlungseingaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE adresse='$adresse' AND objekt='produktion' AND parameter='$id'");
    $summe_zahlungsausgaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungsausgang WHERE adresse='$adresse' AND objekt='produktion' AND parameter='$id'");

    $summe_gesamtsumme = $this->app->DB->Select("SELECT gesamtsumme FROM produktion WHERE id='$id' LIMIT 1");

    $summe_zahlungseingaenge = $summe_zahlungseingaenge - $summe_zahlungsausgaenge; 

    $summe_zahlungseingaenge= $summe_zahlungseingaenge*1.00;
    $summe_gesamtsumme = $summe_gesamtsumme *1.00;

    if($summe_zahlungseingaenge < $summe_gesamtsumme)
    {
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(zahlungsmail,'%d.%m') FROM produktion WHERE id='$id' LIMIT 1");
      if($datum=="00.00") $datum="keine";
      //zu wenig bzw. noch gar nicht
      if($summe_zahlungseingaenge==0)
      {
	if($summe_zahlungsausgaenge >0)
	  $tpl_zahlungseingangmeldung = "<b>Zahlung wurde storniert!</b>";
	else
	  $tpl_zahlungseingangmeldung ="<b>Keine Zahlung vorhanden! </b>&nbsp;<input type=\"button\" value=\"Mail senden (letzte: $datum)\" onclick=\"if(!confirm('Zahlungsmail an Kunden senden?')) return false; else window.location.href='index.php?module=produktion&action=zahlungsmail&id=$id';\">";
      }
      else
      {
      $tpl_zahlungseingangmeldung = "<font color=\"red\"><b>Zuwenig bezahlt!</b>&nbsp;<input type=\"button\" value=\"Zahlungsmail senden (zuletzt am: $datum)\" onclick=\"if(!confirm('Zahlungsmail an Kunden senden?')) return false; else window.location.href='index.php?module=produktion&action=zahlungsmail&id=$id';\"></font>";
      }
    } else if ((int)($summe_zahlungseingaenge) == (int)($summe_gesamtsumme))
    {
      //passt genau
      if ($summe_gesamtsumme!=0)
      $tpl_zahlungseingangmeldung = "<font color=\"green\"><b>Vollst&auml;ndig bezahlt!</b></font>";

    } else {
	$tpl_zahlungseingangmeldung = "<font color=\"red\"><b>Zuviel bezahlt!</b></font>";
    }
    } else {
      //rechnung lastschrift oder nachnahme
//    $adresse = $this->app->DB->Select("SELECT id FROM rechnung FROM produktion WHERE id='$id' LIMIT 1");
    $table = new EasyTable(&$this->app);
    $table->Query("SELECT DATE_FORMAT(r.datum,'%d.%m.%Y') as datum, r.belegnr,r.soll,r.zahlungsweise,(SELECT SUM(k.betrag) FROM kontoauszuege_zahlungseingang k WHERE k.objekt='rechnung' AND k.parameter=r.id) as ist  FROM rechnung r WHERE r.produktionid='$id'");
//echo "SELECT r.belegnr FROM rechnung r WHERE r.produktion='$id'";
//    $table->Query("SELECT DATE_FORMAT(kz.datum,'%d.%m.%Y') as eingang, kz.betrag, ko.bezeichnung as konto,kz.abgeschlossen as komplett FROM kontoauszuege_zahlungseingang kz LEFT JOIN kontoauszuege k ON kz.kontoauszuege=k.id LEFT JOIN konten ko ON ko.id=k.konto WHERE kz.adresse='$adresse' AND kz.objekt='produktion' AND kz.parameter='$id'");
    $tpl_zahlungseingang .= $table->DisplayNew("return","Bezahlt","noAction");

    $summe_soll = $this->app->DB->Select("SELECT soll FROM rechnung r WHERE r.produktionid='$id'");
    $summe = $this->app->DB->Select("SELECT (SELECT SUM(k.betrag) FROM kontoauszuege_zahlungseingang k WHERE k.objekt='rechnung' AND k.parameter=r.id) as ist  FROM rechnung r WHERE r.produktionid='$id'");
if(!is_array($summe_soll) && !is_array($summe)) //TODO
{
    if(($summe_soll - $summe)  <= 0 && $summe_soll > 0)
      $tpl_zahlungseingangmeldung = "<font color=\"green\"><b>Vollst&auml;ndig bezahlt!</b></font>";
    else
      if($summe=="" || $summe==0)
	$tpl_zahlungseingangmeldung = "<font color=\"red\"><b>Noch nicht bezahlt!</b></font>";
      else
	$tpl_zahlungseingangmeldung = "<font color=\"red\"><b>Noch nicht vollst&auml;ndig bezahlt!</b></font>";
} else {

  $tpl_zahlungseingangmeldung = "Mehrer Rechnungen k&ouml;nnen aktuell noch nicht verarbeitet werden.";
}
    }

    return('
    <table width="100%">
        <tr><td>Zahlung:</td><td>'.$tpl_zahlungseingang.'</td>
        </tr>
        <tr><td colspan="2" align="center"><table width="100%" cellpadding=0 cellspacing=0><tr><td>'.$tpl_zahlungseingangmeldung.'</td><td>'.$tpl_vorkassezahlung.'</td></tr></table></td>
        </tr>
    </table>');

  }

  function ProduktionTrackingTabelle($id)
  {
    $table = new EasyTable(&$this->app);

    $table->Query("SELECT if(v.versendet_am!='0000-00-00', DATE_FORMAT(v.versendet_am,'%d.%m.%Y'),CONCAT('Heute im Versand<br><a href=\"#\" onclick=\"if(!confirm(\'Produktion wirklich aus dem Versand nehmen?\')) return false; else window.location.href=\'index.php?module=produktion&action=ausversand&id=',v.id,'\'\">Produktion ist aktuell im Versand -> Jetzt als RMA markieren</a>')) as datum, v.versandunternehmen as versand, v.tracking as L,
      CONCAT('<a href=\"index.php?module=lieferschein&action=pdf&id=',v.lieferschein,'\">',l.belegnr,'</a><br><a href=\"index.php?module=lieferschein&action=edit&id=',v.lieferschein,'\">zum LS</a>') as LS,
      CONCAT('<a href=\"index.php?module=rechnung&action=pdf&id=',v.rechnung,'\">',r.belegnr,'</a><br><a href=\"index.php?module=rechnung&action=edit&id=',v.rechnung,'\">zur RE</a>') as RE,
      if(tracking!='',CONCAT('<a href=\"http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=de&idc=',tracking,'\" target=\"_blank\">Online-Status</a>'),'') FROM versand v 
      LEFT JOIN lieferschein l ON v.lieferschein=l.id 
      LEFT JOIN rechnung r ON v.rechnung=r.id 
      WHERE l.produktionid='$id' AND l.produktion!=''");

     $result = $table->DisplayNew("return","Tracking","noAction");

     $heuteimversand = $this->app->DB->Select("SELECT if(v.versendet_am!='0000-00-00', DATE_FORMAT(v.versendet_am,'%d.%m.%Y'),'Heute im Versand') as datum
       FROM versand v LEFT JOIN lieferschein l ON v.lieferschein=l.id WHERE l.produktionid='$id' AND l.produktion!=''");

      if($heuteimversand=="Heute im Versand")
	$result .="<center><a href=\"\" onclick=\"if(!confirm('Wirklich RMA starten?')) return false; else window.location.href='index.php';\">RMA jetzt starten</a></center>";

      $count = $this->app->DB->Select("SELECT COUNT(v.id) FROM versand v
      LEFT JOIN lieferschein l ON v.lieferschein=l.id
      LEFT JOIN rechnung r ON v.rechnung=r.id
      WHERE l.produktionid='$id' AND l.produktion!=''");

    if($count>0)
    return $result;
    else return  "Keine Versandinformationen vorhanden";
  }

  function ProduktionMiniDetail($parsetarget="",$menu=true)
  {
    $id=$this->app->Secure->GetGET("id");
    $produktionArr = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE id='$id' LIMIT 1");
    $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='{$produktionArr[0]['adresse']}' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='{$produktionArr[0]['projekt']}' LIMIT 1");
    $kundenname = $this->app->DB->Select("SELECT name FROM adresse WHERE id='{$produktionArr[0]['adresse']}' LIMIT 1");
    $this->app->Tpl->Set(KUNDE,"<a href=\"index.php?module=adresse&action=edit&id=".$produktionArr[0]['adresse']."\">".$kundennummer."</a> ".$kundenname);
    $this->app->Tpl->Set(PROJEKT,$projekt);
    $this->app->Tpl->Set(ZAHLWEISE,$produktionArr[0]['zahlungsweise']);
    $summe_zahlungseingaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE adresse='{$produktionArr[0]['adresse']}' AND objekt='produktion' AND parameter='$id'");
    $summe_zahlungsausgaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungsausgang WHERE adresse='{$produktionArr[0]['adresse']}' AND objekt='produktion' AND parameter='$id'");
    $summebrutto = $this->app->DB->Select("SELECT gesamtsumme FROM produktion WHERE id='$id' LIMIT 1");

    if($produktionArr[0]['ust_befreit']==0)
      $this->app->Tpl->Set(STEUER,"Deutschland");
    else if($produktionArr[0]['ust_befreit']==1)
      $this->app->Tpl->Set(STEUER,"EU-Lieferung");
    else
      $this->app->Tpl->Set(STEUER,"Export");




    $this->app->Tpl->Set(EINGANG,number_format($summe_zahlungseingaenge,2,",",""));
    $this->app->Tpl->Set(AUSGANG,number_format($summe_zahlungsausgang,2,",",""));
    $this->app->Tpl->Set(SALDO,number_format( ((-1)*$summe_zahlungsausgang + $summe_zahlungseingaenge) - $summebrutto,2,",",""));
    $this->app->Tpl->Set(GESAMTSUMME,number_format($summebrutto,2,",",""));

   //ENDE ZUSTANDSAUTOMAT FARBEN



    $lieferschein = $this->app->DB->Select("SELECT 
	CONCAT(l.belegnr,'&nbsp;<a href=\"index.php?module=lieferschein&action=pdf&id=',l.id,'\"><img src=\"./themes/new/images/pdf.png\" title=\"Lieferschein PDF\" border=\"0\"></a>&nbsp;
	  <a href=\"index.php?module=lieferschein&action=edit&id=',l.id,'\"><img src=\"./themes/new/images/edit.png\" title=\"Lieferschein bearbeiten\" border=\"0\"></a>')
	FROM lieferschein l WHERE l.produktionid='$id' LIMIT 1");

    $lieferscheinid = $this->app->DB->Select("SELECT l.id
	FROM lieferschein l WHERE l.produktionid='$id' AND l.produktion!='' LIMIT 1");


    if($lieferschein!="")
      $this->app->Tpl->Set(LIEFERSCHEIN,"<a href=\"index.php?module=lieferschein&action=edit&id=".$lieferscheinid."\">".$lieferschein."</a>");
    else
      $this->app->Tpl->Set(LIEFERSCHEIN,"-");


    $rechnung = $this->app->DB->Select("SELECT 
	CONCAT(r.belegnr,'&nbsp;<a href=\"index.php?module=rechnung&action=pdf&id=',r.id,'\"><img src=\"./themes/new/images/pdf.png\" title=\"Rechnung PDF\" border=\"0\"></a>&nbsp;
	  <a href=\"index.php?module=rechnung&action=edit&id=',r.id,'\"><img src=\"./themes/new/images/edit.png\" title=\"Rechnung bearbeiten\" border=\"0\"></a>')
	FROM rechnung r WHERE r.produktionid='$id' LIMIT 1");

    $rechnungid = $this->app->DB->Select("SELECT r.id
	FROM rechnung r WHERE r.produktionid='$id' AND r.produktion!='' LIMIT 1");

    if($rechnung!="")
      $this->app->Tpl->Set(RECHNUNG,"<a href=\"index.php?module=rechnung&action=edit&id=".$rechnungid."\">".$rechnung."</a>");
    else
      $this->app->Tpl->Set(RECHNUNG,"-");


    $tmpVersand = $this->app->DB->Select("SELECT if(v.versendet_am!='0000-00-00', DATE_FORMAT(v.versendet_am,'%d.%m.%Y'),CONCAT('Heute im Versand<br><a href=\"#\" onclick=\"if(!confirm(\'Produktion wirklich aus dem Versand nehmen?\')) return false; else window.location.href=\'index.php?module=produktion&action=ausversand&id=',v.id,'\'\">Produktion ist aktuell im Versand -> Jetzt als RMA markieren</a>')) as datum, v.versandunternehmen as versand, v.tracking as L
      FROM versand v 
      LEFT JOIN lieferschein l ON v.lieferschein=l.id 
      LEFT JOIN rechnung r ON v.rechnung=r.id 
      WHERE l.produktionid='$id' AND l.produktion!=''");


    $tracking = $this->app->DB->Select("SELECT 
	if(versandunternehmen='dhl',if(tracking!='',CONCAT(UPPER(versandunternehmen),':<a href=\"http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=de&idc=',tracking,'\" target=\"_blank\">',tracking,'</a>
      <a href=\"index.php?module=produktion&action=tracking&tracking=',l.id,'_',tracking,'\"><img src=\"./themes/new/images/pdf.png\" title=\"Tracking PDF\" border=\"0\"></a>
      '),'nicht vorhanden'),CONCAT(versandunternehmen,' ',tracking))
	FROM versand v LEFT JOIN lieferschein l ON v.lieferschein=l.id WHERE l.produktionid='$id' AND l.produktion!=''");

      if($tracking!="" && $tracking!=" ")
	$this->app->Tpl->Set(TRACKING,$tracking);
      else
      {
	
	$this->app->Tpl->Set(TRACKING,$tmpVersand);
	//$this->app->Tpl->Set(TRACKING,'-');
      }


    $icons = $this->app->YUI->IconsSQLProduktion();
    $icons = $this->app->DB->Select("SELECT $icons FROM produktion a WHERE a.id='$id' LIMIT 1");
    $this->app->Tpl->Set(STATUSICONS,$icons);

    $this->app->Tpl->Set(STATUS,$produktionArr[0]['status']);
    $this->app->Tpl->Set(INTERNET,$produktionArr[0]['internet']);

    if($menu)
    {
      $menu = $this->ProduktionIconMenu($id);
      $this->app->Tpl->Set(MENU,$menu);
    }


 // ARTIKEL

 $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");

    $table = new EasyTable($this->app);

    if($status=="freigegeben")
    {
    $table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, ap.menge as Menge,
      if(a.lagerartikel,if(a.porto,'-',if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel) > ap.menge,(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),
      if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel)>0,CONCAT('<font color=red><b>',(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),'</b></font>'),
      '<font color=red><b>aus</b></font>'))),'-') as Lager, (SELECT SUM(r.menge) FROM lager_reserviert r WHERE r.artikel=ap.artikel) as Reserviert
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew("return","Reserviert","noAction");

        $this->app->Tpl->Add(JAVASCRIPT,"
            var auto_refresh = setInterval(
        function ()
        {
        $('#artikeltabellelive$id').load('index.php?module=produktion&action=livetabelle&id=$id').fadeIn('slow');
        }, 3000); // refresh every 10000 milliseconds
        ");




    } else {
      //$table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, if(a.lagerartikel,ap.menge,'-') as Menge
      $table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, ap.menge as Menge
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew("return","Menge","noAction");
    }


    $this->app->Tpl->Set(ARTIKEL,'<div id="artikeltabellelive'.$id.'">'.$artikel.'</div>');

//    $this->app->Tpl->Set(ZAHLUNGEN,$this->ProduktionZahlung(true));

  
    //START ZUSTANDSAUTOMAT FARBEN
    if($produktionArr[0]['status']=="freigegeben")
    {
      $this->app->Tpl->Set(VERSANDFARBE,"red");
      $this->app->Tpl->Set(VERSANDTEXT,"Noch nicht versendet!");
    } else if ($produktionArr[0]['status']=="abgeschlossen")
    {
      $this->app->Tpl->Set(VERSANDFARBE,"green");
      $this->app->Tpl->Set(VERSANDTEXT,"versendet!");
    }  else {
      $this->app->Tpl->Set(VERSANDFARBE,"grey");
      $this->app->Tpl->Set(VERSANDTEXT,"-");
    }
 

    $vorkasse_ok = $this->app->DB->Select("SELECT vorkasse_ok FROM produktion WHERE id='$id' LIMIT 1");
    $zahlungsweise = $produktionArr[0]['zahlungsweise'];
    if($vorkasse_ok==1){
      if($zahlungsweise=="vorkasse" || $zahlungsweise=="paypal" || $zahlungsweise=="kreditkarte") {$this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"info\">Der Produktion wurde bezahlt.</div>");}
      else if ($zahlungsweise=="rechnung") { $this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"info\">Der Produktion wird per Rechnung bezahlt.</div>"); }
      else if ($zahlungsweise=="bar" || $zahlungsweise=="nachnahme" ) { $this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"success\">Der Produktion wird bei &Uuml;bergabe bezahlt.</div>"); }
      else { $this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"error\">Fehler (Zahlungsweise fehlt)!</div>"); }
    }
    else  {
      if($zahlungsweise=="vorkasse" || $zahlungsweise=="paypal" || $zahlungsweise=="kreditkarte" || $zahlungsweise=="bar") $this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"error\">Vorkasse noch nicht abgeschlossen!</div>");
    }

    // schaue ob es eine GS zu diesem Produktion gibt
  // schaue ob es eine GS zu diesem Produktion gibt
    $gutschriftid = $this->app->DB->Select("SELECT id FROM gutschrift WHERE rechnungid='$rechnungid' LIMIT 1");

    if(is_numeric($gutschriftid) && $gitschriftid!=0)
        $this->app->Tpl->Add(ZAHLUNGEN,"<div class=\"info\">Zu der Rechnung des Produktions existiert eine Gutschrift 
	<a href=\"index.php?module=gutschrift&action=pdf&id=$gutschriftid\"><img src=\"./themes/new/images/pdf.png\"></a>&nbsp;
	<a href=\"index.php?module=gutschrift&action=edit&id=$gutschriftid\"><img src=\"./themes/new/images/edit.png\"></a>
	! </div>");




    if($produktionArr[0]['rma']==1)
      $this->app->YUI->ParserVarIf(RMA,1);
    else
      $this->app->YUI->ParserVarIf(RMA,0);

    $this->app->Tpl->Set(RMAFARBE,"red");
    $this->app->Tpl->Set(RMATEXT,"RMA zu diesem Produktion vorhanden!");

 


    
    $this->app->Tpl->Set(BELEGNR,$produktionArr[0]['belegnr']);
    $this->app->Tpl->Set(AUFTRAGID,$produktionArr[0]['id']);

    
    $this->app->Tpl->Set(RECHNUNGLIEFERADRESSE,$this->ProduktionRechnungsLieferadresse($produktionArr[0]['id']));


    $this->app->Tpl->Set(RMA,"Es ist kein RMA-Prozess zu diesem Produktion vorhanden.");


    if($parsetarget=="")
    {
      $this->app->Tpl->Output("produktion_minidetail.tpl");
      exit;
    }  else {
      $this->app->Tpl->Parse($parsetarget,"produktion_minidetail.tpl");
    }
  }

  function ProduktionRechnungsLieferadresse($produktionid)
  {
    $data = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE id='$produktionid' LIMIT 1");

    foreach($data[0] as $key=>$value)
    {
      if($data[0][$key]!="" && $key!="abweichendelieferadresse" && $key!="land" && $key!="plz" && $key!="lieferland" && $key!="lieferplz") $data[0][$key] = $data[0][$key]."<br>";
    }


    $rechnungsadresse = $data[0][name]."".$data[0][ansprechpartner]."".$data[0][abteilung]."".$data[0][unterabteilung].
	"".$data[0][strasse]."".$data[0][adresszusatz]."".$data[0][land]."-".$data[0][plz]." ".$data[0][ort];

    if($data[0][abweichendelieferadresse]!=0){

      $lieferadresse = $data[0][liefername]."".$data[0][lieferansprechpartner]."".$data[0][lieferabteilung]."".$data[0][lieferunterabteilung].
	"".$data[0][lieferstrasse]."".$data[0][lieferadresszusatz]."".$data[0][lieferland]."-".$data[0][lieferplz]." ".$data[0][lieferort];


    } else {
      $lieferadresse = "entspricht Rechnungsadresse";
    }

    return "<table width=\"100%\"><tr valign=\"top\"><td width=\"50%\"><b>Rechnungsadresse:</b><br><br>$rechnungsadresse</td><td><b>Lieferadresse:</b><br><br>$lieferadresse</td></tr></table>";
  }



  function ProduktionZahlungsmail()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->erp->ProduktionZahlungsmail($id,1);
    header("Location: index.php?module=produktion&action=edit&id=$id");
    exit;
  }

  function ProduktionSuche()
  {
    //$this->app->Tpl->Set(UEBERSCHRIFT,"Produktionssuche");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Produktionssuche");
    //$this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=create","Neuen Produktion anlegen");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=search","Produktion Suchen");
    $this->app->erp->MenuEintrag("index.php","Zur&uuml;ck zur &Uuml;bersicht");
   // $this->app->Tpl->Add(TABS,"<li><br><br></li>");

    $this->app->Tpl->Set(TABTEXT,"Produktionssuche");

    $name = trim($this->app->Secure->GetPOST("name"));
    $suchwort = trim($this->app->Secure->GetPOST("suchwort"));
    $email = trim($this->app->Secure->GetPOST("email"));
    $plz = trim($this->app->Secure->GetPOST("plz"));
    $produktion = trim($this->app->Secure->GetPOST("produktion"));
    $proforma = trim($this->app->Secure->GetPOST("proforma"));
    $kundennummer = trim($this->app->Secure->GetPOST("kundennummer"));
    $betrag= trim($this->app->Secure->GetPOST("betrag"));

    $betrag = str_replace(',','.',$betrag);

    if($name!="" || $plz!="" || $proforma!="" || $kundennummer!="" || $produktion!="" || $email!="" || $betrag!="" || $suchwort!="")
    {
      $table = new EasyTable($this->app);
      $this->app->Tpl->Add(ERGEBNISSE,"<h2>Trefferliste:</h2><br>");
      if($suchwort!="")
      {
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse, a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.name LIKE '%$suchwort%' OR a.email LIKE '%$suchwort%' OR a.plz LIKE '$suchwort%' OR a.internet LIKE '%$suchwort%' OR (adr.kundennummer='$suchwort' AND adr.kundennummer!=0)
	  OR (a.gesamtsumme='$suchwort' AND a.gesamtsumme!=0) OR (a.belegnr='$suchwort' AND a.belegnr!=0 ))");
      } else {
      if($name!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse,  a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.name LIKE '%$name%')");
      else if($email!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse, a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.email LIKE '%$email%')");
      else if($plz!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse, a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.plz LIKE '$plz%')");
      else if($proforma!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse, a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.internet LIKE '%$proforma%')");
      else if($kundennummer!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse,  a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (adr.kundennummer='$kundennummer')");
      else if($betrag!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse,  a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.gesamtsumme='$betrag')");
      else if($produktion!="")
	$table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name, a.belegnr as produktion, adr.kundennummer, a.internet, a.plz, a.ort, a.strasse, a.zahlungsweise, a.status, a.id FROM produktion a 
	  LEFT JOIN adresse adr ON adr.id = a.adresse WHERE (a.belegnr='$produktion')");

      }
      $table->DisplayNew(ERGEBNISSE,"<a href=\"index.php?module=produktion&action=edit&id=%value%\">Lesen</a>");
    } else {
      $this->app->Tpl->Add(ERGEBNISSE,"<div class=\"info\">Produktionssuche (bitte entsprechende Suchparameter eingeben)</div>");
    }

      $this->app->Tpl->Parse(INHALT,"produktionssuche.tpl");

    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Parse(TAB1,"rahmen77.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }



  function ProduktionRechnung()
  {
    $id = $this->app->Secure->GetGET("id");

    $newid = $this->app->erp->WeiterfuehrenProduktionZuRechnung($id);

    header("Location: index.php?module=rechnung&action=edit&id=$newid");
    exit;
  }

  function ProduktionLieferschein()
  {
    $id = $this->app->Secure->GetGET("id");

    $newid = $this->app->erp->WeiterfuehrenProduktionZuLieferschein($id);

    header("Location: index.php?module=lieferschein&action=edit&id=$newid");
    exit;
  }



  function ProduktionCopy()
  {
    $id = $this->app->Secure->GetGET("id");

    $newid = $this->app->erp->CopyProduktion($id);

    header("Location: index.php?module=produktion&action=edit&id=$newid");
    exit;
  }


  function ProduktionFreigabe()
  {
    $id = $this->app->Secure->GetGET("id");
    $freigabe= $this->app->Secure->GetGET("freigabe");
    $this->app->Tpl->Set(TABTEXT,"Freigabe");

    if($freigabe==$id)
    {
      $belegnr = $this->app->DB->Select("SELECT MAX(belegnr) FROM produktion WHERE firma='".$this->app->User->GetFirma()."'");
      if($belegnr <= 0) $belegnr = 200000; else $belegnr = $belegnr + 1;
      $this->app->DB->Update("UPDATE produktion SET belegnr='$belegnr', status='freigegeben', vertrieb='".$this->app->User->GetDescription()."' WHERE id='$id' LIMIT 1");
      $this->app->erp->ProduktionProtokoll($id,"Produktion freigegeben");

      $msg = base64_encode("<div class=\"error2\">Der Produktion wurde freigegeben und kann jetzt versendet werden!</div>");
      header("Location: index.php?module=produktion&action=edit&id=$id&msg=$msg");
      exit;

    } else { 

      $name = $this->app->DB->Select("SELECT a.name FROM produktion b LEFT JOIN adresse a ON a.id=b.adresse WHERE b.id='$id' LIMIT 1");
      $summe = $this->app->DB->Select("SELECT FORMAT(SUM(menge*preis),2) FROM produktion_position
	WHERE produktion='$id'");
      $waehrung = $this->app->DB->Select("SELECT waehrung FROM produktion_position
	WHERE produktion='$id' LIMIT 1");

      $this->app->Tpl->Set(TAB1,"<div class=\"info\">Soll die Produktion an <b>$name</b> im Wert von <b>$summe $waehrung</b> 
	jetzt freigegeben werden? <input type=\"button\" value=\"Freigabe\" onclick=\"window.location.href='index.php?module=produktion&action=freigabe&id=$id&freigabe=$id'\">
	</div>");
    }
    $this->ProduktionMenu();
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

  function ProduktionAbschicken()
  {
    $this->ProduktionMenu();
    $id = $this->app->Secure->GetGET("id");

    $this->app->Tpl->Set(TABTEXT,"Abschicken");

    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
    $adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$id' LIMIT 1");
    if($projekt=="" || $projekt==0)
      $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' LIMIT 1");

    if($status !='angelegt')
    {
      //$this->app->Tpl->Set(TAB1,"<div class=\"warning\">Die Produktion ist freigegeben und wurde noch nicht versendet!</div>");  
      $this->app->erp->DokumentMask(TAB1,"produktion",$id,$adresse,$projekt);

      /*
      if($this->app->Secure->GetPOST("submit")=="")
      {
	$this->app->Tpl->Set(DRUCKER,$this->app->erp->GetSelectDrucker());
	$this->app->Tpl->Set(EMAILEMPFAENGER,$this->app->erp->GetSelectEmail());
	$this->app->erp->DokumentSendShow(TAB1,"produktion",$id,$adresse);
      }
      else
      {

	$betreff = $this->app->Secure->GetPOST("betreff");
	$text = $this->app->Secure->GetPOST("text");
	$art = $this->app->Secure->GetPOST("senden");

	// update status freigegebn auf versendet
	$Brief = new BriefPDF(&$this->app);

	if($art == "fax")
	  $Brief->GetBriefTMP($adresse,$betreff,$text,1);
	else
	  $Brief->GetBriefTMP($adresse,$betreff,$text);
  
	if($art !="email")
	  $tmpbrief= $Brief->displayTMP(); 

	// sende 
	$Brief = new ProduktionPDF(&$this->app);
	$Brief->GetProduktion($id);
	$tmpfile = $Brief->displayTMP(); 

	if($art == "email")	
	  $dateien = array($tmpfile);
	else
	  $dateien = array($tmpbrief,$tmpfile);

	
	if($art == "brief") $drucker = $this->app->Secure->GetPOST("drucker_brief");
	else if($art == "fax") $drucker = $this->app->Secure->GetPOST("drucker_fax");
	else if ($art == "email") $drucker = $this->app->Secure->GetPOST("email_from");

        $ret = $this->app->erp->DokumentSend($adresse,"produktion",$id,$art,$betreff,$text,$dateien,$drucker);
	if($ret == "")
	{
	  $this->app->Tpl->Set(TAB1,"<div class=\"info\">Dokument wurde erfolgreich versendet</div>"); 
	  $this->app->DB->Update("UPDATE produktion SET versendet=1, versendet_am=NOW(),versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
	  $this->app->erp->ProduktionProtokoll($id,"Produktion versendet");
	}
	else
	  $this->app->Tpl->Set(TAB1,"<div class=\"error\">$ret</div>"); 

	$this->app->Tpl->Set(DRUCKER,$this->app->erp->GetSelectDrucker());
	$this->app->Tpl->Set(EMAILEMPFAENGER,$this->app->erp->GetSelectEmail());
	$this->app->erp->DokumentSendShow(TAB1,"produktion",$id,$adresse);

	// temp datei wieder loeschen
	unlink($tmpfile);
	unlink($tmpbrief);
      }
*/
      //$this->app->erp->ProduktionProtokoll($id,"Produktion per Mail versendet");
    } else 
    {
      $this->app->Tpl->Set(TAB1,"<div class=\"error\">Die Produktion wurde noch nicht freigegeben!</div>");  
    }
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }



  function ProduktionAbschluss()
  {
    $id = $this->app->Secure->GetGET("id");
    $abschluss= $this->app->Secure->GetGET("abschluss");

    $name = $this->app->DB->Select("SELECT name FROM produktion WHERE id='$id' LIMIT 1");
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");

    $this->app->Tpl->Set(TABTEXT,"Abschluss");


    if($abschluss==$id)
    {
      if($status=="angelegt")
      {
	// KUNDE muss RMA starten
	$msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) kann nicht abgeschlossen werden da er noch nicht freigeben wurde! Bitte Produktion erst freigeben!</div>");
      } 
      else if($status=="storniert")
      {
	$msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) kann nicht abgeschlossen werden da er bereits storniert ist!</div>");
      } 
      else if($status=="freigegeben")
      {
      $this->app->DB->Update("UPDATE produktion SET status='abgeschlossen' WHERE id='$id' LIMIT 1"); 
      $this->app->erp->ProduktionProtokoll($id,"Produktion trotzdem manuell abschlie&zlig;en");

      $msg = base64_encode("<div class=\"error\">Der Produktion wurde abgeschlossen!</div>");
      }
      header("Location: index.php?module=produktion&action=edit&id=$id&msg=$msg");
      exit;
    }
    else {
      $name = $this->app->DB->Select("SELECT a.name FROM produktion b LEFT JOIN adresse a ON a.id=b.adresse WHERE b.id='$id' LIMIT 1");
      $this->app->Tpl->Set(TAB1,"<div class=\"info\">Soll der Produktion an <b>$name</b> jetzt abgeschlossen werden?
        <input type=\"button\" value=\"Abschluss\" onclick=\"window.location.href='index.php?module=produktion&action=abschluss&id=$id&abschluss=$id&msg=$msg'\">
        </div>");
    }
    $this->ProduktionMenu();
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }


  function ProduktionDelete()
  {
    $id = $this->app->Secure->GetGET("id");
    $mail = $this->app->Secure->GetGET("mail");
    $abschluss = $this->app->Secure->GetGET("abschluss");

    $name = $this->app->DB->Select("SELECT name FROM produktion WHERE id='$id' LIMIT 1");
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");

    $this->app->Tpl->Set(TABTEXT,"Stornierung");

    if($abschluss==$id)
    {
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->erp->DeleteProduktion($id);
      $msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) wurde gel&ouml;scht!</div>");
      //header("Location: ".$_SERVER['HTTP_REFERER']."&msg=$msg");
      header("Location: index.php?module=produktion&action=list&msg=$msg");
      exit;
    } else 
    {
      if($status=="abgeschlossen")
      {
	// KUNDE muss RMA starten
	  $msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) kann nicht storniert werden da Ware bereits versendet wurde! Bitte RMA starten!</div>");
      } 
      else if($status=="storniert")
      {
	// KUNDE muss RMA starten
      // KUNDE muss RMA starten
        // pruefe ob produktion groesste nummer hat
        $maxbelegnr = $this->app->DB->Select("SELECT MAX(belegnr) FROM produktion");
        if($maxbelegnr == $belegnr)
        {
          $this->app->DB->Delete("DELETE FROM produktion_position WHERE produktion='$id'");
          $this->app->DB->Delete("DELETE FROM produktion WHERE id='$id'");
          $msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) wurde ge&ouml;scht !</div>");
        } else 
        {
	  $msg = base64_encode("<div class=\"error\">Produktion \"$name\" ($belegnr) kann nicht storniert werden da er bereits storniert ist!</div>");
        }
        header("Location: index.php?module=produktion&action=list&msg=$msg");
        exit;
      } 


      else {

      $this->app->DB->Update("UPDATE produktion SET status='storniert' WHERE id='$id' LIMIT 1"); 
      $this->app->erp->ProduktionProtokoll($id,"Produktion storniert");

      // ausfuellen automatisch stornofelder
      //stornobetrag // summe des zahlungseingangs!!!!
      //stornogutschrift
      //stornowareerhalten
      //stornorueckzahlung
      // zureuckzahlen per



      // email senden?
      if($mail==1)
      $this->app->erp->Stornomail($id);

      $recheck = $this->app->DB->Select("SELECT id FROM rechnung WHERE produktion='$belegnr' LIMIT 1");

      if($recheck <= 0)
      {
	// Fall 1 keine RE und LS
	// -> stornieren und Geld zurueckueberweisen (Paypal, Kredit oder Bank)
	// geld wird ueber ipayment oder paypal zurueckgebucht!!!
	// negatives produktionssguthaben loescht produktionsguthaben
	$this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Achtung dem Kunden sofort das Geld &uuml;berweisen!</div>");

      } else {
	//Fall 2 es gibt eine RE und ein LS
	// GS und liegt Ware wieder in Lager dann Zahlung freigeben immer per Scheck?
      }
      //$this->app->erp->($id);
      $msg = base64_encode("<div class=\"error\">Der Produktion wurde storniert!</div>");
      }
    }
    //$this->ProduktionSuche();

    header("Location: index.php?module=produktion&action=list&msg=$msg");
    exit;
    } else {
      $name = $this->app->DB->Select("SELECT a.name FROM produktion b LEFT JOIN adresse a ON a.id=b.adresse WHERE b.id='$id' LIMIT 1");
      $this->app->Tpl->Set(TAB1,"<div class=\"info\">Soll der Produktion an <b>$name</b> jetzt storniert werden?
        <input type=\"button\" value=\"Stornierung MIT E-Mail an den Kunden\" onclick=\"window.location.href='index.php?module=produktion&action=delete&id=$id&abschluss=$id&msg=$msg&mail=1'\">&nbsp;
        <input type=\"button\" value=\"Stornierung OHNE E-Mail an den Kunden\" onclick=\"window.location.href='index.php?module=produktion&action=delete&id=$id&abschluss=$id&msg=$msg&mail=0'\">&nbsp;
        </div>");
    }
    $this->ProduktionMenu();
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function ProduktionDeleteAusVersand()
  {

    $id = $this->app->Secure->GetGET("id");

    $rechnung = $this->app->DB->Select("SELECT rechnung FROM versand WHERE id='$id' LIMIT 1");
    $lieferschein  = $this->app->DB->Select("SELECT lieferschein  FROM versand WHERE id='$id' LIMIT 1");
    $produktion  = $this->app->DB->Select("SELECT produktionid FROM rechnung WHERE id='$rechnung' LIMIT 1");

    // status aendern
    $this->app->DB->Update("UPDATE lieferschein SET versandart='rma' WHERE id='$lieferschein' LIMIT 1");

    // RMA anlegen 

    $msg = base64_encode("<div class=\"error\">Der Produktion wurde als RMA im Versand markiert!</div>");

    header("Location: index.php?module=produktion&action=edit&id=$produktion&msg=$msg");
    exit;


  }



  function ProduktionProtokoll()
  {
    $this->ProduktionMenu();
    $id = $this->app->Secure->GetGET("id");

    $this->app->Tpl->Set(TABTEXT,"Protokoll");


    //$this->ProduktionMiniDetail(TAB1);


    $tmp = new EasyTable(&$this->app);
    $tmp->Query("SELECT zeit,bearbeiter,grund FROM produktion_protokoll WHERE produktion='$id' ORDER by zeit DESC");
    $tmp->DisplayNew(TAB1,"Protokoll","noAction");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

  function ProduktionAddPosition()
  {

    $sid = $this->app->Secure->GetGET("sid");
    $id = $this->app->Secure->GetGET("id");
    $menge = $this->app->Secure->GetGET("menge");
    $datum  = $this->app->Secure->GetGET("datum");
    $datum  = $this->app->String->Convert($datum,"%1.%2.%3","%3-%2-%1");
    $this->app->erp->AddProduktionPosition($id, $sid,$menge,$datum);
    $this->app->erp->ProduktionNeuberechnen($id);
    header("Location: index.php?module=produktion&action=positionen&id=$id");
    exit;

  }

  function ProduktionProforma()
  {
    $id = $this->app->Secure->GetGET("id");

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");

    //if(is_numeric($belegnr) && $belegnr!=0)
    //{
      $Brief = new ProduktionPDF(&$this->app,"proforma");
      $Brief->GetProduktion($id);
      $Brief->displayDocument(); 
    //} else
    //  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Noch nicht freigegebene Produktionen k&ouml;nnen nicht als PDF betrachtet werden.!</div>");


    $this->ProduktionList();
 }

  function ProduktionPDF()
  {
    $id = $this->app->Secure->GetGET("id");

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");

    //if(is_numeric($belegnr) && $belegnr!=0)
    //{
      $Brief = new ProduktionPDF(&$this->app);
      $Brief->GetProduktion($id);
      $Brief->displayDocument(); 
    //} else
    //  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Noch nicht freigegebene Produktionen k&ouml;nnen nicht als PDF betrachtet werden.!</div>");


    $this->ProduktionList();
 }


  function ProduktionMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->erp->ProduktionNeuberechnen($id);
    $backurl = $this->app->Secure->GetGET("backurl");
    $backurl = base64_decode($backurl);


    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    $name = $this->app->DB->Select("SELECT name FROM produktion WHERE id='$id' LIMIT 1");

    if($belegnr<=0) $belegnr ="(Entwurf)";
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Produktion $belegnr");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT2,"$name");
 
    //$this->app->Tpl->Add(TABS,"<li><h2 style=\"background-color: [FARBE2]\">Produktion</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=edit&id=$id","Produktionsdaten");

    $this->app->erp->MenuEintrag("index.php?module=produktion&action=zahlungsmahnungswesen&id=$id","Zahlung-/Versandstatus");


    // status bestell
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
   
    if($status=='bestellt')
    { 
      $this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=produktion&action=wareneingang&id=$id\">Wareneingang<br>R&uuml;ckst&auml;nde</a></li>");
      $this->app->Tpl->Add(TABS,"<li><a class=\"tab\" href=\"index.php?module=produktion&action=wareneingang&id=$id\">Mahnstufen</a></li>");
    } else if ($status=="angelegt")
    {
      $this->app->erp->MenuEintrag("index.php?module=produktion&action=freigabe&id=$id","Freigabe");
    }

    $this->app->erp->MenuEintrag("index.php?module=produktion&action=abschicken&id=$id","Abschicken");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=protokoll&id=$id","Protokoll");

    if($backurl=="")
      $this->app->erp->MenuEintrag("index.php?module=produktion&action=list","Zur&uuml;ck zur &Uuml;bersicht");
    else
      $this->app->erp->MenuEintrag("$backurl","Zur&uuml;ck zur &Uuml;bersicht");

  }

  function ProduktionPositionstabelle($parsetarget)
  {
    $this->app->YUI->TableSearch($parsetarget,"auftraegeoffene");
  }


  function ProduktionPositionen()
  {
    $id = $this->app->Secure->GetGET("id");

    $this->app->YUI->AARLGPositionen(false);
    $this->app->erp->ProduktionEinzelnBerechnen($id);
    $this->app->erp->ProduktionNeuberechnen($id);


  }

  function DelProduktionPosition()
  {
    $sid = $this->app->Secure->GetGET("sid");
    $id = $this->app->Secure->GetGET("id");
    $this->app->YUI->SortListEvent("del","produktion_position","produktion");
		if(is_numeric($sid))
		{
    $unterartikel = $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE explodiert_parent='$sid'");

    if(count($unterartikel)>0 && $sid >0 && $id >0)
    {
      for($i=0;$i<count($unterartikel);$i++)
      {
				$sidexplodiert = $unterartikel[$i][id];
				if($sidexplodiert>0)
				{
					$sort = $this->app->DB->Select("SELECT sort FROM produktion_position WHERE id='$sidexplodiert' LIMIT 1");
					if($sort>0)
					{
						$this->app->DB->Delete("DELETE FROM produktion_position WHERE sort='$sort' AND produktion='$id' LIMIT 1");
						$this->app->DB->Update("UPDATE produktion_position SET sort=sort-1 WHERE produktion='$id' AND sort > $sort LIMIT 1");
					}
				}
      }
    }
		}
    $this->ProduktionPositionen();
  }

  function UpProduktionPosition()
  {
    $this->app->YUI->SortListEvent("up","produktion_position","produktion");
    $this->ProduktionPositionen();
  }

  function DownProduktionPosition()
  {
    $this->app->YUI->SortListEvent("down","produktion_position","produktion");
    $this->ProduktionPositionen();
  }

  function ProduktionCheckDisplayPopup()
  { 
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");

    if($frame=="false")
    { 
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(700,700);
    } else {
      // nach page 	
	
	$projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$id' LIMIT 1");
	$projektcheckname = $this->app->DB->Select("SELECT checkname FROM projekt WHERE id='$projekt' LIMIT 1");

	include_once ("./plugins/class.".$projektcheckname.".php");		
	$tmp = new $projektcheckname(&$this->app);
	$tmp->CheckDisplay(PAGE,$produktion);

      $this->app->BuildNavigation=false;
    }
  }


  function ProduktionPositionenEditPopup()
  {
   $id = $this->app->Secure->GetGET("id");

      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetProduktion_position(&$this->app,PAGE);
      $sid= $this->app->DB->Select("SELECT produktion FROM produktion_position WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=produktion&action=positionen&id=$sid");
      $widget->Edit();
      $this->app->BuildNavigation=false;
  }


  function ProduktionEdit()
  {
    $action = $this->app->Secure->GetGET("action");
    $id = $this->app->Secure->GetGET("id");
    $msg = $this->app->Secure->GetGET("msg");
    $storno = $this->app->Secure->GetGET("storno");

    $msg = base64_decode($msg);
    $this->app->Tpl->Set(MESSAGE,$msg);

    $zahlungsweise= $this->app->DB->Select("SELECT zahlungsweise FROM produktion WHERE id='$id' LIMIT 1");
    $zahlungszieltage= $this->app->DB->Select("SELECT zahlungszieltage FROM produktion WHERE id='$id' LIMIT 1");

		if($zahlungsweise=="rechnung" && $zahlungszieltage<1)
		{
			$this->app->Tpl->Add(MESSAGE,"<div class=\"info\">Bitte mehr als 0 Tage dem Kunden Zeit geben sonst wird F&auml;lligkeit auf \"sofort\" gesetzt!</div>");
		}



    $this->app->erp->ProduktionEinzelnBerechnen($id);

    $this->app->erp->ProduktionNeuberechnen($id);


//    $this->ProduktionMiniDetail(MINIDETAIL,true);

    $icons = $this->app->YUI->IconsSQLProduktion();
    $icons = $this->app->DB->Select("SELECT $icons FROM produktion a WHERE a.id='$id' LIMIT 1");
    $this->app->Tpl->Set(STATUSICONS,$icons);

    $this->app->YUI->AARLGPositionen();


    //$tmp = new EasyTable(&$this->app);
    //$tmp->Query("SELECT zeit,bearbeiter,grund FROM produktion_protokoll WHERE produktion='$id'");
    //$tmp->DisplayNew(MINIDETAIL2,"Protokoll","noAction");


    $status= $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
    if($status=="")
      $this->app->DB->Update("UPDATE produktion SET status='angelegt' WHERE id='$id' LIMIT 1");


    $tmpcheckversand = $this->app->DB->Select("SELECT versandart FROM produktion WHERE id='$id' LIMIT 1");
    if($tmpcheckversand=="packstation")
      $this->app->DB->Update("UPDATE produktion SET abweichendelieferadresse='0' WHERE id='$id' LIMIT 1");


    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
    $nummer = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM produktion WHERE id='$id' LIMIT 1");
    $adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");

    $this->app->erp->AnsprechpartnerButton($adresse);
    $this->app->erp->LieferadresseButton($adresse);


    if($nummer>0)
    {
      $this->app->Tpl->Set(NUMMER,$nummer);
      $this->app->Tpl->Set(KUNDE,"&nbsp;&nbsp;&nbsp;Kd.KdNr.".$kundennummer);
    }
    $this->app->Tpl->Set(ICONMENU,$this->ProduktionIconMenu($id));

    if($status=="angelegt")
    {
    $this->app->Tpl->Set(ABGESCHLOSSENENABLE,"<!--"); //TODO
    $this->app->Tpl->Set(ABGESCHLOSSENDISABLE,"-->"); //TODO
    }

    if($status!="storniert")
    {
      $this->app->Tpl->Set(STORNOENABLE,"<!--");
      $this->app->Tpl->Set(STORNODISABLE,"-->");
    }

   $stornobezahlt = $this->app->DB->Select("SELECT stornobezahlt FROM produktion WHERE id='$id' LIMIT 1");

    if($storno!="abschluss" && $stornobezahlt==0)
    {
      $this->app->Tpl->Set(STORNORETOUREENABLE,"<!--");
      $this->app->Tpl->Set(STORNORETOUREDISABLE,"-->");
    } else {
      $this->app->Tpl->Set(HIDDENFIELD,"<input type=\"hidden\" name=\"storno_abschluss\" value=\"1\">");
      // bearbeiter 
	$stornobezahltvon = $this->app->DB->Select("SELECT stornobezahltvon FROM produktion WHERE id='$id' LIMIT 1");
	$stornobezahltam = $this->app->DB->Select("SELECT stornobezahltam FROM produktion WHERE id='$id' LIMIT 1");
	if($stornobezahltvon=="")
	  $this->app->DB->Update("UPDATE produktion SET stornobezahltvon='".$this->app->User->GetName()."' WHERE id='$id' LIMIT 1");
	if($stornobezahltam=="0000-00-00")
	  $this->app->DB->Update("UPDATE produktion SET stornobezahltam=NOW() WHERE id='$id' LIMIT 1");
    }

//    $this->ProduktionAmpel($id,AMPEL);

    // immer wenn sich der lieferant genändert hat standartwerte setzen
    if($this->app->Secure->GetPOST("adresse")!="")
    {
      // wenn schon neuer lieferant in den POST variablen vorhanden ist
//      $tmp = $this->app->Secure->GetPOST("adresse");
 //     $adresse = $this->app->DB->Select("SELECT id FROM adresse WHERE name='$tmp' AND geloescht=0 LIMIT 1");
  $tmp = $this->app->Secure->GetPOST("adresse");
      $kundennummer = substr($tmp,0,5);
      $name = substr($tmp,6);
      $adresse =  $this->app->DB->Select("SELECT id FROM adresse WHERE name='$name' AND kundennummer='$kundennummer'  AND geloescht=0 LIMIT 1");


      //$adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
      $name_von_adresse = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
      $name_von_produktion = $this->app->DB->Select("SELECT name FROM produktion WHERE id='$id' LIMIT 1");
      if($name_von_adresse!=$name_von_produktion)
      { 
/*
	$summe = $this->app->DB->Select("SELECT count(id) FROM produktion_position WHERE produktion='$id'");
	if($summe > 0){
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Lieferant kann nicht mehr ge&auml;ndert werden,
	    da Produktion bereits Artikel enth&auml;lt!</div>");
	  $adresseorg = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
	  $nameorg = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresseorg' LIMIT 1");
	  $this->app->Secure->POST['adresse'] = $nameorg;
	}
	else
	{
*/
	  $this->app->erp->LoadProduktionStandardwerte($id,$adresse);
//	}
      }
    } 
      // easy table mit arbeitspaketen YUI als template 
    $table = new EasyTable($this->app);
    $table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, ap.menge, (SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel) as Lagerbestand, ap.geliefert ausgeliefert,ap.vpe as VPE, FORMAT(ap.preis,4) as preis
      FROM produktion_position ap
      WHERE ap.produktion='$id'");
    $table->DisplayNew(POSITIONEN,"Preis","noAction");

    $summe = $this->app->DB->Select("SELECT FORMAT(SUM(menge*preis),2) FROM produktion_position
      WHERE produktion='$id'");
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM produktion_position
      WHERE produktion='$id' LIMIT 1");

    $summebrutto = $this->app->DB->Select("SELECT gesamtsumme FROM produktion WHERE id='$id' LIMIT 1");
    $ust_befreit_check = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$id' LIMIT 1");

    if($ust_befreit_check==1)
      $tmp = "Kunde ist UST befreit";
    else
      $tmp = "Kunde zahlt mit UST";

    if($summe > 0)
      $this->app->Tpl->Add(POSITIONEN, "<br><center>Zu zahlen: <b>$summe (netto) $summebrutto (brutto) $waehrung</b> ($tmp)&nbsp;&nbsp;");

    $bearbeiter = $this->app->DB->Select("SELECT bearbeiter FROM produktion WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(BEARBEITER,"<input type=\"text\" value=\"".$this->app->erp->GetAdressName($bearbeiter)."\" readonly size=\"30\">");

    $vertrieb = $this->app->DB->Select("SELECT vertrieb FROM produktion WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(VERTRIEB,"<input type=\"text\" value=\"".$vertrieb."\" size=\"30\" readonly>");
    
    //$status= $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
    //$this->app->Tpl->Set(STATUS,"<input type=\"text\" value=\"".$status."\" readonly>");
    
    $belegnr= $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(BELEGNR,"<input type=\"text\" value=\"".$belegnr."\" readonly size=\"30\">");

    
    $internet = $this->app->DB->Select("SELECT internet FROM produktion WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(INTERNET,"<input type=\"text\" value=\"".$internet."\" readonly size=\"30\">");

    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(STATUS,"<input type=\"text\" value=\"".$status."\" readonly size=\"30\">");



// ENDE 
    $this->app->Tpl->Set(ZAHLUNG, $this->ProduktionZahlungsweiseTabelle($id));


    //alle RE und LS zu diesem Produktion
    $anzahl =   $this->app->DB->Select("SELECT COUNT(r.belegnr as rechnung) FROM rechnung r LEFT JOIN lieferschein l ON r.lieferschein=l.id WHERE r.adresse='$adresse' AND r.produktion='$produktionsnummer' AND r.produktion!=''");

    if($anzahl >0)
    {
      $this->app->Tpl->Set(AUFTRAGSDOKUMENTE,"<fieldset><legend>Rechnungen und Lieferscheine</legend>");

      $table = new EasyTable(&$this->app);
      $produktionsnummer  = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
      $table->Query("SELECT r.belegnr as rechnung, DATE_FORMAT(r.datum,'%d.%m.%Y') as ausgang, l.belegnr as lieferschein, r.soll as betrag FROM rechnung r LEFT JOIN lieferschein l ON r.lieferschein=l.id WHERE r.adresse='$adresse' AND r.produktion='$produktionsnummer' AND r.produktion!=''");
      $table->DisplayNew(AUFTRAGSDOKUMENTE,"Betrag","noAction");
    
      $this->app->Tpl->Add(AUFTRAGSDOKUMENTE,"</fieldset>");

    }
   
    //suche alle LS zu diesem Produktion

 //   $table = new EasyTable(&$this->app);
    $produktionsnummer  = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");

    if($produktionsnummer>0)
    {
      $this->app->Tpl->Set(VERSAND,$this->ProduktionTrackingTabelle($id));
/*
    $table->Query("SELECT if(v.versendet_am!='0000-00-00', DATE_FORMAT(v.versendet_am,'%d.%m.%Y'),CONCAT('Heute im Versand<br><a href=\"#\" onclick=\"if(!confirm(\'Produktion wirklich aus dem Versand nehmen?\')) return false; else window.location.href=\'index.php?module=produktion&action=ausversand&id=',v.id,'\'\">Aus Versandprozess nehmen</a>')) as datum, v.versandunternehmen as versand, v.tracking, 
      CONCAT('<a href=\"index.php?module=lieferschein&action=pdf&id=',v.lieferschein,'\">PDF</a>') as LS,
      CONCAT('<a href=\"index.php?module=rechnung&action=pdf&id=',v.rechnung,'\">PDF</a>') as RE,
      if(tracking!='',CONCAT('<a href=\"http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=de&idc=',tracking,'\" target=\"_blank\">Online-Status</a>'),'') FROM versand v LEFT JOIN lieferschein l ON v.lieferschein=l.id WHERE l.produktion='$produktionsnummer' AND l.produktion!=''");
      $table->DisplayNew(VERSAND,"Tracking","noAction");

      $heuteimversand = $this->app->DB->Select("SELECT if(v.versendet_am!='0000-00-00', DATE_FORMAT(v.versendet_am,'%d.%m.%Y'),'Heute im Versand') as datum
       FROM versand v LEFT JOIN lieferschein l ON v.lieferschein=l.id WHERE l.produktion='$produktionsnummer' AND l.produktion!=''");

      if($heuteimversand=="Heute im Versand")
      $this->app->Tpl->Add(VERSAND,"<center><a href=\"\" onclick=\"if(!confirm('Wirklich RMA starten?')) return false; else window.location.href='index.php';\">RMA jetzt starten</a></center>");
*/
    } 

    // UST
    $ust_ok = $this->app->DB->Select("SELECT ust_ok FROM produktion WHERE id='$id' LIMIT 1");
    $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$id' LIMIT 1");
    $ustid = $this->app->DB->Select("SELECT ustid FROM produktion WHERE id='$id' LIMIT 1");
    $land = $this->app->DB->Select("SELECT land FROM produktion WHERE id='$id' LIMIT 1");

    $ustprfid = $this->app->DB->Select("SELECT id FROM ustprf WHERE DATE_FORMAT(datum_online,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') AND adresse='$adresse' AND status='erfolgreich' LIMIT 1");

    if($ust_befreit==0)
    {
      $this->app->Tpl->Set(USTPRUEFUNG,"Abgabe in Deutschland");
    } else if ($ust_befreit==1)
    {

      if($ust_ok == 1)
      {
	  $datum = $this->app->DB->Select("SELECT briefbestellt FROM ustprf WHERE id='$ustprfid' LIMIT 1");
	  $datum = $this->app->String->Convert($datum,"%1-%2-%3","%3.%2.%1");
	  $this->app->Tpl->Set(USTPRUEFUNG,"EU-Lieferung mit Pruefung<br>Brief bestellt: $datum");
      }
      else
	$this->app->Tpl->Set(USTPRUEFUNG,"Pruefung notwendig! (<a href=\"index.php?module=adresse&action=ustprf&id=$adresse\">Starten</a>)");

    } else {
      if($ust_ok == 1)
	$this->app->Tpl->Set(USTPRUEFUNG,"Freigabe Export (Drittland)");
      else
	$this->app->Tpl->Set(USTPRUEFUNG,"Fehlende Freigabe Export!");

    }


/*
    if($land=="DE")
      $this->app->Tpl->Set(USTPRUEFUNG,"Lieferung nach Deutschland");
    else {

      if($this->app->erp->Export($land)==true)
      {
	$this->app->Tpl->Set(USTPRUEFUNG,"Export Drittland");
      } else {
	if($ustprfid!="" && $ust_befreit==1)
	{
	  $datum = $this->app->DB->Select("SELECT briefbestellt FROM ustprf WHERE id='$ustprfid' LIMIT 1");
	  $datum = $this->app->String->Convert($datum,"%1-%2-%3","%3.%2.%1");
	  $this->app->Tpl->Set(USTPRUEFUNG,"EU-Lieferung mit Pruefung<br>Brief bestellt: $datum");
	}
	else
	{
	  if($ustid!="")
	  {
	    $adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
	    $this->app->Tpl->Set(USTPRUEFUNG,"Pruefung notwendig! (<a href=\"index.php?module=adresse&action=ustprf&id=$adresse\">Starten</a>)");
	  }
	  else
	    $this->app->Tpl->Set(USTPRUEFUNG,"Steuer in Deutschland");
	}	

      }

    }
*/

    $versandart = $this->app->DB->Select("SELECT versandart FROM produktion WHERE id='$id' LIMIT 1");
    if($this->app->Secure->GetPOST("versandart")!="") $versandart = $this->app->Secure->GetPOST("versandart");
    $this->app->Tpl->Set(PACKSTATION,"none");
    if($versandart=="packstation") $this->app->Tpl->Set(PACKSTATION,"");

    $abweichendelieferadresse= $this->app->DB->Select("SELECT abweichendelieferadresse FROM produktion WHERE id='$id' LIMIT 1");
    if($this->app->Secure->GetPOST("abweichendelieferadresse")!="") $versandart = $this->app->Secure->GetPOST("abweichendelieferadresse");
    $this->app->Tpl->Set(ABWEICHENDELIEFERADRESSESTYLE,"none");
    if($abweichendelieferadresse=="1") $this->app->Tpl->Set(ABWEICHENDELIEFERADRESSESTYLE,"");


    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    parent::ProduktionEdit();
    if($this->app->Secure->GetPOST("storno_abschluss")=="1")
      header("Location: index.php?module=stornierungen&action=list");

    if($this->app->Secure->GetPOST("speichern")!="" && $storno=="")
    {
      if($this->app->Secure->GetGET("msg")=="")
      {
        $msg = $this->app->Tpl->Get(MESSAGE);
        $msg = base64_encode($msg);
      } else {
        $msg = base64_encode($msg);
      }

      header("Location: index.php?module=produktion&action=edit&id=$id&msg=$msg");
      exit;
    } else if ($this->app->Secure->GetPOST("speichern")!="" && $storno=="abschluss")
    {
      header("Location: index.php?module=stornierungen&action=list");
      exit;
    }


    if($this->app->Secure->GetPOST("weiter")!="")
    {
      header("Location: index.php?module=produktion&action=positionen&id=$id");
      exit;
    }
    $this->ProduktionMenu();

  }

  function ProduktionUstStart()
  {
    $id = $this->app->Secure->GetGET("id");

    $name= $this->app->DB->Select("SELECT name FROM produktion WHERE id='$id' LIMIT 1");
    $ustid= $this->app->DB->Select("SELECT ustid FROM produktion WHERE id='$id' LIMIT 1");
    $land = $this->app->DB->Select("SELECT land FROM produktion WHERE id='$id' LIMIT 1");
    $ort = $this->app->DB->Select("SELECT ort FROM produktion WHERE id='$id' LIMIT 1");
    $plz = $this->app->DB->Select("SELECT plz FROM produktion WHERE id='$id' LIMIT 1");
    $strasse = $this->app->DB->Select("SELECT strasse FROM produktion WHERE id='$id' LIMIT 1");
 
    //$this->app->DB->Insert("INSERT INTO ustprf (id,adresse,name,ustid,land,plz,ort,strasse) VALUES ('','$adresse','$name','$ustid','$land','$plz','$ort','$strasse')");
    //$lid = $this->app->DB->GetInsertID();

    $frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");

    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(600,320);
    } else {
      // nach page inhalt des dialogs ausgeben
      //header("Location: index.php?module=adresse&action=ustedit&id=$id&lid=233");
      // WIDGET UST PRUEFUNG!!!!




      $this->app->BuildNavigation=false;
    }


  }


  function ProduktionCreate()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Produktion");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=list","Zur&uuml;ck zur &Uuml;bersicht");


    $anlegen = $this->app->Secure->GetGET("anlegen");

    if($anlegen != "")
    {
      $id = $this->app->erp->CreateProduktion();
      $this->app->erp->ProduktionProtokoll($id,"Produktion angelegt");
      header("Location: index.php?module=produktion&action=edit&id=$id");
      exit;
    }
    $this->app->Tpl->Set(MESSAGE,"<div class=\"warning\">M&ouml;chten Sie ein Produktion jetzt anlegen? &nbsp;
      <input type=\"button\" onclick=\"window.location.href='index.php?module=produktion&action=create&anlegen=1'\" value=\"Ja - Produktion jetzt anlegen\"></div><br>");
    $this->app->Tpl->Set(TAB1,"
     <table width=\"100%\" style=\"background-color: #fff; border: solid 1px #000;\" align=\"center\">
<tr>
<td align=\"center\">
<br><b style=\"font-size: 14pt\">Produktionen in Bearbeitung</b>
<br>
<br>
Offene Produktionen, die durch andere Mitarbeiter in Bearbeitung sind.
<br>
</td>
</tr>  
</table>
<br> 
      [AUFTRAGE]");


    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(datum,'%d.%m.%y') as vom, if(belegnr,belegnr,'ohne Nummer') as beleg, name, vertrieb, status, id
      FROM produktion WHERE status='angelegt' order by datum DESC, id DESC");
    $table->DisplayNew(AUFTRAGE, "<a href=\"index.php?module=produktion&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/new/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=produktion&action=delete&id=%value%';\">
          <img src=\"./themes/new/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich kopieren?')) return false; else window.location.href='index.php?module=produktion&action=copy&id=%value%';\">
        <img src=\"./themes/new/images/copy.png\" border=\"0\"></a>
        ");


    $this->app->Tpl->Set(TABTEXT,"Produktion anlegen");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

/*
    $this->app->Tpl->Add(TABS,"<li><h2>Produktion</h2></li>");
    $this->app->Tpl->Add(TABS,
      "<li><a href=\"index.php?module=produktion&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    $anlegen = $this->app->Secure->GetGET("anlegen");

    if($anlegen != "")
    {
      $id = $this->app->erp->CreateProduktion();
      $this->app->erp->ProduktionProtokoll($id,"Produktion angelegt");
      header("Location: index.php?module=produktion&action=edit&id=$id");
      exit;
    }

    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Set(PAGE,"<div class=\"info\">M&ouml;chten Sie eine Produktion jetzt anlegen? 
      <input type=\"button\" onclick=\"window.location.href='index.php?module=produktion&action=create&anlegen=1'\" value=\"Anlegen\"></div>");
    //parent::ProduktionCreate();
*/
  }



  function AuftraegeBerechnen()
  {
    $auftraege = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE status='freigegeben' AND inbearbeitung=0 ORDER By datum");    

    for($i=0;$i<count($auftraege); $i++)
      {
      $this->app->erp->ProduktionNeuberechnen($auftraege[$i][id]);
      $this->app->erp->ProduktionEinzelnBerechnen($auftraege[$i][id]);
    }

    header("Location: index.php?module=lager&action=ausgehend&cmd=produktion");
    exit;
  }


  function ProduktionReservieren()
  {
    $id = $this->app->Secure->GetGET("id");

    $artikelarr= $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE produktion='$id' AND geliefert=0");

    $adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='$id' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$id' LIMIT 1");
    $belegnr= $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");

    //schaue artikel fuer artikel an wieviel geliefert wurde und ob bereits reservierungen vorliegen, wenn welche vorliegen auch reservieren auf 9999-01-01

    // Lager Check
    //echo "{$auftraege[0][internet]} Adresse:$adresse Produktion $produktion";
    for($k=0;$k<count($artikelarr); $k++)
    {
      $menge = $artikelarr[$k][menge] - $artikelarr[$k][gelieferte_menge];
      $artikel = $artikelarr[$k][artikel];
      // pruefe artikel 12 menge 4
      $lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
      //if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001")
      if($lagerartikel=="1")
      {
        //echo "Artikel $artikel Menge $menge";
	//$this->app->erp->LagerCheck($adresse,$artikel,$menge)>0)
	$anzahl_lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel'");
	$anzahl_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW() AND objekt!='lieferschein'");

	$artikel_fuer_adresse_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");

	//erstmal die bestehenden reservierungen fuer produktion uebernehmen
	if($artikel_fuer_adresse_reserviert >0)
	{
	    //reservierung anpassen an Artikel f&uuml;r Produktion ....
	    $this->app->DB->Update("UPDATE lager_reserviert  SET datum='9999-01-01' WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");
	} 

	//ermittle menge der noch zu reserviernden artikel
	$reservierende_menge = $menge - $artikel_fuer_adresse_reserviert;
      
	//schauen ob lager - alle reservierungen noch reicht
	if( ($anzahl_lager - $anzahl_reserviert) >0)
	{
	  if(($anzahl_lager - $anzahl_reserviert) <= $reservierende_menge)  
	    $menge = $anzahl_lager - $anzahl_reserviert;
	  else
	    $menge = $reservierende_menge;


	  $this->app->DB->Insert("INSERT INTO lager_reserviert (id,adresse,artikel,menge,grund,projekt,firma,bearbeiter,datum)
	    VALUES('','$adresse','$artikel','$menge','Produktion f&uuml;r Produktion $belegnr','$projekt','".$this->app->User->GetFirma()."','".$this->app->User->GetName()."','999-99-99')");
	}
      }
    }
    $this->ProduktionList();
  }

  function ProduktionVersand($id="")
  {
    // mit der funktionen koennen nur erstauftraege abgewickelt koennen!!!
    if($id!="")$internmodus=1;
    if($id=="") $id = $this->app->Secure->GetGET("id");

    // artikel reservieren
    $produktion = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE id='$id' LIMIT 1");
    $adresse = $produktion[0][adresse];
    $versandart= $produktion[0][versandart];
    $projekt= $produktion[0][projekt];
    $belegnr = $produktion[0][belegnr];
    $tmpname = $produktion[0][name];
    $keinetrackingmail = $produktion[0][keinetrackingmail];

    $this->app->erp->ProduktionEinzelnBerechnen($id);


/*
    //schauen ob es einen offenen versand mit nicht versendetem lieferschein und nicht versendeter rechnung gibt, dann erweitere diese nicht bei vorkasse, paypal
    if($produktion[0][status]=="freigegeben" && $produktion[0][nachlieferung]=="0" && $produktion[0][lager_ok]=="1"&&$produktion[0][porto_ok]=="1"&&$produktion[0][ust_ok]=="1"&&$produktion[0][vorkasse_ok]=="1"&&$produktion[0][nachnahme_ok]=="1")
    {
        $msg = base64_encode("<div class=\"error\">Der Produktion kann nicht versendet werden! Freigabe, Zahlung, Nachnahmegeb&uuml;hr, Lager oder das Porto stimmen nicht!</div>");
	if($internmodus!="1")
	{
	header("Location: index.php?module=produktion&action=edit&id=$id&msg=$msg");
	exit;
	}
    }
*/
    if($produktion[0][status]=="freigegeben" && $produktion[0][lager_ok]=="1")
    {


      // pruefe ob es lagerartikel gibt
      $summe_lagerartikel = $this->app->DB->Select("SELECT SUM(ap.id) FROM produktion_position ap, artikel a WHERE ap.produktion='$id'  AND a.id=ap.artikel AND a.lagerartikel='1'");


      // produktion_position geliefert_menge und geliefert anpassen
      $artikelarr = $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE produktion='$id'");

      for($i=0;$i<count($artikelarr); $i++)
      {
	$lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$i][artikel]}' LIMIT 1");
	//if($artikelarr[$i][nummer]!="200000" && $artikelarr[$i][nummer]!="200001" && $artikelarr[$i][nummer]!="200002")
	if($lagerartikel=="1")
	{
	  $produktionspositionsid = $artikelarr[$i][id];
	  $artikel = $artikelarr[$i][artikel];
	  $menge= $artikelarr[$i][menge];
	  // lager teile reservieren
	  $this->app->DB->Insert("INSERT INTO lager_reserviert (id,adresse,artikel,menge,grund,projekt,firma,bearbeiter,datum,objekt,parameter)
	    VALUES('','$adresse','$artikel','$menge','Auslagern f&uuml;r Produktion $belegnr','$projekt','".$this->app->User->GetFirma()."','".$this->app->User->GetName()."','9999-01-01','produktion','$id')");

	  $this->app->DB->Update("UPDATE produktion_position SET geliefert_menge='$menge', geliefert='1' WHERE id='$produktionspositionsid' LIMIT 1");
	}
      }
/*
      // nur wenn autoversand projekt
      $autoversand_pruefung = $this->app->DB->Select("SELECT autoversand FROM projekt WHERE id='$projekt' LIMIT 1");
      $automailrechnung =     $this->app->DB->Select("SELECT automailrechnung FROM projekt WHERE id='$projekt' LIMIT 1");
 */     
 //     if($autoversand_pruefung==1)
  //    {
	
//	$this->app->DB->Insert("INSERT INTO versand (id,adresse,rechnung,lieferschein,versandart,projekt,gewicht,freigegeben,bearbeiter,versender,abgeschlossen,logdatei,firma,keinetrackingmail)
//	  VALUES('','$adresse','$rechnung','$lieferschein','$versandart','$projekt','','1','".$this->app->User->GetName()."','','0',NOW(),'".$this->app->User->GetFirma()."','$keinetrackingmail')");

	$this->app->Tpl->Add(MESSAGE,"<div class=\"info\">Die Produktion $belegnr von $tmpname wurde an das Lager &uuml;bergeben!</div>");
/*
      } else {
	
			$this->app->Tpl->Add(MESSAGE,"<div class=\"info\">Der Produktion $belegnr von $tmpname wurde abgeschlossen!</div>");
	// rechnung per mail versenden????

	if($automailrechnung)
	{
	  // rechnung per mail versenden
	    // sende 
//	  $this->app->erp->Rechnungsmail($rechnung);

	}
      }
	
*/
      // produktion abschliessen
      $this->app->DB->Update("UPDATE produktion SET status='abgeschlossen' WHERE id='$id' LIMIT 1");

  // $checkok = $this->app->DB->Select("SELECT kundenfreigabe_loeschen FROM projekt WHERE id='$projekt' LIMIT 1");
    if(0)
	$this->app->DB->Update("UPDATE adresse SET  kundenfreigabe='0' WHERE id='$adresse' LIMIT 1");
    } else {
      // nur erfolgreiche anzeigen
      //$this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Der Produktion $belegnr ist nicht vollst&auml;ndig und kann daher nicht versendet werden!</div>");
	if($produktion[0][status]=="storniert")
	  $msg = base64_encode("<div class=\"error\">Der Produktion kann nicht versendet werden, da er bereits storniert ist!</div>");
	if($produktion[0][status]=="angelegt")
	  $msg = base64_encode("<div class=\"error\">Der Produktion kann nicht versendet werden, er noch nicht freigeben ist!</div>");

      if($produktion[0][status]=="freigegeben" && ($produktion[0][lager_ok]=="0"))
        $msg = base64_encode("<div class=\"error\">Der Produktion kann nicht versendet werden! Freigabe, Zahlung, Nachnahmegeb&uuml;hr, Kunden-Freigabe, Lager oder das Porto stimmen nicht!</div>");
        
     if($produktion[0][status]=="angelegt" && ($produktion[0][lager_ok]=="0"))
        $msg = base64_encode("<div class=\"error\">Der Produktion kann nicht versendet werden! Bitte Produktion erst freigeben!</div>");
 /* 
     if($produktion[0][autoversand]!="1")
     	$msg = base64_encode("<div class=\"error\">Produktion ist nicht f&uuml;r Auto-Versand markiert. <br>Bitte Auto-Versand Haken setzen oder Produktion manuell drucken und/oder Produktion manuell abgschlie&szlig;en:
         <input type=\"button\" value=\"Produktion manuell abschliessen\" onclick=\"window.location.href='index.php?module=produktion&action=abschluss&id=$id&abschluss=$id'\"></div>

      ");
*/

	
	if($internmodus!="1")
	{
	header("Location: index.php?module=produktion&action=edit&id=$id&msg=$msg");
	exit;
	}

    }

    if($internmodus!="1")
    {
//      $this->ProduktionList();

   //header("Location: index.php?module=produktion&action=search");
   header("Location: index.php?module=produktion&action=edit&id=$id");
    exit;

    }
  }


  function ProduktionTeillieferung()
  {
    $this->ProduktionMenu();
    $id = $this->app->Secure->GetGET("id");


    $this->app->Tpl->Set(TABTEXT,"Teillieferung");
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");


    $table = new EasyTable($this->app);

    if($status=="freigegeben")
    {
      $table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, ap.menge as Menge,
      if(a.lagerartikel,if(a.porto,'-',if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel) > ap.menge,(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),
      if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel)>0,CONCAT('<font color=red><b>',(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),'</b></font>'),
      '<font color=red><b>aus</b></font>'))),'-') as Lager, 

      if(a.lagerartikel,
      CONCAT('<input type=\"text\" size=\"5\" name=\"artikel[',ap.id,']\" value=\"',
      if((SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel)>0,(SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=ap.artikel),0)
      ,'\">'),'Kein Lagerartikel') as teilversand
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew(TAB1,"Versenden","noAction");

    $this->app->Tpl->Add(TAB1,"<table width=\"100%\"><tr><td align=\"right\">

      <select name=\"teillieferungrechnung\">
	  <option>Produktion splitten in mehrer Auftr&auml;ge</option>
	  <option>Teillieferung Rechnung bei n&auml;chstem Produktion mitsenden</option>
	  <option>Rechnung bei n&auml;chstem Produktion mitsenden</option>
      <input type=\"submit\" value=\"Produktion erzeugen\" name=\"teillieferung\"></td></tr></table>");

    } else {
      $table->Query("SELECT ap.bezeichnung as artikel, ap.nummer as Nummer, if(a.lagerartikel,ap.menge,'-') as Menge
      FROM produktion_position ap, artikel a WHERE ap.produktion='$id' AND a.id=ap.artikel");
    $artikel = $table->DisplayNew(TAB1,"Menge","noAction");
    }


    //$this->ProduktionMiniDetail(TAB1);
/*
    $tmp = new EasyTable(&$this->app);
    $tmp->Query("SELECT zeit,bearbeiter,grund FROM produktion_protokoll WHERE produktion='$id'");
    $tmp->DisplayNew(TAB1,"Protokoll","noAction");
*/
    $this->app->Tpl->Parse(PAGE,"teillieferung.tpl");

    // lager teile reservieren

    // versand erzeugen (RE + LS) und verlinken


    // alle daten so setzten das Nachlieferung 100% klar ist was noch fehlt (bei Nachlieferung wieder RE und LS) vor allem schauen ob guthaben noch passt

  }


  function ProduktionSelbstabholerNachricht()
  {
    // kann man immer wieder aufrufen wenn ein teilchen gekommen ist bis produktion voll erfuellt ist

  }

  function ProduktionSelbstabholerAbgeholt()
  {
    // kann man immer wieder aufrufen wenn ein teilchen gekommen ist bis produktion voll erfuellt ist

  }


  function ProduktionNachlieferungCheck()
  {

    //echo "pruefe ob eine Nachlieferung gemacht werden kann";

  }


  function ProduktionNachlieferung()
  {
    // kann man immer wieder aufrufen wenn ein teilchen gekommen ist bis produktion voll erfuellt ist

  }




  function ProduktionVerfuegbar()
  {
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(600,400);
    } else {
      // nach page inhalt des dialogs ausgeben
      $table = new EasyTable(&$this->app); 
      $table->Query("SELECT ap.nummer, ap.bezeichnung, ap.menge, (SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) as lager, 
      (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') as reserviert, 
      if(((SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) - (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') - ap.menge)>=0,'',
      ((SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) - (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') - ap.menge)
	) as fehlend 
      FROM produktion_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE ap.produktion='$id' AND a.lagerartikel=1");

      $table->DisplayNEW(PAGE,"Fehlende","noAction");



      $this->app->BuildNavigation=false;
    }
  }

  function ProduktionAmpel($id,$parsetarget)
  {
    $status = $this->app->DB->Select("SELECT status FROM produktion WHERE id='$id' LIMIT 1");

    if($status=="abgeschlossen" || $status=="storniert")
    {
     $go = "<img src=\"./themes/new/images/grey.png\" width=\"17\" border=\"0\">";
     $stop = "<img src=\"./themes/new/images/grey.png\" width=\"17\" border=\"0\">";
     $reserviert = "<img src=\"./themes/new/images/grey.png\" width=\"17\" border=\"0\">";
     $check = "<img src=\"./themes/new/images/grey.png\" width=\"17\" border=\"0\">";
    } else {

    $go = "<img src=\"./themes/new/images/go.png\" width=\"17\" border=\"0\">";
    $stop = "<img src=\"./themes/new/images/stop.png\" width=\"17\" border=\"0\">";
    $reserviert = "<img src=\"./themes/new/images/reserviert.png\" width=\"17\" border=\"0\">";
        $check = "<img src=\"./themes/new/images/mail-mark-important.png\" width=\"17\" border=\"0\">";

    }

    // offene Auftraege
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(a.datum,'%d.%m.%Y') as vom, if(a.belegnr,a.belegnr,'ohne Nummer') as produktion, a.internet, CONCAT('<a href=\"index.php?module=adresse&action=edit&id=',a.adresse,'\">',a.name,'</a>') as name, a.land, p.abkuerzung as projekt, a.zahlungsweise as per, a.gesamtsumme as soll, (SELECT SUM(k.betrag) FROM kontoauszuege_zahlungseingang k WHERE k.objekt='produktion' AND k.parameter=a.id) as ist,
     if(a.check_ok,'','<a href=\"index.php?module=produktion&action=checkdisplay&id=1031&frame=false\" onclick=\"makeRequest(this); return false;\">$check</a>') as AC, 

      if(a.reserviert_ok,'$reserviert','') as AR, 
      if(a.lager_ok,'$go','$stop') as LA, 
      a.id
      FROM produktion a, projekt p WHERE a.inbearbeitung=0 AND p.id=a.projekt AND a.id=$id LIMIT 1");

/*
    $table->DisplayNew($parsetarget, "
        <a href=\"index.php?module=produktion&action=pdf&id=%value%\"><img border=\"0\" src=\"./themes/new/images/pdf.png\"></a>
        <a onclick=\"if(!confirm('Wirklich stornieren?')) return false; else window.location.href='index.php?module=produktion&action=delete&id=%value%';\">
          <img src=\"./themes/new/images/delete.gif\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich kopieren?')) return false; else window.location.href='index.php?module=produktion&action=copy&id=%value%';\">
        <img src=\"./themes/new/images/copy.png\" border=\"0\"></a>
     <a onclick=\"if(!confirm('Wirklich als Lieferschein weiterf&uuml;hren?')) return false; else window.location.href='index.php?module=produktion&action=lieferschein&id=%value%';\">
        <img src=\"./themes/new/images/lieferung.png\" border=\"0\" alt=\"weiterf&uuml;hren als Lieferschein\"></a>
     <a onclick=\"if(!confirm('Wirklich als Rechnung weiterf&uuml;hren?')) return false; else window.location.href='index.php?module=produktion&action=rechnung&id=%value%';\">
        <img src=\"./themes/new/images/rechnung.png\" border=\"0\" alt=\"weiterf&uuml;hren als Rechnung\"></a>
     <a onclick=\"if(!confirm('Wirklich als Versand weiterf&uuml;hren?')) return false; else window.location.href='index.php?module=produktion&action=versand&id=%value%';\">
        <img src=\"./themes/new/images/versand.png\" width=\"18\" border=\"0\" alt=\"weiterf&uuml;hren als Versand\"></a>
        ");

*/
    $table->DisplayNew($parsetarget, "
        <a href=\"index.php?module=produktion&action=pdf&id=%value%\"><img border=\"0\" src=\"./themes/new/images/pdf.png\"></a>
        <a onclick=\"if(!confirm('Wirklich stornieren?')) return false; else window.location.href='index.php?module=produktion&action=delete&id=%value%';\">
          <img src=\"./themes/new/images/delete.gif\" border=\"0\"></a>
        ");


  }


  function ProduktionList()
  {
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Produktion");

    $backurl = $this->app->Secure->GetGET("backurl");
    $backurl = base64_decode($backurl);

    $msg = $this->app->Secure->GetGET("msg");
    $msg = base64_decode($msg);
    $this->app->Tpl->Set(MESSAGE,$msg);



//    $this->app->Tpl->Set(WIDGETCONTENT,"<h2>Lagerlampen</h2><br><div class=\"tabsbutton\"><a href=\"index.php?module=artikel&action=lagerlampe\">Einstellungen</a></div>");
//    $this->app->Tpl->Parse(WIDGET,"widget.tpl");


    $this->app->erp->MenuEintrag("index.php?module=produktion&action=create","Neue Produktion anlegen");
    $this->app->erp->MenuEintrag("index.php?module=produktion&action=berechnen","Materialbestand berechnen");
//    $this->app->erp->MenuEintrag("index.php?module=lager&action=ausgehend&cmd=produktion","Bauteile fehlende");


    if(strlen($backurl)>5)
    $this->app->erp->MenuEintrag("$backurl","Zur&uuml;ck zur &Uuml;bersicht");
    else
    $this->app->erp->MenuEintrag("index.php","Zur&uuml;ck zur &Uuml;bersicht");


    // ZAHLUNGSMAIL 
    $zahlungsmail= $this->app->Secure->GetPOST("zahlungsmail");

    if($zahlungsmail!="")
    {
      $meineauftraege = $this->app->DB->SelectArr("SELECT id FROM produktion WHERE status='freigegeben' 
	AND vorkasse_ok!='1' AND zahlungsweise!='rechnung' AND zahlungsweise!='nachnahme' AND zahlungsweise!='bar' AND zahlungsweise!='lastschrift'");
      for($i=0;$i<count($meineauftraege);$i++)
      {
	$this->app->erp->ProduktionNeuberechnen($meineauftraege[$i][id]);

	$this->app->erp->ProduktionEinzelnBerechnen($meineauftraege[$i][id]);
	$adresse = $this->app->DB->Select("SELECT adresse FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
	$belegnr= $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
/*	  
	$tage = $this->app->DB->Select("SELECT DATEDIFF(NOW(),zahlungsmail) FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
	if(!is_numeric($tage))
	{
	  $tage = $this->app->DB->Select("SELECT DATEDIFF(NOW(),datum) FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
	} 
	if($tage > 7)
	{
*/
	  $this->app->erp->ProduktionZahlungsmail($meineauftraege[$i][id]);
//	}
	//$this->app->erp->Zahlungsmail($adresse,$produktionssumme-$summeimproduktion,$belegnr);
	//$this->ProduktionVersand($meineauftraege[$i][id]);
      }
    }
   
    $checkarr = $this->app->DB->SelectArr("SELECT count(a.id) FROM produktion a, projekt p WHERE a.status='angelegt' AND p.id=a.projekt order by a.datum DESC, a.id DESC");

    if($checkarr>0 && $this->app->Secure->GetGET("msg")=="") 
      $this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Achtung es gibt Produktionen in \"in Bearbeitung\"!</div>");



    // AUFTAEGE ABSCHLIESSEN!
    $submit = $this->app->Secure->GetPOST("submit");
    $auftraegemarkiert = $this->app->Secure->GetPOST("auftraegemarkiert");
    if($submit!="")
    {
      for($i=0;$i<count($auftraegemarkiert);$i++)
      {
	$this->app->erp->ProduktionEinzelnBerechnen($auftraegemarkiert[$i]);
	$this->ProduktionVersand($auftraegemarkiert[$i]);
      }

      //$meineauftraege = $this->app->DB->SelectArr("SELECT id FROM produktion WHERE status='freigegeben' AND nachlieferung!='1' ORDER by datum");
      /*
      for($i=0;$i<count($meineauftraege);$i++)
      {
	$this->app->erp->ProduktionEinzelnBerechnen($meineauftraege[$i][id]);
	$this->ProduktionVersand($meineauftraege[$i][id]);
      }
      */
    }
   
    //FOLGEBESTAETIGUNG 
    $folge= $this->app->Secure->GetPOST("folge");
    if($folge!="")
    {
      $meineauftraege = $this->app->DB->SelectArr("SELECT id FROM produktion WHERE status='freigegeben' AND lager_ok!='1'");
      for($i=0;$i<count($meineauftraege);$i++)
      {
	$this->app->erp->ProduktionEinzelnBerechnen($meineauftraege[$i][id]);
	
	$tage = $this->app->DB->Select("SELECT DATEDIFF(NOW(),folgebestaetigung) FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
	if(!is_numeric($tage))
	{
	  $tage = $this->app->DB->Select("SELECT DATEDIFF(NOW(),datum) FROM produktion WHERE id='{$meineauftraege[$i][id]}' LIMIT 1");
	  $tage = $tage + 2;
	} 
	if($tage > 7)
	{
	  $this->app->erp->Folgebestaetigung($meineauftraege[$i][id]);	
	  $this->app->DB->Update("UPDATE produktion SET folgebestaetigung=NOW() WHERE id='$id' LIMIT 1");
	}

	//$this->ProduktionVersand($meineauftraege[$i][id]);
      }
    }


     // auftraege berechnen
     //$this->AuftraegeBerechnen(); // lager waren und summen und status  //TODO dauert viel zu lange!!

     $this->app->YUI->TableSearch(TAB2,"produktionoffeneauto");
     $this->app->YUI->TableSearch(TAB1,"produktion");
     $this->app->YUI->TableSearch(TAB3,"produktioninbearbeitung");
 
    $this->app->Tpl->Parse(PAGE,"produktionuebersicht.tpl");
  }

}
?>
