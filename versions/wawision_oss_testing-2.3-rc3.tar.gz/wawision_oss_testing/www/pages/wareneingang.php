<?php

class Wareneingang 
{

  function Wareneingang(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("main","WareneingangMain");
    $this->app->ActionHandler("list","WareneingangList");
    $this->app->ActionHandler("help","WareneingangHelp");
    $this->app->ActionHandler("vorgang","VorgangAnlegen");
    $this->app->ActionHandler("removevorgang","VorgangEntfernen");
    $this->app->ActionHandler("create","WareneingangCreate");
    $this->app->ActionHandler("paketannahme","WareneingangPaketannahme");
    $this->app->ActionHandler("paketabsender","WareneingangPaketAbsender");
    $this->app->ActionHandler("paketzustand","WareneingangPaketZustand");
    $this->app->ActionHandler("paketetikett","WareneingangPaketEtikett");
    $this->app->ActionHandler("paketabschliessen","WareneingangPaketAbschliessen");
    $this->app->ActionHandler("distribution","WareneingangPaketDistribution");
    $this->app->ActionHandler("distriinhalt","WareneingangPaketDistriInhalt");
    $this->app->ActionHandler("distrietiketten","WareneingangPaketDistriEtiketten");
    $this->app->ActionHandler("distriabschluss","WareneingangPaketDistriAbschluss");
    $this->app->ActionHandler("rmalist","WareneingangRMAList");
    $this->app->ActionHandler("rmadetail","WareneingangRMADetail");
  
    $this->app->DefaultActionHandler("login");
    
    $this->app->Tpl->Set(UEBERSCHRIFT," Wareneingang");

    $this->app->ActionHandlerListen(&$app);
  }

  function WareneingangRMAList()
  {
      $table = new EasyTable($this->app);

      $this->app->Tpl->Set(TABTEXT,"RMA Lieferungen");
      $table->Query("SELECT adr.name, COUNT(rma.id) as artikel, adr.id FROM rma_artikel rma, artikel a, adresse adr 
	WHERE rma.adresse=adr.id AND rma.artikel=a.id AND rma.status!='abgeschlossen' GROUP by adr.id");
      $table->DisplayNew(TAB1,"<a href=\"index.php?module=wareneingang&action=rmadetail&id=%value%\"><img src=\"./themes/[THEME]/images/einlagern.png\" border=\"0\"></a>");

      $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }


  function WareneingangRMADetail()
  {
    // erstens technik check
    $id = $this->app->Secure->GetGET("id");

    $name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$id' LIMIT 1");
    $kundennummer  = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$id' LIMIT 1");

    $this->app->Tpl->Set(KUNDENNUMMER,$kundennummer);
    $this->app->Tpl->Set(NAME,$name);

    $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE objekt='Paketannahme' AND parameter='$wareneingang'");
    
    $this->app->Tpl->Set(BILD,"index.php?module=dateien&action=send&id=2388&ext=.jpg");

    $table = new EasyTable($this->app);

  /* 
    $this->app->Tpl->Set(TABTEXT,"RMA Lieferungen");
    $table->Query("SELECT a.name_de,r.wunsch,r.status, r.id FROM rma_artikel r, artikel a
	WHERE r.adresse='$id' AND r.artikel=a.id");
    $table->DisplayNew(AUFTRAEGE,"
      <a href=\"index.php?module=wareneingang&action=rmadetail&id=%value%\"><img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a>
    ");
*/

    $this->app->Tpl->Set(TABTEXT,"RMA Lieferungen");
    $table->Query("SELECT '20.01.1982' as datum, 'Wareneingang' as status, 'Martina Purrucker' as bearbeiter, r.id FROM rma_artikel r, artikel a
	WHERE r.adresse='$id' AND r.artikel=a.id");
    $table->DisplayNew(ARTIKEL,"
      <a href=\"index.php?module=wareneingang&action=rmadetail&id=%value%\"><img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a>
      <a href=\"index.php?module=wareneingang&action=rmadetail&id=%value%\"><img src=\"./themes/[THEME]/images/hammer.png\" border=\"0\"></a>
    ");


    $this->app->Tpl->Set(RMAID,1);
    $this->app->Tpl->Add(SUBTABVIEWYUI,'var myTabsSub = new YAHOO.widget.TabView("subtabview1");');
    $this->app->Tpl->Parse(TABVIEW,"rmatabview.tpl");
    $this->app->Tpl->Parse(RMAARTIKEL,"rmadetail_artikel.tpl");

    $this->app->Tpl->Set(TABVIEW,"");

    $this->app->Tpl->Set(RMAID,2);
    $this->app->Tpl->Add(SUBTABVIEWYUI,'var myTabsSub = new YAHOO.widget.TabView("subtabview2");');
    $this->app->Tpl->Parse(TABVIEW,"rmatabview.tpl");
    $this->app->Tpl->Parse(RMAARTIKEL,"rmadetail_artikel.tpl");


    $this->app->Tpl->Set(TABTEXT,"RMA Prozess");
    $this->app->Tpl->Parse(TAB1,"rmadetail.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }



  function WareneingangPaketMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(ID,$id);
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Paketannahme");
    $this->app->erp->MenuEintrag("index.php?module=wareneingang&action=distribution","zur Distribution");
  }

 function WareneingangPaketDistriMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(ID,$id);
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Paketdistribution");
    $this->app->erp->MenuEintrag("index.php?module=wareneingang&action=paketannahme","zur Paketannahme");
  }


  function WareneingangMenu()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Wareneingang");
    $this->app->erp->MenuEintrag("index.php?module=wareneingang&action=list","&Uuml;bersicht");
    $this->app->erp->MenuEintrag("index.php?module=wareneingang&action=create","Paketannahme");
    //$this->app->erp->MenuEintrag("index.php?module=wareneingang&action=create\">Inhalt erfassen</a></li>");
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=wareneingang&action=create\">weitere Artikel erfassen</a></li>");
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=wareneingang&action=search\">Lieferung suchen</a></li>");
  }


  function WareneingangPaketDistriInhalt()
  {
    $id = $this->app->Secure->GetGET("id");
    $submit = $this->app->Secure->GetPOST("submit");
    $submitkunde = $this->app->Secure->GetPOST("submitkunde");

    $this->WareneingangPaketDistriMenu(); 

    if($submit!="")
    {
      $tmp = $this->app->Secure->GetPOST("pos"); 

      $pos = key($tmp);
      $menge = $tmp[$pos];

      if($menge<=0)
      {
	 $this->app->Tpl->Set(TAB1,"<div class=\"error\">Bitte geben Sie eine Menge an!</div>");
      } else {
	header("Location: index.php?module=wareneingang&action=distrietiketten&id=$id&pos=$pos&menge=$menge");
	exit;
      }
    }
 
    if($submitkunde!="")
    {
      $tmp = $this->app->Secure->GetPOST("pos"); 
      $artikelnummer = $this->app->Secure->GetPOST("artikelnummer");

      $pos = key($tmp);
      $menge = $tmp[$pos];

      if($menge<=0 && $pos >0)
      {
	 $this->app->Tpl->Set(TAB1,"<div class=\"error\">Bitte geben Sie eine Menge an!</div>");
      } else {
	// weil artikel aus kundenliste gewaehlt wurde ist vorgang ein RMA
	header("Location: index.php?module=wareneingang&action=distrietiketten&id=$id&pos=$pos&menge=$menge&rma=rma&artikelnummer=$artikelnummer");
	exit;
      }
    }
   

    $adresse= $this->app->DB->Select("SELECT adresse FROM paketannahme WHERE id='$id' LIMIT 1");

    // pruefe ob 
    $lieferant = $this->app->DB->Select("SELECT lieferantennummer FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $kunde= $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

    $name= $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

    if(is_numeric($lieferant) && $lieferant!=0)
    {
      $this->app->Tpl->Add(TAB1,"<br><h1>Offene Artikel von Bestellungen an $name:</h1><br>");

      $table = new EasyTable($this->app);
      $table->Query("SELECT bp.bestellnummer, b.belegnr as bestellung, CONCAT(LEFT(bp.bezeichnunglieferant,20),'...') as beschreibung, if(bp.lieferdatum,DATE_FORMAT(bp.lieferdatum,'%d.%m.%Y'),'sofort') as lieferdatum, p.abkuerzung as projekt, 
      bp.vpe, bp.menge, bp.geliefert, bp.menge -  bp.geliefert as offen, bp.id FROM bestellung_position bp
      LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN projekt p ON bp.projekt=p.id WHERE b.adresse='$adresse' AND b.belegnr > 0 
      AND bp.geliefert < bp.menge AND (bp.abgeschlossen IS NULL OR bp.abgeschlossen=0)");

      $table->DisplayNew(TAB1,"<form style=\"padding: 0px; margin: 0px;\" action=\"\" method=\"post\" name=\"eprooform\">Menge:&nbsp;<input type=\"text\" size=\"1\" name=\"pos[%value%]\">&nbsp;<input type=\"submit\" value=\"zuordnen\" name=\"submit\"></form>");
      //$this->app->Tpl->Add(TAB1,"<div class=\"info\">Es kann immer nur ein Artikel zugwiesen werden!</h1><br>");
    } 

    if(is_numeric($kunde) && $kunde!=0)
    {
      $this->app->Tpl->Add(TAB1,"<br><h1>Artikel Scannen:</h1><br>");

  $this->app->Tpl->Add(TAB11,
    "<br><br><center><form style=\"padding: 0px; margin: 0px;\" action=\"\" method=\"post\" name=\"eprooform\">
  Artikelnummer wenn Artikel nicht in Liste:&nbsp;<input type=\"text\" id=\"erstes\" name=\"artikelnummer\">&nbsp;<input type=\"submit\" value=\"Artikel zuweisen\" name=\"submitkunde\">
</form></center><br><br><script type=\"text/javascript\">document.getElementById(\"erstes\").focus(); </script>");

      // Kunde
      $this->app->Tpl->Add(TAB11,"<br><h1>Ausgelieferte Artikel an Kunden $name:</h1><br>");


      $table = new EasyTable($this->app);
      $table->Query("SELECT lp.nummer, CONCAT(LEFT(lp.bezeichnung,20),'...') as beschreibung, p.abkuerzung as projekt, 
      lp.menge, lp.geliefert, l.belegnr as lieferschein, DATE_FORMAT(l.datum,'%d.%m.%Y') as datum, lp.id FROM lieferschein_position lp
      LEFT JOIN lieferschein l ON lp.lieferschein=l.id LEFT JOIN projekt p ON lp.projekt=p.id WHERE l.adresse='$adresse' AND l.status='versendet'");

      $table->DisplayNew(TAB11,"<form style=\"padding: 0px; margin: 0px;\" action=\"\" method=\"post\" name=\"eprooform\">Menge:&nbsp;<input type=\"text\" size=\"1\" name=\"pos[%value%]\">&nbsp;<input type=\"submit\" value=\"zuordnen\" name=\"submitkunde\"></form>");



    }


    $this->app->Tpl->Set(AKTIV_TAB2,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketdistribution.tpl");
  }


  function WareneingangPaketDistriEtiketten()
  {
    $id = $this->app->Secure->GetGET("id");  
    $pos = $this->app->Secure->GetGET("pos");  
    $artikelnummer = $this->app->Secure->GetGET("artikelnummer");  
    $menge = $this->app->Secure->GetGET("menge");  
    $rma = $this->app->Secure->GetGET("rma");  

    $submit = $this->app->Secure->GetPOST("submit");  
    $lager = $this->app->Secure->GetPOST("lager");  
    $etiketten = $this->app->Secure->GetPOST("etiketten");  
    $anzahlauswahl = $this->app->Secure->GetPOST("anzahlauswahl");  
    $anzahl_fix = $this->app->Secure->GetPOST("anzahl_fix");  
    $anzahl_dyn = $this->app->Secure->GetPOST("anzahl_dyn");  
    $anzahl = $this->app->Secure->GetPOST("anzahl");  
    $bemerkung = $this->app->Secure->GetPOST("bemerkung");  
    $wunsch= $this->app->Secure->GetPOST("wunsch");  

    $this->app->Tpl->Set(ID,$id);

    if($rma=="rma")
    {

      if($pos>0)
      {
	$artikel = $this->app->DB->Select("SELECT artikel FROM lieferschein_position WHERE id='$pos' LIMIT 1");
	$projekt = $this->app->DB->Select("SELECT projekt FROM lieferschein_position WHERE id='$pos' LIMIT 1");
	$bestellung = $this->app->DB->Select("SELECT lieferschein FROM lieferschein_position WHERE id='$pos' LIMIT 1");
	$vpe= $this->app->DB->Select("SELECT vpe FROM lieferschein_position WHERE id='$pos' LIMIT 1");
	$menge_bestellung = $this->app->DB->Select("SELECT menge FROM lieferschein_position WHERE id='$pos' LIMIT 1");
	$adresse = $this->app->DB->Select("SELECT adresse FROM paketannahme WHERE id='$id' LIMIT 1");
	$name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
	$mitarbeiter = $this->app->DB->Select("SELECT bearbeiter FROM lieferschein WHERE id='$bestellung' LIMIT 1");
      } else {
	$artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$artikelnummer' LIMIT 1");
	$adresse = $this->app->DB->Select("SELECT adresse FROM paketannahme WHERE id='$id' LIMIT 1");
	$name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
      }

    } else {
    //bestellung
    // bestellung findet man raus ueber pos (bestellung) 
    $artikel = $this->app->DB->Select("SELECT artikel FROM bestellung_position WHERE id='$pos' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM bestellung_position WHERE id='$pos' LIMIT 1");
    $bestellung = $this->app->DB->Select("SELECT bestellung FROM bestellung_position WHERE id='$pos' LIMIT 1");
    $vpe= $this->app->DB->Select("SELECT vpe FROM bestellung_position WHERE id='$pos' LIMIT 1");
    $menge_bestellung = $this->app->DB->Select("SELECT menge FROM bestellung_position WHERE id='$pos' LIMIT 1");
    $adresse = $this->app->DB->Select("SELECT adresse FROM paketannahme WHERE id='$id' LIMIT 1");
    $name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $mitarbeiter = $this->app->DB->Select("SELECT bearbeiter FROM bestellung WHERE id='$bestellung' LIMIT 1");
    }

    $lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='$artikel' LIMIT 1");
    $mitarbeiter_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$mitarbeiter' AND geloescht=0 LIMIT 1");
    $artikelcheckliste = $this->app->DB->Select("SELECT artikelcheckliste FROM artikel WHERE id='$artikel' LIMIT 1");
    $funktionstest = $this->app->DB->Select("SELECT funktionstest FROM artikel WHERE id='$artikel' LIMIT 1");
    $endmontage = $this->app->DB->Select("SELECT endmontage FROM artikel WHERE id='$artikel' LIMIT 1");
    $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
    $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
    $chargenverwaltung= $this->app->DB->Select("SELECT chargenverwaltung FROM artikel WHERE id='$artikel' LIMIT 1");
    $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$artikel' LIMIT 1");
    $shopartikel = $this->app->DB->Select("SELECT shop FROM artikel WHERE id='$artikel' LIMIT 1");


    if($standardbild=="")
      $standardbild = $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE subjekt='Shopbild' AND objekt='Artikel' AND parameter='$artikel' LIMIT 1");


    if($menge > $menge_bestellung)
      $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Achtung! Es wurden mehr geliefert als in der aktuellen Position bestellt worden sind!
      &nbsp;<input type=\"button\" onclick=\"window.location.href='index.php?module=wareneingang&action=distriinhalt&id=$id'\"
      value=\"Anzahl anpassen\" /></div>");


    if(!$shopartikel > 0)
    {
      $this->app->Tpl->Set(SHOWIMGSTART,"<!--");
      $this->app->Tpl->Set(SHOWIMGEND,"-->");
    }

    $this->app->Tpl->Set(LAGER,$this->app->erp->GetSelect($this->app->erp->GetLager(),$lager));
    $this->app->Tpl->Set(ETIKETTEN,$this->app->erp->GetSelect($this->app->erp->GetEtikett(),$etiketten));
    $this->app->Tpl->Set(MENGE,$menge);
    $this->app->Tpl->Set(LIEFERANT,$name);
    $this->app->Tpl->Set(MITARBEITER,$mitarbeiter_name);
    $this->app->Tpl->Set(VPE,$vpe);
    $this->app->Tpl->Set(NAME,$name_de);
    $this->app->Tpl->Set(DATEI,$standardbild);

    //befehl ab ins lager, produktion oder mitarbeiter

    $typ = "";
    //weiter mit paket bis fertig
    if($rma=="rma")
    {
      $typ = "rma";
      $this->app->Tpl->Parse(TAB1,"wareneingangpaketdistribution_tab3_rma.tpl");
    } else {
    if($lagerartikel && !$artikelcheckliste && !$funktionstest && !$endmontage)
    {
      $typ = "lager";
      $this->app->Tpl->Parse(TAB1,"wareneingangpaketdistribution_tab3_lager.tpl");
    } else if($artikelcheckliste || $funktionstest || $endmontage)
    {
      $typ = "produktion";
      $this->app->Tpl->Parse(TAB1,"wareneingangpaketdistribution_tab3_produktion.tpl");
    } else if (!$lagerartikel && !$artikelcheckliste && !$funktionstest && !$endmontage)
    {
      $typ = "mitarbeiter";
      $this->app->Tpl->Parse(TAB1,"wareneingangpaketdistribution_tab3_mitarbeiter.tpl");
    } else {echo "Diesen Fall gibt es nich. Bitte Bene holen!!!!";}
    }
  
    if($submit!="")
    {
      switch($typ)
      {
	case "lager":
	  if($chargenverwaltung=="1")
	  {
	    // wenn chargenverwaltung dann chargen id holen!!!! und mit bei lagerung und etikett speichern!
	    $this->app->DB->Insert("INSERT INTO chargenverwaltung (id,artikel,bestellung,menge,vpe,zeit,bearbeiter) VALUES ('','$artikel','$bestellung','$menge','$vpe',NOW(),'".$this->app->User->GetName()."')");
	    // drucken (inkl. chargennummer)
	    $ch = $this->app->DB->GetInsertID();
	  } else $ch = 0;

	  if($anzahlauswahl=="fix") $druckanzahl = $anzahl_fix;
	  else $druckanzahl = $anzahl_dyn;
          $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");                     
          $name_de = base64_encode($name_de);  
		
	  //$etiketten AUSWAHL etiketten ob gross oder klein
	  if($etiketten=="gross")
	    HttpClient::quickGet("http://192.168.0.178/druck.php?nr=$nummer&ch=$ch&anzahl=$druckanzahl&etikett=$etiketten&beschriftung=$name_de");
	  else
{      $etiketten ="klein";   
	    HttpClient::quickGet("http://192.168.0.178/druck.php?nr=$nummer&ch=$ch&anzahl=$druckanzahl&etikett=$etiketten&beschriftung=$name_de");
	    }
	  // entweder ins zwischenlager 
	  if($lager=="Zwischenlager")
	  {
	    $this->app->DB->Insert("INSERT INTO zwischenlager (id,bearbeiter,projekt,artikel,menge,vpe,grund,lager_von,richtung,objekt,parameter,firma)
	      VALUES ('','".$this->app->User->GetName()."','$projekt','$artikel','$menge','$vpe','Wareneingang von Bestellung $bestellung','Wareneingang','Eingang',
	      'Bestellung','$bestellung','".$this->app->User->GetFirma()."')");
	    $typ = "zwischenlager";
	  }
	  // oder direkt ins manuelle (lagerplatz + lager_bewegung)
	  else 
	  {
	    $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz,artikel,menge,eingang,zeit,referenz,vpe,bearbeiter) VALUES  
		('','$lager','$artikel','$menge','1',NOW(),'Wareneingang von Bestellung $id','$vpe','".$this->app->User->GetName()."')");	    

	    $this->app->DB->Insert("INSERT INTO lager_platz_inhalt (id,lager_platz,artikel,menge,vpe,bearbeiter,bestellung) VALUES  
		('','$lager','$artikel','$menge','$vpe','".$this->app->User->GetName()."','$bestellung')");	    

	    // die id von lager_platz_inhalt ist die chargenid UND JETZT ERST DRUCKEN!!!!!!!!!!
	  }

	break;

	case "produktion":
	  // drucken $anzahl etiketten
	  // buchen in produktionstabelle
	  // wenn produktionsartikel muss artikel in der maske produktion erscheinen 
	  $this->app->DB->Insert("INSERT INTO produktionslager (id,artikel,menge,bemerkung,status,bearbeiter,vpe,bestellung_pos,projekt)
	    VALUES ('','$artikel','$menge','$bemerkung','offen','".$this->app->User->GetName()."','$vpe','$pos','$projekt')");
	  $tmpid= $this->app->DB->GetInsertID();
	  for($i=0;$i<$anzahl;$i++)
	    HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$tmpid&label=Produktion");
	break;

	case "mitarbeiter":
	  // buchen als mitarbeiter inventar auf das projekt was angegeben ist
	  // wenn mitarbeiterartikel muss artikel als inventar dem mitarbeiter gebucht werden fuer projekt bla bla
	  $this->app->DB->Insert("INSERT INTO projekt_inventar (id,artikel,menge,projekt,mitarbeiter,bestellung,zeit,vpe)
	    VALUES('','$artikel','$menge','$projekt','$mitarbeiter','$bestellung',NOW(),'$vpe')");
	break;


	case "rma":

	  $lieferschein = $bestellung;

	  $id = $this->app->Secure->GetGET("id");
/*
	  echo "lieferschein: ".$lieferschein;
	  echo "<br>";
	  echo "wunsch: ".$wunsch;
	  echo "<br>";
	  echo "bemerkung: ".$bemerkung;
	  echo "<br>";
	  echo "artikel: ".$artikel;
	  echo "<br>";
	  echo "pos : ".$pos;
*/

	  // wunsch und bemerkung
	  // buchen als mitarbeiter inventar auf das projekt was angegeben ist
	  // wenn mitarbeiterartikel muss artikel als inventar dem mitarbeiter gebucht werden fuer projekt bla bla

	   $this->app->DB->Insert("INSERT INTO rma_artikel (id,adresse,bearbeiter,lieferschein,pos,wunsch,bemerkung,artikel,menge,status,angelegtam,firma,wareneingang)
	    VALUES('','$adresse','".$this->app->User->GetName()."','$lieferschein','$pos','$wunsch','$bemerkung','$artikel','$menge','angelegt',NOW(),'".$this->app->User->GetFirma()."','$id')");

	  $tmpid= $this->app->DB->GetInsertID();

	  HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$tmpid&label=RMA");

	break;


	default:
	  echo "ACHTUNG DAS DARF NICHT PASSIEREN!! BENE HOLEN! FEHLER IM PROGRAMM?";  
      }


      if($typ!="rma")
      {
	// Distribution speichern!
	$this->app->DB->Insert("INSERT INTO paketdistribution (id,bearbeiter,zeit,paketannahme,adresse,artikel,menge,vpe,etiketten,bemerkung,bestellung_position)
	VALUES ('','".$this->app->User->GetName()."',NOW(),'$id','$adresse','$artikel','$menge','$vpe','$etiketten','$bemerkung','$pos')");

	// anzahl gelieferte erhoehen bestellung_position !!!
	$geliefert = $this->app->DB->Select("SELECT geliefert FROM bestellung_position WHERE id='$pos' LIMIT 1");
	$gesamt_erwartet = $this->app->DB->Select("SELECT menge FROM bestellung_position WHERE id='$pos' LIMIT 1");
	$geliefert = $geliefert + $menge;
	$this->app->DB->Update("UPDATE bestellung_position SET geliefert='$geliefert' WHERE id='$pos' LIMIT 1");
      }

      // alles passt weiter im abschluss
      header("Location: index.php?module=wareneingang&action=distriabschluss&id=$id&pos=$pos&typ=$typ&rma=$rma");
      exit;
    }
   

    $this->app->Tpl->Set(AKTIV_TAB2,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketdistribution.tpl");

  }


  function WareneingangPaketDistriAbschluss()
  {
    $id = $this->app->Secure->GetGET("id");
    $typ  = $this->app->Secure->GetGET("typ");
    $submit = $this->app->Secure->GetGET("submit");
    $abschliessen = $this->app->Secure->GetPOST("abschliessen");
    $weiter = $this->app->Secure->GetPOST("weiter");

    $this->WareneingangPaketDistriMenu(); 


    if($weiter!="")
    {
      header("Location: index.php?module=wareneingang&action=distriinhalt&id=$id");
      exit;
    }

    if($abschliessen!="")
    {
      // paketannahme auf abgeschlossen setzten
      $this->app->DB->Update("UPDATE paketannahme SET status='abgeschlossen' WHERE id='$id' LIMIT 1");

      if($typ=="rma")
      {
	  //RMA bericht drucken mit allen artikeln des Kunden

	  

      }


      header("Location: index.php?module=wareneingang&action=distribution");
      exit;
    }

    if($typ=="rma")
    {
      $this->app->Tpl->Set(PAGE,"<form action=\"\" method=\"post\"><br><br><center>
      <input type=\"submit\" name=\"weiter\" value=\"weitere Artikel aus dem Paket zurordnen\">&nbsp;
      <input type=\"submit\" name=\"abschliessen\" value=\"Paket ist komplett erfasst!\"></center></form>");

    } else {

    $this->app->Tpl->Set(PAGE,"<form action=\"\" method=\"post\"><br><br><center>
      <input type=\"submit\" name=\"weiter\" value=\"weitere Artikel aus dem Paket zurordnen\">&nbsp;
      <input type=\"submit\" name=\"abschliessen\" value=\"Paketinhalt ist jetzt komplett erfasst!\"></center></form>");
    }
  }



  function WareneingangPaketDistribution()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->WareneingangPaketDistriMenu(); 

    if(is_numeric($id))
    {
      //$this->app->FormHandler->FormGetVars("paketannahme",$id);


      if($this->app->Secure->GetPOST("submit")!="")
      {
	$beipack_rechnung = $this->app->Secure->GetPOST("rechnung");
	$beipack_lieferschein = $this->app->Secure->GetPOST("lieferschein");
	$beipack_anschreiben = $this->app->Secure->GetPOST("anschreiben");
	$beipack_gesamt = $this->app->Secure->GetPOST("gesamt");
	$postgrund = $this->app->Secure->GetPOST("postgrund");
	//speichern und weiter
	$this->app->DB->Update("UPDATE paketannahme SET	    
	    beipack_rechnung='$beipack_rechnung',beipack_lieferschein='$beipack_lieferschein', 
	    beipack_anschreiben='$beipack_anschreiben',beipack_gesamt='$beipack_gesamt',status='distribution',bearbeiter_distribution='{$this->app->User->GetName()}',postgrund='$postgrund'
	  WHERE id='$id' LIMIT 1");


	if($beipack_rechnung)
	{
	  $file = $this->app->erp->CreateDateiOhneInitialeVersion("Rechnung von Paketannahme $id","Dokument aus Paket","",$this->app->User->GetName());
          $this->app->erp->AddDateiStichwort($file,"Rechnung","Paketannahme",$id);
	  HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$file&label=Rechnung");
	}
	if($beipack_lieferschein)
	{
	  $file = $this->app->erp->CreateDateiOhneInitialeVersion("Lieferschein von Paketannahme $id","Dokument aus Paket","",$this->app->User->GetName());
          $this->app->erp->AddDateiStichwort($file,"Lieferschein","Paketannahme",$id);
	  HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$file&label=Lieferschein");
	}
	if($beipack_anschreiben)
	{
	  $file = $this->app->erp->CreateDateiOhneInitialeVersion("Anschreiben von Paketannahme $id","Dokument aus Paket","",$this->app->User->GetName());
          $this->app->erp->AddDateiStichwort($file,"Anschreiben","Paketannahme",$id);
	  HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$file&label=Anschreiben");
	}
	// hier dms anlegen!!!!! nummer geben lassen und etikett drucken!
	for($r=0;$r<$beipack_gesamt;$r++)
	{
	  $file = $this->app->erp->CreateDateiOhneInitialeVersion("Dokument von Paketannahme $id","Dokument aus Paket","",$this->app->User->GetName());
          $this->app->erp->AddDateiStichwort($file,"Dokument","Paketannahme",$id);
	  HttpClient::quickGet("http://192.168.0.178/druck_dms.php?nr=$file&label=Dokument");
	}


	header("Location: index.php?module=wareneingang&action=distriinhalt&id=$id");
	exit;
      }

      $tmp = $this->app->DB->SelectArr("SELECT * FROM paketannahme WHERE id='$id' LIMIT 1");
      $this->app->Tpl->Set(ADRESSE,$this->app->DB->Select("SELECT name FROM adresse WHERE id='{$tmp[0][adresse]}' AND geloescht=0 LIMIT 1"));
      $kunde = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='{$tmp[0][adresse]}' AND geloescht=0 LIMIT 1");
      $this->app->Tpl->Set(KUNDE,$nr = $kunde?$kunde:"kein Kunde");
      $lieferant = $this->app->DB->Select("SELECT lieferantennummer FROM adresse WHERE id='{$tmp[0][adresse]}' AND geloescht=0 LIMIT 1");
      $this->app->Tpl->Set(LIEFERANT,$lieferant?$lieferant:"kein Lieferant");

      $this->app->Tpl->Set(STATUS,$tmp[0][status]);
      $this->app->Tpl->Set(DATUM,$this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y %H:%i') FROM paketannahme WHERE id='$id' LIMIT 1"));
      $this->app->Tpl->Set(BEARBEITER,$tmp[0][bearbeiter]);
      $this->app->Tpl->Set(GEWICHT,$tmp[0][gewicht]);
      $this->app->Tpl->Set(FOTO,$tmp[0][foto]);


      $anzahl = array(0,1,2,3,4,5);
      $select = $this->app->erp->GetSelect($anzahl,$tmp[0][beipack_gesamt]);

      $this->app->Tpl->Set(RECHNUNG,$tmp[0][beipack_rechnung]?"checked":"");
      $this->app->Tpl->Set(LIEFERSCHEIN,$tmp[0][beipack_lieferschein]?"checked":"");
      $this->app->Tpl->Set(ANSCHREIBEN,$tmp[0][beipack_anschreiben]?"checked":"");
      $this->app->Tpl->Set(GESAMT,$select);

      if($kunde > 0)
      {
      $postgrund = array(""=>"bitte w&auml;hlen","verweigert"=>"Annahme verweigert","unbekannt"=>"Empf&auml;nger unbekannt","porto"=>"Zu wenig frankiert","rma"=>"RMA Paketmarke","zusendung"=>"Zusendung");
      $postgrund= $this->app->erp->GetSelectAsso($postgrund,$tmp[0][postgrund]);
      $this->app->Tpl->Set(POSTGRUND,$postgrund);
      } else {
	// wenn adresse nur lieferant ist
	$this->app->Tpl->Set(POSTGRUNDENABLE,"<!--");
	$this->app->Tpl->Set(POSTGRUNDDISABLE,"-->");
      }

      $this->app->Tpl->Parse(TAB1,"wareneingangpaketdistribution_tab1.tpl");
      $this->app->Tpl->Set(AKTIV_TAB1,"tabs-1");
      $this->app->Tpl->Parse(PAGE,"wareneingangpaketdistribution.tpl");
    } else 
    {

      // pruefen welche pakete auf ausgepackt gesetzt gehoeren //TODO auf abgeschlossen setzen

      $this->app->Tpl->Set(SUBHEADING,"Lieferungen");
      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
      $table = new EasyTable($this->app);
      $table->Query("SELECT DATE_FORMAT(p.datum,'%d.%m.%Y') as datum,p.id as paket, a.name,bearbeiter as Paketannahme,p.id  FROM paketannahme p LEFT JOIN adresse a ON a.id=p.adresse WHERE status='angenommen'");
      $table->DisplayNew(INHALT,"<a href=\"index.php?module=wareneingang&action=distribution&id=%value%\">auspacken</a>");
      $this->app->Tpl->Parse(TAB1,"rahmen.tpl");
      $this->app->Tpl->Set(INHALT,"");

      $this->app->Tpl->Set(SUBHEADING,"Lieferungen in Bearbeitung");
      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
      $table = new EasyTable($this->app);
      $table->Query("SELECT DATE_FORMAT(p.datum,'%d.%m.%Y') as datum,p.id as paket, a.name,bearbeiter_distribution as bearbeiter,p.id  FROM paketannahme p LEFT JOIN adresse a ON a.id=p.adresse WHERE status='distribution'");
      $table->DisplayNew(INHALT,"<a href=\"index.php?module=wareneingang&action=distriinhalt&id=%value%\">weiter auspacken</a>&nbsp;<a href=\"index.php?module=wareneingang&action=distriabschluss&id=%value%\">Abschlie&szlig;en</a>");
      $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

      $this->app->Tpl->Set(INHALT,"");
      $this->app->Tpl->Set(SUBHEADING,"Abgeschlossene Lieferungen (letzten 14 Tage)");
      //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
      $table = new EasyTable($this->app);
      $table->Query("SELECT DATE_FORMAT(p.datum,'%d.%m.%Y') as datum,p.id as Nr, a.name,bearbeiter_distribution,p.id  FROM paketannahme p LEFT JOIN adresse a ON a.id=p.adresse WHERE status='abgeschlossen'");
      $table->DisplayNew(INHALT,"<a href=\"index.php?module=wareneingang&action=distribution&id=%value%\">Betrachten</a>&nbsp;<a href=#>&Uuml;bernehmen</a>");
      $this->app->Tpl->Parse(TAB1,"rahmen.tpl");


      $this->app->Tpl->Parse(PAGE,"wareneinganguebersicht.tpl");
    }

  }


  function WareneingangPaketAbsender()
  {
    $id = $this->app->Secure->GetGET("id");
    $submit = $this->app->Secure->GetPOST("submit");
    $zurueck= $this->app->Secure->GetPOST("zurueck");
    $this->WareneingangPaketMenu();

    $adresse = $this->app->DB->Select("SELECT adresse FROM paketannahme WHERE id='$id' LIMIT 1");
      
    if($zurueck!="")
    {
      $this->app->DB->Delete("DELETE FROM paketannahme WHERE id='$id' LIMIT 1");
      header("Location: index.php?module=wareneingang&action=paketannahme");
      exit;
    }

    if($submit!="")
      header("Location: index.php?module=wareneingang&action=paketzustand&id=$id");


    $this->app->FormHandler->FormGetVars("adresse",$adresse);
    
    $this->app->Tpl->Parse(TAB1,"wareneingangpaketannahme_tab2.tpl");

    $this->app->Tpl->Set(AKTIV_TAB2,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketannahme.tpl");
  }

  function WareneingangPaketZustand()
  {
    $this->WareneingangPaketMenu();
    $id = $this->app->Secure->GetGET("id");
    $submit = $this->app->Secure->GetPOST("submit");
    if($submit!="")
    {
      $this->app->FormHandler->FormUpdateDatabase("paketannahme",$id);
      
      header("Location: index.php?module=wareneingang&action=paketetikett&id=$id");
      exit;
    }
    //$client = new HttpClient("192.168.0.171");
    $pageContent = HttpClient::quickGet("http://192.168.0.53/manage.php");

    $gewicht = $pageContent;
  
    $gewicht = intval($gewicht)-2;

    $this->app->Tpl->Set(GEWICHT,$gewicht);

    $datei = HttpClient::quickGet("http://192.168.0.53/snap.jpg");

    $ersteller = $this->app->User->GetName();
    $file = $this->app->erp->CreateDatei(date('Ymd')."_paketannahme_$id.jpg","Paketannahme $id","","",$datei,$ersteller);
 
    $this->app->Tpl->Set(FOTO,$file);

    $this->app->erp->AddDateiStichwort($file,"Bild","Paketannahme",$id);


    if($gewicht <= 0)
      $this->app->Tpl->Set(MELDUNG,"<div class=\"error\">Bitte legen Sie das Paket auf die Waage und schie&szlig;en Sie nochmal ein Foto!</div>");
 

    $this->app->Tpl->Parse(TAB1,"wareneingangpaketannahme_tab3.tpl");
    $this->app->Tpl->Set(AKTIV_TAB3,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketannahme.tpl");
  }


  function WareneingangPaketEtikett()
  {
    $this->WareneingangPaketMenu();
    $id = $this->app->Secure->GetGET("id");
    $submit = $this->app->Secure->GetPOST("submit");
    if($submit!="")
      header("Location: index.php?module=wareneingang&action=paketabschliessen&id=$id");


    $this->app->Tpl->Parse(TAB1,"wareneingangpaketannahme_tab4.tpl");
    $this->app->Tpl->Set(AKTIV_TAB4,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketannahme.tpl");
  }

  function WareneingangPaketAbschliessen()
  {
    $this->WareneingangPaketMenu();
    $id = $this->app->Secure->GetGET("id");
    $weiteres= $this->app->Secure->GetPOST("weiteres");
    $abschluss= $this->app->Secure->GetPOST("abschluss");
    $distri= $this->app->Secure->GetPOST("distri");

    if($weiteres!="")
      header("Location: index.php?module=wareneingang&action=paketannahme");
    if($abschluss!="")
      header("Location: index.php?module=wareneingang&action=distribution");
    if($distri!="")
      header("Location: index.php?module=wareneingang&action=distribution&id=$id");




    $this->app->Tpl->Parse(TAB1,"wareneingangpaketannahme_tab5.tpl");
    $this->app->Tpl->Set(AKTIV_TAB5,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketannahme.tpl");
  }




  function WareneingangList()
  {
    $this->WareneingangMenu();

    $this->app->Tpl->Set(SUBHEADING,"Lieferungen");
    //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
    $table = new EasyTable($this->app);
    $table->Query("SELECT '23.11.2009' as datum, 'Olimex' as lieferant,id FROM aufgabe LIMIT 3");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%\">Lesen</a>");
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");
    $this->app->Tpl->Set(INHALT,"");


    $this->app->Tpl->Set(AKTIV_TAB1,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneinganguebersicht.tpl");
  }

  function WareneingangPaketannahme()
  {
    $this->WareneingangPaketMenu();

    $vorlage= $this->app->Secure->GetGET("vorlage");
    $suche= $this->app->Secure->GetPOST("suche");
    $id = $this->app->Secure->GetGET("id");

    if($vorlage!="")
    {
      if($vorlage=="bestellung")
      {
	$vorlageid = $id;
	$adresse = $this->app->DB->Select("SELECT adresse FROM bestellung WHERE id='$id' LIMIT 1");
	$projekt = $this->app->DB->Select("SELECT projekt FROM bestellung WHERE id='$id' LIMIT 1");
      } 
      else if ($vorlage=="rma")
      {
	$vorlageid = $id;
	$adresse = $this->app->DB->Select("SELECT adresse FROM rma WHERE id='$id' LIMIT 1");
	$projekt = $this->app->DB->Select("SELECT projekt FROM rma WHERE id='$id' LIMIT 1");
      }
      else if ($vorlage=="adresse")
      {
	$adresse = $id;
	$vorlageid = $adresse;
	// standardprojekt von kunde
	$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
      } else exit;

      $bearbeiter = $this->app->User->GetName(); 

      $sql = "INSERT INTO paketannahme (id,datum,adresse,vorlage,vorlageid,projekt,bearbeiter,status) VALUES
	('',NOW(),'$adresse','$vorlage','$vorlageid','$projekt','$bearbeiter','angenommen')";
      $this->app->DB->Insert($sql);
      $id = $this->app->DB->GetInsertID();
      header("Location: index.php?module=wareneingang&action=paketabsender&id=$id");
    }

    if($suche!="")  
    {
      $table = new EasyTable($this->app);
      $this->app->Tpl->Set(SUCHE,"<h2>Trefferliste:</h2><br>");
      $table->Query("SELECT name, plz, ort, strasse, id FROM adresse WHERE (name LIKE '%$suche%' or plz='$suche') AND geloescht=0");
      $table->DisplayNew(SUCHE,"<a href=\"index.php?module=wareneingang&action=paketannahme&id=%value%&vorlage=adresse\">Adresse ausw&auml;hlen</a>");
    } else {
      $letzte_adresse = $this->app->DB->Select("SELECT adresse FROM paketannahme Order by datum DESC LIMIT 1");
      $this->app->Tpl->Set(SUCHE,"<h2>Letzte Paketannahme:</h2><br>");
      $table = new EasyTable($this->app);
      $table->Query("SELECT name, plz, ort, strasse, id FROM adresse WHERE id='$letzte_adresse' AND geloescht=0");
      $table->DisplayNew(SUCHE,"<a href=\"index.php?module=wareneingang&action=paketannahme&id=%value%&vorlage=adresse\">Adresse nochmal ausw&auml;hlen</a>");
    }

    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, name, belegnr as bestellung, id FROM bestellung WHERE status!='geliefert'");
    $table->DisplayNew(BESTELLUNGEN,"<a href=\"index.php?module=wareneingang&action=paketannahme&id=%value%&vorlage=bestellung\">weiter</a>");

    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, name, belegnr as RMA, id FROM rma WHERE status!='geliefert'");
    $table->DisplayNew(RMA,"<a href=\"index.php?module=wareneingang&action=paketannahme&id=%value%&vorlage=rma\">weiter</a>");
 
    $this->app->Tpl->Parse(TAB1,"wareneingangpaketannahme_tab1.tpl");

    $this->app->Tpl->Set(AKTIV_TAB1,"tabs-1");
    $this->app->Tpl->Parse(PAGE,"wareneingangpaketannahme.tpl");
  }




}
?>
