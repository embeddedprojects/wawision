<?
include ("_gen/widget.gen.gutschrift.php");

class WidgetGutschrift extends WidgetGenGutschrift 
{
  private $app;
  function WidgetGutschrift(&$app,$parsetarget)
  {
    $this->app = &$app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenGutschrift($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
    $this->app->YUI->AutoComplete("adresse","kunde");
    $this->app->YUI->AutoComplete("projekt","projektname",1);
    $this->app->YUI->AutoComplete("lieferschein","lieferschein");


    $this->app->YUI->DatePicker("datum");
    $this->app->YUI->DatePicker("ustbrief_eingang_am");
    $this->app->YUI->DatePicker("lieferdatum");


    $this->form->ReplaceFunction("datum",&$this,"ReplaceDatum");
    $this->form->ReplaceFunction("ustbrief_eingang_am",&$this,"ReplaceDatum");
    $this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");
    $this->form->ReplaceFunction("adresse",&$this,"ReplaceKunde");


    $zahlungsweise = $this->app->erp->GetZahlungsweiseGutschrift();

    $zahlungsstatus= $this->app->erp->GetZahlungsstatusLieferant();

    $id = $this->app->Secure->GetGET("id");
    $zahlungsstatus= $this->app->DB->Select("SELECT zahlungsstatus FROM gutschrift WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(ZAHLUNGSSTATUS,$zahlungsstatus);

    $status = $this->app->erp->GetStatusGutschrift();

    //$this->app->erp->GetSelect($versandart,$this->app->

    $field = new HTMLSelect("zahlungsweise",0);
    $field->onchange="aktion_buchen(this.form.zahlungsweise.options[this.form.zahlungsweise.selectedIndex].value);";
    $field->AddOptionsSimpleArray($zahlungsweise);
    $this->form->NewField($field);


    $field = new HTMLInput("land","hidden","");
    $this->form->NewField($field);

  }


  function ReplaceProjekt($db,$value)
  {
    return $this->app->erp->ReplaceProjekt($db,$value);
  }

  function ReplaceKunde($db,$value)
  {
    return $this->app->erp->ReplaceKunde($db,$value);
  }

  function ReplaceDatum($db,$value)
  {
    return $this->app->erp->ReplaceDatum($db,$value);
  }


}
?>
