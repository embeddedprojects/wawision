<?
include ("_gen/widget.gen.artikel.php");

class WidgetArtikel extends WidgetGenArtikel 
{
  private $app;
  function WidgetArtikel($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenArtikel($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
    //$this->app->YUI->AutoComplete(LIEFERANTAUTO,"adresse",array('name'),"name","lieferant");

    //$this->app->YUI->AutoComplete(STANDARDLAGERAUTO,"lager_platz",array('kurzbezeichnung'),"kurzbezeichnung");
    //$this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");
    $this->app->YUI->AutoComplete("projekt","projektname",1);
    $this->app->YUI->AutoComplete("adresse","lieferant");
    $this->app->YUI->AutoComplete("typ","artikelgruppe");
    $this->app->YUI->AutoComplete("shop","shopname");
    $this->app->YUI->AutoComplete("hersteller","hersteller");
    $this->app->YUI->AutoComplete("herstellerlink","herstellerlink");
    $this->app->YUI->AutoComplete("lager_platz","lagerplatz");


    $this->form->ReplaceFunction("adresse",&$this,"ReplaceLieferant");
    $this->form->ReplaceFunction("gueltigbis",&$this,"ReplaceDatum");
    $this->form->ReplaceFunction("lager_platz",&$this,"ReplaceLagerplatz");
    $this->form->ReplaceFunction("shop",&$this,"ReplaceShopname");
    $this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");


    $id = $this->app->Secure->GetGET("id");    
    $action = $this->app->Secure->GetGET("action");    

    /* pruefung Artikel nummer doppel */
    $nummer_db = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
    $artikelart= $this->app->DB->Select("SELECT typ FROM artikel WHERE id='$id' LIMIT 1");
    $anzahl_nummer = $this->app->DB->Select("SELECT count(id) FROM artikel WHERE firma='".$this->app->User->GetFirma()."' AND nummer='$nummer_db'");

    $nummer = $this->app->Secure->GetPOST("nummer"); 
		if($nummer > 0)
    $fremde_anzahl_nummer = $this->app->DB->Select("SELECT count(id) FROM artikel WHERE firma='".$this->app->User->GetFirma()."' AND nummer='$nummer' AND id!='$id' AND geloescht=0");
		else $fremde_anzahl_nummer = 0;


    if(($nummer_db == "" || $nummer_db ==0) && $action=="edit")
    { 
      $neue_nummer = $this->app->erp->NeueArtikelNummer($artikelart);
      $nummer_db = $neue_nummer;

      $this->app->DB->Update("UPDATE artikel SET nummer='$neue_nummer' WHERE id='$id' LIMIT 1");
      $this->app->YUI->Message("info","Es wurde eine neue Artikelnummer vergeben.");
    }

    if($fremde_anzahl_nummer > 0 || $anzahl_nummer > 1) 
      $this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Achtung Artikel Nr. doppelt vergeben!</div>");

/*
    $already_set=0;
    $anzahl_nummer = $this->app->DB->Select("SELECT count(id) FROM artikel WHERE firma='".$this->app->User->GetFirma()."' AND nummer='$nummer_db'");
    if($anzahl_nummer > 1 || $fremde_anzahl_nummer > 0)
    { 
      //$this->app->Tpl->Add(MESSAGE,"<div class=\"error\">Achtung Artikel Nr. doppelt vergeben!</div>");
      $this->app->YUI->Message("error","Achtung! Die Artikelnummer wurde doppelt vergeben!");
    }
*/

    //$this->app->Tpl->Set(KALENDER_GUELTIGBIS,
    //    "<input type=\"button\" value=\"Datum\" onclick=\"displayCalendar(document.forms[0].gueltigbis,'dd.mm.yyyy',this)\">");


    $warengruppe = $this->app->erp->GetArtikelWarengruppe();

    $field = new HTMLSelect("warengruppe",0);
    $field->AddOptionsSimpleArray($warengruppe);
    $this->form->NewField($field);

    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);
  }


  function ReplaceProjekt($db,$value)
  {
    return $this->app->erp->ReplaceProjekt($db,$value);
  }

  function ReplaceDatum($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(strpos($value,'-') > 0) $dbformat = 1;

    // wenn ziel datenbank
    if($db)
    { 
      if($dbformat) return $value;
      else return $this->app->String->Convert($value,"%1.%2.%3","%3-%2-%1");
    }
    // wenn ziel formular
    else
    { 
      if($dbformat) return $this->app->String->Convert($value,"%1-%2-%3","%3.%2.%1");
      else return $value;
    }
  }


  function ReplaceShopname($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(is_numeric($value)) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT bezeichnung FROM shopexport WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM shopexport WHERE bezeichnung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }



  function ReplaceLagerplatz($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(is_numeric($value)) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM lager_platz WHERE kurzbezeichnung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }


  function ReplaceLieferant($db,$value)
  {
    return $this->app->erp->ReplaceLieferant($db,$value);
  }


  public function Table()
  {
    $table = new EasyTable($this->app);  
    $table->Query("SELECT nummer, name_de as name,barcode, id FROM artikel order by nummer");
    $table->Display($this->parsetarget);
  }



  public function Search()
  {
    //$this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }


}
?>
