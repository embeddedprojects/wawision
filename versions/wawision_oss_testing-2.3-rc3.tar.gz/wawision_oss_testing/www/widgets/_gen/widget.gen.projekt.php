<?php 

class WidgetGenprojekt
{

  private $app;            //application object  
  public $form;            //store form object  
  private $parsetarget;    //target for content

  public function WidgetGenprojekt($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    $this->Form();
  }

  public function projektDelete()
  {
    
    $this->form->Execute("projekt","delete");

    $this->projektList();
  }

  function Edit()
  {
    $this->form->Edit();
  }

  function Copy()
  {
    $this->form->Copy();
  }

  public function Create()
  {
    $this->form->Create();
  }

  public function Search()
  {
    $this->app->Tpl->Set($this->parsetarget,"SUUUCHEEE");
  }

  public function Summary()
  {
    $this->app->Tpl->Set($this->parsetarget,"grosse Tabelle");
  }

  function Form()
  {
    $this->form = $this->app->FormHandler->CreateNew("projekt");
    $this->form->UseTable("projekt");
    $this->form->UseTemplate("projekt.tpl",$this->parsetarget);

    $field = new HTMLInput("name","text","","50","","","","","","","0");
    $this->form->NewField($field);
    $this->form->AddMandatory("name","notempty","Pflichtfeld!",MSGNAME);

    $field = new HTMLInput("abkuerzung","text","","40","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("verantwortlicher","text","","40","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLTextarea("beschreibung",5,50);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("sonstiges",5,50);   
    $this->form->NewField($field);

    $field = new HTMLCheckbox("aktiv","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("folgebestaetigung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("autoversand","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("portocheck","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("automailrechnung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("checkok","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("checkname","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("zahlungserinnerung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("zahlungsmailbedinungen","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("autobestellung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("stornomail","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("speziallieferschein","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("speziallieferscheinbeschriftung","","","1","0");
    $this->form->NewField($field);



  }

}

?>