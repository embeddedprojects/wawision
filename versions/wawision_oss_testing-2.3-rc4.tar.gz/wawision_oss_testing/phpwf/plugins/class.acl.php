<?php


class Acl 
{
  //var $engine;
  function Acl(&$app)
  {
    $this->app = &$app;
  }


  function CheckTimeOut()
  {
    // check if user is applied 
    $sessid =  $this->app->DB->Select("SELECT sessionid FROM useronline,user WHERE
       login='1' AND sessionid='".session_id()."' AND user.id=useronline.user_id AND user.activ='1' LIMIT 1");
    
    if(session_id() == $sessid)
    { 
      // check if time is expired
      $time =  $this->app->DB->Select("SELECT UNIX_TIMESTAMP(time) FROM useronline,user WHERE
       login='1' AND sessionid='".session_id()."' AND user.id=useronline.user_id AND user.activ='1' LIMIT 1");

      if((time()-$time) > $this->app->Conf->WFconf[logintimeout])
      {
	//$this->app->WF->ReBuildPageFrame();
	$this->Logout("Ihre Zeit ist abgelaufen, bitte melden Sie sich erneut an.");
	return false;
      }
      else {
	// update time
	 $this->app->DB->Update("UPDATE useronline,user SET useronline.time=NOW() WHERE
            login='1' AND sessionid='".session_id()."' AND user.id=useronline.user_id AND user.activ='1'");
            
         session_write_close(); // Blockade wegnehmen           
                
	return true; 
      }
    }

  }

  function Check($usertype,$module,$action, $userid='')
  {
    $ret = false;
    $permissions = $this->app->Conf->WFconf[permissions][$usertype][$module];
		if($usertype=="admin")
			return true;

		// Change Userrights with new 'userrights'-Table	
		if(!is_array($permissions)) $permissions = array();
		if(is_numeric($userid) && $userid>0) {
			$permission_db = $this->app->DB->Select("SELECT permission FROM userrights WHERE module='$module' AND action='$action' AND user='$userid' LIMIT 1");
			$actionkey = array_search($action, $permissions);
			if($actionkey===false) {
				if($permission_db=='1')
					$permissions[] = $action;
			}else {
				if($permission_db=='0'){
					unset($permissions[$actionkey]);
					$permissions = array_values($permissions);
				}				
			}
		}
		// --- END ---
 
    while (list($key, $val) = @each($permissions)) 
    {
      if($val==$action || $usertype=="admin")
      {
				$ret = true;
				break;
      }
    }
    
    if(!$ret)
    {
      $this->app->Tpl->Parse(PAGE,"permissiondenied.tpl");
    }
    return $ret;
  }

  function Login()
  {
    $username = $this->app->Secure->GetPOST("username");
    $password = $this->app->Secure->GetPOST("password");
    $token = $this->app->Secure->GetPOST("token");
  
    if($username=="" && ($password=="" || $token=="")){
      $this->app->Tpl->Set(LOGINMSG,"Bitte geben Sie Benutzername und Passwort ein.");  
      $this->app->Tpl->Parse(PAGE,"login.tpl");
    }
   /* elseif($username==""||$password==""){
      $this->app->Tpl->Set(LOGINERRORMSG,"Bitte geben Sie einen Benutzername und ein Passwort an.");  
      $this->app->Tpl->Parse(PAGE,"login.tpl");
    }*/
    else {
      // Benutzer hat Daten angegeben
      $encrypted = $this->app->DB->Select("SELECT password FROM user
        WHERE username='".$username."' AND activ='1' LIMIT 1");

      $fehllogins= $this->app->DB->Select("SELECT fehllogins FROM user
        WHERE username='".$username."' AND activ='1' LIMIT 1");

			//$fehllogins=0;

      $type= $this->app->DB->Select("SELECT type FROM user
        WHERE username='".$username."' AND activ='1' LIMIT 1");

      $externlogin= $this->app->DB->Select("SELECT externlogin FROM user
        WHERE username='".$username."' AND activ='1' LIMIT 1");

      $hwtoken = $this->app->DB->Select("SELECT hwtoken FROM user
        WHERE username='".$username."' AND activ='1' LIMIT 1");

      // try login and set user_login if login was successfull
			// wenn intern geht immer passwort???
			//$hwtoken=0;

			// MOTP

      $user_id="";

      $userip = $_SERVER['REMOTE_ADDR'];
      $ip_arr = split('\.',$userip);

      if($ip_arr[0]=="192" || $ip_arr[0]=="10")
        $localconnection = 1;
      else 
        $localconnection = 0;


      //HACK intern immer Passwort
      if($localconnection==1)
        $hwtoken=0;
 
      if($hwtoken==1) //motp
      {
        $pin = $this->app->DB->Select("SELECT motppin FROM user
              WHERE username='".$username."' AND activ='1' LIMIT 1");
        
        $secret = $this->app->DB->Select("SELECT motpsecret FROM user
              WHERE username='".$username."' AND activ='1' LIMIT 1");

        if($this->mOTP($pin,$token,$secret) && $fehllogins<6)
        {
          $user_id = $this->app->DB->Select("SELECT id FROM user
              WHERE username='".$username."' AND activ='1' LIMIT 1");
        } else { $user_id = ""; }

      } 
			//picosafe login
			else if ($hwtoken==2)
			{
				//include("/var/www/wawision/trunk/phpwf/plugins/class.picosafelogin.php");
				$myPicosafe = new PicosafeLogin();

				$aes = $this->app->DB->Select("SELECT hwkey FROM user WHERE username='".$username."' AND activ='1' LIMIT 1");
				$datablock = $this->app->DB->Select("SELECT hwdatablock FROM user WHERE username='".$username."' AND activ='1' LIMIT 1");
				$counter = $this->app->DB->Select("SELECT hwcounter FROM user WHERE username='".$username."' AND activ='1' LIMIT 1");

				$myPicosafe->SetUserAES($aes);
				$myPicosafe->SetUserDatablock($datablock);
				$myPicosafe->SetUserCounter($counter);		

        if ( $myPicosafe->LoginOTP($token) && crypt( $password,  $encrypted ) == $encrypted  && $fehllogins<6)
				{
  					$user_id = $this->app->DB->Select("SELECT id FROM user
              WHERE username='".$username."' AND activ='1' LIMIT 1");

						// Update counter
						$newcounter = $myPicosafe->GetLastValidCounter();
						$this->app->DB->Update("UPDATE user SET hwcounter='$newcounter' WHERE id='$user_id' LIMIT 1");

				} else {
						//echo $myPicosafe->error_message;
						$user_id = "";
				}

			}
			else {


        if (crypt( $password,  $encrypted ) == $encrypted  && $fehllogins<6)
        {
            $user_id = $this->app->DB->Select("SELECT id FROM user
              WHERE username='".$username."' AND activ='1' LIMIT 1");
        }
        else { $user_id = ""; }
      }
      $password = substr($password, 0, 8); //TODO !!! besseres verfahren!!
      
      //pruefen ob extern login erlaubt ist!!
      

      // wenn keine externerlogin erlaubt ist und verbindung extern
      if($externlogin==0 && $localconnection==0)
      {
	$this->app->Tpl->Set(LOGINERRORMSG,"Es gibt angehende technische Probleme. Bitte wenden Sie sich an Ihren Vorgesetzten.");  
	$this->app->Tpl->Parse(PAGE,"login.tpl");
      }
      else if(is_numeric($user_id))
      { 
        $this->app->DB->Insert("INSERT INTO useronline (user_id, sessionid, ip, login, time)
          VALUES ('".$user_id."','".session_id()."','".$_SERVER[REMOTE_ADDR]."','1',NOW())");

	$this->app->DB->Select("UPDATE user SET fehllogins=0
        WHERE username='".$username."' LIMIT 1");

	$this->app->erp->calledOnceAfterLogin($type);

	$startseite = $this->app->DB->Select("SELECT startseite FROM user WHERE id='$user_id' LIMIT 1");
	if($startseite!="")
          header("Location: ".$this->app->http."://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/".$startseite);
	else
          header("Location: ".$this->app->http."://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");

	exit;
      }
      else if ($fehllogins>=6)
      {

	$this->app->Tpl->Set(LOGINERRORMSG,"Es gibt technische Probleme. Bitte wenden Sie sich an Ihren Vorgesetzten.");  
	$this->app->Tpl->Parse(PAGE,"login.tpl");

      }
      else
      { 

       $this->app->DB->Select("UPDATE user SET fehllogins=fehllogins+1 WHERE username='".$username."' LIMIT 1");

	$this->app->Tpl->Set(LOGINERRORMSG,"Benutzername oder Passwort falsch.");  
	$this->app->Tpl->Parse(PAGE,"login.tpl");
      }
    }
  }

  function Logout($msg="")
  {
    $username = $this->app->User->GetName();
    $this->app->DB->Delete("UPDATE useronline SET login='0' WHERE user_id='".$this->app->User->GetID()."'");
    session_destroy();
    session_start();
    session_regenerate_id(true);
    $_SESSION['database']="";
    header("Location: ".$this->app->http."://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
    exit;
    $this->app->Tpl->Set(LOGINERRORMSG,$msg);  
    $this->app->Tpl->Parse(PAGE,"login.tpl");
  }


  function CreateAclDB()
  {

  }


	function mOTP($pin,$otp,$initsecret)
	{


		$maxperiod = 3*60; // in seconds = +/- 3 minutes
		//$time=gmdate("U");
    date_default_timezone_set('UTC');    
		$time=time();

		$time = $time + (3600*2);

		for($i = $time - $maxperiod; $i <= $time + $maxperiod; $i++)
		{
			$md5 = substr(md5(substr($i,0,-1).trim($initsecret).trim($pin)),0,6);
			if($otp == $md5) { 
				return(true);
			}
		}
		return(false);
	}

}
?>
