function Ansprechpartner(value)
{

     var strSource = "./index.php";
     var strData = "module=ajax&action=ansprechpartner&id="+value;
     var intType= 0; //GET
     var intID = 0;
     command = 'getAnsprechpartner';
     sendRequest(strSource,strData,intType,intID);

}

function Lieferadresse(value)
{

     var strSource = "./index.php";
     var strData = "module=ajax&action=lieferadresse&id="+value;
     var intType= 0; //GET
     var intID = 0;
     command = 'getLieferadresse';
     sendRequest(strSource,strData,intType,intID);

}





function CopyDialog(value)
{

  if(!confirm("Soll der Eintrag wirklich kopiert werden?")) return false;
    else window.location.href=value;

}


function PrintDialog(value)
{
  if(!confirm("Soll der Eintrag gedruckt werden?")) return false;
    else window.location.href=value;
}

function InsertDialog(value)
{

  if(!confirm("Soll der Eintrag wirklich eingefügt werden?")) return false;
    else window.location.href=value;

}

function DisableDialog(value)
{
  if(!confirm("Soll der Eintrag wirklich deaktiviert werden?")) return false;
    else window.location.href=value;

}


function DeleteDialog(value)
{

  if(!confirm("Soll der Eintrag wirklich gelöscht werden?")) return false;
    else window.location.href=value;

}

function BackupDialog(value)
{

	if(!confirm("Soll das Backup wirklich wieder eingespielt werden? Alle seit dem vorgenommenen Änderungen gehen verloren.")) return false;
    else window.location.href=value;

}

function ResetDialog()
{

  if(!confirm("Wollen Sie die Datenbank wirklich zurücksetzen?")) return false;
    else return true;

}

function getXMLRequester( )
{
    var xmlHttp = false; //Variable initialisieren
            
    try
    {
        // Der Internet Explorer stellt ein ActiveXObjekt zur Verfügung
        if( window.ActiveXObject )
        {
            // Versuche die neueste Version des Objektes zu laden
            for( var i = 5; i; i-- )
            {
                try
                {
                    //Wenn keine neuere geht, das alte Objekt verwenden
                    if( i == 2 )
                    {
                        xmlHttp = new ActiveXObject( "Microsoft.XMLHTTP" );    
                    }
                    // Sonst die neuestmögliche Version verwenden
                    else
                    {
                        
                        xmlHttp = new ActiveXObject( "Msxml2.XMLHTTP." + i + ".0" );
                    }
                    break; //Wenn eine Version geladen wurde, unterbreche Schleife
                }
                catch( excNotLoadable )
                {                        
                    xmlHttp = false;
                }
            }
        }
        // alle anderen Browser
        else if( window.XMLHttpRequest )
        {
            xmlHttp = new XMLHttpRequest();
        }
    }
    // loading of xmlhttp object failed
    catch( excNotLoadable )
    {
        xmlHttp = false;
    }
    return xmlHttp ;
}
// Konstanten
var REQUEST_GET        = 0;
var REQUEST_POST        = 2;
var REQUEST_HEAD    = 1;
var REQUEST_XML        = 3;

function sendRequest( strSource, strData, intType, intID )
{
    // Falls strData nicht gesetzt ist, als Standardwert einen leeren String setzen
    if( !strData )
        strData = '';

    // Falls der Request-Typ nicht gesetzt ist, standardmäßig auf GET setzen
    if( isNaN( intType ) )
        intType = 0;

    // wenn ein vorhergehender Request noch nicht beendet ist, beenden
    if( xmlHttp && xmlHttp.readyState )
    {
        xmlHttp.abort( );
        xmlHttp = false;
    }
        
    // wenn möglich, neues XMLHttpRequest-Objekt erzeugen, sonst abbrechen
    if( !xmlHttp )
    {
        xmlHttp = getXMLRequester( );
        if( !xmlHttp )
            return;
    }
    
    // Falls die zu sendenden Daten mit einem & oder einem ? beginnen, erstes Zeichen abschneiden
    if( intType != 1 && ( strData && strData.substr( 0, 1 ) == '&' || strData.substr( 0, 1 ) == '?' ))
        strData = strData.substring( 1, strData.length );

// Als Rückgabedaten die gesendeten Daten, oder die Zieladresse setzen
    var dataReturn = strData ? strData : strSource;
    
    switch( intType )
    {
        case 1:    //Falls Daten in XML-Form versendet werden, xml davorschreiben
            strData = "xml=" + strData;
        case 2: // falls Daten per POST versendet werden
            // Verbindung öffnen 
            xmlHttp.open( "POST", strSource, true );
            xmlHttp.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
            xmlHttp.setRequestHeader( 'Content-length', strData.length );
            break;
        case 3: // Falls keine Daten versendet werden
            // Verbindung zur Seite aufbauen
            xmlHttp.open( "HEAD", strSource, true );
            strData = null;
            break;
        default: // Falls Daten per GET versendet werden
            //Zieladresse zusammensetzen aus Adresse und Daten
            var strDataFile = strSource + (strData ? '?' + strData : '' );
            // Verbindung aufbauen
            xmlHttp.open( "GET", strDataFile, true );
            strData = null;
    }
    
    // die Funktion processResponse als Event-handler setzen, wenn sich der Verarbeitungszustand der 
    xmlHttp.onreadystatechange = new Function( "", "processResponse(" + intID + ")" ); ;

    // Anfrage an den Server setzen
    xmlHttp.send( strData );    //strData enthält nur dann Daten, wenn die Anfrage über POST passiert

    // gibt die gesendeten Daten oder die Zieladresse zurück
    return dataReturn;
}


function processResponse( intID )
{
    //aktuellen Status prüfen
    switch( xmlHttp.readyState )
    {
        //nicht initialisiert
        case 0:
        // initialisiert
        case 1:
        // abgeschickt
        case 2:
        // ladend
        case 3:
            break;
        // fertig
        case 4:    
            // Http-Status überprüfen
            if( xmlHttp.status == 200 )    // Erfolg
            {
                processData( xmlHttp, intID ); //Daten verarbeiten
            }
            //Fehlerbehandlung
            else
            {
                if( window.handleAJAXError )
                    handleAJAXError( xmlHttp, intID );
                else
                    alert( "ERROR\n HTTP status = " + xmlHttp.status + "\n" + xmlHttp.statusText ) ;
            }
    }
}

// handle response errors
function handleAJAXError( xmlHttp, intID )
{
  //alert("AJAX Fehler!");
}

var command;

var once;

function Select_Value_Set(SelectName, Value) {
  eval('SelectObject = parent.document.' + 
    SelectName + ';');
  for(index = 0; 
    index < SelectObject.length; 
    index++) {
   if(SelectObject[index].value == Value)
     SelectObject.selectedIndex = index;
   }
}

function processData( xmlHttp, intID )
{
  // process text data
  //updateMenu( xmlHttp.responseText );
  var render=0;
  switch(command)
  {
		case 'getAnsprechpartner':
			var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");

			parent.document.getElementById('ansprechpartner').value=trim(mySplitResult[0]);
			parent.document.getElementById('email').value=trim(mySplitResult[1]);
			parent.document.getElementById('telefon').value=trim(mySplitResult[2]);
			parent.document.getElementById('telefax').value=trim(mySplitResult[3]);
			parent.document.getElementById('abteilung').value=trim(mySplitResult[4]);
			parent.document.getElementById('unterabteilung').value=trim(mySplitResult[5]);


		break;
		case 'getLieferadresse':
			var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");

    //name  abteilung   unterabteilung  land  strasse   ort   plz adresszusatz

			parent.document.getElementById('liefername').value=trim(mySplitResult[0]);
			parent.document.getElementById('lieferabteilung').value=trim(mySplitResult[1]);
			parent.document.getElementById('lieferunterabteilung').value=trim(mySplitResult[2]);
			//parent.document.getElementById('lieferland').options[parent.document.getElementById('lieferland').selectedIndex].value=trim(mySplitResult[3]);
			Select_Value_Set('eprooform.lieferland',trim(mySplitResult[3]));
			parent.document.getElementById('lieferstrasse').value=trim(mySplitResult[4]);
			parent.document.getElementById('lieferort').value=trim(mySplitResult[5]);
			parent.document.getElementById('lieferplz').value=trim(mySplitResult[6]);
			parent.document.getElementById('lieferadresszusatz').value=trim(mySplitResult[7]);
			parent.document.getElementById('lieferansprechpartner').value=trim(mySplitResult[8]);
/*
			parent.document.getElementById('').value=trim(mySplitResult[1]);
			parent.document.getElementById('telefon').value=trim(mySplitResult[2]);
			parent.document.getElementById('telefax').value=trim(mySplitResult[3]);
			parent.document.getElementById('abteilung').value=trim(mySplitResult[4]);
			parent.document.getElementById('unterabteilung').value=trim(mySplitResult[5]);
*/

		break;

    case 'fillArtikel':
      var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");
      if(myString.length>3)
      {
	render=1;
      document.getElementById("artikel").value=trim(mySplitResult[0]);
      document.getElementById("nummer").value=mySplitResult[1];
      document.getElementById("projekt").value=mySplitResult[2];
      document.getElementById("preis").value=mySplitResult[3];
      document.getElementById("menge").value=mySplitResult[4];
			if(document.getElementById("preis").value==0 || document.getElementById("preis").value=="") {
				document.getElementById('preis').style.background ='#FE2E2E';
				if(once!=1)
				alert('Achtung: Es ist kein Verkaufspreis hinterlegt!');
				once = 1;
			}
      }
   break;
    case 'fillArtikelLieferschein':
      var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");
      if(myString.length>3)
      {
			render=1;
      document.getElementById("artikel").value=trim(mySplitResult[0]);
      document.getElementById("nummer").value=mySplitResult[1];
      document.getElementById("projekt").value=mySplitResult[2];
      document.getElementById("menge").value=mySplitResult[4];
      }
   break;
    case 'fillArtikelProduktion':
      var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");
      if(myString.length>3)
      {
			render=1;
      document.getElementById("artikel").value=trim(mySplitResult[0]);
      document.getElementById("nummer").value=mySplitResult[1];
      document.getElementById("projekt").value=mySplitResult[2];
      document.getElementById("menge").value=mySplitResult[4];
      }
   break;



   case 'fillArtikelBestellung':
  
      var myString = xmlHttp.responseText;
      var mySplitResult = myString.split(":");
      if(myString.length>3)
      {
	render=1;
      document.getElementById("artikel").value=trim(mySplitResult[0]);
      document.getElementById("nummer").value=mySplitResult[1];
      document.getElementById("projekt").value=mySplitResult[2];
      document.getElementById("preis").value=mySplitResult[3];
      document.getElementById("menge").value=mySplitResult[4];
      document.getElementById("bestellnummer").value=mySplitResult[5];
      document.getElementById("bezeichnunglieferant").value=mySplitResult[6];
    }
    break;

  }
  if(render<=0)
  {
    document.getElementById("menge").value="";
    document.getElementById("preis").value="";
    document.getElementById("nummer").value="";
    document.getElementById("projekt").value="";
  }
}

function trim (zeichenkette) {
  // Erst führende, dann Abschließende Whitespaces entfernen
  // und das Ergebnis dieser Operationen zurückliefern
  return zeichenkette.replace (/^\s+/, '').replace (/\s+$/, '');
}





// globales XMLHttpRequest-Objekt erzeugen
var xmlHttp = getXMLRequester();


