<?php
include ("_gen/widget.gen.adresse.php");

class WidgetAdresse extends WidgetGenAdresse 
{
  private $app;
  function WidgetAdresse($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenAdresse($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {

    $action = $this->app->Secure->GetGET("action");
      
    if($action=="create")
    {
      // liste zuweisen
      $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
      $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
      $this->form->NewField($field);
    }
      $field = new HTMLInput("land","hidden","");
      $this->form->NewField($field);

    $versandart = $this->app->erp->GetVersandartAuftrag();
    $field = new HTMLSelect("versandart",0);
    $field->AddOptionsSimpleArray($versandart);
    $this->form->NewField($field);

    $zahlungsweise = $this->app->erp->GetZahlungsweiseLieferant();
    $field = new HTMLSelect("zahlungsweise",0);
    //$field->onchange="aktion_buchen(this.form.zahlungsweise.options[this.form.zahlungsweise.selectedIndex].value);";
    $field->AddOptionsSimpleArray($zahlungsweise);
    $this->form->NewField($field);


    $field = new HTMLSelect("zahlungsweiselieferant",0);
    //$field->onchange="aktion_buchen(this.form.zahlungsweiselieferant.options[this.form.zahlungsweise.selectedIndex].value);";
    $field->AddOptionsSimpleArray($zahlungsweise);
    $this->form->NewField($field);


 
    $this->app->YUI->AutoComplete("projekt","projektname",1);
    $this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");
  }

  function ReplaceProjekt($db,$value)
  {
    return $this->app->erp->ReplaceProjekt($db,$value);
  }


}
?>
