<?php 

class WidgetGendrucker
{

  private $app;            //application object  
  public $form;            //store form object  
  private $parsetarget;    //target for content

  public function WidgetGendrucker($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    $this->Form();
  }

  public function druckerDelete()
  {
    
    $this->form->Execute("drucker","delete");

    $this->druckerList();
  }

  function Edit()
  {
    $this->form->Edit();
  }

  function Copy()
  {
    $this->form->Copy();
  }

  public function Create()
  {
    $this->form->Create();
  }

  public function Search()
  {
    $this->app->Tpl->Set($this->parsetarget,"SUUUCHEEE");
  }

  public function Summary()
  {
    $this->app->Tpl->Set($this->parsetarget,"grosse Tabelle");
  }

  function Form()
  {
    $this->form = $this->app->FormHandler->CreateNew("drucker");
    $this->form->UseTable("drucker");
    $this->form->UseTemplate("drucker.tpl",$this->parsetarget);

    $field = new HTMLInput("name","text","","40","","","","","","","0");
    $this->form->NewField($field);
    $this->form->AddMandatory("name","notempty","Pflichfeld!",MSGNAME);

    $field = new HTMLInput("bezeichnung","text","","40","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLSelect("anbindung",0);
    $field->AddOption('Drucker-Server','cups');
    $field->AddOption('Adapterbox','adapterbox');
    $this->form->NewField($field);

    $field = new HTMLInput("befehl","text","","40","","","","","","","0");
    $this->form->NewField($field);
    $this->form->AddMandatory("befehl","notempty","Pflichfeld!",MSGBEFEHL);

    $field = new HTMLCheckbox("aktiv","","","1","0");
    $this->form->NewField($field);


  }

}

?>