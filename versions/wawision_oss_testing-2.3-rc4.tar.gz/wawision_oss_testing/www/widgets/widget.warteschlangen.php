<?php
include ("_gen/widget.gen.warteschlangen.php");

class WidgetWarteschlangen extends WidgetGenWarteschlangen 
{
  private $app;
  function WidgetWarteschlangen($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenWarteschlangen($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
    //firma
    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);

    $this->app->YUI->AutoComplete("projekt","projektname",1);

    $this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");



    //$this->app->Tpl->Set(DATUM_BUCHUNG,
    //    "<img src=\"./themes/[THEME]/images/kalender.png\" onclick=\"displayCalendar(document.forms[0].datum,'dd.mm.yyyy',this)\">");

  }
  function ReplaceProjekt($db,$value)
  {
    return $this->app->erp->ReplaceProjekt($db,$value);
  }




  public function Table()
  {

    $table = new EasyTable($this->app);  
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Warteschlangen");
    $table->Query("SELECT warteschlange, label, id FROM warteschlangen ORDER by warteschlange DESC");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=warteschlangen&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=warteschlangen&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        ");

    /*$this->app->Tpl->Set(EXTEND,"<input type=\"button\" value=\"Warteschlangen exportieren\" onclick=\"window.location.href='index.php?module=warteschlangen&action=exportieren'\">");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Warteschlangen exportiert");
    $table->Query("SELECT a.name, betrag, auswahl as typ, grund FROM warteschlangen, adresse a WHERE warteschlangen.adresse = a.id AND warteschlangen.exportiert=1");
    $table->DisplayNew(INHALT, "Grund","noAction");
    */
    $this->app->Tpl->Set(EXTEND,"");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

  }



  public function Search()
  {
    //$this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }


}
?>
