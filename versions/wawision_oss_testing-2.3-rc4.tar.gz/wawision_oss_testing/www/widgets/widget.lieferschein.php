<?php
include ("_gen/widget.gen.lieferschein.php");

class WidgetLieferschein extends WidgetGenlieferschein 
{
  private $app;
  function WidgetLieferschein(&$app,$parsetarget)
  {
    $this->app = &$app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenlieferschein($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
    $this->app->YUI->AutoComplete("adresse","kunde");
    $this->app->YUI->AutoComplete("projekt","projektname",1);


    $this->app->YUI->DatePicker("datum");


    $this->form->ReplaceFunction("datum",&$this,"ReplaceDatum");
    $this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");
    $this->form->ReplaceFunction("adresse",&$this,"ReplaceKunde");
  

    $versandart = $this->app->erp->GetVersandartAuftrag();
    $field = new HTMLSelect("versandart",0);
    $field->onchange="versand(this.form.versandart.options[this.form.versandart.selectedIndex].value);";
    $field->AddOptionsSimpleArray($versandart);
    $this->form->NewField($field);

    $status = $this->app->erp->GetStatusLieferschein();

    $field = new HTMLInput("land","hidden","");
    $this->form->NewField($field);
  }


  function ReplaceProjekt($db,$value)
  {
    return $this->app->erp->ReplaceProjekt($db,$value);
  }

  function ReplaceKunde($db,$value)
  {
    return $this->app->erp->ReplaceKunde($db,$value);
  }

  function ReplaceDatum($db,$value)
  {
    return $this->app->erp->ReplaceDatum($db,$value);
  }

}
?>
