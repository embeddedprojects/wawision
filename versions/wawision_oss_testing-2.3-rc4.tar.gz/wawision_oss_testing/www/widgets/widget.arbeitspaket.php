<?php
include ("_gen/widget.gen.arbeitspaket.php");

class WidgetArbeitspaket extends WidgetGenArbeitspaket 
{
  private $app;
  function WidgetArbeitspaket($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenArbeitspaket($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {

/*
    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);
*/
    $this->app->YUI->DatePicker("abgabedatum");
    $this->app->YUI->AutoComplete("adresse","mitarbeiter");

    $this->form->ReplaceFunction("adresse",&$this,"ReplaceMitarbeiter");
    $this->form->ReplaceFunction("abgabedatum",&$this,"ReplaceDatum");



 		$action = $this->app->Secure->GetGET("action");
    if($action=="arbeitspaket")
    {
      // liste zuweisen
      $pid = $this->app->Secure->GetGET("id");
      $this->app->Secure->POST["projekt"]=$pid;
      $field = new HTMLInput("projekt","hidden",$pid);
      $this->form->NewField($field);
    }



  }



  function ReplaceDatum($db,$value)
  {
    return $this->app->erp->ReplaceDatum($db,$value);
  }


  function ReplaceMitarbeiter($db,$value)
  {
    return $this->app->erp->ReplaceMitarbeiter($db,$value);
  }


  public function Table()
  {
    $table = new EasyTable($this->app);
    $table->Query("SELECT nummer, name_de as name,barcode, id FROM einkaufspreise order by nummer");
    $table->Display($this->parsetarget);
  }



  public function Search()
  {
    $this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }



}
?>
