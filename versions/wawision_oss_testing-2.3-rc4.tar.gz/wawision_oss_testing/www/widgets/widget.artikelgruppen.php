<?php
include ("_gen/widget.gen.artikelgruppen.php");

class WidgetArtikelgruppen extends WidgetGenArtikelgruppen
{
  private $app;
  function WidgetArtikelgruppen($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenArtikelgruppen($app,$parsetarget);
    $this->ExtendsForm();
  }

  function ExtendsForm()
  {
    //firma
//    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
//    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
//    $this->form->NewField($field);
    $this->app->YUI->AutoComplete("shop","shopname");
    $this->form->ReplaceFunction("shop",&$this,"ReplaceShopname");



    //$this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");
    //$this->form->ReplaceFunction("projekt",&$this,"ReplaceProjekt");


    //$this->app->Tpl->Set(DATUM_BUCHUNG,
    //    "<img src=\"./themes/[THEME]/images/kalender.png\" onclick=\"displayCalendar(document.forms[0].datum,'dd.mm.yyyy',this)\">");

  }
  function ReplaceProjekt($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(is_numeric($value)) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  function ReplaceDecimal($db,$value)
  {
    //value muss hier vom format ueberprueft werden

    return str_replace(",",".",$value);
  }

  function ReplaceDatum($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(strpos($value,'-') > 0) $dbformat = 1;

    // wenn ziel datenbank
    if($db)
    { 
      if($dbformat) return $value;
      else return $this->app->String->Convert($value,"%1.%2.%3","%3-%2-%1");
    }
    // wenn ziel formular
    else
    { 
      if($dbformat) return $this->app->String->Convert($value,"%1-%2-%3","%3.%2.%1");
      else return $value;
    }
  }

  function ReplaceAdresse($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(is_numeric($value)) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM adresse WHERE name='$value' AND geloescht=0 LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  public function Table()
  {

    $table = new EasyTable($this->app);  
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Artikelgruppen");
    $table->Query("SELECT g.bezeichnung as artikelgruppe, g.id as gruppe, s.bezeichnung, if(g.aktiv,'online','') as aktiv, g.id FROM artikelgruppen g, shopexport s WHERE s.firma='".$this->app->User->GetFirma()."'
    AND s.id=g.shop");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=artikelgruppen&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
        <a onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=artikelgruppen&action=delete&id=%value%';\">
          <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
        ");

    /*$this->app->Tpl->Set(EXTEND,"<input type=\"button\" value=\"Artikelgruppen exportieren\" onclick=\"window.location.href='index.php?module=artikelgruppen&action=exportieren'\">");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBSUBHEADING,"Artikelgruppen exportiert");
    $table->Query("SELECT a.name, betrag, auswahl as typ, grund FROM artikelgruppen, adresse a WHERE geschaeftsbrief_vorlagen.adresse = a.id AND geschaeftsbrief_vorlagen.exportiert=1");
    $table->DisplayNew(INHALT, "Grund","noAction");
    */
    $this->app->Tpl->Set(EXTEND,"");
    $this->app->Tpl->Parse($this->parsetarget,"rahmen70.tpl");

  }
  function ReplaceShopname($db,$value)
  {
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(is_numeric($value)) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT bezeichnung FROM shopexport WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM shopexport WHERE bezeichnung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    {
      return $id;
    }
    // wenn ziel formular
    else
    {
      return $abkuerzung;
    }
  }



  public function Search()
  {
    //$this->app->Tpl->Set($this->parsetarget,"suchmaske");
    //$this->app->Table(
    //$table = new OrderTable("veranstalter");
    //$table->Heading(array('Name','Homepage','Telefon'));
  }


}
?>
