<?php

class Verkaufszahlen {
  var $app;
  
  function Verkaufszahlen($app) {
    $this->app=&$app;

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("list","VerkaufszahlenList");
    $this->app->ActionHandler("details","VerkaufszahlenDetailsPopup");


    $this->app->Tpl->Set(UEBERSCHRIFT,"Verkaufszahlen");
    $this->app->ActionHandlerListen(&$app);

    $this->app = $app;
  }

  function VerkaufszahlenDetailsPopup()
  {
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(650,530);
    } else {
      // nach page inhalt des dialogs ausgeben

    $tmp = split('-',$id);

    $projekt=$tmp[3];
    $abkuerzung=$this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$projekt' LIMIT 1");
    $datum=$tmp[0].'-'.$tmp[1].'-'.$tmp[2];

    $this->app->Tpl->Set(SUBHEADING,"Umsatz pro Tag Projekt $abkuerzung");
    $table = new EasyTable($this->app);
    $table->Query("SELECT 
      DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, a.name as kunde, SUM(ap.preis*ap.menge) as Umsatz
      FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id LEFT JOIN projekt p ON p.id=a.projekt
      WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')='$datum' AND a.projekt='$projekt'
      GROUP by a.id");

      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') GROUP by a.projekt",10);
    $table->DisplayNew(INHALT,"Umsatz","noAction");


    $summe = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id 
      LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')='$datum' AND a.projekt='$projekt'");

    $this->app->Tpl->Set(EXTEND,"Summe: $summe EUR");

    $this->app->Tpl->Parse(PAGE,"rahmen100.tpl");
 
      $this->app->BuildNavigation=false;
    }
  }



  function VerkaufszahlenList()
  {
    $this->VerkaufszahlenMenu();

    $this->app->Tpl->Set(TABTEXT,"Verkaufszahlen");

    

   // projekte
   //$projekte = array(1,2,4);
   $projekte_arr = $this->app->DB->SelectArr("SELECT projekt FROM shopexport GROUP by projekt ORDER by 1");
   for($i=0;$i<count($projekte_arr);$i++)
      $projekte[] = $projekte_arr[$i]['projekt'];
    


   $spalte = 0;
   for ($zaehler = -12; $zaehler <= 0; $zaehler++) {
      $daten .=  "[$spalte,'".date("D", strtotime("+" . $zaehler . " day"))."<br>".date("d.m", strtotime("+" . $zaehler . " day"))."']";
      
      $tagdatum =  date("Y-m-d", strtotime("+" . $zaehler . " day"));
      

      foreach($projekte as $value)
      {
	//$betrag = rand(10,100);
      $betrag = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge)
      FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id 
      LEFT JOIN projekt p ON p.id=a.projekt WHERE a.status!='storniert' AND a.belegnr>0  AND p.id='$value' AND a.datum='$tagdatum'");

	if($betrag!="")$betrag = "'".$betrag."'";
	else $betrag="null";

	$projekte_daten[$value] .= "[$spalte,$betrag]";
      }
      if($zaehler<0)
      {
	$daten .= ",";
	foreach($projekte as $value)
	  $projekte_daten[$value] .= ",";
      }
      $spalte++;
    } 

    $this->app->Tpl->Set(DATUM,"[$daten]");

	$nummer = 1;	
	foreach($projekte as $value)
	{
	  $var .= "var d$nummer = [".$projekte_daten[$value]."];";
	  $nummer++;
	}
    $this->app->Tpl->Set(VARIABLEN,$var);


    $this->app->Tpl->Set(SUBHEADING,"Artikel Heute");
    $table = new EasyTable($this->app);
    $table->Query("SELECT SUM(ap.menge) as Stk, SUBSTR(a.name_de,1,40) as artikel, a.nummer, p.abkuerzung as projekt FROM auftrag_position ap ,  artikel a, projekt p, auftrag auf WHERE a.id=ap.artikel AND ap.explodiert_parent='0' AND  p.id=ap.projekt AND ap.auftrag=auf.id AND auf.datum=DATE_FORMAT(NOW(),'%Y-%m-%d') AND a.porto=0 AND auf.status!='storniert' AND auf.belegnr>0  GROUP by a.id ORDER by projekt, menge DESC");
      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') GROUP by a.projekt",10);
    $table->DisplayNew(ARTIKEL,"Projekt","noAction");
    
    
    $this->app->Tpl->Set(SUBHEADING,"Artikel Gestern");
    $table = new EasyTable($this->app);
    $table->Query("SELECT SUM(ap.menge) as Stk, SUBSTR(a.name_de,1,40) as artikel, a.nummer, p.abkuerzung as projekt FROM auftrag_position ap ,  artikel a, projekt p, auftrag auf WHERE a.id=ap.artikel AND ap.explodiert_parent='0' AND  p.id=ap.projekt AND ap.auftrag=auf.id AND auf.datum=DATE_FORMAT(SUBDATE( CURRENT_DATE, INTERVAL 1 DAY),'%Y-%m-%d') AND a.porto=0 AND auf.status!='storniert' AND auf.belegnr>0 GROUP by a.id ORDER by projekt, menge DESC");
      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') GROUP by a.projekt",10);
    $table->DisplayNew(ARTIKELGESTERN,"Projekt","noAction");



    $table = new EasyTable($this->app);
    $table->Query("SELECT 
      DATE_FORMAT(a.datum,'%d.%m.%Y') as datum, FORMAT(SUM(ap.preis*ap.menge),2) as Umsatz
      FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id WHERE a.status!='storniert' AND a.belegnr>0  GROUP by a.datum DESC LIMIT 14");
    $table->DisplayNew(TAGESUEBERSICHT,"Umsatz","noAction");

    /* extend */
 
    $summe = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id WHERE (a.status!='storniert' and a.status!='angelegt')");
    $summe_gs = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM gutschrift_position ap LEFT JOIN gutschrift a ON ap.gutschrift=a.id WHERE (a.status!='storniert' and a.status!='angelegt')"); 

      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");
    $summe30 = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id 
      WHERE a.datum > date_add(NOW(), interval -30 day) AND (a.status!='storniert' and a.status!='angelegt')");
    $summe30_gs = $this->app->DB->Select("SELECT SUM(ap.preis*ap.menge) FROM gutschrift_position ap LEFT JOIN gutschrift a ON ap.gutschrift=a.id 
      WHERE a.datum > date_add(NOW(), interval -30 day) AND (a.status!='storniert' and a.status!='angelegt')");
      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");


    $summemenge = count($this->app->DB->SelectArr("SELECT 
      COUNT(a.datum) FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id WHERE (a.status!='storniert' and a.status!='angelegt')
      GROUP by a.datum, a.projekt "));

    if($summemenge < 30)
    {
      $summe_gutschriften = $summe_gs;
      $summe_auftrag = $summe;
      $durchschnitt = ($summe-$summe_gs) / $summemenge; 
      $summe= number_format(($summe-$summe_gs),2);
      $tage = $summemenge;
    } else {
      $summe_gutschriften = $summe30_gs;
      $summe_auftrag = $summe30;
      $durchschnitt = ($summe30-$summe30_gs) / 30;  // wenn mehr als 30 tage
      $summe= number_format(($summe30-$summe30_gs),2);
      $tage = 30;
    }

    $summe_gutschriften = number_format($summe_gutschriften,2);
    $summe_auftrag = number_format($summe_auftrag,2);

    $durchschnitt = number_format($durchschnitt,2);
    $this->app->Tpl->Set(EXTEND,"Summe: $summe_auftrag &euro; (abzgl. Gutschriften $summe_gutschriften &euro; = pro Tag $durchschnitt seit $tage Tagen)");


    /* tages uebersicht detail */
 
    $table = new EasyTable($this->app);
    $table->Query("SELECT 
      DATE_FORMAT(a.datum,'%d.%m.%Y') as datum,p.abkuerzung as projekt, SUM(ap.preis*ap.menge) as Umsatz, COUNT(ap.id) as positionen, 
      CONCAT('<a href=\"index.php?module=verkaufszahlen&action=details&frame=false&id=',DATE_FORMAT(a.datum,'%Y-%m-%d'),'-',a.projekt,'\" onclick=\"makeRequest(this); return false;\">Details</a>') as id FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id 
      LEFT JOIN projekt p ON p.id=a.projekt WHERE a.status!='storniert' GROUP by a.datum DESC, a.projekt LIMIT 14");
    $table->DisplayNew(TAGESUEBERSICHTDETAIL,"");



    /* tages uebersicht detail */                                                                                                                             
                                                                                                                                                                  
$table = new EasyTable($this->app);                                                                                                                       
$table->Query("SELECT                                                                                                                                     
DATE_FORMAT(a.datum,'%d.%m.%Y') as datum,p.abkuerzung as projekt, SUM(ap.preis*ap.menge) as Umsatz, COUNT(ap.id) as positionen,                         
CONCAT('<a href=\"index.php?module=verkaufszahlen&action=details&frame=false&id=',DATE_FORMAT(a.datum,'%Y-%m-%d'),'-',a.projekt,'\" onclick=\"makeReques
LEFT JOIN projekt p ON p.id=a.projekt WHERE a.status!='storniert' GROUP by a.datum DESC, a.projekt LIMIT 14");                                          
$table->DisplayNew(TAGESUEBERSICHTDETAILGESTERN,"");                                                                                                             
                                                                                                                                                                                                                                                       
 
    $table = new EasyTable($this->app);
    $table->Query("SELECT SUM(ap.menge) menge,ap.bezeichnung FROM auftrag_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE a.lagerartikel=1 GROUP BY ap.artikel ORDER by 1 DESC LIMIT 14");
    $table->DisplayNew(TOPARTIKEL,"Umsatz","noAction");




  /* umsatz gesamt */
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, SUM(a.soll) FROM rechnung a WHERE a.status='versendet' 
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(JAHR,"Jahr","noAction");

    $projektesummen = $this->app->DB->SelectArr("SELECT SUM(a.soll) as summe,p.abkuerzung as projekt FROM rechnung a LEFT JOIN projekt p ON p.id=a.projekt
      WHERE a.status='versendet' AND EXTRACT(YEAR FROM a.datum)=EXTRACT(YEAR FROM NOW()) 
      GROUP By a.projekt");

    $nochmal = false;
    foreach($projektesummen as $key=>$value)
    {
      if($nochmal) $projektesummenwerte .=',';
      if($value['projekt'] =="")$value['projekt']="ohne Projekt";
      $projektesummenwerte .='{ label: "'.$value['projekt'].'",  data: [[1,'.$value['summe'].']]}';
      $nochmal = true;
    }
    $this->app->Tpl->Set(UMSATZPIE,$projektesummenwerte);
   /* jahres uebersicht projekte */ 
   $table = new EasyTable($this->app);   
   $table->Query("       
       SELECT SUM(a.soll)/1.19 as summe,p.abkuerzung as projekt,COUNT(a.id) as rechnungen FROM rechnung a LEFT JOIN projekt p ON p.id=a.projekt  
       	WHERE a.status!='angelegt' AND a.status!='storniert' AND EXTRACT(YEAR FROM a.datum)=EXTRACT(YEAR FROM NOW())  AND p.abkuerzung!=''
GROUP By projekt ORDER by summe");                                                                                                                                              
     $table->DisplayNew(JAHRESUEBERSICHTPROJEKTE,"Anzahl Rechnungen","noAction");                                                                                                                                                   
            

  /* gutschriften  */
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, FORMAT(SUM(a.soll),2) FROM gutschrift a WHERE (a.status!='storniert'  AND
a.status!='angelegt')
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(GUTSCHRIFTJAHR,"Jahr","noAction");

  /* angebot  */
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, FORMAT(SUM(ap.preis*ap.menge),2) FROM angebot a 
      LEFT JOIN angebot_position ap ON a.id=ap.angebot WHERE (a.status!='storniert'  AND
a.status!='angelegt')
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(ANGEBOTJAHR,"Jahr","noAction");




    /* Woher kennen Sie uns */



  /* woher kennen sie uns monatlich  */
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as monat, EXTRACT(YEAR FROM a.datum) as jahr, COUNT(a.id) as anzahl, a.kennen FROM auftrag a 
     WHERE (a.status!='storniert' AND a.status!='angelegt') AND (a.kennen!='sonstiges' AND a.kennen!='sontiges' AND a.kennen!='') GROUP By monat,jahr,kennen ORDER by jahr DESC, monat DESC, kennen");
     $table->DisplayNew(WOHERKENNENSIEUNS,"Quelle","noAction");


  /* woher kennen sie uns gesamt  */
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT COUNT(a.id) as anzahl, a.kennen FROM auftrag a WHERE (a.status!='storniert' AND a.status!='angelegt' AND a.kennen!='sontiges' AND a.kennen!='sonstiges') AND a.kennen!='' GROUP By a.kennen ORDER by anzahl DESC");
     $table->DisplayNew(WOHERKENNENSIEUNSGESAMT,"Quelle","noAction");





    $this->app->Tpl->Parse(JAVASCRIPT,"verkaufszahlengraph.tpl");
    //$this->app->Tpl->Add(JQUERY,"plotgraph();");
    $this->app->Tpl->Parse(TAB1,"verkaufszahlen.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");


    return;
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");
 
    $this->app->Tpl->Set(SUBHEADING,"Umsatz pro Tag (pro Projekt)");
    $table = new EasyTable($this->app);
    $table->Query("SELECT 
      DATE_FORMAT(a.datum,'%d.%m.%Y') as datum,p.abkuerzung as projekt, SUM(ap.preis*ap.menge) as Umsatz, COUNT(ap.id) as positionen, 
      CONCAT('<a href=\"index.php?module=verkaufszahlen&action=details&frame=false&id=',DATE_FORMAT(a.datum,'%Y-%m-%d'),'-',a.projekt,'\" onclick=\"makeRequest(this); return false;\">Details</a>') as id FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id 
      LEFT JOIN projekt p ON p.id=a.projekt WHERE a.status!='storniert' GROUP by a.datum DESC, a.projekt ");
      //LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') GROUP by a.projekt",10);
    $table->DisplayNew(INHALT,"");
    

 
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(EXTEND,"");


    /* meits verkaufte artikel */

    $this->app->Tpl->Set(SUBHEADING,"TOP 50 Meist verkaufte Lager-Artikel");
    $table = new EasyTable($this->app);
    $table->Query("SELECT SUM(ap.menge) menge,ap.bezeichnung FROM auftrag_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE a.lagerartikel=1 GROUP BY ap.artikel ORDER by 1 DESC LIMIT 50");
    $table->DisplayNew(INHALT,"","");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");


    /* meist verkaufte nicht lager artikel */
    $this->app->Tpl->Set(SUBHEADING,"TOP 10 Meist verkaufte Artikel ohne Lager");
    $table = new EasyTable($this->app);
    $table->Query("SELECT SUM(ap.menge) menge,ap.bezeichnung FROM auftrag_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE a.lagerartikel=0 GROUP BY ap.artikel ORDER by 1 DESC LIMIT 10");
    $table->DisplayNew(INHALT,"","");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");


    /* umsatz projekt eproo */
    $this->app->Tpl->Set(SUBHEADING,"UMSATZ EPROO-SHOP");
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, SUM(a.gesamtsumme) FROM auftrag a WHERE a.status='abgeschlossen' AND a.projekt=1
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(INHALT,"Jahr","noAction");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");

    $this->app->Tpl->Set(INHALT,"");


  /* umsatz projekt uni */
    $this->app->Tpl->Set(SUBHEADING,"UMSATZ UNI-SHOP");
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, SUM(a.gesamtsumme) FROM auftrag a WHERE a.status='abgeschlossen' AND a.projekt=2
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(INHALT,"Jahr","noAction");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");

    $this->app->Tpl->Set(INHALT,"");

  /* umsatz projekt uni */
    $this->app->Tpl->Set(SUBHEADING,"UMSATZ EPJOURNAL");
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, SUM(a.gesamtsumme) FROM auftrag a WHERE a.status='abgeschlossen' AND a.projekt=4
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(INHALT,"Jahr","noAction");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");

    $this->app->Tpl->Set(INHALT,"");



  /* umsatz gesamt */
    $this->app->Tpl->Set(SUBHEADING,"UMSATZ GESAMT");
     $table = new EasyTable($this->app);
    $table->Query("
    SELECT EXTRACT(MONTH FROM a.datum) as month, EXTRACT(YEAR FROM a.datum) as year, SUM(a.gesamtsumme) FROM auftrag a WHERE a.status='abgeschlossen' 
GROUP By month,year ORDER by year DESC, month DESC");
     $table->DisplayNew(INHALT,"Jahr","noAction");

    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");

    $this->app->Tpl->Set(INHALT,"");

//    $this->app->YUI->ChartDB("SELECT SUM(a.gesamtsumme) as wert , DATE_FORMAT(a.datum,'%d.%m') as legende 
//    FROM auftrag a WHERE a.status='abgeschlossen' GROUP By legend",TAB1,800,200);





    /* effektiv gewinn partnernetz */

    $this->app->Tpl->Set(SUBHEADING,"Effektiv Gewinn Partnernetz");
    $table = new EasyTable($this->app);
    $table->Query("SELECT pa.bezeichnung, SUM(ap.preis*ap.menge) as umsatz FROM auftrag_position ap LEFT JOIN auftrag a ON ap.auftrag=a.id  LEFT JOIN partner pa ON pa.ref=a.partnerid LEFT JOIN adresse adr ON adr.id=pa.adresse
      LEFT JOIN projekt p ON p.id=a.projekt WHERE DATE_FORMAT(a.datum,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m') AND a.partnerid!='' AND a.partnerid!=0 GROUP by a.partnerid ");

    $table->DisplayNew(INHALT,"Umsatz","noAction");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");


     
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");


  }
  
  function VerkaufszahlenMenu()
  {
    $id = $this->app->Secure->GetGET("id");

    
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Verkaufszahlen");
    $this->app->erp->MenuEintrag("index.php?module=shopimport&action=list","Shopimport");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=verkaufszahlen&action=list\">&Uuml;bersicht</a></li>");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=verkaufszahlen&action=partner&id=$id\">Partner</a></li>");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
  }




}

?>
