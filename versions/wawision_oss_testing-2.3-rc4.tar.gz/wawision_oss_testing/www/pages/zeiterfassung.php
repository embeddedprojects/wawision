<?php

//include ("_gen/zeiterfassung.php");

class Zeiterfassung { //extends GenZeiterfassung {
  var $app;
  
  function Zeiterfassung($app) {    
//parent::GenZeiterfassung($app);
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","ZeiterfassungCreate");
    $this->app->ActionHandler("edit","ZeiterfassungEdit");
    $this->app->ActionHandler("list","ZeiterfassungList");
    $this->app->ActionHandler("delete","ZeiterfassungDelete");
    $this->app->ActionHandler("arbeitspaket","ArbeitspaketDetails");
    $this->app->ActionHandler("details","ZeiterfassungDetails");
    
    $this->app->Tpl->Parse(UEBERSCHRIFT,"Zeiterfassung");

    $this->app->ActionHandlerListen(&$app);

    $this->app = $app;
  }
 
 
  function ZeiterfassungCreate()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Zeiterfassung");

//    $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=list","&Uuml;bersicht");
//    $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=create","Neue Zeiterfassung");

    $this->app->erp->StartseiteMenu();


    $id =  $this->app->User->GetId();      
    if(is_numeric($id))
      $adr_id = $this->app->DB->Select("SELECT adresse FROM user WHERE id=$id");
 
    $this->ZeiterfassungManuell($adr_id);
    //$this->app->Tpl->Parse(PAGE,"zeiterfassung_create.tpl");
  }

  function ZeiterfassungList()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Zeiterfassung");

  $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=list","&Uuml;bersicht");
    $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=create","Neue Zeiterfassung");




    //$this->app->Tpl->Add(TABS,"<a class=\"tab\" href=\"index.php?module=adresse&action=search\">Zeiterfassung suchen</a>");
    // Adress-ID mit USER-ID abfragen
    $id =  $this->app->User->GetId();      
    if($id!="")
      $adr_id = $this->app->DB->Select("SELECT adresse FROM user WHERE id=$id");
      
    //$this->AufgabenOffen($adr_id);
    //$this->ZeiterfassungOffen($adr_id);
    //$this->app->erp->Wochenplan($adr_id,WOCHENPLAN);
    $this->ZeiterfassungAbgeschlossen($adr_id);
    $this->ZeiterfassungArchiv($adr_id);
   
    //$this->app->Tpl->Set(AKTIV_TAB1,"selected"); 
    $this->app->Tpl->Parse(PAGE,"zeiterfassung.tpl");
  }
 

  function ZeiterfassungMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Zeiterfassung");

 
//    $this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=zeiterfassung&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
  }


  function ZeiterfassungEdit()
  {
    $this->ZeiterfassungMenu();
    $this->app->Tpl->Set(TABLE_ADRESSE_KONTAKTHISTORIE,"TDB");
    $this->app->Tpl->Set(TABLE_ADRESSE_ROLLEN,"TDB");
    
    $this->app->Tpl->Set(TABLE_ADRESSE_USTID,"TDB");

    //parent::ZeiterfassungEdit();
  }

  function ArbeitspaketReadDetails($index,&$ref)
  {
    $pakete = $ref->app->DB->SelectArr("SELECT * FROM arbeitspakete WHERE id='$index'");
    $myArr = $pakete[0];

    $ref->app->Tpl->Set(AUFGABE, $myArr["aufgabe"]);
    $ref->app->Tpl->Set(PROJEKT, $myArr["projekt"]);
    $this->app->Tpl->Set(BESCHREIBUNG, $myArr["beschreibung"]);
    $this->app->Tpl->Set(ZEITGEPLANT, $myArr["zeit_geplant"]);
    $this->app->Tpl->Set(KOSTENSTELLE, $myArr["kostenstelle"]);
    $this->app->Tpl->Set(STATUS, $myArr["status"]);
  }

  function ArbeitspaketDetails()
  {
    $this->app->Tpl->Set(HEADING,"Details zum Arbeitspaket");

    $this->app->Tpl->Set(SUBSUBHEADING, "Details");
    $this->app->Tpl->Set(DATUM, date("d.m.Y", time()));
    
    $this->app->Tpl->Add(TABS,
      "<li><h2>Zeiterfassung</h2></li>");

    $this->app->Tpl->Add(TABS,
      "<li><a href=\"index.php?module=zeiterfassung&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    // Adress-ID mit USER-ID abfragen
    $id =  $this->app->User->GetId();
    if($id!="")
      $adr_id = $this->app->DB->Select("SELECT adresse FROM user WHERE id=$id");
    
    $ap_id = $this->app->Secure->GetGET("lid");

    $pakete = $this->app->DB->SelectArr('SELECT * FROM arbeitspaket WHERE id='.$ap_id.' AND adresse='.$adr_id);
    $myArr = $pakete[0];    

    $this->app->Tpl->Set(AUFGABE, $myArr["aufgabe"]);
    $this->app->Tpl->Set(PROJEKT, $myArr["projekt"]);
    $this->app->Tpl->Set(BESCHREIBUNG, $myArr["beschreibung"]);
    $this->app->Tpl->Set(ZEITGEPLANT, $myArr["zeit_geplant"]);
    $this->app->Tpl->Set(KOSTENSTELLE, $myArr["kostenstelle"]);
    $this->app->Tpl->Set(STATUS, $myArr["status"]);
    
    if($myArr["abgabe"] == "abgegeben")
      $this->app->Tpl->Set(ABGABE, 'fertig' ); 
    else
      $this->app->Tpl->Set(ABGABE, '<input type="checkbox" name="abgabefeld" value="nicht abgegeben">' );
   
    if($this->app->Secure->GetPOST("abgabefeld") == "nicht abgegeben"){
      $this->app->DB->Update('UPDATE arbeitspakete SET abgabe="abgegeben", abgabedatum="'.date("Y-m-d").'" WHERE id='.$myArr["id"]);
      $myArr["abgabe"] = "abgegeben";
    }
    $this->app->Tpl->Parse(INHALT, "arbeitspaket_details.tpl");
    $this->app->Tpl->Parse(PAGE,"rahmen_submit_extend.tpl");
  }


  function ZeiterfassungManuell($adr_id)
  {
    $this->app->Tpl->Set(HEADING,"Zeiterfassung (&Uuml;bersicht)");
    
    $this->app->Tpl->Set(SUBSUBHEADING, "Zeit erfassen");
    $this->app->Tpl->Set(DATUM, date("d.m.Y", time()));
    
    $aufgabe = $this->app->Secure->GetPOST("aufgabe");
    $datum = $this->app->Secure->GetPOST("datum");
    $art= $this->app->Secure->GetPOST("art");
    $vonZeit = $this->app->String->Convert($datum,"%1.%2.%3","%3-%2-%1")." ".$this->app->Secure->GetPOST("vonZeit").":00";
    $bisZeit = $this->app->String->Convert($datum,"%1.%2.%3","%3-%2-%1")." ".$this->app->Secure->GetPOST("bisZeit").":00";
    $beschreibung = $this->app->Secure->GetPOST("beschreibung");
    $projekt = $this->app->Secure->GetPOST("projekt_manuell");
    $paketauswahl = $this->app->Secure->GetPOST("arbeitspakete");
    $pakete = $this->app->DB->SelectArr('SELECT id, aufgabe FROM arbeitspaket WHERE adresse = '.$adr_id.'');

    if($this->app->Secure->GetPOST("vonZeit")=="")
    {

      $vonZeit =  $this->app->DB->Select("SELECT DATE_FORMAT(MAX(bis),'%H:%i') FROM zeiterfassung WHERE adresse='$adr_id' AND DATE_FORMAT(bis,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d')");
      $this->app->Tpl->Set(VONZEIT,$vonZeit?$vonZeit:"09:00");
    }
    if($paketauswahl!="0")
      $projekt = $this->app->DB->Select("SELECT projekt FROM arbeitspaket WHERE id='$paketauswahl' LIMIT 1");


    $row = $this->app->DB->SelectArr("SELECT DISTINCT t1.id, t1.name FROM projekt AS t1 ORDER by t1.id");
    for($i=0; $i<sizeof($row); $i++){
      $myArr = $row[$i];
      $select = $select.'<option value="'.$myArr["id"].'">'.$myArr[id].': '.$myArr["name"].'</option>';  
    }
    $this->app->Tpl->Set(PROJEKTAUSWAHL, $select);
    
    $this->app->Tpl->Set(ART, $this->app->erp->GetSelect($this->app->erp->GetZeiterfassungArt(),$art));
     
      /*$row = $this->app->DB->Select("SELECT ");
      if($projekt==""){
	 $projekt = 0;
      }*/
    $select = '<option value="0">manuelle Eingabe (direkt auf Projekt buchen)</option>';
    for($i =0; $i<sizeof($pakete); $i++){
      $myArr = $pakete[$i];
      $select = $select.'<option value="'.$myArr["id"].'">Arbeitspaket: '.$myArr["aufgabe"].'</option>';  
    }
    $this->app->Tpl->Set(PAKETAUSWAHL, $select);
    
    if($this->app->Secure->GetPOST("ok")){
      if($paketauswahl == 0){
	if(($aufgabe!="") && ($this->app->Secure->GetPOST("vonZeit")!="") && ($this->app->Secure->GetPOST("bisZeit")!="") && ($datum!="")){	
	  $this->app->erp->AddArbeitszeit($adr_id, $vonZeit, $bisZeit, $aufgabe, $beschreibung, $projekt, 0,$art);
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"success\">T&auml;tigkeit erfolgreich gebucht</div>");
	}else{
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Fehler! Die Felder T&auml;tigkeit, Von, Bis, Am, m&uuml;ssen ausgef&uuml;llt sein</div>");
	}
      }else{
	if(($this->app->Secure->GetPOST("vonZeit")!="") && ($this->app->Secure->GetPOST("bisZeit")!="") && ($datum!="")){
	  $this->app->erp->AddArbeitszeit($adr_id, $vonZeit, $bisZeit, $aufgabe, $beschreibung, $projekt, $paketauswahl,$art); 
	  $this->app->Tpl->Set(MESSAGE,"<div class=\"success\">T&auml;tigkeit erfolgreich gebucht</div>");
	}else{
	    $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Fehler! Die Felder Von, Bis, Am, m&uuml;ssen ausgef&uuml;llt sein</div>");
	}
      }
      $vonZeit =  $this->app->DB->Select("SELECT DATE_FORMAT(MAX(bis),'%H:%i') FROM zeiterfassung WHERE adresse='$adr_id' AND DATE_FORMAT(bis,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d')");
      $this->app->Tpl->Set(VONZEIT,$vonZeit?$vonZeit:"09:00");
   } 
   
    //tabelle mit gebuchten tätigkeiten heute

    $table = new EasyTable($this->app);

    $table->Query("SELECT DATE_FORMAT(bis, GET_FORMAT(DATE,'EUR')) AS Datum, DATE_FORMAT(von,'%H:%i') as von, DATE_FORMAT(bis,'%H:%i') as bis,
    TIMEDIFF(bis, von) AS Dauer,
    aufgabe as Taetigkeit,
    IF(DATEDIFF(CURDATE(), bis)<= 5, 
      CONCAT('<a href=\"#\" onclick=\"if(!confirm(\'Wirklich stornieren?\')) return false; else window.location.href=\'index.php?module=zeiterfassung&action=list&do=stornieren&lid=', id, '\'\">Stornieren</a>'), '')
    FROM zeiterfassung
    WHERE adresse=$adr_id AND DATE_FORMAT(bis,'%Y-%m-%d')= DATE_FORMAT(NOW(),'%Y-%m-%d')
    ORDER BY 1 DESC,2 DESC
    ");
    $table->DisplayNew(TABELLE,"Aktion","noAction");


 
    $this->app->Tpl->Set(TABTEXT,"Zeiterfassung"); 
    $this->app->Tpl->Parse(TAB1, "zeiterfassung_manuell.tpl");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
    //$this->app->Tpl->Parse(PAGE,"rahmen_submit_extend.tpl");
  }

  

  function ZeiterfassungOffen($adr_id)
  {
    $this->app->Tpl->Set(SUBSUBHEADING, "offene Arbeitspakete");
    $this->app->Tpl->Set(INHALT,"");
    
    $table = new EasyTable($this->app);
    $table->Query("SELECT DISTINCT a.aufgabe, a.zeit_geplant as vorgabe, 
	(SELECT FORMAT(SUM(TIMEDIFF(bis,von)/10000),2) FROM zeiterfassung WHERE arbeitspaket=a.id) as Gebucht, 
	DATE_FORMAT(a.abgabedatum,'%d.%m.%y') as bis, a.id
	FROM arbeitspaket a LEFT JOIN zeiterfassung z ON z.arbeitspaket=a.id
	WHERE a.adresse='$adr_id' AND (a.status = 'gestartet' OR a.status = 'besprochen')");

    $table->DisplayNew(INHALT,'[DETAILS%value%]');
    $this->app->YUI->Dialog($table,DETAILS,"Arbeitspaket","aufgabe","arbeitspaket_details.tpl",&$this,"ArbeitspaketReadDetails"); 

    $this->app->Tpl->Parse(ARBEITSPAKETE,"rahmen70.tpl");
     
  }

  function ZeiterfassungAbgeschlossen($adr_id)
  {

    $monat = $this->app->DB->Select("SELECT DATE_FORMAT(NOW(),'%M')");
    $this->app->Tpl->Set(SUBSUBHEADING, "Zeiterfassung ($monat)");
    $this->app->Tpl->Set(INHALT,"");
    $table = new EasyTable($this->app);
    
  //  SELECT SUM(hour(z.bis) - hour(z.von)) AS dauer, a.aufgabe, a.zeit_geplant FROM zeiterfassung AS z, arbeitspakete AS a WHERE z.adresse = 2 AND z.adresse = a.adresse AND z.arbeitspaket = a.id  AND a.id = 2 AND (status = "gestartet" OR status = "besprochen") GROUP BY aufgabe
    
    if($this->app->Secure->GetGET("do")=="stornieren"){
      $lid = $this->app->Secure->GetGET("lid");
      if($lid!="")
	$this->app->DB->Delete("DELETE FROM zeiterfassung WHERE id=$lid");
    }

    $table->Query("SELECT DATE_FORMAT(bis, GET_FORMAT(DATE,'EUR')) AS Datum, DATE_FORMAT(von,'%H:%i') as von, DATE_FORMAT(bis,'%H:%i') as bis,
    TIMEDIFF(bis, von) AS Dauer,
    aufgabe as Taetigkeit,
    IF(DATEDIFF(CURDATE(), bis)<= 5, 
      CONCAT('<a href=\"#\" onclick=\"if(!confirm(\'Wirklich stornieren?\')) return false; else window.location.href=\'index.php?module=zeiterfassung&action=list&do=stornieren&lid=', id, '\'\">Stornieren</a>'), '')
    FROM zeiterfassung
    WHERE adresse=$adr_id
    AND (
    MONTH(bis) = MONTH(NOW()) OR DATEDIFF(CURDATE(), bis)<= 5
    )  
    ORDER BY 1 DESC,2 DESC
    ");

    $table->DisplayNew(INHALT,"Aktion","noAction");

   
   // $this->app->Tpl->Set(INHALT,"Abgschlossen");
    $this->app->Tpl->Parse(ZEITERFASSUNGEN,"rahmen70.tpl");
  }

  function AufgabenOffen($adr_id){
    $this->app->Tpl->Set(SUBHEADING, "offene Aufgaben");
    $this->app->Tpl->Set(INHALT,"");
    
    // selektierte Aufgabe Updaten
    if($this->app->Secure->GetPOST("ok") != ""){
      $aufg_id = $this->app->Secure->GetPOST("aufg_id");
      foreach($aufg_id as $myId){
        $this->app->DB->Update("UPDATE aufgabe SET abgeschlossen_am = CURDATE(), abgeschlossen='1' WHERE id=$myId LIMIT 1");
        // Kopie nach aufgabe_erledigt
        $this->app->DB->Insert("INSERT INTO aufgabe_erledigt (adresse, aufgabe, abgeschlossen_am)
          VALUES ($adr_id, $myId, CURDATE())");
      }
    }

    $table = new EasyTable($this->app); 
    // Hole einmalige und wiederholende Aufgaben
    // bei wiederholenden Aufgaben werden nur die vom heutigen Tag und nach Schema startdatum + (intervall*n) geholt
    $table->Query("SELECT
      CONCAT(\"<input type='checkbox' name='aufg_id[]' value='\", id, \"'>\") AS Ok, 
      IF(intervall_tage=0, DATE_FORMAT(startdatum, '%d.%m.%Y'), 
	DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL MOD(DATEDIFF(CURDATE(),DATE_FORMAT(startdatum, '%Y:%m:%d')),intervall_tage) day),'%d.%m.%Y')) AS Datum,
      IF(intervall_tage=0, DATEDIFF(CURDATE(), startdatum) ,MOD(DATEDIFF(CURDATE(), startdatum),intervall_tage)) AS Verzug,
      IF(intervall_tage=0, 'einmalig', intervall_tage) AS Intervall,
      aufgabe, beschreibung
      FROM aufgabe
      WHERE
	(abgeschlossen=0 AND (adresse=$adr_id OR adresse=0))
      OR 
        (DATE_SUB(CURDATE(), INTERVAL MOD(DATEDIFF(CURDATE(),DATE_FORMAT(startdatum, '%Y:%m:%d')),intervall_tage) day)=CURDATE()
	AND DATE_SUB(CURDATE(), INTERVAL MOD(DATEDIFF(CURDATE(),DATE_FORMAT(startdatum, '%Y:%m:%d')),intervall_tage) day) != abgeschlossen_am
	AND intervall_tage>0 AND (adresse=$adr_id OR adresse=0))
      ORDER BY Datum");
       
    $table->DisplayNew(INHALT,"Beschreibung","noAction");
    
    $this->app->Tpl->Parse(AUFGABEN,"rahmen_submit_100.tpl");   
  }

  function ZeiterfassungArchiv($adr_id)
  {
    $this->app->Tpl->Set(SUBHEADING, "Archiv");
    $this->app->Tpl->Set(INHALT,"");  

    $table = new EasyTable($this->app);
    $table->Query("SELECT 
      MONTHNAME(bis) AS Monat,
      YEAR(bis) Jahr,
      CONCAT(ROUND(SUM(TIME_TO_SEC(TIMEDIFF(bis,von)))/3600,1),' Stunden') AS Arbeitszeit,
      CONCAT('<a href=\"index.php?module=zeiterfassung&action=details&month=', MONTH(bis),'&year=', YEAR(bis),'\" class=\"popup\" title=\"Details\">Details</a>')
      FROM `zeiterfassung` 
      WHERE adresse=$adr_id
      GROUP BY MONTHNAME(bis)
      ORDER BY bis DESC");

    $table->DisplayNew(INHALT,"Aktion", "noAction");

    $this->app->Tpl->Parse(ARCHIV,"rahmen100.tpl");
  }

  function ZeiterfassungDetails()
  {
    $monat = $this->app->Secure->GetGET("month");
    $jahr = $this->app->Secure->GetGET("year");
    $frame = $this->app->Secure->GetGET("frame");

 if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(650,730);
    } else {

    $id =  $this->app->User->GetId();
    if($id!="")
      $adr_id = $this->app->DB->Select("SELECT adresse FROM user WHERE id=$id");
  
    $monatsname = $this->app->DB->Select("SELECT MONTHNAME('$jahr-$monat-01')");
    
    $this->app->Tpl->Set(SUBHEADING, "Arbeitszeiten f&uuml;r $monatsname");
    $this->app->Tpl->Set(INHALT,"");  


    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Zeiterfassung");

    //$this->app->Tpl->Add(TABS,
    //  "<li><a href=\"index.php?module=zeiterfassung&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    $table = new EasyTable($this->app);
    $table->Query("SELECT  
	DATE_FORMAT(bis,'%d.%m.%y') as Datum,
	ROUND((TIME_TO_SEC(TIMEDIFF(bis,von))/3600)) AS Dauer,
	buchungsart,
	aufgabe
	FROM zeiterfassung
	WHERE adresse=$adr_id
	AND MONTH(bis)=$monat
	AND YEAR(bis)=$jahr");	
    
    $table->DisplayNew(INHALT,"T&auml;tigkeit", "noAction");
    //$this->app->Tpl->Set(AKTIV_TAB5,"selected"); 
    $this->app->Tpl->Parse(PAGE,"rahmen.tpl");
      $this->app->BuildNavigation=false;
    }


  }
}

?>
