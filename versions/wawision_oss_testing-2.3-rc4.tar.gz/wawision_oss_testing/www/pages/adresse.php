<?php
include ("_gen/adresse.php");

class Adresse extends GenAdresse {
  var $app;
  
  function Adresse($app) {
    //parent::GenAdresse($app);
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","AdresseCreate");
    $this->app->ActionHandler("edit","AdresseEdit");
    $this->app->ActionHandler("list","AdresseList");
    $this->app->ActionHandler("delete","AdresseDelete");
    $this->app->ActionHandler("ustprf","AdresseUstprf");
    $this->app->ActionHandler("ustprfneu","AdresseUstprfNeu");
    $this->app->ActionHandler("ustprfedit","AdresseUstprfEdit");
    $this->app->ActionHandler("lieferantvorlage","AdresseLieferantvorlage");
    $this->app->ActionHandler("kundevorlage","AdresseKundevorlage");

    $this->app->ActionHandler("lieferadresse","AdresseLieferadresse");
    $this->app->ActionHandler("lieferadresseneditpopup","AdresseLieferadressenEditPopup");
    $this->app->ActionHandler("ansprechpartner","AdresseAnsprechpartner");
    $this->app->ActionHandler("ansprechpartnereditpopup","AdresseAnsprechpartnerEditPopup");
    $this->app->ActionHandler("ansprechpartnerpopup","AdresseAnsprechpartnerPopup");
    $this->app->ActionHandler("lieferadressepopup","AdresseLieferadressePopup");
    $this->app->ActionHandler("ustpopup","AdresseUSTPopup");
    $this->app->ActionHandler("rollen","AdresseRollen");
    $this->app->ActionHandler("kontakthistorie","AdresseKontakthistorie");
    $this->app->ActionHandler("kontakthistorieeditpopup","AdresseKontakthistorieEditPopup");
    $this->app->ActionHandler("rolecreate","AdresseRolleAnlegen");
    $this->app->ActionHandler("roledel","AdresseRolleLoeschen");
    $this->app->ActionHandler("addposition","AdresseAddPosition");
    $this->app->ActionHandler("suchmaske","AdresseSuchmaske");
    $this->app->ActionHandler("dateien","AdresseDateien");
    $this->app->ActionHandler("brief","AdresseBrief");
    $this->app->ActionHandler("briefdelete","AdresseBriefDelete");
    $this->app->ActionHandler("briefpdf","AdresseBriefPDF");
    $this->app->ActionHandler("briefeditpopup","AdresseBriefEditPopup");
    $this->app->ActionHandler("email","AdresseEmail");
    $this->app->ActionHandler("auftraege","AdresseAuftraege");
    $this->app->ActionHandler("positioneneditpopup","AdresseArtikelEditPopup");
    $this->app->ActionHandler("emaileditpopup","AdresseEmailEditPopup");
    $this->app->ActionHandler("artikel","AdresseArtikelPosition");
    $this->app->ActionHandler("lieferantartikel","AdresseLieferantArtikel");
    $this->app->ActionHandler("kundeartikel","AdresseKundeArtikel");
    $this->app->ActionHandler("delartikel","DelArtikel");
    $this->app->ActionHandler("upartikel","UpArtikel");
    $this->app->ActionHandler("downartikel","DownArtikel");

    $this->app->ActionHandler("rolledelete","AdresseRolleDelete");
    $this->app->ActionHandler("artikeleditpopup","AdresseArtikelEditPopup");
    $this->app->ActionHandler("kontakthistorie","AdresseKontaktHistorie");
    $this->app->ActionHandler("offenebestellungen","AdresseOffeneBestellungen");
    $this->app->ActionHandler("adressebestellungmarkieren","AdresseBestellungMarkiert");
    $this->app->ActionHandler("autocomplete","AdresseAutoComplete");

    $this->app->ActionHandler("lohn","AdresseLohnStundensatzUebersicht");
    $this->app->ActionHandler("stundensatz","AdresseStundensatz");
    $this->app->ActionHandler("stundensatzedit","AdresseStundensatzEdit");
    $this->app->ActionHandler("stundensatzdelete","AdresseStundensatzDelete");
    $this->app->ActionHandler("createdokument","AdresseCreateDokument");
    


    $id = $this->app->Secure->GetGET("id");
    //$nummer = $this->app->Secure->GetPOST("nummer");

    //if($nummer=="")
      //$name = $this->app->DB->Select("SELECT CONCAT(name,'&nbsp;&nbsp;',
      $nummer = $this->app->DB->Select("SELECT CONCAT(
	if(kundennummer,CONCAT(' Kunde: ',kundennummer),''),
	if(lieferantennummer,CONCAT(' Lieferant: ',lieferantennummer),'')) FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
 	$name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");

   // else
   //   $name = $nummer;

    if($name!="")
      $this->app->Tpl->Set(UEBERSCHRIFT,"Adresse von: ".$name);
    else
      $this->app->Tpl->Set(UEBERSCHRIFT,"Adressen");

    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Adresse");
		if($name!="")
    $this->app->Tpl->Set(KURZUEBERSCHRIFT2,"$name ($nummer)");
    $this->app->Tpl->Set(FARBE,"[FARBE1]");


    $this->app->ActionHandlerListen(&$app);
    $this->app = $app;
  }


	function AdresseCreateDokument()
	{
		$id = $this->app->Secure->GetGET("id");
		$cmd = $this->app->Secure->GetGET("cmd");

		$relocation = true;

		switch($cmd)
		{	
			case 'auftrag': $newid = $this->app->erp->CreateAuftrag($id); $this->app->erp->LoadAuftragStandardwerte($newid,$id); break;
			case 'angebot': $newid = $this->app->erp->CreateAngebot($id); $this->app->erp->LoadAngebotStandardwerte($newid,$id); break;
			case 'rechnung': $newid = $this->app->erp->CreateRechnung($id); $this->app->erp->LoadRechnungStandardwerte($newid,$id); break;
			case 'lieferschein': $newid = $this->app->erp->CreateLieferschein($id); $this->app->erp->LoadLieferscheinStandardwerte($newid,$id); break;
			case 'gutschrift': $newid = $this->app->erp->CreateGutschrift($id); $this->app->erp->LoadGutschriftStandardwerte($newid,$id); break;
			case 'bestellung': $newid = $this->app->erp->CreateBestellung($id); $this->app->erp->LoadBestellungStandardwerte($newid,$id);break;
			default: $relocation = false;
		}
		
		if($relocation)
		{
			header("Location: index.php?module=$cmd&action=edit&id=$newid");
			exit;
		}

	}

  function AdresseLohnStundensatzUebersicht()
	{
		$this->AdresseMenu();	

		$msg = base64_decode($this->app->Secure->GetGET("msg"));
		if($msg!="") $this->app->Tpl->Set(MESSAGE, $msg);

		$this->AdresseLohn();
		$this->AdresseStundensatz();

    $this->app->Tpl->Parse(PAGE,"adresse_lohn.tpl");
	}

	function AdresseLohn()
	{
		$id = $this->app->Secure->GetGET("id");
		if(is_numeric($id))
		{
			$this->app->YUI->TableSearch(TAB1,"adresselohn");
		}else
			$this->app->Tpl->Set(MESSAGE, "<div class=\"error\">Mitarbeiter-ID konnte nicht gefunden werden.</div>");

	}

  function AdresseStundensatz($id)
  {
		$id = $this->app->Secure->GetGET("id");	
	
		if(is_numeric($id))
   	{
			$stundensatz = $this->app->Secure->GetPOST("Stundensatz_StandardStundensatz");
			$submit = $this->app->Secure->GetPOST("Stundensatz_Submit");

			// Speichere neuen Stundensatz
			if($submit!="")
			{
				$this->app->DB->Insert("INSERT INTO stundensatz (adresse, satz, typ, projekt, datum) VALUES ('$id', '$stundensatz', 'Standard', '0', NOW())");
				$this->app->Tpl->Set(MESSAGE, "<div class=\"success\">Der neue Standard-Stundensatz wurde &uuml;bernommen.</div>");
			}

			// Hole neuesten Stundensatz
			$standard = $this->app->DB->Select("SELECT satz 
																					FROM stundensatz 
																					WHERE typ='standard'
																					AND adresse='$id'
																					ORDER BY datum DESC LIMIT 1");
 			$this->app->Tpl->Set(STANDARDSTUNDENSATZ, $standard);

			// Fülle Projekt-Tabelle
			$this->app->YUI->TableSearch(TAB2,"adressestundensatz");
		}else
			$this->app->Tpl->Set(MESSAGE, "<div class=\"error\">Mitarbeiter-ID konnte nicht gefunden werden.</div>");
  }

	function AdresseStundensatzEdit()
	{
		$this->AdresseMenu();

		$user = $this->app->Secure->GetGET("user");
		$id = $this->app->Secure->GetGET("id");	
		$projekt = $this->app->Secure->GetGET("projekt");

		$satz = $this->app->Secure->GetPOST("Stundensatz_Angepasst");
		$adapt = $this->app->Secure->GetPOST("Stundensatz_Adapt");
		$cancel = $this->app->Secure->GetPOST("Stundensatz_Angepasst_Cancel");
		$submit = $this->app->Secure->GetPOST("Stundensatz_Angepasst_Submit");
	

		if($cancel!="")
		{
			header("Location: ./index.php?module=adresse&action=lohn&id=$user");
			exit;
		}
	

		// Hole neuesten Standard-Stundensatz
    $standard = $this->app->DB->Select("SELECT satz 
                                        FROM stundensatz 
                                        WHERE typ='standard'
                                        AND adresse='$user'
                                        ORDER BY datum DESC LIMIT 1");

		if(is_numeric($id))
		{
			// Stundensatz existiert bereits, hole Daten
			$stundensatz = $this->app->DB->SelectArr("SELECT * FROM stundensatz WHERE id='$id' LIMIT 1");
			$this->app->Tpl->Set(STUNDENSATZANGEPASST, $stundensatz[0][satz]);

			if($submit!="")	
			{
				$projekt = $this->app->DB->Select("SELECT projekt FROM stundensatz WHERE id='$id' LIMIT 1");

				if($adapt!="")
					$this->app->DB->Update("UPDATE stundensatz SET satz='$satz' WHERE adresse='$user' AND projekt='$projekt'");

				$this->app->DB->Insert("INSERT INTO stundensatz (adresse, satz, typ, projekt, datum)
																VALUES ('$user', '$satz', 'Angepasst', '$projekt', NOW())");
				header("Location: ./index.php?module=adresse&action=lohn&id=$user&msg=$msg");
        exit;		
			}


			$this->app->Tpl->Set(MODE, "Stundensatz editieren");
		}else
		{
			// Stundensatz existiert noch nicht
			$this->app->Tpl->Set(STUNDENSATZANGEPASST, $standard);
			$this->app->Tpl->Set(ADAPTDISABLED, "DISABLED");
						
			if($submit!="")
			{
				// Schreibe neuen Satz
				$this->app->DB->Insert("INSERT INTO stundensatz (adresse, satz, typ, projekt, datum)
																VALUES ('$user', '$satz', 'Angepasst', '$projekt', NOW())");

				$msg = base64_encode("<div class=\"success\">Der Stundensatz wurde erfolgreich gespeichert.</div>");
				header("Location: ./index.php?module=adresse&action=lohn&id=$user&msg=$msg");
				exit;
			}	

			$this->app->Tpl->Set(MODE, "Stundensatz erstellen");
		}

		$this->app->Tpl->Parse(PAGE, "adresse_stundensatz_edit.tpl");	
	}

	function AdresseStundensatzDelete()
	{
		$user = $this->app->Secure->GetGET("user");
		$id = $this->app->Secure->GetGET("id");

		if(is_numeric($id))
			$this->app->DB->Delete("DELETE FROM stundensatz WHERE id='$id' LIMIT 1");
		else
			$msg = base64_encode("<div class=\"error\">Stundensatz-ID konnte nicht gefunden werden. Standard-Stundens&auml;tze k&ouml;nnen nicht gel&ouml;scht werden.</div>"); 

		header("Location: ./index.php?module=adresse&action=lohn&id=$user&msg=$msg");
		exit; 
	}



  function AdresseAutoComplete()
  {

    $table = $this->app->Secure->GetGET("table");
    $filter = $this->app->Secure->GetGET("filter");
    $name = $this->app->Secure->GetGET("name");
    $query = $this->app->Secure->GetGET("query");
    $colsstring = base64_decode($this->app->Secure->GetGET("colsstring"));
    $returncol= base64_decode($this->app->Secure->GetGET("returncol"));
     if($table=="")
      $table=$name;

    if($filter=="kunde")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id WHERE adresse_rolle.subjekt='Kunde' AND adresse.kundennummer!=0 AND adresse.geloescht=0 AND adresse.name LIKE '%$query%'";

    if($filter=="mitarbeiter")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id WHERE adresse_rolle.subjekt='Mitarbeiter' AND adresse.mitarbeiternummer!=0 AND adresse.geloescht=0 
AND adresse.name LIKE '%$query%'";


    if($filter=="lieferant")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id WHERE adresse_rolle.subjekt='Lieferant' AND adresse.geloescht=0 AND adresse.name LIKE '%$query%'";

    if($filter=="kunde_auftrag")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id LEFT JOIN auftrag ON auftrag.adresse=adresse.id WHERE adresse_rolle.subjekt='Kunde' AND ((auftrag.status='freigegeben' OR auftrag.status='storniert') OR (auftrag.vorkasse_ok=0 AND (auftrag.zahlungsweise='paypal' OR auftrag.zahlungsweise='vorkasse' OR auftrag.zahlungsweise='kreditkarte'))) AND adresse.geloescht=0
 AND adresse.name LIKE '%$query%'";

    if($filter=="kunde_rechnung")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id LEFT JOIN rechnung ON rechnung.adresse=adresse.id WHERE adresse_rolle.subjekt='Kunde' AND rechnung.ist < rechnung.soll AND adresse.geloescht=0 AND adresse.name LIKE '%$query%'";

 if($filter=="kunde_gutschrift")
      $filter = "LEFT JOIN adresse_rolle ON adresse_rolle.adresse=adresse.id LEFT JOIN gutschrift ON gutschrift.adresse=adresse.id WHERE adresse_rolle.subjekt='Kunde' AND adresse.geloescht=0 AND adresse.name LIKE '%$query%'";

    
    if($table=="artikel")
      $filter = "WHERE name_de LIKE '%$query%'";


    if(($filter=="" || $filter=="adresse") && $name=="adresse")
      $filter = "WHERE adresse.geloescht=0 AND adresse.name LIKE '%$query%'";

      $arr = $this->app->DB->SelectArr("SELECT DISTINCT $colsstring, $returncol FROM $table $filter ORDER by 1 LIMIT 10");
//      echo "SELECT DISTINCT $colsstring, $returncol FROM $table $filter ORDER by 1";

      $cols = split(',',$colsstring);
      foreach($arr as $key=>$value){
        //$tpl_end .= '{id:"'.$value[$returncol].'", cola:"'.$value[$cols[0]].'", colb:"'.$value[$cols[1]].'", colc:"'.$value[$cols[2]].'"},';
        echo $value[$returncol]."!*!".$value[$cols[0]].' '.$value[$cols[1]].' '.$value[$cols[2]]."\n";
        //echo $value[$cols[0]].' '.$value[$cols[1]].' '.$value[$cols[2]]."\n";
        //echo $value[$cols[0]]."\n";
     } 


    exit;

  }


  function AdresseDateien()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->AdresseMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Dateien)");
    $this->app->YUI->DateiUpload(PAGE,"Adressen",$id);
  }


  function AdresseDelete()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->DB->Update("UPDATE adresse SET geloescht='1' WHERE id='$id' LIMIT 1");

    $this->AdresseList();
  }


  function AdresseRolleDelete()
  {
    $id = $this->app->Secure->GetGET("id");
    $sid = $this->app->Secure->GetGET("sid");

    $this->app->DB->Delete("DELETE FROM adresse_rolle WHERE id='$sid' AND adresse='$id' LIMIT 1");
    $this->app->Secure->POST['rolleanlegen'] = "true";
    //$this->AdresseEdit();
    $this->AdresseRollen();
    //$this->app->Tpl->Set(AKTIV_TAB3,"selected");
  }

  function AdresseCreate()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"anlegen");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=list","Zur&uuml;ck zur &Uuml;bersicht");

    parent::AdresseCreate();
  }


  function AdresseList()
  {

    //$this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=create","Neue Adresse anlegen");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    $this->app->Tpl->Set(UEBERSCHRIFT,"Adresssuche");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Adressen");

    $this->app->YUI->TableSearch(TAB1,"adressetabelle");
    $this->app->Tpl->Parse(PAGE,"adresseuebersicht.tpl");

/*

    $action=$this->app->Secure->GetGET("action");

    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\" style=\"background-color: [FARBE1]\">Allgemein</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=create\">Neue Adresse anlegen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=list\">Adresse suchen</a></li>");

      
    if($action=="list")
      $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=welcome&action=main\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    else 
      $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    $this->app->Tpl->Add(TABS,"<li><br><br></li>");

      $this->app->erp->EasylogPaketmarke('name','adresszusatz','strasse','plzi','ort','land',1);


    //kunden
    $sql = $this->app->erp->AdressSuche(TAB1);
    $table = new EasyTable($this->app);
    $table->Query($sql,10);
    $table->DisplayOwn(INHALT,"
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
      <a onclick=\"if(!confirm('Adresse wirklich l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=delete&id=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/copy.png\"></a>
      ",30,"mid");
    $this->app->Tpl->Parse(TAB1,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");
*/
/*
    //Lieferant
    $sql = $this->app->erp->AdressSuche(TAB2,"Lieferant");
    $table = new EasyTable($this->app);
    $table->Query($sql,10);
    $table->DisplayOwn(INHALT,"
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/delete.gif\"></a>
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/copy.png\"></a>
      ",30,"mid");
    $this->app->Tpl->Parse(TAB2,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");

    //mitarbeiter
    $table = new EasyTable($this->app);
    $table->Query("SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Mitarbeiter'",10);
    $table->DisplayNew(INHALT,"
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
      ","");
    $this->app->Tpl->Parse(TAB3,"rahmen100.tpl");
    $this->app->Tpl->Set(INHALT,"");

    //ohne rolle
    $table = new EasyTable($this->app);
    $table->Query("SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt IS NULL");
    $table->DisplayNew(INHALT,"
      <a href=\"index.php?module=adresse&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
      ","");
    $this->app->Tpl->Parse(TAB4,"rahmen100.tpl");
*/

  //  $this->app->Tpl->Set(AKTIV_TAB1,"selected");

 //   $this->app->Tpl->Parse(PAGE,"adresseuebersicht.tpl");
    //parent::AdresseList();
  }

  
  function AdresseMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $action= $this->app->Secure->GetGET("action");

//    $this->app->Tpl->Add(TABS,"<li><h2 style=\"background-color: [FARBE1];\">Adresse</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=edit&id=$id","Details");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=rollen&id=$id","Rollen");
    
	// Ist Benutzer ein Mitarbeiter?
	$mitarbeiter = $this->app->DB->Select("SELECT id FROM adresse_rolle WHERE adresse='$id' AND subjekt='Mitarbeiter' LIMIT 1");
	if(is_numeric($mitarbeiter))
		$this->app->erp->MenuEintrag("index.php?module=adresse&action=lohn&id=$id","Lohn");

    $this->app->erp->MenuEintrag("index.php?module=adresse&action=ansprechpartner&id=$id","Ansprechpartner");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=lieferadresse&id=$id","Lieferadressen");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=kontakthistorie&id=$id\">Kontakthistorie</a></li>");

  
    if($this->app->erp->IsAdresseSubjekt($id,"Kunde"))
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=auftraege&id=$id","Belegsuche");

    $this->app->erp->MenuEintrag("index.php?module=adresse&action=brief&id=$id","Korrespondenzen");


    //$this->app->Tpl->Add("index.php?module=adresse&action=email&id=$id\">E-Mail schreiben</a></li>");
    $this->app->erp->MenuEintrag("index.php?module=adresse&action=dateien&id=$id","Dateien");


    $this->app->erp->MenuEintrag("index.php?module=adresse&action=kundeartikel&id=$id","Gekaufte Artikel");

    if($this->app->erp->IsAdresseSubjekt($id,"Lieferant"))
    {
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=lieferantartikel&id=$id","Artikel bei Lieferant");
     //$this->app->erp->MenuEintrag("index.php?module=adresse&action=lieferantvorlage&id=$id","Daten bei Lieferant");
    }

//    if($this->app->erp->IsAdresseSubjekt($id,"Kunde"))
//      $this->app->erp->MenuEintrag("index.php?module=adresse&action=kundevorlage&id=$id","Zahlungsweise");

    if($this->app->erp->IsAdresseSubjekt($id,"Kunde"))
    {
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=email&id=$id","RMAs");
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=artikel&id=$id","Abrechnungsartikel");
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=ustprf&id=$id","USTID-Pr&uuml;fung");
      //$this->app->Tpl->Add("index.php?module=adresse&action=email&id=$id\">Rabatte</a></li>");
    }

    if($this->app->erp->IsAdresseSubjekt($id,"Lieferant"))
    {
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=email&id=$id","RMAs</a></li>");
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=offenebestellungen&id=$id","Bestellungen");
    }

//    $this->app->erp->MenuEintrag("index.php?module=adresse&action=create","Neue Adresse anlegen");

   if($action=="list")
      $this->app->erp->MenuEintrag("index.php?module=welcome&action=main","Zur&uuml;ck zur &Uuml;bersicht");
    else 
      $this->app->erp->MenuEintrag("index.php?module=adresse&action=list","Zur&uuml;ck zur &Uuml;bersicht");


/*
    $this->app->Tpl->Add(TABS,"<li><br><br></li>");
    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=create\">Neue Adresse anlegen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=list\">Adresse suchen</a></li>");
   
    if($action=="list")
      $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=welcome&action=main\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    else 
      $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=adresse&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

*/


     //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=adresse&action=kosten&id=$id\">Gesamtkalkulation</a></li>");
  }

/*
  function AdresseKontaktHistorie()
  {
    $this->AdresseMenu();

    $this->app->Tpl->Set(SUBSUBHEADING,"Gespr&auml;che");
    $id = $this->app->Secure->GetGET("id");
 
    //Formula lieferadresse
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(datum,'%d.%m.%Y %H:%i') as Kontakt, grund,bearbeiter 
      FROM adresse_kontakhistorie WHERE adresse='$id' order by datum DESC");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=bestellung&action=edit&id=%value%\">Lesen</a>&nbsp;
	<a href=\"index.php?module=bestellung&action=edit&id=%value%\">Antworten</a>&nbsp;");


    // easy table mit arbeitspaketen YUI als template 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Set(TABTEXT,"Gespr&auml;che");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  } 
*/
  function AdresseKontaktHistorie()
  {
    $this->AdresseMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Kontakthistorie)");
    $this->app->Tpl->Set(SUBSUBHEADING,"Adressen");
    $id = $this->app->Secure->GetGET("id");
 
    // neues arbeitspaket
    $widget = new WidgetAnsprechpartner(&$this->app,TAB2);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=ansprechpartner&id=$id");
    $widget->Create();


    //Formula ansprechpartner
    $table = new EasyTable($this->app);
    $table->Query("SELECT name, bereich, telefon, email,id FROM ansprechpartner WHERE adresse='$id'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=adresse&action=ansprechpartnereditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Bearbeiten</a>");

    // easy table mit arbeitspaketen YUI als template 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Parse(PAGE,"ansprechpartneruebersicht.tpl");
  }

  function AdresseKontaktHistorieEditPopup()
  {
    $frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
 
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(600,320);
    } else {
      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetAnsprechpartner(&$this->app,PAGE);
      $adresse = $this->app->DB->Select("SELECT adresse FROM ansprechpartner WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=adresse&action=ansprechpartner&id=$adresse");

      $widget->Edit();
      $this->app->BuildNavigation=false;
    }
  }
 



  function AdresseRolle()
  {


  } 

  function AdresseNummern($id)
  {
    $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    $lieferantennummer = $this->app->DB->Select("SELECT lieferantennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    $mitarbeiternummer= $this->app->DB->Select("SELECT mitarbeiternummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");


    if($kundennummer==0 || $kundennummer==""){
      // pruefe ob rolle kunden vorhanden
      $check = $this->app->DB->Select("SELECT adresse FROM adresse_rolle WHERE adresse='$id' AND subjekt='Kunde' LIMIT 1");
      if($check!="")
      {
	$kundennummer = $this->app->erp->GetNextKundennummer();
	$this->app->DB->Update("UPDATE adresse SET kundennummer='$kundennummer' WHERE id='$id' AND kundennummer='0' LIMIT 1");
      } else 
	$kundennummer="noch keine";
    }

    if($lieferantennummer==0){
      $check = $this->app->DB->Select("SELECT adresse FROM adresse_rolle WHERE adresse='$id' AND subjekt='Lieferant' LIMIT 1");
      if($check!="")
      {
	$lieferantennummer= $this->app->erp->GetNextLieferantennummer();
	$this->app->DB->Update("UPDATE adresse SET lieferantennummer='$lieferantennummer' WHERE id='$id' AND lieferantennummer='0' LIMIT 1");
      } else 
	$lieferantennummer="noch keine";
    }

    if($mitarbeiternummer==0){
      $check = $this->app->DB->Select("SELECT adresse FROM adresse_rolle WHERE adresse='$id' AND subjekt='Mitarbeiter' LIMIT 1");
      if($check!="")
      {
	$mitarbeiternummer= $this->app->erp->GetNextMitarbeiternummer();
	$this->app->DB->Update("UPDATE adresse SET mitarbeiternummer='$mitarbeiternummer' WHERE id='$id' AND mitarbeiternummer='0' LIMIT 1");
      } else 
	$mitarbeiternummer="noch keine";
    }
  }

  function AdresseEdit()
  {
    $id = $this->app->Secure->GetGET("id");

    $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    $lieferantennummer = $this->app->DB->Select("SELECT lieferantennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    $mitarbeiternummer= $this->app->DB->Select("SELECT mitarbeiternummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");


$things = array('angebot','auftrag','rechnung','lieferschein','gutschrift');

foreach($things as $key=>$value)
$buttons_kunde .= '
<a href="#" onclick="if(!confirm(\''.ucfirst($value).' wirklich anlegen?\')) return false; else window.location.href=\'index.php?module=adresse&action=createdokument&id='.$id.'&cmd='.$value.'\';">
	<table width="110"><tr><td>'.ucfirst($value).'</td></tr></table></a>';

$things = array('bestellung');
foreach($things as $key=>$value)
$buttons_lieferant .= '
<a href="#" onclick="if(!confirm(\''.ucfirst($value).' wirklich anlegen?\')) return false; else window.location.href=\'index.php?module=adresse&action=createdokument&id='.$id.'&cmd='.$value.'\';">
	<table width="110"><tr><td>'.ucfirst($value).'</td></tr></table></a>';



if($kundennummer > 0) $buttons = $buttons_kunde;
if($lieferantennummer > 0) $buttons .= $buttons_lieferant;

$this->app->Tpl->Set(BUTTONS,'<fieldset><legend>Neu Anlegen</legend><div class="tabsbutton" align="center">'.$buttons.'</div></fieldset>');


    $anzahl_rollen = $this->app->DB->Select("SELECT SUM(id) FROM adresse_rolle WHERE adresse='$id'");
    if($anzahl_rollen<1)
    $this->app->Tpl->Set(MESSAGE,"<div class=\"success\">Achtung: Diese Adresse hat noch keine Kunden- oder Lieferantennummer! M&ouml;chten Sie jetzt eine entsprechende <a href=\"index.php?module=adresse&action=rollen&id=$id\">Rolle</a> anlegen?</div>");
    
    /* google maps */
    //$this->app->Tpl->Set(ONLOAD,'onload="load()" onunload="GUnload()"');

    //$key = "ABQIAAAAF-3x19QGjrDnM0qot_5RLhRPMKv2yVfFADlvP9s78xqAFkzplRTXptJWNlxCNcnzn7tujwTd6WlJDQ";
/*
    $adresse= $this->app->DB->Select("SELECT CONCAT(strasse,'+,',plz,'+',ort,',+',land) FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    $adresse = str_replace(' ','+',$adresse);
    //$adresse = "1600+Amphitheatre+Parkway,+Mountain+View,+CA";
    //$adresse = "Holzbachstrasse+4,+Augsburg";
    $geo = implode(file("http://maps.google.com/maps/geo?q=".$adresse."&output=xml&hl=de&key=".$key));  $geo = utf8_encode($geo);

    $xml = xml_parser_create();  xml_parse_into_struct($xml, $geo, $ausgabe);  xml_parser_free($xml);
    
    foreach($ausgabe as $a) {    
      if($a["tag"] == "COORDINATES") $position = $a["value"];    
    }
    $position = explode(",", $position);  $position = $position[1].",".$position[0];

    $this->app->Tpl->Set(JAVASCRIPT,'  
    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAF-3x19QGjrDnM0qot_5RLhRPMKv2yVfFADlvP9s78xqAFkzplRTXptJWNlxCNcnzn7tujwTd6WlJDQ"
      type="text/javascript"></script>
    <script type="text/javascript">

      function load() {
      if (GBrowserIsCompatible()) {
        var map = new GMap2(document.getElementById("map"));
        map.setCenter(new GLatLng('.$position.'), 13);
      }
    }
  </script>    
  <div id="map" style="width: 500px; height: 300px"></div>
'); 
*/
    // aktiviere tab 1
    $this->app->Tpl->Set(AKTIV_ADRESSE,"selected");
    $this->AdresseNummern($id);
    if($kundennummer==0) $kundennummer = "keine Kundennummer vorhanden";
    if($lieferantennummer==0)$lieferantennummer = "keine Lieferantennummer vorhanden";
    if($mitarbeiternummer==0)$mitarbeiternummer = "keine Mitarbeiternummer vorhanden";


    $this->app->Tpl->Set(KUNDENNUMMERANZEIGE,$kundennummer);
    $this->app->Tpl->Set(LIEFERANTENNUMMERANZEIGE,$lieferantennummer);
    $this->app->Tpl->Set(MITARBEITERNUMMERANZEIGE,$mitarbeiternummer);

    $this->AdresseMenu();
    $this->app->Tpl->Set(TABLE_ADRESSE_KONTAKTHISTORIE,"TDB");
    $this->app->Tpl->Set(TABLE_ADRESSE_ROLLEN,"TDB");
    
    $this->app->Tpl->Set(TABLE_ADRESSE_USTID,"TDB");


    $this->app->Tpl->Set(SUBSUBHEADING,"Rolle anlegen");
    if($this->app->Secure->GetPOST("rolleanlegen")!="")
      $this->app->Tpl->Set(AKTIV_TAB3,"selected");
    else
      $this->app->Tpl->Set(AKTIV_TAB1,"selected");


    parent::AdresseEdit();
  }

  function AdresseRollen()
  { 
    $this->AdresseMenu();

    $id = $this->app->Secure->GetGET("id");
    $reload = $this->app->Secure->GetGET("reload");

    $this->AdresseNummern($id);

    $widget = new WidgetAdresse_rolle(&$this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=adresse&action=rollen&id=$id&reload=true");

    $widget->Create();

    if($this->app->Secure->GetPOST("rolleanlegen")!="" || $reload=="true")
    {
      header("Location: index.php?module=adresse&action=rollen&id=$id");
      exit;
    } 


    $this->app->Tpl->Set(SUBSUBHEADING,"Rollen der Adresse");
    $this->app->Tpl->Set(TABTEXT,"Rollen");

    $table = new EasyTable($this->app);
    $table->Query("SELECT a.subjekt as Rolle, 
      if(a.objekt='','ALLE',a.objekt) as Zuordnung, 
      if(a.parameter='','ALLE',p.abkuerzung) as projekt, 
      DATE_FORMAT(a.von,'%d.%m.%Y') as seit, a.id
      FROM adresse_rolle a  LEFT JOIN projekt p ON a.parameter=p.id WHERE a.adresse='$id'");
    $table->DisplayNew(TAB1NEXT, "<!--<a href=\"index.php?module=adresse&action=rolleeditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\"><img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a>&nbsp;-->
<a onclick=\"if(!confirm('Rolle wirklich l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=rolledelete&id=$id&sid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
	");
 
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  } 

  function AdresseUSTPopup()
  {
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(650,530);
    } else {

      // nach page inhalt des dialogs ausgeben
      //$sid = $this->app->DB->Select("SELECT shop FROM shopexport_kampange WHERE id='$id' LIMIT 1");

      $this->AdresseUstprf();
      //$widget = new WidgetShopexport_kampange(&$this->app,PAGE);

      //$widget->form->SpecialActionAfterExecute("close_refresh",
      //  "index.php?module=marketing&action=kampangenedit&id=$sid");

      //$widget->Edit();

      $this->app->BuildNavigation=false;
    }
  }



  function AdresseUstprf()
  {

    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
 
    $this->app->Tpl->Set(HEADING,"Adresse (USTID-Pr&uuml;fung)");
    $this->app->Tpl->Set(SUBSUBHEADING,"Umstatzsteuerpr&uuml;fungen");
    //Formula lieferadresse

    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(datum_online,GET_FORMAT(DATE,'EUR')) AS Datum, ustid,strasse, plz, ort,status,id FROM ustprf WHERE adresse='$id'");

    $table->DisplayNew(INHALT,"
      <a href=\"index.php?module=adresse&action=ustprfedit&id=$id&lid=%value%\">edit</a>
      <a href=\"index.php?module=adresse&action=ustprfneu&id=$id\">new</a>
      ","");
      //"<a href=\"index.php?module=adresse&action=ustprfneu&id=$id\">Neue USTID-Pr&uuml;fung anlegen</a>");

    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");

    $this->app->Tpl->Set(INHALT,"");

    
    if($this->app->Secure->GetPOST("name")!="")
    {
      //speichern
      $lid = $this->app->FormHandler->FormToDatabase("ustprf","adresse",$id);
      //$this->AdresseUstprf();
      //$lid = $this->app->DB->GetInsertID();
      header("Location: index.php?module=adresse&action=ustprfedit&id=$id&lid=$lid");
      exit;
    }

    //$this->app->Tpl->Set(MESSAGE,"<div class=\"warning\">Adresse unterschiedlich!!! <br>Soll Adressdatensatz vom Kunden angepasst werden?</div>");

    $this->app->Tpl->Set(SUBHEADING,"UST-ID Pr&uuml;fung neu anlegen");
    $this->app->FormHandler->FormGetVars("adresse",$id);
   
    $this->app->Tpl->Parse(INHALT,"ustprfneu.tpl");
    $this->app->Tpl->Parse(TAB2,"rahmen_submit.tpl");

    $this->app->Tpl->Parse(PAGE,"ustuebersicht.tpl");
  }

  function AdresseUstprfEdit()
  {
    $id = $this->app->Secure->GetGET("id");
    $lid = $this->app->Secure->GetGET("lid");
    
    $this->app->Tpl->Set(HEADING,"Adresse (USTID-Pr&uuml;fung)");
    
    $ust = $this->app->Secure->GetPOST("ustid");  
    //$ust = $this->app->Secure->GetPOST("ustid2");
    $name = $this->app->Secure->GetPOST("name");
    $ort = $this->app->Secure->GetPOST("ort");
    $strasse = $this->app->Secure->GetPOST("strasse");
    $plz = $this->app->Secure->GetPOST("plz");
    //$druck = $this->app->Secure->GetPOST("druck");
   
    if($this->app->Secure->GetPOST("aendern") != "")
    {
      //firmenname
      //ort
      //strasse
      //plz
      $this->app->DB->Update("UPDATE auftrag SET name='$name', ort='$ort',ustid='$ust', strasse='$strasse', plz='$plz' WHERE status='freigegeben' AND adresse='$id'");
      $this->app->DB->Update("UPDATE adresse SET name='$name', ort='$ort',ustid='$ust', strasse='$strasse', plz='$plz' WHERE id='$id'");
      $this->app->DB->Update("UPDATE ustprf SET name='$name' WHERE id='$lid'");
      $this->app->DB->Update("UPDATE ustprf SET plz='$plz' WHERE id='$lid'");
      $this->app->DB->Update("UPDATE ustprf SET ort='$ort' WHERE id='$lid'");
      $this->app->DB->Update("UPDATE ustprf SET ustid='$ust' WHERE id='$lid'");
      $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Adresse und USTID bei Kunde und offenen Auftraegen genaendert!</div>");  
    }


    $ust = str_replace(" ","",$ust);
    $status = $this->app->DB->Select("SELECT status FROM ustprf WHERE id='$lid' LIMIT 1");
 
    $datum_online = $this->app->DB->Select("SELECT datum_online FROM ustprf WHERE id='$lid' LIMIT 1");
    if($this->app->Secure->GetPOST("online")!="")
    {
      if($status!="erfolgreich" && $status!="fehlgeschlagen")
      {     
 
      if(!$this->app->erp->CheckUSTFormat($ust)){
	$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">UST-Nr. bzw. Format fuer Land ist nicht korrekt</div>");
      }else{
	//$UstStatus = $this->app->erp->CheckUst($ust,"SE556459933901","Wind River AB","Kista","Finlandsgatan 52","16493","ja");	
	
	$UstStatus = $this->app->erp->CheckUst("DE263136143", $ust, $name, $ort, $strasse, $plz, $druck="nein");

	if(is_array($UstStatus) && !is_numeric($UstStatus))
	{
	  $tmp = new USTID();
	  $msg = $tmp->errormessages($UstStatus['ERROR_CODE']);

	  if($UstStatus['ERROR_CODE']==200)
	    $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">UST g&uuml;ltig aber Name, Ort oder PLZ wird anders geschrieben!</div>");  
	  else
	    $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"error\">Fehlgeschlagen Code:<br>{$UstStatus['ERROR_CODE']}($msg)</div>");  

	  $this->app->Tpl->Set(ERG_NAME, $UstStatus['ERG_NAME']);
	  $this->app->Tpl->Set(ERG_PLZ, $UstStatus['ERG_PLZ']);
	  $this->app->Tpl->Set(ERG_STR, $UstStatus['ERG_STR']);
	  $this->app->Tpl->Set(ERG_ORT, $UstStatus['ERG_ORT']);

	} else if($UstStatus==1){
	  $this->app->Tpl->Set(STATUS,"<div style=\"background-color: green;\">Vollst&auml;ndig</div>");
	  // jetzt brief bestellen! 
	  // $UstStatus = $this->app->erp->CheckUst("DE263136143", $ust, $name, $ort, $strasse, $plz, $druck="ja");
	  // $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","Online-Abfrage OK + Brief bestellt", "'.$this->app->User->GetName().'")');
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Online-Pr&uuml;fung erfolgreich!</div>");
	  $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(),	status="erfolgreich" WHERE id='.$lid.'');
	} else {
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Allgemeiner Fehler! Es wurde kein Brief bestellt!<br><br>".$UstStatus."</div>");
	  $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","'.$UstStatus.'", "'.$this->app->User->GetName().'")');
	  $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(),	status="allgemeiner fehler" WHERE id='.$lid.'');
	}
	
      }			
      } else {

	if($status=="fehlgeschlagen")
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Die Abfrage ist inaktiv da sie als fehlgeschlagen bereits markiert worden ist!</div>");
	else
	{
	   $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Online-Pr&uuml;fung erfolgreich!</div>");
	}
      }
    } 

    $briefbestellt = $this->app->DB->Select("SELECT briefbestellt FROM ustprf WHERE id='$lid' LIMIT 1");

    if($this->app->Secure->GetPOST("brief")!="" && $briefbestellt=="0000-00-00" && $datum_online!="0000-00-00 00:00:00")
    {
      $UstStatus = $this->app->erp->CheckUst("DE263136143", $ust, $name, $ort, $strasse, $plz, $druck="ja");
      $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","Online-Abfrage OK + Brief bestellt", "'.$this->app->User->GetName().'")');
      $this->app->DB->Update('UPDATE ustprf SET briefbestellt=NOW() WHERE id='.$lid.'');
      $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Brief wurde bestellt!</div>");
    } else if ($briefbestellt!="0000-00-00")
    {
      $briefbestellt = $this->app->String->Convert($briefbestellt,"%1-%2-%3","%3.%2.%1");
      $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Brief wurde bereits am $briefbestellt bestellt!</div>");
      $this->app->Tpl->Set(BESTELLT,$briefbestellt);
    }
    else if ($datum_online=="0000-00-00 00:00:00")
    {
      $briefbestellt = $this->app->String->Convert($briefbestellt,"%1-%2-%3","%3.%2.%1");
      $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Brief kann auf Grund erfolgloser Online-Pr&uuml;fung nicht bestellt werden!</div>");
      $this->app->Tpl->Set(BESTELLT,$briefbestellt);
    }


    if($this->app->Secure->GetPOST("benachrichtigen") != "")
    {

	if($status=="benachrichtig" || $status=="fehlgeschlagen")
	{
	  if($status=="fehlgeschlagen")
	    $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">UST-Pr&uuml;fung wurde bereits als fehlgeschlagen markiert! Kunde wurde ebenfalls bereits benachrichtigt!</div>");
	  else
	    $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Kunde wurde bereits benachrichtigt!</div>");
	} else {
	  //echo "ACHTUNG hier muss noch eine MAIL versendet werden!!!!";

	  $mailtext = $this->app->Secure->GetPOST("mailtext");

	  $to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$id' LIMIT 1"); 
	  $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$id' LIMIT 1"); 
	  $to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$id' LIMIT 1"); 

	  $this->app->erp->MailSend($this->app->erp->GetFirmaMail(),$this->app->erp->GetFirmaName(),$to,$to_name,"Your Tax ID number",$mailtext);
	  $this->app->DB->Insert("INSERT INTO dokumente_send (id,dokument,zeit,bearbeiter,adresse,projekt,art,betreff,text) VALUES('','vatid',NOW(),'".$this->app->User->GetName()."','$id','$projekt','email','Your Tax ID number','$mailtext')");

	  $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","Kunde wurde benachrichtigt", "'.$this->app->User->GetName().'")');
	  $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(),	status="benachrichtig" WHERE id='.$lid.'');
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Kunde wurde per Mail benachrichtigt!</div>");
	}
    }

    if($this->app->Secure->GetPOST("manuellok") != "")
    {
      $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","Manuell auf OK gesetzt", "'.$this->app->User->GetName().'")');
      $this->app->DB->Update('UPDATE ustprf SET briefbestellt=NOW(),datum_online=NOW(),status="erfolgreich" WHERE id='.$lid.'');
      $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">Wurde manuell auf OK gesetzt!</div>");
    }

    

    if($this->app->Secure->GetPOST("fehlgeschlagen") != "" && $briefbestellt=="0000-00-00")
    {
	if($status=="fehlgeschlagen")
	{
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">UST-Pr&uuml;fung wurde bereits als fehlgeschlagen markiert! Kunde wurde ebenfalls bereits benachrichtigt!</div>");
	} else 
	{
	  echo "ACHTUNG hier muss noch eine MAIL versendet werden!!!! wenn man das will??????";
	  $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(),	status="fehlgeschlagen" WHERE id='.$lid.'');
	  $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$lid.',"'.date("Y-m-d H:i:s").'","Abfrage als fehlgeschlagen markiert", "'.$this->app->User->GetName().'")');
	  $this->app->Tpl->Set(STATUSMELDUNG,"<div class=\"warning\">UST-Pr&uuml;fung wurde als fehlgeschlagen markiert! Kunde wurde per Mail benachrichtigt!</div>");
	}
    }

    $datum_brief = $this->app->DB->Select("SELECT datum_brief FROM ustprf WHERE id='$lid' LIMIT 1");
    if($datum_brief!='0000-00-00')
    {
      $datum_brief = $this->app->String->Convert($datum_brief ,"%1-%2-%3","%3.%2.%1");
      $this->app->Tpl->Set(EINGANG,$datum_brief);

    }
    

    $this->AdresseMenu();

    $this->app->Tpl->Set(SUBHEADING,"UST-ID Pr&uuml;fung neu anlegen");
    $this->app->FormHandler->FormGetVars("ustprf",$lid);

    $name = $this->app->DB->Select("SELECT name FROM ustprf WHERE id='$lid'");
    $ort = $this->app->DB->Select("SELECT ort FROM ustprf WHERE id='$lid'");
    $land = $this->app->DB->Select("SELECT land FROM ustprf WHERE id='$lid'");

    $this->app->Tpl->Set(SUCHE,"$name+$ort+$land");

    $this->app->Tpl->Set(ID,$id);
    
    if($ust != "")
      $this->app->Tpl->Set(USTID, $ust);
   
    if($this->app->Secure->GetPOST("name") != "")
      $this->app->Tpl->Set(NAME, $this->app->Secure->GetPOST("name"));  
   
    if($this->app->Secure->GetPOST("ort") != "")
      $this->app->Tpl->Set(ORT, $this->app->Secure->GetPOST("ort"));
      
    if($this->app->Secure->GetPOST("plz") != "")
      $this->app->Tpl->Set(PLZ, $this->app->Secure->GetPOST("plz"));
    
    if($this->app->Secure->GetPOST("strasse") != "")
      $this->app->Tpl->Set(STRASSE, $this->app->Secure->GetPOST("strasse"));


    $this->app->Tpl->Set(ID,$this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1"));
    $this->app->Tpl->Set(LAND,$this->app->DB->Select("SELECT land FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1"));
    $this->app->Tpl->Set(STATUS,$this->app->DB->Select("SELECT status FROM ustprf WHERE id='$lid' LIMIT 1"));
    
    //$this->AdresseProtokoll($lid);

    $this->app->Tpl->Parse(INHALT,"ustprfedit.tpl");
    $this->app->Tpl->Parse(PAGE,"rahmen_submit.tpl");
  }

  function AdresseProtokoll($lid)
  {
    if($lid!=""){
    $table = new EasyTable($this->app);

    $table->Query("SELECT DATE_FORMAT(zeit, '%d.%m.%Y %H:%i') AS Datum, bemerkung,bearbeiter FROM ustprf_protokoll WHERE ustprf_id='$lid' ORDER BY zeit DESC", 0, "noAction");

    $table->DisplayNew(PROTOKOLL,"", "noAction");

    }
  }


	function AdresseKundeArtikel()
	{

  	$this->AdresseMenu();

    $this->app->YUI->TableSearch(TAB1,"adresseartikel");

    $this->app->Tpl->Parse(PAGE,"adresseartikel.tpl");

	}

  function AdresseLieferantArtikel()
  {
    $this->AdresseMenu();
    $this->app->Tpl->Set(HEADING,"Adresse (offene Bestelungen)");
    $this->app->Tpl->Set(SUBSUBHEADING,"Letzten Bestellungen");
    $id = $this->app->Secure->GetGET("id");
    $produktion = $this->app->Secure->GetGET("produktion");
    $jahr = $this->app->Secure->GetGET("jahr");
 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $table = new EasyTable($this->app);

$table->Query("SELECT  a.name_de, a.nummer, e.bestellnummer, (SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=a.id) as lager, (SELECT SUM(b.menge)-SUM(b.geliefert) FROM bestellung_position b, bestellung be WHERE b.artikel=a.id AND be.id=b.bestellung) as 'in bestellung Allgemein', (SELECT SUM(b.menge)-SUM(b.geliefert) FROM bestellung_position b, bestellung be WHERE b.artikel=a.id AND be.id=b.bestellung AND be.adresse='$id') as inbestellunglieferant FROM artikel a, einkaufspreise e WHERE a.id=e.artikel AND e.adresse='$id' GROUP By a.name_de");
    $table->DisplayNew(INHALT,"Warten auf Lieferung bei diesem Lieferant", "noAction");
/*
    //$this->app->Tpl->Set(INHALT,"<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");

    if($jahr=="") $jahr = date('Y');


    for($i=1;$i<13;$i++)
    {
    	if($i < 10) $j = "0".$i;
    	else $j = $i;
    	$sql .="(SELECT SUM(ap.menge) FROM  auftrag_position ap, auftrag auf WHERE ap.artikel=a.id AND auf.id=ap.auftrag AND auf.status='abgeschlossen' AND DATE_FORMAT(auf.datum,'%Y-%m')='$jahr-$j' ) as a$j,";
}
    $this->app->Tpl->Set(SUBSUBHEADING,"Artikel");

    $this->app->Tpl->Set(INHALT,"<a href=\"/index.php?module=adresse&action=lieferantartikel&id=$id&produktion=1\">Hier klicken f&uuml;r nur laufende Produktionen</a><br><br>");
    //Formula lieferadresse
    $table = new EasyTable($this->app);

  if($produktion=="1")
    $produktion = "AND a.produktion=1";

    $table->Query("SELECT  a.name_de, a.nummer, a.mindestlager, (SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=a.id) as lager,
     (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=a.id) as reserviert,
      (SELECT SUM(ap.menge) FROM  auftrag_position ap, auftrag auf WHERE ap.artikel=a.id AND auf.id=ap.auftrag AND auf.status='freigegeben' ) as auftrag,
      (SELECT SUM(ap.menge) FROM  auftrag_position ap, auftrag auf WHERE ap.artikel=a.id AND auf.id=ap.auftrag AND auf.status='abgeschlossen' ) as verkaufte, $sql
      (SELECT SUM(bp.menge - bp.geliefert) FROM  bestellung_position bp WHERE bp.artikel=a.id AND bp.geliefert < bp.menge ) as bestellung

    FROM artikel a WHERE a.adresse='$id' $produktion GROUP BY a.name_de ");

//$table->Query("SELECT  a.name_de, a.nummer, (SELECT SUM(l.menge) FROM lager_platz_inhalt l WHERE l.artikel=a.id) as lager FROM artikel a WHERE a.adresse='$id' GROUP By a.name_de");
    //FROM artikel a WHERE a.lagerartikel=2 GROUP BY a.id ");
    $table->DisplayNew(INHALT,"bestellung", "noAction");


    // easy table mit arbeitspaketen YUI als template 
*/
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Set(TABTEXT,"Artikel&uuml;bersicht");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");

  }

  function AdresseBestellungMarkiert()
  {
    $id = $this->app->Secure->GetGET("id");
    $sid = $this->app->Secure->GetGET("sid");


    // markieren

    $geliefert = $this->app->DB->Select("SELECT geliefert FROM bestellung_position WHERE id='$sid' LIMIT 1");
    $menge  = $this->app->DB->Select("SELECT menge FROM bestellung_position WHERE id='$sid' LIMIT 1");
    $tmp = $menge - $geliefert;
    if($tmp < 0) $tmp=0;
    $this->app->DB->Update("UPDATE bestellung_position SET abgeschlossen='1', mengemanuellgeliefertaktiviert='$tmp', geliefert='$menge',manuellgeliefertbearbeiter='".$this->app->User->GetName()."' WHERE id='$sid' LIMIT 1");

    header("Location: index.php?module=adresse&action=offenebestellungen&id=$id&cmd=offeneartikel");
    exit;


  }


  function AdresseOffeneBestellungen()
  {

    $cmd = $this->app->Secure->GetGET("cmd");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(ID,$id);

      
    $this->AdresseMenu();


	$this->app->Tpl->Set(UEBERSCHRIFT1,"Bestellungen");
	$this->app->Tpl->Set(INFORMATIONSTEXT,"Alle Bestellungen bei aktuellem Lieferant.");
	//Formula lieferadresse
	$table = new EasyTable($this->app);
	$table->Query("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as Bestelldatum, if(belegnr,belegnr,'ohne Nummer') as beleg, name, status, 
		DATE_FORMAT(versendet_am,'%d.%m.%Y') versendet_am, versendet_durch, versendet_per, id
		FROM bestellung WHERE adresse='$id' order by datum DESC, id DESC LIMIT 10");
	$table->DisplayNew(INHALT, "<a href=\"index.php?module=bestellung&action=edit&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/edit.png\"></a>
		<a href=\"index.php?module=bestellung&action=pdf&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/pdf.png\"></a>
		<a onclick=\"if(!confirm('Wirklich kopieren?')) return false; else window.location.href='index.php?module=bestellung&action=copy&id=%value%';\">
		<img src=\"./themes/[THEME]/images/copy.png\" border=\"0\"></a>
		");
	$summe = $this->app->DB->Select("SELECT SUM(bp.menge*bp.preis) FROM bestellung_position bp LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN projekt p ON p.id=bp.projekt WHERE b.adresse='$id'");
	$this->app->Tpl->Set(EXTEND,"Gesamt: $summe EUR");

	// easy table mit arbeitspaketen YUI als template 
	$this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
	$this->app->Tpl->Set(TAB1SELECT,"selected");
	$this->app->Tpl->Set(EXTEND,"");
	$this->app->Tpl->Set(INHALT,"");




	$this->app->Tpl->Set(UEBERSCHRIFT1,"Offen Artikel");
	$this->app->Tpl->Set(INFORMATIONSTEXT,"Alle noch nicht gelieferten Artikel bei aktuellem Lieferant. Jederzeit kann mit dem Pfeil eine Artikel als geliefert markiert werden. <br>Hinweis: Eigentlich
	  sollte jeder Artikel durch die Paketdistribution aus dieser Liste bei der Lieferung verschwinden.");

	$this->app->Tpl->Set(SUBSUBHEADING,"Offene Artikel");
	//Formula lieferadresse
	$table = new EasyTable($this->app);
	$table->Query("SELECT DATE_FORMAT(b.datum,'%d.%m.%Y') as Bestellung, bp.bezeichnunglieferant as name, bp.bestellnummer as nummer,
	  if(bp.lieferdatum,DATE_FORMAT(bp.lieferdatum,'%d.%m.%Y'),'sofort') as lieferdatum,
	   p.abkuerzung, bp.menge, bp.geliefert, FORMAT(bp.preis,2) as preis, bp.id
	  FROM bestellung_position bp LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN projekt p ON p.id=bp.projekt WHERE b.adresse='$id' AND bp.geliefert < bp.menge AND bp.abgeschlossen IS NULL ORDER by datum DESC");
	$table->DisplayNew(INHALT, "
		<a onclick=\"if(!confirm('Wirklich als geliefert markieren?')) return false; else window.location.href='index.php?module=adresse&action=adressebestellungmarkieren&sid=%value%&id=[ID]';\">
		<img src=\"./themes/[THEME]/images/right.png\"  width=\"18\"border=\"0\"></a>
		","geliefert");

	// easy table mit arbeitspaketen YUI als template 
	$this->app->Tpl->Parse(TAB2,"rahmen70.tpl");

	$this->app->Tpl->Set(TAB2SELECT,"selected");
	$this->app->Tpl->Set(INHALT,"");



	$this->app->Tpl->Set(UEBERSCHRIFT1,"Abgeschlossene Artikel");
	$this->app->Tpl->Set(INFORMATIONSTEXT,"Alle abgeschlossenen Artikel der Bestellungen.");

	//Formula lieferadresse
	$table = new EasyTable($this->app);
	$table->Query("SELECT DATE_FORMAT(b.datum,'%d.%m.%Y') as Bestellung, b.belegnr, bp.bezeichnunglieferant as name, bp.bestellnummer as nummer, 
	  if(bp.lieferdatum,DATE_FORMAT(bp.lieferdatum,'%d.%m.%Y'),'sofort') as lieferdatum, p.abkuerzung as projekt, bp.menge, bp.geliefert, bp.id
	  FROM bestellung_position bp LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN projekt p ON p.id=bp.projekt WHERE b.adresse='$id' AND (bp.geliefert >= bp.menge  OR bp.abgeschlossen='1') ORDER by datum DESC");
	$table->DisplayNew(INHALT,"preis", "noAction");

	// easy table mit arbeitspaketen YUI als template 
	$this->app->Tpl->Parse(TAB3,"rahmen70.tpl");

    $this->app->Tpl->Parse(PAGE,"adressebestellung.tpl");

  }


  function AdresseAnsprechpartnerPopup()
  {
  $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
/*
    //if($frame=="false")
    //{
      // hier nur fenster größe anpassen
    //  $this->app->YUI->IframeDialog(500,400);
    //} else {
      // nach page inhalt des dialogs ausgeben
//      $sid = $this->app->DB->Select("SELECT artikel FROM artikel_artikelgruppe WHERE id='$id' LIMIT 1");
      //$widget = new WidgetVerkaufspreise(&$this->app,PAGE);
      //$widget->form->SpecialActionAfterExecute("close_refresh",
      //  "index.php?module=artikel&action=verkauf&id=$sid");


      // neue warengruppe hinzugefuegt
      $artikelgruppe = $this->app->Secure->GetPOST("artikelgruppe");
      $ok= $this->app->Secure->GetPOST("ok");
      if($artikelgruppe!="" && $ok=="") $this->app->DB->Insert("INSERT INTO artikel_artikelgruppe (id,artikel,artikelgruppe) VALUES ('','$id','$artikelgruppe')");


      //warengruppe geloescht
      $sid= $this->app->Secure->GetGET("sid");
      $cmd= $this->app->Secure->GetGET("cmd");
      if($sid!="" && $cmd=="del") $this->app->DB->DELETE("DELETE FROM artikel_artikelgruppe WHERE id='$sid' LIMIT 1");
      if($sid!="" && $cmd=="image") $this->app->DB->DELETE("UPDATE artikel SET standardbild='$sid' WHERE id='$id' LIMIT 1");

      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$id' LIMIT 1");
      $this->app->Tpl->Set(SUBSUBHEADING,"Online-Shop Attribute: $name ($nummer)");
      $this->app->Tpl->Set(AKTIV_TAB1,"selected");

      //Warengruppen
      $tmp = new EasyTable(&$this->app);
      $tmp->Query("SELECT a.bezeichnung, aa.id FROM artikel_artikelgruppe aa LEFT JOIN artikelgruppen a ON a.id=aa.artikelgruppe WHERE artikel='$id'");
      $tmp->DisplayNew(WARENGRUPPEN,"<a href=\"#\" onclick=\"if(!confirm('Wirklich löschen?')) return false; else window.location.href='index.php?module=artikel&cmd=del&action=onlineshop&id=$id&sid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>");

      $shop = $this->app->DB->Select("SELECT shop FROM artikel WHERE id='$id' LIMIT 1");

      $arr = $this->app->DB->SelectArr("SELECT bezeichnung,id FROM artikelgruppen WHERE shop='$shop'");

      foreach($arr as $key=>$value)
  $html.="<option value=\"{$value[id]}\">{$value[bezeichnung]}</option>";

      $this->app->Tpl->Add(WARENGRUPPEN,"<center><select name=\"artikelgruppe\">$html</select>");
      $this->app->Tpl->Add(WARENGRUPPEN,"<input type=submit value=\"hinzuf&uuml;gen\"></center>");

      // standard bild
      $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$id'");
      $tmp = new EasyTable(&$this->app);
      $tmp->Query("SELECT d.titel, d.id FROM datei d LEFT JOIN datei_stichwoerter s ON d.id=s.datei  
      LEFT JOIN datei_version v ON v.datei=d.id
      WHERE s.objekt='Artikel' AND s.parameter='$id' AND s.subjekt='Shopbild' AND d.geloescht=0");

      $tmp->DisplayNew(HAUPTBILD,
  "<a href=\"#\" onclick=\"if(!confirm('Als Standard definieren?')) return false; else window.location.href='index.php?module=artikel&action=onlineshop&cmd=image&id=$id&sid=%value%';\"><img src=\"./themes/[THEME]/images/ack.png\" border=\"0\"></a>");

      $standardbild_name = $this->app->DB->Select("SELECT titel FROM datei WHERE id='$standardbild'");
      $this->app->Tpl->Add(HAUPTBILD,"<br>Standardbild: <b>$standardbild_name</b>");



      $this->app->Tpl->Parse(PAGE,"onlineshop.tpl");
*/
			$this->AdresseAnsprechpartner();
      $this->app->BuildNavigation=false;

  }



  function AdresseAnsprechpartner()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
    $lid = $this->app->Secure->GetGET("lid");
    $delete = $this->app->Secure->GetGET("delete");
    $create= $this->app->Secure->GetGET("create");

    $iframe = $this->app->Secure->GetGET("iframe");

    if($iframe=="true")
      $this->app->BuildNavigation=false;


    if($delete==1)
    {
      $this->app->DB->Delete("DELETE FROM ansprechpartner WHERE id='$lid' AND adresse='$id' LIMIT 1"); 
      header("Location: index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe");
      exit;
    }
/*
    if($create==1)
    {
      $this->app->DB->Delete("INSERT INTO lieferadressen (id,name,adresse) VALUES ('','Neuer Datensatz','$id')"); 
      $lid = $this->app->DB->GetInsertID();
      header("Location: index.php?module=adresse&action=lieferadresse&id=$id&lid=$lid&iframe=$iframe");
      exit;
    }
*/
 
    // neues arbeitspaket
    $widget = new WidgetAnsprechpartner(&$this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe");
    if($lid > 0)
{
  $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe");
    $widget->Edit();
}
    else
  {
    $widget->Create();
  }

		if($iframe=="true") $einfuegen = "<a onclick=\"Ansprechpartner('%value%'); parent.closeIframe();\"><img src=\"./themes/[THEME]/images/down.png\" border=\"0\"></a>";
    //Formula lieferadresse
    $table = new EasyTable($this->app);
    $table->Query("SELECT name, bereich, email, telefon, telefax, id FROM ansprechpartner WHERE adresse='$id' AND name!='Neuer Datensatz' ORDER by name,strasse");
    $table->DisplayNew(TABNEXT, "<a href=\"index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe&lid=%value%\">
        <img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a><a onclick=\"if(!confirm('Ansprechpartner wirklich l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=ansprechpartner&delete=1&iframe=$iframe&id=$id&lid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>$einfuegen","","id",$id);

    // easy table mit arbeitspaketen YUI als template 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");

		if($iframe=="true")
			$this->app->Tpl->Parse(PAGE,"ansprechpartneruebersicht_popup.tpl");
		else
			$this->app->Tpl->Parse(PAGE,"ansprechpartneruebersicht.tpl");

/*
    $this->AdresseMenu();
    $iframe = $this->app->Secure->GetGET("iframe");

    if($iframe=="true")
      $this->app->BuildNavigation=false;



    $id = $this->app->Secure->GetGET("id");
    $lid = $this->app->Secure->GetGET("lid");
    $delete = $this->app->Secure->GetGET("delete");
    $create= $this->app->Secure->GetGET("create");

    if($delete==1)
    {
      $this->app->DB->Delete("DELETE FROM ansprechpartner WHERE id='$lid' AND adresse='$id' LIMIT 1"); 
    }

    if($create==1)
    {
      $this->app->DB->Delete("INSERT INTO ansprechpartner (id,name,adresse) VALUES ('','Neuer Datensatz','$id')"); 
      $lid = $this->app->DB->GetInsertID();
      header("Location: index.php?module=adresse&action=ansprechpartner&id=$id&lid=$lid&iframe=$iframe");
      exit;
    }
 

    // neues arbeitspaket
    $widget = new WidgetAnsprechpartner(&$this->app,TAB2);
   // $widget->form->SpecialActionAfterExecute("none",
   //     "index.php?module=adresse&action=ansprechpartner&id=$id");
   // $widget->Create();
    if($lid > 0)
    {
      $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe");

      $widget->Edit();
    }
    else
{
      $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=ansprechpartner&id=$id&iframe=$iframe");


     $widget->Create();

}

    //Formula ansprechpartner
    $table = new EasyTable($this->app);
    $table->Query("SELECT name, bereich, telefon, email,id FROM ansprechpartner WHERE adresse='$id' AND name!='Neuer Datensatz'");
    $table->DisplayOwn(INHALT, "<a href=\"index.php?module=adresse&action=ansprechpartner&iframe=$iframe&id=$id&lid=%value%\">
        <img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a><a onclick=\"if(!confirm('Ansprechpartner wirklich l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=ansprechpartner&delete=1&iframe=$iframe&id=$id&lid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>","30","id",$id);


    // easy table mit arbeitspaketen YUI als template 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Parse(PAGE,"ansprechpartneruebersicht.tpl");
*/
  }

  function AdresseAnsprechpartnerEditPopup()
  {
    $frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
 
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(600,320);
    } else {
      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetAnsprechpartner(&$this->app,PAGE);
      $adresse = $this->app->DB->Select("SELECT adresse FROM ansprechpartner WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=adresse&action=ansprechpartner&id=$adresse");

      $widget->Edit();
      $this->app->BuildNavigation=false;
    }
  }
 


  function AdresseLieferadressePopup()
  {
   $frame = $this->app->Secure->GetGET("frame");
   $id = $this->app->Secure->GetGET("id");
/*
    if($frame=="false")
    {
      $this->app->YUI->IframeDialog(650,730);
    } else {

      // nach page inhalt des dialogs ausgeben
      //$sid = $this->app->DB->Select("SELECT shop FROM shopexport_kampange WHERE id='$id' LIMIT 1");

      $this->AdresseLieferadresse();
      //$widget = new WidgetShopexport_kampange(&$this->app,PAGE);

      //$widget->form->SpecialActionAfterExecute("close_refresh",
      //  "index.php?module=marketing&action=kampangenedit&id=$sid");

      //$widget->Edit();
*/
			$this->AdresseLieferadresse();
      $this->app->BuildNavigation=false;
 //   }
  }


  function AdresseLieferadresse()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
    $lid = $this->app->Secure->GetGET("lid");
    $delete = $this->app->Secure->GetGET("delete");
    $create= $this->app->Secure->GetGET("create");

    $iframe = $this->app->Secure->GetGET("iframe");

    if($iframe=="true")
      $this->app->BuildNavigation=false;


    if($delete==1)
    {
      $this->app->DB->Delete("DELETE FROM lieferadressen WHERE id='$lid' AND adresse='$id' LIMIT 1"); 
      header("Location: index.php?module=adresse&action=lieferadresse&id=$id&iframe=$iframe");
      exit;
    }
/*
    if($create==1)
    {
      $this->app->DB->Delete("INSERT INTO lieferadressen (id,name,adresse) VALUES ('','Neuer Datensatz','$id')"); 
      $lid = $this->app->DB->GetInsertID();
      header("Location: index.php?module=adresse&action=lieferadresse&id=$id&lid=$lid&iframe=$iframe");
      exit;
    }
*/ 
    // neues arbeitspaket
    $widget = new WidgetLieferadressen(&$this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=lieferadresse&id=$id&iframe=$iframe");
    if($lid > 0)
{
  $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=adresse&action=lieferadresse&id=$id&iframe=$iframe");
    $widget->Edit();
}
    else
  {
    $widget->Create();
  }

    //Formula lieferadresse
    if($iframe=="true") $einfuegen = "<a onclick=\"Lieferadresse('%value%'); parent.closeIframe();\"><img src=\"./themes/[THEME]/images/down.png\" border=\"0\"></a>";
    $table = new EasyTable($this->app);
    $table->Query("SELECT name, strasse, land, plz, ort,id FROM lieferadressen WHERE adresse='$id' AND name!='Neuer Datensatz' ORDER by name,strasse");
    $table->DisplayNew(TABNEXT, "<a href=\"index.php?module=adresse&action=lieferadresse&id=$id&iframe=$iframe&lid=%value%\">
        <img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a><a onclick=\"if(!confirm('Lieferadresse wirklich l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=lieferadresse&delete=1&iframe=$iframe&id=$id&lid=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>$einfuegen","","id",$id);

    // easy table mit arbeitspaketen YUI als template 
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");

		if($iframe=="true")
			$this->app->Tpl->Parse(PAGE,"lieferadressenuebersicht_popup.tpl");
		else
			$this->app->Tpl->Parse(PAGE,"lieferadressenuebersicht.tpl");

  }

  function AdresseLieferadressenEditPopup()
  {
    $frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
 
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(600,320);
    } else {
      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetLieferadressen(&$this->app,PAGE);
      $adresse = $this->app->DB->Select("SELECT adresse FROM lieferadressen WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=adresse&action=lieferadresse&id=$adresse");

      $widget->Edit();
      $this->app->BuildNavigation=false;
    }
  }
 

  function AdresseBrief()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
    $sid = $this->app->Secure->GetGET("sid");


    // NEU füllen
 //   $widget = new WidgetBrief(&$this->app,TAB2);
 //   $widget->form->SpecialActionAfterExecute("none",
 //       "index.php?module=adresse&action=brief&id=$id");
 //   $widget->Create();

    /* START */
    $adresse = $id;
    //$this->app->erp->DokumentMask(TAB2,"brieffax",$sid,$adresse);
    /* ENDE */



    // UEBERSICHT füllen
    $this->app->Tpl->Set(HEADING,"Adresse");
//    $this->app->Tpl->Set(SUBHEADING,"Korrespondenzen <a class=\"fancy_briefeditpopup\" data-fancybox-type=\"iframe\" href=\"./index.php?module=korrespondenz&action=create&user=$id\">[Neu]</a>");

$buttons .= "
<a onclick=\"KorrPopup('./index.php?module=korrespondenz&action=create&user=$id')\" href=\"#\">
  <table width=\"110\"><tr><td>Korrespondenz</td></tr></table></a>";
$buttons .= "
<a onclick=\"KorrPopup('./index.php?module=korrespondenz&action=create&user=$id')\" href=\"#\">
  <table width=\"110\"><tr><td>E-Mail</td></tr></table></a>";
$buttons .= "
<a onclick=\"KorrPopup('./index.php?module=korrespondenz&action=create&user=$id')\" href=\"#\">
  <table width=\"110\"><tr><td>Telefonat</td></tr></table></a>";
$buttons .= "
<a onclick=\"KorrPopup('./index.php?module=korrespondenz&action=create&user=$id')\" href=\"#\">
  <table width=\"110\"><tr><td>Notiz</td></tr></table></a>";





$this->app->Tpl->Set(SUBHEADING,'<fieldset><legend>Neu Anlegen</legend><div class="tabsbutton" align="center">'.$buttons.'</div></fieldset><br><br>Korrespondenzen');


    $adresse = $this->app->User->GetAdresse();

    //Korrespondenzen
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(d.created,'%d.%m.%Y %H:%i') as 'Erstellt am', d.betreff, d.von, d.send_as as Art, if(d.sent,'<center>ja</center>','') as versendet,d.id FROM dokumente d
									 WHERE d.adresse_to='$id' AND (d.deleted=0 OR d.deleted IS NULL) AND d.typ='brieffax' ORDER by d.created DESC");

    $table->DisplayNew(INHALT, "<a onClick=\"javascript:KorrPopup('index.php?module=korrespondenz&action=edit&user=$id&id=%value%');makeRequest(this);return false\" href=\"#\">
				<img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich  l&ouml;schen?')) return false; else window.location.href='index.php?module=korrespondenz&action=delete&id=%value%';\">
        <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
	<a href=\"index.php?module=korrespondenz&action=pdf&id=%value%\"><img src=\"./themes/[THEME]/images/pdf.png\" border=\"0\"></a>");

/*
    $table->Query("SELECT DATE_FORMAT(d.zeit,'%d.%m.%Y %H:%i') as datum, d.betreff, d.bearbeiter,p.abkuerzung as projekt,d.art, if(d.versendet,'<center>ja</center>','') as versendet,d.id FROM dokumente_send d  LEFT JOIN projekt p ON p.id=d.projekt
      WHERE d.adresse='$id' AND d.geloescht=0 AND d.dokument='brieffax' ORDER by d.zeit DESC");
    $table->DisplayNew(INHALT, "<a class=\"fancy_briefeditpopup\" data-fancybox-type=\"iframe\" href=\"index.php?module=adresse&action=briefeditpopup&frame=false&id=$id&sid=%value%\" 
        onclick=\"makeRequest(this);return false\"><img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a>
        <a onclick=\"if(!confirm('Wirklich  l&ouml;schen?')) return false; else window.location.href='index.php?module=adresse&action=briefdelete&id=$id&sid=%value%';\">
        <img src=\"./themes/[THEME]/images/delete.gif\" border=\"0\"></a>
  <a href=\"index.php?module=adresse&action=briefpdf&sid=%value%&id=$id\"><img src=\"./themes/[THEME]/images/pdf.png\" border=\"0\"></a>");





*/
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBHEADING,"Begleitschreiben zur RE, LS, AB, AN, BE, GS");
    $adresse = $this->app->User->GetAdresse();

    //Korrespondenzen
    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(d.zeit,'%d.%m.%Y %H:%i') as datum, d.betreff, d.bearbeiter,p.abkuerzung as projekt,d.art, if(d.versendet,'<center>ja</center>','') as versendet,d.id FROM dokumente_send d  LEFT JOIN projekt p ON p.id=d.projekt
      WHERE d.adresse='$id' AND d.geloescht=0 AND d.dokument!='brieffax' ORDER by d.zeit DESC");
    $table->DisplayNew(INHALT, "<a href=\"\"><img src=\"./themes/[THEME]/images/edit.png\" border=\"0\"></a> 
	<a href=\"index.php?module=adresse&action=briefpdf&sid=%value%&id=$id\"><img src=\"./themes/[THEME]/images/pdf.png\" border=\"0\"></a>
");
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBHEADING,"Tickets");

    //Korrespondenzen
    $table = new EasyTable($this->app);
        $table->Query("SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y') as zeit, t.prio, CONCAT(LEFT(tn.betreff,30),'...') as betreff, tn.verfasser, 
	  (SELECT COUNT(tn.id) FROM ticket_nachricht as tn WHERE tn.ticket=t.schluessel) as Antworten,
          tn.id FROM ticket as t, ticket_nachricht as tn WHERE t.schluessel=tn.ticket 
          AND t.adresse='$id'
          ORDER by t.prio, tn.zeit");

    $table->DisplayNew(INHALT,"<a href=\"index.php?module=ticket&action=assistent&id=%value%&lesen=1\" target=\"_blank\">Lesen</a>");

    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

 
    $this->app->Tpl->Set(INHALT,"");
    $this->app->Tpl->Set(SUBHEADING,"E-Mails");

    //Korrespondenzen
    $table = new EasyTable($this->app);
     $table->Query("SELECT DATE_FORMAT(empfang,'%d.%m.%Y') as zeit, CONCAT(LEFT(subject,30),'...') as betreff, sender as verfasser, id FROM emailbackup_mails WHERE adresse='$id'");
    $table->DisplayNew(INHALT,"<a href=\"index.php?module=webmail&action=view&id=%value%\">Lesen</a>");

    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

 
 
    // PARSE
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");

    $this->app->Tpl->Parse(PAGE,"briefuebersicht.tpl");

  }



  function AdresseBriefEditPopup()
  {
    $frame = $this->app->Secure->GetGET("frame");
    $id= $this->app->Secure->GetGET("id");
    $sid= $this->app->Secure->GetGET("sid");

    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(800,650,"index.php?module=adresse&action=briefeditpopup&id=$id&sid=$sid");
    } else {

      $adresse = $id;

      $typ = $this->app->DB->Select("SELECT dokument FROM dokumente_send WHERE id='$sid' LIMIT 1");
      //$parameter = $this->app->DB->Select("SELECT parameter FROM dokumente_send WHERE id='$sid' LIMIT 1");
      $parameter = $sid;

      //echo "typ = $typ ".$parameter;

      $this->app->erp->DokumentMask(PAGE,$typ,$parameter,$adresse,'',true);
  
      $this->app->BuildNavigation=false;
    }
  }


  function AdresseBriefDelete()
  {
    $sid = $this->app->Secure->GetGET("sid");
    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Update("UPDATE dokumente_send SET geloescht=1 WHERE id='$sid' LIMIT 1");

    $this->AdresseBrief();
  }

  function AdresseBriefPDF()
  {
    $sid = $this->app->Secure->GetGET("sid");
    $id = $this->app->Secure->GetGET("id");

    //$Brief = new Geschaeftsbrief(&$this->app,$sid);
    $Brief = new BriefPDF(&$this->app);
    $Brief->GetBrief($sid);
    $Brief->displayDocument();

    $this->AdresseBrief();
  }


  function AdresseAuftraege()
  {
    $this->AdresseMenu();

		$this->app->YUI->TableSearch(TAB1,"belege");

    $this->app->Tpl->Parse(PAGE,"adresseauftraege.tpl");

  }



  function AdresseEmail()
  {
    $this->AdresseMenu();


    // NEU füllen
    $widget = new WidgetEmail(&$this->app,TAB2);
    $widget->Create();

    // UEBERSICHT füllen
    $this->app->Tpl->Set(HEADING,"Adresse");
    $this->app->Tpl->Set(SUBHEADING,"Email schreiben");
    $adresse = $this->app->User->GetAdresse();

    //Offene Aufgaben
    $table = new EasyTable($this->app);
    $table->Query("SELECT betreff, id FROM email");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=adresse&action=emaileditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Bearbeiten</a>");
    $this->app->Tpl->Parse(TAB1,"rahmen.tpl");

    // PARSE
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");

    $this->app->Tpl->Parse(PAGE,"emailuebersicht.tpl");

  }



  function AdresseEmailEditPopup()
  {
    $frame = $this->app->Secure->GetGET("frame");
    if($frame=="false")
    {
      // hier nur fenster größe anpassen
      $this->app->YUI->IframeDialog(510,610);
    } else {
      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetEmail(&$this->app,PAGE);
      $widget->Edit();
      $this->app->BuildNavigation=false;
    }
  }




  function AdresseSuchmaske()
  {
    $typ=$this->app->Secure->GetGET("typ");

    $this->app->Tpl->Set(HEADING,"Suchmaske f&uuml;r Adressen");
    $table = new EasyTable($this->app);
    switch($typ) {
      case "auftragrechnung":
	$table->Query("SELECT typ,name, ort, plz, strasse, abteilung, unterabteilung, ustid, email, adresszusatz, id as kundeadressid, id FROM adresse WHERE geloescht=0
	order by name");
      break;
      case "auftraglieferschein":
	$table->Query("SELECT typ as liefertyp, name as liefername, ort as lieferort, plz as lieferplz, strasse as lieferstrasse, abteilung as lieferabteilung, unterabteilung
	as lieferunterabteilung, adresszusatz as lieferadresszusatz, id as lieferadressid  FROM adresse WHERE geloescht=0 order by name");
      break;
      default:
	$table->Query("SELECT typ,name, ort, plz, strasse, abteilung, unterabteilung, ustid, email, adresszusatz, id as kundeadressid, id FROM adresse WHERE geloescht=0 order by name");
    }
 
    $table->DisplayWithDelivery(PAGE);

    $this->app->BuildNavigation=false;
  }



  function AdresseKundevorlage()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
    // prufe ob es schon einen eintrag gibt
    $check = $this->app->DB->Select("SELECT id FROM kundevorlage WHERE adresse='$id' LIMIT 1");
    if( !($check > 0 && is_numeric($check)))
    {
      $this->app->DB->Insert("INSERT INTO kundevorlage (id,adresse) VALUES ('','$id')");
    }

    $check = $this->app->DB->Select("SELECT id FROM kundevorlage WHERE adresse='$id' LIMIT 1");
    $this->app->Secure->GET['id']=$check;
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $widget = new WidgetKundevorlage(&$this->app,PAGE);
    $widget->Edit();
    $this->app->Secure->GET['id']=$id;
  }

  function AdresseAddPosition()
  {
    $sid = $this->app->Secure->GetGET("sid");
    $id = $this->app->Secure->GetGET("id");
    $menge = $this->app->Secure->GetGET("menge");
    $datum  = $this->app->Secure->GetGET("datum");
    $datum  = $this->app->String->Convert($datum,"%1.%2.%3","%3-%2-%1");
    $this->app->erp->AddAdressePosition($id, $sid,$menge,$datum);
    
    header("Location: index.php?module=adresse&action=artikel&id=$id");
    exit;
  }

  function AdresseLieferantvorlage()
  {

  //zahlungsweise   zahlungszieltage  zahlungszieltageskonto  zahlungszielskonto  versandart
  //zahlungsweiselieferant  zahlungszieltagelieferant   zahlungszieltageskontolieferant   zahlungszielskontolieferant   versandartlieferant
		$arr = $this->app->DB->SelectArr("SELECT id,kundennummerlieferant FROM adresse WHERE lieferantennummer >0");

		foreach($arr as $key=>$value)
		{
			if($value['kundennummerlieferant']=="")
			{
				$id = $value['id'];
    		$kundennummer = $this->app->DB->Select("SELECT kundennummer FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    		$zahlungsweiselieferant = $this->app->DB->Select("SELECT zahlungsweise FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    		$zahlungszieltagelieferant = $this->app->DB->Select("SELECT zahlungszieltage FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    		$zahlungszieltageskontolieferant = $this->app->DB->Select("SELECT zahlungszielskonto FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    		$versandartlieferant = $this->app->DB->Select("SELECT versandart FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");

				if($kundennummer !="")	
				{
					echo "UPDATE adresse SET kundennummerlieferant='$kundennummer',zahlungsweiselieferant='$zahlungsweiselieferant',
                                  zahlungszieltagelieferant='$zahlungszieltagelieferant',zahlungszieltageskontolieferant='$zahlungszieltageskontolieferant',
                                  versandartlieferant='$versandartlieferant' WHERE id='$id';";
				} 
			}

		}

		
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");
    // prufe ob es schon einen eintrag gibt
    $check = $this->app->DB->Select("SELECT id FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    if( !($check > 0 && is_numeric($check)))
    {
      $this->app->DB->Insert("INSERT INTO lieferantvorlage (id,adresse) VALUES ('','$id')");
    }

    $check = $this->app->DB->Select("SELECT id FROM lieferantvorlage WHERE adresse='$id' LIMIT 1");
    $this->app->Secure->GET['id']=$check;
    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $widget = new WidgetLieferantvorlage(&$this->app,PAGE);
    $widget->Edit();
    $this->app->Secure->GET['id']=$id;
  }




  function AdresseArtikelPosition()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");

    /* neu anlegen formular */
    $artikelart = $this->app->Secure->GetPOST("artikelart");
    $bezeichnung = $this->app->Secure->GetPOST("bezeichnung");
    $vpe = $this->app->Secure->GetPOST("vpe");
    $umsatzsteuerklasse = $this->app->Secure->GetPOST("umsatzsteuerklasse");
    $waehrung = $this->app->Secure->GetPOST("waehrung");
    $projekt= $this->app->Secure->GetPOST("projekt");
    $preis = $this->app->Secure->GetPOST("preis");
    $preis = str_replace(',','.',$preis);
    $menge = $this->app->Secure->GetPOST("menge");
    $lieferdatum = $this->app->Secure->GetPOST("lieferdatum");
    $zahlzyklus = $this->app->Secure->GetPOST("zahlzyklus");
    $wiederholend= $this->app->Secure->GetPOST("wiederholend");
    $startdatum= $this->app->Secure->GetPOST("startdatum");

    if($lieferdatum=="") $lieferdatum=date("d.m.Y");


    $anlegen_artikelneu = $this->app->Secure->GetPOST("anlegen_artikelneu");

    if($anlegen_artikelneu!="")
    { 

      if($bezeichnung!="" && $menge!="" && $preis!="")
      { 

        $neue_nummer = $this->app->erp->NeueArtikelNummer($artikelart);

        // anlegen als artikel
        $this->app->DB->Insert("INSERT INTO artikel (id,typ,nummer,projekt,name_de,umsatzsteuer,adresse,firma)  
         VALUES ('','$artikelart','$neue_nummer','$projekt','$bezeichnung','$umsatzsteuerklasse','$lieferant','".$this->app->User->GetFirma()."')");

        $artikel_id = $this->app->DB->GetInsertID();
        // einkaufspreis anlegen

        $this->app->DB->Insert("INSERT INTO verkaufspreise (id,artikel,adresse,objekt,projekt,preis,ab_menge,angelegt_am,bearbeiter)
          VALUES ('','$artikel_id','$id','Standard','$projekt','$preis','$menge',NOW(),'".$this->app->User->GetName()."')");

        $lieferdatum = $this->app->String->Convert($lieferdatum,"%1.%2.%3","%3-%2-%1");
        $startdatum= $this->app->String->Convert($startdatum,"%1.%2.%3","%3-%2-%1");

       $this->app->DB->Insert("INSERT INTO abrechnungsartikel (id,artikel,bezeichnung,nummer,menge,preis, sort,lieferdatum, steuerklasse, status,projekt,wiederholend,zahlzyklus,adresse,startdatum) 
         VALUES ('','$artikel_id','$bezeichnung','$neue_nummer','$menge','$preis','$sort','$lieferdatum','$umsatzsteuerklasse','angelegt','$projekt','$wiederholend','$zahlzyklus','$id','$startdatum')");

        header("Location: index.php?module=adresse&action=artikel&id=$id");
        exit;
      } else
        $this->app->Tpl->Set(NEUMESSAGE,"<div class=\"error\">Bestellnummer, bezeichnung, Menge und Preis sind Pflichfelder!</div>");

    }

    $ajaxbuchen = $this->app->Secure->GetPOST("ajaxbuchen");
    if($ajaxbuchen!="")
    {
      $artikel = $this->app->Secure->GetPOST("artikel");
      $nummer = $this->app->Secure->GetPOST("nummer");
      $projekt = $this->app->Secure->GetPOST("projekt");
      $projekt = $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$projekt' LIMIT 1");
      $sort = $this->app->DB->Select("SELECT MAX(sort) FROM angebot_position WHERE auftrag='$id' LIMIT 1");
      $sort = $sort + 1;
      $artikel_id = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1");
      $bezeichnung = $artikel;
      $neue_nummer = $nummer;
      $waehrung = 'EUR';
      $umsatzsteuerklasse = $this->app->DB->Select("SELECT umsatzsteuerklasse FROM artikel WHERE nummer='$nummer' LIMIT 1");
      $vpe = 'einzeln';

//        $this->app->DB->Insert("INSERT INTO angebot_position (id,angebot,artikel,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
//          VALUES ('','$id','$artikel_id','$bezeichnung','$neue_nummer','$menge','$preis','$waehrung','$sort','$lieferdatum','$umsatzsteuerklasse','angelegt','$projekt','$vpe')");
    }


    if(1)
    {
      $this->app->Tpl->Set(ARTIKELART,$this->app->erp->GetSelect($this->app->erp->GetArtikelart(),$artikelart));
      $this->app->Tpl->Set(VPE,$this->app->erp->GetSelect($this->app->erp->GetVPE(),$vpe));
      $this->app->Tpl->Set(WAEHRUNG,$this->app->erp->GetSelect($this->app->erp->GetWaehrung(),$vpe));
      $this->app->Tpl->Set(UMSATZSTEUERKLASSE,$this->app->erp->GetSelect($this->app->erp->GetUmsatzsteuerklasse(),$umsatzsteuerklasse));
      $this->app->Tpl->Set(PROJEKT,$this->app->erp->GetProjektSelect($projekt));
      $this->app->Tpl->Set(PREIS,$preis);
      $this->app->Tpl->Set(MENGE,$menge);
      $this->app->Tpl->Set(LIEFERDATUM,$lieferdatum);
      $this->app->Tpl->Set(ZAHLZYKLUS,$zahlzyklus);
      $this->app->Tpl->Set(BEZEICHNUNG,$bezeichung);

      $this->app->Tpl->Set(SUBSUBHEADING,"Neuen Artikel anlegen");
//      $this->app->Tpl->Parse(INHALT,"aboabrechnungsartikel_artikelneu.tpl");
 //     $this->app->Tpl->Set(EXTEND,"<input type=\"submit\" value=\"Artikel anlegen\" name=\"anlegen_artikelneu\">");
      $this->app->Tpl->Parse(UEBERSICHT,"rahmen70.tpl");
      $this->app->Tpl->Set(EXTEND,"");
      $this->app->Tpl->Set(INHALT,"");

      /* ende neu anlegen formular */
   /* ende neu anlegen formular */


//      $this->app->Tpl->Add(TAB1,"Artikelstamm");
/*
      $lieferant = $this->app->DB->Select("SELECT adresse FROM angebot WHERE id='$id' LIMIT 1");
      $table = new EasyTable($this->app);
      $table->Query("SELECT CONCAT(LEFT(a.name_de,80),'...') as artikel, a.nummer, 
              v.ab_menge as ab, v.preis, p.abkuerzung as projekt,
              CONCAT('<input type=\"text\" size=\"8\" value=\"00.00.0000\" id=\"datum',v.id,'\">
              <img src=\"./themes/[THEME]/images/kalender.png\" height=\"12\" onclick=\"displayCalendar(document.forms[1].datum',v.id,',\'dd.mm.yyyy\',this)\" border=0 align=right>') as Lieferdatum, 
              CONCAT('<input type=\"text\" size=\"3\" value=\"\" id=\"menge',v.id,'\">') as menge, v.id as id
              FROM artikel a LEFT JOIN verkaufspreise v ON a.id=v.artikel LEFT JOIN projekt p ON v.projekt=p.id WHERE v.ab_menge>=1 AND a.lagerartikel!=1 AND a.juststueckliste!=1 AND a.stueckliste!=1 LIMIT 10");
      
$table->DisplayNew(INHALT, "<input type=\"button\" 
              onclick=\"document.location.href='index.php?module=adresse&action=addposition&id=$id&sid=%value%&menge=' + document.getElementById('menge%value%').value + '&datum=' + document.getElementById('datum%value%').value;\" value=\"anlegen\">");  
      $this->app->Tpl->Parse(UEBERSICHT,"rahmen70.tpl");
      $this->app->Tpl->Set(INHALT,"");
*/
			$this->app->YUI->TableSearch('UEBERSICHT','abrechnungsartikel');
            // child table einfuegen

      $this->app->Tpl->Set(SUBSUBHEADING,"Positionen");
      $menu = array("up"=>"upartikel",
                          "down"=>"downartikel",
                          //"add"=>"addstueckliste",
                          "edit"=>"positioneneditpopup",
                          "del"=>"delartikel");

      $sql = "SELECT a.name_de as Artikel, p.abkuerzung as projekt, a.nummer as nummer, b.nummer as nummer, DATE_FORMAT(lieferdatum,'%d.%m.%Y') as lieferdatum, b.menge as menge, b.preis as preis, b.id as id
                FROM angebot_position b
                LEFT JOIN artikel a ON a.id=b.artikel LEFT JOIN projekt p ON b.projekt=p.id 
                WHERE b.angebot='$id'";


 // wiederholende artikel
    $this->app->Tpl->Add(TAB1,"wiederholende Artikel");
    $sql = "SELECT aa.bezeichnung,aa.nummer, DATE_FORMAT(aa.abgerechnetbis,'%d.%m.%Y') as abgerechnet, 
        aa.preis as preis, aa.menge as menge, aa.id as id
        FROM abrechnungsartikel aa
        WHERE aa.adresse='$id' AND aa.wiederholend=1";
    $this->app->YUI->SortList(INHALT,&$this,$menu,$sql,false);
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(INHALT,"");


    // einmalige artikel
    $this->app->Tpl->Add(TAB1,"einmalige Artikel");
    $sql = "SELECT aa.bezeichnung, aa.nummer, DATE_FORMAT(aa.abgerechnetbis,'%d.%m.%Y') as abgerechnet, 
        aa.preis as preis, aa.menge as menge, aa.id as id
        FROM abrechnungsartikel aa
        WHERE aa.adresse='$id' AND aa.wiederholend=0 AND aa.abgerechnet=0";
    $this->app->YUI->SortList(INHALT,&$this,$menu,$sql,false);
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
      

      if($anlegen_artikelneu!="")
        $this->app->Tpl->Set(AKTIV_TAB2,"selected");
      else
        $this->app->Tpl->Set(AKTIV_TAB1,"selected");
      $this->app->Tpl->Parse(PAGE,"angebot_positionuebersicht.tpl");
    }
  }


  function AdresseArtikel()
  {
    $this->AdresseMenu();
    $id = $this->app->Secure->GetGET("id");

    // neues arbeitspaket
    //$widget = new WidgetAbrechnungsartikel(&$this->app,TAB2);
    //$widget->Create();


    // child table einfuegen

    $menu = array("up"=>"upartikel",
                  "down"=>"downartikel",
                  //"add"=>"addstueckliste",
                  "edit"=>"artikeleditpopup",
                  "del"=>"delartikel");

    // wiederholende artikel
    $this->app->Tpl->Set(SUBSUBHEADING,"wiederholende Artikel");
    $sql = "SELECT aa.bezeichnung, DATE_FORMAT(aa.abgerechnetbis,'%d.%m.%Y') as abgerechnet, 
	aa.preis as preis, aa.menge as menge, aa.id as id
        FROM abrechnungsartikel aa
        WHERE aa.adresse='$id' AND aa.wiederholend=1";
    $this->app->YUI->SortList(INHALT,&$this,$menu,$sql,false);
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");
    $this->app->Tpl->Set(INHALT,"");


    // einmalige artikel
    $this->app->Tpl->Set(SUBSUBHEADING,"einmalige Artikel");
    $sql = "SELECT aa.bezeichnung, DATE_FORMAT(aa.abgerechnetbis,'%d.%m.%Y') as abgerechnet, 
	aa.preis as preis, aa.menge as menge, aa.id as id
        FROM abrechnungsartikel aa
        WHERE aa.adresse='$id' AND aa.wiederholend=0 AND aa.abgerechnet=0";
    $this->app->YUI->SortList(INHALT,&$this,$menu,$sql,false);
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Set(AKTIV_TAB1,"selected");
    $this->app->Tpl->Parse(PAGE,"artikeluebersicht.tpl");
  }

  function AdresseArtikelEditPopup()
  {
   $id = $this->app->Secure->GetGET("id");

      // nach page inhalt des dialogs ausgeben
      //$widget = new WidgetAbrechnungsartikel(&$this->app,PAGE);
      $sid = $this->app->DB->Select("SELECT adresse FROM abrechnungsartikel WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh",
        "index.php?module=adresse&action=artikel&id=$sid");
      $widget->Edit();
      $this->app->BuildNavigation=false;
  }

  function UpArtikel()
  {
    $this->app->YUI->SortListEvent("up","abrechnungsartikel","adresse");
    $this->AdresseArtikel();
  }

  function DownArtikel()
  {
    $this->app->YUI->SortListEvent("down","abrechnungsartikel","adresse");
    $this->AdresseArtikel();
  }


  function DelArtikel()
  {
    $this->app->YUI->SortListEvent("del","abrechnungsartikel","adresse");
    $this->AdresseArtikel();
  }



}

?>
