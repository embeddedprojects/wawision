<?php
include ("_gen/projekt.php");

class Projekt extends GenProjekt {
  var $app;
  
  function Projekt($app) {
    //parent::GenProjekt($app);
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","ProjektCreate");
    $this->app->ActionHandler("edit","ProjektEdit");
    $this->app->ActionHandler("list","ProjektList");
    $this->app->ActionHandler("delete","ProjektDelete");
    $this->app->ActionHandler("dateien","ProjektDateien");
    $this->app->ActionHandler("zeit","ProjektZeit");
    $this->app->ActionHandler("material","ProjektMaterial");
    $this->app->ActionHandler("arbeitspaket","ProjektArbeitspaket");
    $this->app->ActionHandler("arbeitspaketeditpopup","ProjektArbeitspaketEditPopup");
    $this->app->ActionHandler("arbeitspaketdelete","ProjektArbeitspaketDelete");
    $this->app->ActionHandler("arbeitspaketdisable","ProjektArbeitspaketDisable");
    $this->app->ActionHandler("arbeitspaketcopy","ProjektArbeitspaketCopy");

    $this->app->ActionHandler("kostenstellen","ProjektKostenstellen");
    $this->app->ActionHandler("schaltung","ProjektSchaltung");

    $this->app->ActionHandlerListen(&$app);

    $id = $this->app->Secure->GetGET("id");
    //$nummer = $this->app->Secure->GetPOST("nummer");

    $name = $this->app->DB->Select("SELECT name FROM projekt WHERE id='$id' LIMIT 1");
    $abk= $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");


    $this->app->Tpl->Set(UEBERSCHRIFT,"Projekt: ".$name." ($abk)");
    $this->app->Tpl->Set(FARBE,"[FARBE1]");


    $this->app = $app;
  }

	function ProjektDelete()
	{
		$ref = $_SERVER['HTTP_REFERER'];
		$id = $this->app->Secure->GetGET('id');
		if(is_numeric($id)) {
			$this->app->DB->Delete("DELETE FROM projekt WHERE id='$id' LIMIT 1");
		}
		header("Location: $ref");
		exit;
	}

  function ProjektDateien()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ProjektMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Dateien)");
    $this->app->YUI->DateiUpload(PAGE,"Projekt",$id);
  }
  

  function ProjektZeit()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ProjektMenu();
    $this->app->Tpl->Set(SUBSUBHEADING,"Zeitkonten");

    $this->app->Tpl->Set(TABTEXT,"Zeiterfassung");

    $table = new EasyTable($this->app);
    $table->Query("SELECT DATE_FORMAT(bis, GET_FORMAT(DATE,'EUR')) AS Datum, DATE_FORMAT(von,'%H:%i') as start, DATE_FORMAT(bis,'%H:%i') as ende,
    TIMEDIFF(bis, von) AS Dauer,
    aufgabe as Taetigkeit, 'nein' as abgrechnet
    FROM zeiterfassung
    WHERE projekt=$id
    ORDER BY bis DESC
    ");

    $table->DisplayNew(INHALT, "Abgrechnet","noAction");

    $summe = $this->app->DB->Select("SELECT FORMAT(SUM(TIMEDIFF(bis, von))/10000,2) FROM zeiterfassung WHERE (art='' OR art='Arbeit') AND projekt='$id' AND abgerechnet!='1'");
    $summegesamt=$summe;

    $summeeur = $this->ProjektOffeneZeit($id);

    $this->app->Tpl->Add(INHALT,"<br>Summe offen: $summe Summe gesamt: $summegesamt<br>");
    $this->app->Tpl->Add(INHALT,"Summe offen: $summeeur EUR");

    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }
 

  function ProjektMaterial()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ProjektMenu();
    $this->app->Tpl->Set(TABTEXT,"Materialeinsatz");
    $this->app->Tpl->Set(SUBSUBHEADING,"Positionen aus Bestellungen");
    $table = new EasyTable($this->app);
    $table->Query("SELECT  bp.bezeichnunglieferant as artikel, a.name as lieferant,b.belegnr as bestellung, bp.menge, bp.preis,menge*preis as gesamt, if(bp.abgerechnet,'ja','nein') as rechung FROM bestellung_position bp 
    LEFT JOIN bestellung b ON bp.bestellung=b.id LEFT JOIN adresse a ON b.adresse=a.id WHERE bp.projekt='$id' ORDER By bp.bestellung");

    $table->DisplayNew(INHALT, "abgerechnet","noAction");

    $summe = $this->app->DB->Select("SELECT  SUM(menge*preis) FROM bestellung_position WHERE projekt='$id' AND abgerechnet!='1' ORDER By bestellung");
    $summevk= $this->ProjektOffenesMaterial($id);
    $summegesamt = $summe;

    $this->app->Tpl->Add(INHALT,"<br>Summe offen: $summe ");
    $this->app->Tpl->Add(INHALT,"<br>Summe offen: $summevk ");
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");

    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBSUBHEADING,"Positionen aus Lieferungen");
    $table = new EasyTable($this->app);
    $table->Query("SELECT  bp.menge, bp.bezeichnung as artikel, bp.seriennummer, b.belegnr as lieferschein, if(bp.abgerechnet,'ja','nein') as rechnung FROM lieferschein_position bp 
    LEFT JOIN lieferschein b ON bp.lieferschein=b.id LEFT JOIN adresse a ON b.adresse=a.id WHERE b.projekt='$id' ORDER By bp.lieferschein");

    $table->DisplayNew(INHALT, "abgerechnet","noAction");

    $summe = $this->app->DB->Select("SELECT  SUM(menge*preis) FROM bestellung_position WHERE projekt='$id' AND abgerechnet!='1' ORDER By bestellung");
    $summegesamt = $summe;

    //$this->app->Tpl->Add(INHALT,"<br>Summe offen: $summe Summe gesamt: $summegesamt<br>");
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");


    $this->app->Tpl->Set(INHALT,"");

    $this->app->Tpl->Set(SUBSUBHEADING,"Material im Lager");
    $table = new EasyTable($this->app);
    $table->Query("SELECT  DISTINCT a.name_de as artikel, a.nummer, lp.kurzbezeichnung as regal, lpi.menge, a.hersteller FROM lager_platz_inhalt lpi
    LEFT JOIN artikel a ON a.id=lpi.artikel LEFT JOIN lager_platz lp ON lpi.lager_platz=lp.id WHERE a.projekt='$id' GROUP BY a.id");

    $table->DisplayNew(INHALT, "abgerechnet","noAction");

    $summe = $this->app->DB->Select("SELECT  SUM(menge*preis) FROM bestellung_position WHERE projekt='$id' AND abgerechnet!='1' ORDER By bestellung");
    $summegesamt = $summe;

    //$this->app->Tpl->Add(INHALT,"<br>Summe offen: $summe Summe gesamt: $summegesamt<br>");
    $this->app->Tpl->Parse(TAB1,"rahmen70.tpl");


    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

  function ProjektOffenesMaterial($id)
  {
    $summe = $this->app->DB->Select("SELECT  SUM(menge*preis) FROM bestellung_position WHERE projekt='$id' AND abgerechnet!='1' ORDER By bestellung");
    $summevk= $summe*((100 + $this->app->erp->GetStandardMarge())/100);
    $summegesamt = $summe;
    return $summevk;
  }

  function ProjektOffeneZeit($id)
  {
    $summe = $this->app->DB->Select("SELECT FORMAT(SUM(TIMEDIFF(bis, von))/10000,2) FROM zeiterfassung WHERE (art='' OR art='Arbeit') AND projekt='$id' AND abgerechnet!='1'");
    $summeeur = $summe*$this->app->erp->GetStandardStundensatz();

    return $summeeur;
  }
 

  function ProjektSchaltung()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ProjektMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Schaltung)");
    $this->app->Tpl->Set(PAGE,"
      <br>Neues Teilprojekt anlegen: <br>
  Name:<input type=text value=\"KUBUS 3B\"><br>Budget: <input type=text><br>Liefertermin: <input type=text value=>
<br><br>
<br><br>
<table border=1><tr><td>Teilprojekt</td><td>Aktion</td></tr>
<tr><td>Prototyp 1 KUBUS 3B</td><td><a>BOM</a>&nbsp;<a>Lagerbestand</a>&nbsp;<a>Bestellung</a>&nbsp;<a>Datenblaetter</a>&nbsp;<a>Schaltplan u. Layout</a>&nbsp;<a>Projekt Charter</a></td>
<tr><td>SNOM Stick</td><td><a>BOM</a>&nbsp;<a>Lagerbestand</a>&nbsp;<a>Bestellung</a>&nbsp;<a>Datenblaetter</a>&nbsp;<a>Schaltplan u. Layout</a>&nbsp;<a>Projekt Charter</a></td>
</table>
<br><br>
	 Prototyp 1 (inkl. eagle, stuecklisten, fertigungsauftrag fuer prototype, prueflisten, lagerbestand, bestellungsauftrag usw..)<br>Budget<br>Kostenstellen (ende mit 1)");
  }
  

  function ProjektKostenstellen()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->ProjektMenu();
    $this->app->Tpl->Add(UEBERSCHRIFT," (Kostenstellen)");



    $summezeit = $this->ProjektOffeneZeit($id);
    $summevk = $this->ProjektOffenesMaterial($id);

    $kosten = $summezeit + $summevk;

    $this->app->Tpl->Set(PAGE,"Kostenstellen Filter: <select><option>Gesamt</option><option>Teilprojekt 1</option></select><br>

<br><br>Projektabrechnung
<ul>
<li>Material</li>
<li>Personal</li>
<li>5% Logistik (Versandkosten etc, Telefon)</li>
<li>pauschal 49,99 EUR Projekt im WAWI mit Kudencenter Zugang</li>
</ul>

<br><br>Project Charter</br>
<ul>
<li>Stueckliste</li>
<li>Schaltplan</li>
<li>InbetriebnahmeProtokoll</li>
<li>Techniche Hinweise</li>
<li>Lager Inhalt</li>
</ul>


<br><br>
Kosten f&uuml;r Kunde aktuell: $kosten EUR

<br><br><br><br><table>
	<tr><td>Kostenstelle</td><td>Nr.</td><td>betrag</td></tr>
	<tr><td>Personal</td><td>1000</td><td>$summezeit EUR</td></tr>
	<tr><td>fremdleistungen</td><td>1000</td><td>00,00 EUR</td></tr>
	<tr><td>vebrauchsmaterial</td><td>1000</td><td>$summevk EUR</td></tr>
	<tr><td>lagerbestand</td><td>1000</td><td>00,00 EUR</td></tr>
	<tr><td>geräte/inventar</td><td>1000</td><td>00,00 EUR</td></tr>
	<tr><td>entwicklungsbedarf</td><td>1000</td><td>00,00 EUR</td></tr>
	<tr><td>sonsitges</td><td>1000</td><td>00,00 EUR</td></tr>
	<tr><td>porto</td><td>1000</td><td>00,00 EUR</td></tr>
	</table><br><br>Und jetzt im Vergleich mit Verkauf -> ROI<br><br>Ergebnis:<font color=red>Achtung das Projekt bringt nichts!!!</font>");
  }
  


  function ProjektCreate()
  {
    $this->app->Tpl->Add(TABS,
      "<a class=\"tab\" href=\"index.php?module=projekt&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a>");
    parent::ProjektCreate();
  }

  function ProjektList()
  {

    //$this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=create","Neues Projekt anlegen");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");

    $this->app->Tpl->Set(UEBERSCHRIFT,"Projekte");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Projekte");

    $this->app->YUI->TableSearch(TAB1,"projekttabelle");
    $this->app->Tpl->Parse(PAGE,"projektuebersicht.tpl");
/*

    $this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=projekt&action=create\">Neues Projekt anlegen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=projekt&action=search\">Projekt suchen</a></li>");
    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=projekt&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    $this->app->Tpl->Add(TABS,"<li><br><br></li>");
    parent::ProjektList();
*/
  }

  
  function ProjektMenu()
  {
    $id = $this->app->Secure->GetGET("id");
    $abk= $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");
    $name= $this->app->DB->Select("SELECT name FROM projekt WHERE id='$id' LIMIT 1");


    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Projekt $abk");
    $this->app->Tpl->Add(KURZUEBERSCHRIFT2,$name);

    $this->app->erp->MenuEintrag("index.php?module=projekt&action=edit&id=$id","Details");
//    $this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=projekt&action=edit&id=$id\">Adressen</a></li>");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=dateien&id=$id","Dateien");
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=projekt&action=schaltung&id=$id\">Schaltungen</a></li>");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=kostenstellen&id=$id","Kostenstellen");
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=projekt&action=edit&id=$id\">Kosten</a></li>");
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=projekt&action=edit&id=$id\">Wareneingang</a></li>");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=zeit&id=$id","Zeiterfassung");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=material&id=$id","Material");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=arbeitspaket&id=$id","Arbeitspakete");
    //$this->app->Tpl->Add(TABS,"<a href=\"index.php?module=projekt&action=kosten&id=$id\">Gesamtkalkulation</a>&nbsp;");
    $this->app->erp->MenuEintrag("index.php?module=projekt&action=list","Zur&uuml;ck zur &Uuml;bersicht");
  }

 function ArbeitspaketReadDetails($index,&$ref)
  {

  }

  function ProjektArbeitspaket()
  {
    $this->ProjektMenu();
   
    $id = $this->app->Secure->GetGET("id");
    // neues arbeitspaket
    $widget = new WidgetArbeitspaket(&$this->app,TAB2);
 		$widget->form->SpecialActionAfterExecute("none",
        "index.php?module=projekt&action=arbeitspaket&id=$id#tabs-1");
    $this->app->Tpl->Set(TMPSCRIPT,"<script type=\"text/javascript\">$(document).ready(function(){ $('#tabs').tabs('select', 1); });</script>");

    $widget->Create();


    // easy table mit arbeitspaketen YUI als template 
    $this->app->YUI->TableSearch(TAB1,"arbeitspakete");

    $this->app->Tpl->Parse(PAGE,"arbeitspaketeuebersicht.tpl");
  }

  function ProjektArbeitspaketEditPopup()
  {
    $this->ProjektMenu();
    //$frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(OPENDISABLE,"<!--");
    $this->app->Tpl->Set(CLOSEDISABLE,"-->");


    $sid = $this->app->DB->Select("SELECT projekt FROM arbeitspaket WHERE id='$id' LIMIT 1");
/*
    $this->ArtikelMenu($sid);
    $artikel = $this->app->DB->Select("SELECT CONCAT(name_de,' (',nummer,')') FROM artikel WHERE id='$sid' LIMIT 1");
    $this->app->Tpl->Set(UEBERSCHRIFT,"Artikel: ".$artikel);
    $this->app->Tpl->Add(UEBERSCHRIFT," (Einkauf)");
*/
    $this->app->Tpl->Set(ABBRECHEN,"<input type=\"button\" value=\"Abbrechen\" onclick=\"window.location.href='index.php?module=projekt&action=arbeitspaket&id=$sid';\">");

      $widget = new WidgetArbeitspaket(&$this->app,TAB1);
    $widget->form->SpecialActionAfterExecute("close_refresh",
  "index.php?module=projekt&action=arbeitspaket&id=$sid#tabs-1");
    $widget->Edit();


    $this->app->Tpl->Add(TAB2,"Sie bearbeiten gerade ein Arbeitspaket. Erst nach dem Speichern k&ouml;nnen neue Arbeitspakete angelegt werden.");
/*
    $widget = new WidgetEinkaufspreise(&$this->app,TAB2);
    $widget->form->SpecialActionAfterExecute("none",
        "index.php?module=artikel&action=einkauf&id=$id");
    $widget->Create();
*/
    $this->app->Tpl->Parse(PAGE,"arbeitspaketeuebersicht.tpl");
  }

	
  function ProjektArbeitspaketDisable()
  {
 //   $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Update("UPDATE arbeitspaket SET abgenommen=1,abgenommen_von='".$this->app->User->GetID()."' WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT projekt FROM arbeitspaket WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=projekt&action=arbeitspaket&id=".$sid);
    exit;

  }

  function ProjektArbeitspaketDelete()
  {
//    $this->ArtikelMenu();
    $id = $this->app->Secure->GetGET("id");

    $this->app->DB->Update("UPDATE arbeitspaket SET geloescht='1' WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT projekt FROM arbeitspaket WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=projekt&action=arbeitspaket&id=".$sid);
    exit;
  }


  function ProjektArbeitspaketCopy()
  {
    $id = $this->app->Secure->GetGET("id");

    $id = $this->app->DB->MysqlCopyRow("arbeitspaket","id",$id);
    $this->app->DB->Update("UPDATE arbeitspaket SET geloescht='0', abgenommen='0', abgenommen_von='0', abgenommen_bemerkung='' WHERE id='$id' LIMIT 1");

    //$this->app->DB->Update("UPDATE einkaufspreise SET geloescht='1' WHERE id='$id' LIMIT 1");
    $sid = $this->app->DB->Select("SELECT projekt FROM arbeitspaket WHERE id='$id' LIMIT 1");
    header("Location: index.php?module=projekt&action=arbeitspaket&id=".$sid);
    exit;


  }


  function ProjektEdit()
  {
    $this->ProjektMenu();
    $id = $this->app->Secure->GetGET("id");

    $msg = $this->app->Secure->GetGET("msg");
    $msg = base64_decode($msg);

    $this->app->Tpl->Set(MESSAGE,$msg);
    $this->app->Tpl->Set(TMPSCRIPT,"");


    $allowed = "/[^a-z0-9]/i";      
    $this->app->Secure->POST["abkuerzung"] = preg_replace($allowed,"",$this->app->Secure->POST["abkuerzung"]); 
    $this->app->Secure->POST["abkuerzung"]=substr(strtoupper($this->app->Secure->POST["abkuerzung"]),0,20);



    parent::ProjektEdit();

    if($this->app->Secure->GetPOST("speichern")!="")
    {
      if($this->app->Secure->GetGET("msg")=="")
      {
        $msg = $msg.$this->app->Tpl->Get(MESSAGE);
        $msg = base64_encode($msg);
      } else {
        $msg = base64_encode($msg);
      }

      header("Location: index.php?module=projekt&action=edit&id=$id&msg=$msg");
      exit;
    }


  }



}

?>
