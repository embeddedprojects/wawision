<?php

class Etikettendrucker {
  var $app;
  
  function Etikettendrucker($app) {
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","EtikettendruckerCreate");
    $this->app->ActionHandler("edit","EtikettendruckerEdit");
    $this->app->ActionHandler("list","EtikettendruckerList");

    $this->app->DefaultActionHandler("list");

    $this->app->ActionHandlerListen(&$app);
  }


  function EtikettendruckerCreate()
  {
  }

  function EtikettendruckerList()
  {

		$drucken = $this->app->Secure->GetPOST("drucken");

		$bezeichnung1 = $this->app->Secure->GetPOST("bezeichnung1");
		$bezeichnung2 = $this->app->Secure->GetPOST("bezeichnung2");

    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Etikettendrucker");
		$this->app->Tpl->Set(BEZEICHNUNG1,$bezeichnung1);
		$this->app->Tpl->Set(BEZEICHNUNG2,$bezeichnung2);


		if($drucken!="")
		{

			$bezeichnung1 = base64_encode($bezeichnung1);
			$bezeichnung2 = base64_encode($bezeichnung2);
		  HttpClient::quickGet("http://192.168.0.178/druck_string.php?label1=$bezeichnung1&label2=$bezeichnung2");
		}

    $this->app->Tpl->Set(TABTEXT,"Etikettendrucker");
    $this->app->Tpl->Parse(TAB1,"etikettendrucker_list.tpl");
    $this->app->Tpl->Parse(PAGE,"tabview.tpl");
  }

  function EtikettendruckerMenu()
  {
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Etikettendrucker");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=list","Zur&uuml;ck zur &Uuml;bersicht");
  }


  function EtikettendruckerEdit()
  {
  }





}

?>
