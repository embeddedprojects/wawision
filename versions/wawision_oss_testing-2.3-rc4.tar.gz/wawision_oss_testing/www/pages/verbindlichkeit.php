<?php
include ("_gen/verbindlichkeit.php");

class Verbindlichkeit extends GenVerbindlichkeit {
  var $app;
  
  function Verbindlichkeit($app) {
    //parent::GenVerbindlichkeit($app);
    $this->app=&$app;

    $id = $this->app->Secure->GetGET("id");
    if(is_numeric($id))
      $this->app->Tpl->Set(SUBHEADING,": ".
        $this->app->DB->Select("SELECT nummer FROM artikel WHERE id=$id LIMIT 1"));

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","VerbindlichkeitCreate");
    $this->app->ActionHandler("edit","VerbindlichkeitEdit");
    $this->app->ActionHandler("list","VerbindlichkeitList");
    $this->app->ActionHandler("bezahlt","VerbindlichkeitBezahlt");


    $this->app->ActionHandlerListen(&$app);

    $this->app = $app;
  }


  function VerbindlichkeitCreate()
  {
    $this->VerbindlichkeitMenu();
    parent::VerbindlichkeitCreate();
  }


  function VerbindlichkeitBezahlt()
  {
    $id = $this->app->Secure->GetGET("id");
    $this->app->DB->Update("UPDATE verbindlichkeit SET status='bezahlt' WHERE id='$id' LIMIT 1");
    $this->VerbindlichkeitList();
  }

  function VerbindlichkeitList()
  {
    $this->VerbindlichkeitMenu();
    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=artikel&action=search\">Verbindlichkeit suchen</a></li>");

    parent::VerbindlichkeitList();
  }
  function VerbindlichkeitMenu()
  {
    $id = $this->app->Secure->GetGET("id");



		$this->app->Tpl->Add(KURZUEBERSCHRIFT,"Verbindlich- keiten");

    $this->app->erp->MenuEintrag("index.php?module=verbindlichkeit&action=create","Neue Verbindlichkeit anlegen");
    $this->app->erp->MenuEintrag("index.php?module=verbindlichkeit&action=list","Zur&uuml;ck zur &Uuml;bersicht");



//    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=verbindlichkeit&action=searc\">Rechnung Suchen</a></li>");
//    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=verbindlichkeit&action=list\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");



    //$this->app->Tpl->Add(TABS,"<li><a href=\"index.php?module=artikel&action=search\">Verbindlichkeit suchen</a></li>");


  }


  function VerbindlichkeitEdit()
  {
    $this->VerbindlichkeitMenu();
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(ID,$id);


    $freigabe = $this->app->DB->Select("SELECT freigabe FROM verbindlichkeit WHERE id='$id' LIMIT 1");
    $freigabemitarbeiter= $this->app->DB->Select("SELECT freigabemitarbeiter FROM verbindlichkeit WHERE id='$id' LIMIT 1");
    if($freigabemitarbeiter=="" && $freigabe=="1") {
      $this->app->DB->Update("UPDATE verbindlichkeit SET freigabemitarbeiter = '".$this->app->User->GetName()."'  WHERE id='$id' LIMIT 1");
      $freigabemitarbeiter= $this->app->DB->Select("SELECT freigabemitarbeiter FROM verbindlichkeit WHERE id='$id' LIMIT 1");
    }

    $this->app->Tpl->Set(FREIGABEMITARBEITER,"<input type=\"text\" value=\"".$freigabemitarbeiter."\" readonly>");

    $bezahlt= $this->app->DB->Select("SELECT bezahlt FROM verbindlichkeit WHERE id='$id' LIMIT 1");
    $this->app->Tpl->Set(BEZAHLT,"<input type=\"text\" value=\"".$bezahlt."\" readonly>");


    $this->app->Tpl->Set(TABLE_ADRESSE_KONTAKTHISTORIE,"TDB");
    $this->app->Tpl->Set(TABLE_ADRESSE_ROLLEN,"TDB");

    $this->app->Tpl->Set(TABLE_ADRESSE_USTID,"TDB");

    parent::VerbindlichkeitEdit();
  }





}

?>
