<?php
include ("_gen/lager.php");
class Lager extends GenLager {
  var $app;
  function Lager($app) {
    //parent::GenLager($app);
    $this->app = & $app;
    $this->app->ActionHandlerInit($this);
    $this->app->ActionHandler("create", "LagerCreate");
    $this->app->ActionHandler("edit", "LagerEdit");
    $this->app->ActionHandler("list", "LagerList");
    $this->app->ActionHandler("platz", "LagerPlatz");
    $this->app->ActionHandler("bewegung", "LagerBewegung");
    $this->app->ActionHandler("bewegungpopup", "LagerBewegungPopup");
    $this->app->ActionHandler("bestand", "LagerBestand");
    $this->app->ActionHandler("ausgehend", "LagerAusgehend");
    $this->app->ActionHandler("inventur", "LagerInventur");
    $this->app->ActionHandler("platzeditpopup", "LagerPlatzEditPopup");
    $this->app->ActionHandler("delete", "LagerDelete");
    $this->app->ActionHandler("deleteplatz", "LagerDeletePlatz");
    $this->app->ActionHandler("etiketten", "LagerEtiketten");
    $this->app->ActionHandler("zwischenlager", "LagerZwischenlager");
    $this->app->ActionHandler("artikelfuerlieferungen", "LagerArtikelfuerlieferungen");
    $this->app->ActionHandler("produktionslager", "LagerProduktionslager");
    $this->app->ActionHandler("regaletiketten", "LagerRegalEtiketten");
    $this->app->ActionHandler("reservierungen", "LagerReservierungen");
    $this->app->ActionHandler("buchen", "LagerBuchen");
    $this->app->ActionHandler("buchenzwischenlager", "LagerBuchenZwischenlager");
    $this->app->ActionHandler("bucheneinlagern", "LagerBuchenEinlagern");
    $this->app->ActionHandler("buchenauslagern", "LagerBuchenAuslagern");
    $this->app->ActionHandler("artikelentfernen", "LagerArtikelEntfernen");
    $this->app->ActionHandler("artikelentfernenreserviert", "LagerArtikelEntfernenReserviert");
    $id = $this->app->Secure->GetGET("id");
    $nummer = $this->app->Secure->GetPOST("nummer");
    if ($nummer == "") $lager = $this->app->DB->Select("SELECT bezeichnung FROM lager WHERE id='$id' LIMIT 1");
    else $lager = $nummer;
    $woher = $this->app->Secure->GetPOST("woher");
    $action = $this->app->Secure->GetGET("action");
    $cmd = $this->app->Secure->GetGET("cmd");
    if ($action == "bucheneinlagern") if ($cmd == "zwischenlager") $lager = "Zwischenlager";
    else $lager = "Differenz";
    $this->app->Tpl->Set(UEBERSCHRIFT, "Lager: " . $lager);
    $this->app->ActionHandlerListen(&$app);
    $this->app = $app;
  }

  function LagerDeletePlatz()
  {
    $id = $this->app->Secure->GetGET('id');
    //if(is_numeric($id))
    //  $this->app->DB->Delete("DELETE FROM lager WHERE id='$id' LIMIT 1");

		$lager = $this->app->DB->Select("SELECT lager FROM lager_platz WHERE lager='$id' LIMIT 1");

		$this->app->DB->Select("DELETE FROM lager_platz WHERE id='$id' LIMIT 1");
	  $msg = base64_encode("<div class=\"error2\">Der Lagerplatz wurde gel&ouml;scht!</div>");
	

    $ref = $_SERVER['HTTP_REFERER'];
    header("Location: $ref&msg=$msg");
    exit;
  }



  function LagerDelete()
  {
    $id = $this->app->Secure->GetGET('id');
    //if(is_numeric($id))
    //  $this->app->DB->Delete("DELETE FROM lager WHERE id='$id' LIMIT 1");

		$numberofarticles = $this->app->DB->Select("SELECT COUNT(id) FROM lager_platz WHERE lager='$id' LIMIT 1");

		if($numberofarticles > 0)
		{
			$msg = base64_encode("<div class=\"error\">In diesem Lager existieren noch Lagerpl&auml;tze. Es k&ouml;nnen nur leere Lager gel&ouml;scht werden!</div>");
		}
		else {
		  $this->app->DB->Select("DELETE FROM lager WHERE id='$id' LIMIT 1");
		  $msg = base64_encode("<div class=\"error2\">Das Lager wurde gel&ouml;scht!</div>");
		}

    $ref = $_SERVER['HTTP_REFERER'];
    header("Location: $ref&msg=$msg");
    exit;
  }


  function LagerArtikelEntfernenReserviert() {
    $reservierung = $this->app->Secure->GetGET("reservierung");
    if (is_numeric($reservierung)) $this->app->DB->Delete("DELETE FROM lager_reserviert WHERE id='$reservierung'");
    header("Location: index.php?module=lager&action=reservierungen");
    exit;
  }
  function LagerArtikelEntfernen() {
    $artikel = $this->app->Secure->GetGET("artikel");
    $projekt = $this->app->Secure->GetGET("projekt");
    if (is_numeric($artikel)) $this->app->DB->Delete("DELETE FROM lager_reserviert WHERE artikel='$artikel' AND projekt='$projekt'");
    header("Location: index.php?module=lager&action=artikelfuerlieferungen");
    exit;
  }
  function LagerBuchen() {
    //$this->LagerBuchenMenu();
    //$this->app->Tpl->Set(TABTEXT,"&Uuml;bersicht");
    //$this->app->Tpl->Parse(PAGE,"tabview.tpl");
    $this->LagerBuchenZwischenlager();
  }
  function LagerKalkMenu() {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lagerkalkulation");
    //    $this->app->Tpl->Add(TABS,"<li><h2>Lagerkalkulation</h2></li>");
    //    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=lager&action=ausgehend\">Ausgehende Artikel</a></li>");
    //    $this->app->Tpl->Add(TABS,"<li><a  href=\"index.php?module=lager&action=buchen\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    
  }
  function LagerAusgehend() {
    $cmd = $this->app->Secure->GetGET("cmd");
    if ($cmd == "produktion") {
      $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Produktion");
      $this->app->erp->MenuEintrag("index.php?module=produktion&action=create", "Neue Produktion anlegen");
      $this->app->erp->MenuEintrag("index.php?module=produktion&action=berechnen", "Materialbestand berechnen");
      //    $this->app->erp->MenuEintrag("index.php?module=lager&action=ausgehend&cmd=produktion","Bauteile fehlende");
      $this->app->erp->MenuEintrag("index.php?module=produktion&action=list", "Zur&uuml;ck zur &Uuml;bersicht");
      $this->app->erp->LagerAusgehend(TAB1, true, true);
      $this->app->erp->LagerAusgehend(TAB2, false, true);
    } else {
      $this->LagerKalkMenu();
      $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Ausgehende Artikel");
      $this->app->erp->LagerAusgehend(TAB1, true);
      $this->app->erp->LagerAusgehend(TAB2, false);
    }
    $this->app->Tpl->Set(TABTEXT, "Fehlende Artikel");
    $this->app->Tpl->Set(TABTEXT2, "Nachbestellte Artikel");
    /*
    $htmltable = new HTMLTable(0,"100%","",3,1);
    
    
    $headings=array("Pos.","Artikel","Nummer","Lieferant","Lager","Auftr&auml;ge","Reservierungen","Fehlende");
    
    
    $htmltable->AddRowAsHeading($headings);
    
    $htmltable->ChangingRowColors('#e0e0e0','#fff');
    
    $artikelarr = $this->app->DB->SelectArr("SELECT * FROM artikel WHERE projekt=1 AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lagerartikel=1 ORDER by adresse");
    
      
    for($i=0;$i<count($artikelarr);$i++)
    {
    
      $name_de = $artikelarr[$i][name_de];
      $adresse = $artikelarr[$i][adresse];
    
      $name =  $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
      $nummer = $artikelarr[$i][nummer];
      $id= $artikelarr[$i][id];
      
    
      $lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$id'");
      $auftraege = $this->app->DB->Select("SELECT SUM(menge -geliefert_menge) FROM auftrag_position WHERE artikel='$id'");
      $reservierungen= $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='$id' AND datum >= NOW()");
    
      if($lager=="") $lager="-";
      if($auftraege<=0) $auftraege="-";
      if($reservierungen=="") $reservierungen="-";
    
      $fehlende = ($lager -$reservierungen) - $auftraege;
      if($fehlende <= 0) {
    $htmltable->NewRow();
    $htmltable->AddCol($i+1);
    $htmltable->AddCol($name_de);
    $htmltable->AddCol($nummer);
    $htmltable->AddCol($name);
    $htmltable->AddCol($lager);
    $htmltable->AddCol($auftraege);
    $htmltable->AddCol($reservierungen);
    $htmltable->AddCol(abs($fehlende));
      }
    }
    
    $this->app->Tpl->Set(INHALT,$htmltable->Get());
    */
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Parse(PAGE, "lagerausgehend.tpl");
  }
  function LagerBuchenZwischenlager() {
    $this->LagerBuchenMenu();
    $this->app->Tpl->Set(TABTEXT, "Zwischenlager");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Zwischenlager");
    $this->app->Tpl->Set(SUBSUBHEADING, "EINGANG Zwischenlager Stand " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.name_de as artikel,a.nummer as nummer,z.menge,z.vpe,z.grund, p.abkuerzung as projekt, z.id FROM zwischenlager z LEFT JOIN artikel a ON a.id=z.artikel LEFT JOIN projekt p ON 
	p.id=z.projekt WHERE z.firma='{$this->app->User->GetFirma() }' AND z.richtung='eingang'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bucheneinlagern&cmd=zwischenlager&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/einlagern.png\"></a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(INHALT, "");
    $this->app->Tpl->Set(SUBSUBHEADING, "AUSGANG Zwischenlager Stand " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.name_de as artikel,z.menge,z.vpe,z.grund, p.abkuerzung as projekt, z.id FROM zwischenlager z LEFT JOIN artikel a ON a.id=z.artikel LEFT JOIN projekt p ON 
	p.id=z.projekt WHERE z.firma='{$this->app->User->GetFirma() }' AND z.richtung='ausgang'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bucheneinlagern&cmd=zwischenlager&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/einlagern.png\"></a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
  }

  function LagerBuchenEinlagern() {
    $this->LagerBuchenMenu();
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Einlagern");
    $id = $this->app->Secure->GetGET("id");
    $cmd = $this->app->Secure->GetGET("cmd"); // vom zwischen lager!
    $menge = $this->app->Secure->GetPOST("menge");
 
		$this->app->YUI->Autocomplete('projekt','projektname');
		$this->app->YUI->Autocomplete('nummer','lagerartikelnummer');
		$this->app->YUI->Autocomplete('regal','lagerplatz');

   // allte merken und wieder rein damit wenn nichts neues kam
		//unset($_SESSION[projekt]);
    if ($this->app->Secure->GetPOST("projekt") != "") {
			$projekt = $this->app->Secure->GetPOST("projekt");
    	$projekt = explode(' ', $projekt);
			$projekt = $projekt[0];
			if(!is_numeric($projekt))
				$projekt = $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$projekt' LIMIT 1");
	
      $_SESSION[projekt] = $projekt;
    }

    $projekt = $_SESSION[projekt];
    $regal = $this->app->Secure->GetPOST("regal");
		$regal_id = $this->app->DB->Select("SELECT id FROM lager_platz WHERE kurzbezeichnung='$regal' LIMIT 1");
		if(is_numeric($regal_id))
			$regal = $regal_id;

		$nummer = $this->app->Secure->GetPOST("nummer");
    $nummer = explode(' ', $nummer);
		$nummer = $nummer[0];

    if ($nummer == "" && $cmd != "zwischenlager") {
      $this->app->Tpl->Set(MSGARTIKEL, "<br>Jetzt Artikel abgscannen!");
      $this->app->Tpl->Set(ARTIKELSTYLE, "style=\"background-color:red\"");
    }
    $woher = $this->app->Secure->GetPOST("woher");
    $zwischenlagerid = $this->app->Secure->GetPOST("zwischenlager");
    $menge = $this->app->Secure->GetPOST("menge");
    // hier nur rein wenn artikel lager und projekt sinn machen sonst message ausgeben und artikel wirklich aus zwischenlager
    $alles_komplett = 0;
    if ($woher == "Zwischenlager" && $zwischenlagerid <= 0) {
      $grund.= "<li>Artikel kommt nicht aus Zwischenlager!</li>";
      $alles_komplett++;
    }
    $artikel_tmp = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1");
    $artikelcheck = $this->app->DB->Select("SELECT id FROM artikel WHERE id='$artikel_tmp' LIMIT 1");
    $artikel_quickcheck = 0;
    if ($artikelcheck != $artikel_tmp || $artikel_tmp == "" || $artikel_tmp == 0) {
      $grund.= "<li>Artikel-Nummer gibt es nicht!</li>";
      $alles_komplett++;
      $artikel_quickcheck = 1;
    }
    if ($projekt <= 0 || !is_numeric($projekt)) {
      $grund.= "<li>Es wurde kein Projekt angegeben!</li>";
      $alles_komplett++;
    }
    // gibts regal
    $regalcheck = $this->app->DB->Select("SELECT id FROM lager_platz WHERE id='$regal' LIMIT 1");
    if ($regalcheck != $regal || $regal == "" || $regal == 0) {
      $grund.= "<li>Regal gibt es nicht!</li>";
      $alles_komplett++;
    }
    if ($alles_komplett > 0 && $regal != "") {
      $this->app->Tpl->Set(MESSAGELAGER, "<div class=\"error\">Artikel wurde nicht gebucht! Grund:<ul>$grund</ul> </div>");
    } else {
      if ($artikel_quickcheck == 1 && $nummer != "") $this->app->Tpl->Set(MESSAGELAGER, "<div class=\"error\">Achtung! Artikelnummer  gibt es nicht! </div>");
    }
    if ($nummer == "" && $cmd == "" && $woher == "") $_SESSION[woher] = 'Differenz';
    if ($alles_komplett == 0 && $regal != "") {
      $artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1");
      // pruefe ob es einen ek fuers projekt gibt sonst meckern!!!
      //echo "buchen entweder aus zwischenlager, prpoduktion oder so";
      if ($woher == "Zwischenlager") {
        $this->app->erp->LagerEinlagerVomZwischenlager($zwischenlagerid, $menge, $regal, $projekt);
        header("Location: index.php?module=lager&action=buchenzwischenlager");
        exit;
      }
      if ($woher == "Differenz") {
        $_SESSION[projekt] = $projekt;
        $this->app->erp->LagerEinlagernDifferenz($artikel, $menge, $regal, $projekt);
        header("Location: index.php?module=lager&action=bucheneinlagern");
        exit;
      }
      // wenn von zwischenlager dann header location nach zwischenlager
      // sonst einlagern
      
    }
    // kommt direkt vom zwischenlager
    if ($cmd == "zwischenlager") {
      $_SESSION[woher] = "Zwischenlager";
      $projekt = $this->app->DB->Select("SELECT projekt FROM zwischenlager WHERE id='$id' LIMIT 1");
      $menge = $this->app->DB->Select("SELECT menge FROM zwischenlager WHERE id='$id' LIMIT 1");
      $artikel = $this->app->DB->Select("SELECT artikel FROM zwischenlager WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
      $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
      $lagerplatz = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel' LIMIT 1");
      $lagerbezeichnung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='$lagerplatz' LIMIT 1");
      if ($lagerplatz == "" || $lagerplatz == 0) $lagerbezeichnung = "Regal frei w&auml;hlen";
      $vpe = $this->app->DB->Select("SELECT vpe FROM zwischenlager WHERE id='$id' LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT projekt FROM zwischenlager WHERE id='$id' LIMIT 1");
      if ($projekt == "" || $projekt == 0) $projekt = 1; // default projekt
      $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$artikel' LIMIT 1");
      if ($standardbild == "") $standardbild = $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE subjekt='Shopbild' AND objekt='Artikel' AND parameter='$artikel' LIMIT 1");
      $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bezeichnung:</td><td>$name_de</td></tr>");
      if ($standardbild > 0) $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bild:</td><td align=\"center\"><img src=\"index.php?module=dateien&action=send&id=$standardbild\" width=\"110\"></td></tr>");
      $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr ><td>Regalvorschlag:</td><td align=\"center\"><font size=\"5\">$lagerbezeichnung</font></td></tr>");
      $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td><br><br>Regal:</td><td><br><br><input type=\"text\" name=\"regal\" id=\"regal\" style=\"background-color: red\"><br>Jetzt Regal abscannen!</td></tr>
	  <input type=\"hidden\" name=\"zwischenlager\" value=\"$id\">");
      $this->app->Tpl->Add(ZWISCHENLAGERINFO, '<script type="text/javascript">
      document.getElementById("regal").focus();
      </script>');
    } else {
      if ($menge == "" || $menge == 0) $menge = 1;
      if ($this->app->Secure->GetPOST("woher") != "") {
        $_SESSION[woher] = $this->app->Secure->GetPOST("woher");
      }
      if ($this->app->Secure->GetPOST("nummer") != "") {
        $nummer = $this->app->Secure->GetPOST("nummer");
    		$nummer = explode(' ', $nummer);
				$nummer = $nummer[0];


        $artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1");
        $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
        $lagermeist = $this->app->DB->SelectArr("SELECT lager_platz, SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel' GROUP BY lager_platz ORDER by 1 DESC LIMIT 1");
        $lagermeist = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='{$lagermeist[0]['lager_platz']}' LIMIT 1");
        $lagerplatz = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel' LIMIT 1");
        $lagerbezeichnung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='$lagerplatz' LIMIT 1");
        if ($lagerplatz == "" || $lagerplatz == 0) $lagerbezeichnung = "Regal frei w&auml;hlen";
        //$vpe  = $this->app->DB->Select("SELECT vpe FROM artikel WHERE id='$id' LIMIT 1");
        $vpe = 'einzeln';
        //$projekt = $this->app->DB->Select("SELECT projekt FROM zwischenlager WHERE id='$id' LIMIT 1");
        if ($projekt == "" || $projekt == 0) $projekt = 1; // default projekt
        $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$artikel' LIMIT 1");


        if ($standardbild == "") $standardbild = $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE subjekt='Shopbild' AND objekt='Artikel' AND parameter='$artikel' LIMIT 1");
        //$this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bezeichnung:</td><td>$name_de</td></tr>");
        //if ($standardbild > 0) $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bild:</td><td align=\"center\"><img src=\"index.php?module=dateien&action=send&id=$standardbild\" width=\"110\"></td></tr>");
        //$this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr ><td>Regalvorschlag:</td><td align=\"center\"><font size=\"5\">$lagerbezeichnung (Aktuell am meisten in $lagermeist)</font></td></tr>");
        //$this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Regal:</td><td>[REGALAUTOSTART]<input type=\"text\" name=\"regal\" id=\"regal\" style=\"background-color: red\" style=\"background-color: red\">[REGALAUTOEND]<br>Jetzt Regal abscannen!</td></tr>");
        // letzt einstellung von grad

				if ($standardbild > 0)
					$this->app->Tpl->Set('STANDARDBILD', "<tr valign=\"top\"><td>Bild:</td><td align=\"center\"><img src=\"index.php?module=dateien&action=send&id=$standardbild\" width=\"110\"></td></tr>");
				
				$this->app->Tpl->Set('NAMEDE',$name_de);
				$this->app->Tpl->Set('LAGERMEIST',$lagermeist);
				$this->app->Tpl->Set('LAGERBEZEICHNUNG',$lagerbezeichnung);


//        $this->app->Tpl->Add(ZWISCHENLAGERINFO, '<script type="text/javascript">document.getElementById("regal").focus();</script>');
//				$regal_out .= '<script type="text/javascript">document.getElementById("regal").focus();</script>';
				$this->app->Tpl->Parse('ZWISCHENLAGERINFO', 'lager_regal.tpl');

      } else {
        // letzt einstellung von grad
        //$this->app->Tpl->Add(ZWISCHENLAGERINFO, '<script type="text/javascript">document.getElementById("nummer").focus();</script>');
				$this->app->Tpl->Set('ZWISCHENLAGERINFO', '<script type="text/javascript">document.getElementById("nummer").focus();</script>');
      }
    }
    $this->app->Tpl->Set(NAME, $name_de);
    if ($_SESSION[woher] == "") $_SESSION[woher] = "Differenz";
    if ($_SESSION[woher] == "Zwischenlager") $this->app->Tpl->Set(ZWISCHENLAGER, "selected");
    if ($_SESSION[woher] == "Produktion") $this->app->Tpl->Set(PRODUKTION, "selected");
    if ($_SESSION[woher] == "Differenz") $this->app->Tpl->Set(DIFFERENZ, "selected");
    $projekt = $_SESSION[projekt];
    $this->app->Tpl->Set(MENGE, $menge);
    $this->app->Tpl->Set(NUMMER, $nummer);
    $this->app->Tpl->Set(VPE, $vpe);
		$pr_name = $this->app->DB->Select("SELECT CONCAT(abkuerzung) FROM projekt WHERE id='$projekt' LIMIT 1");
    $this->app->Tpl->Set(PROJEKT, $pr_name);//$this->app->erp->GetProjektSelect($projekt, &$color_selected));
    $this->app->Tpl->Set(TABTEXT, "Einlagern");
		
    $this->app->Tpl->Parse(TAB1, "einlagern.tpl");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
  }
  function LagerBuchenAuslagern() {
    $this->LagerBuchenMenu();
    $this->app->Tpl->Set(TABTEXT, "Auslagern");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Auslagern");
    // checken ob die daten passen
    $nummer = $this->app->Secure->GetPOST("nummer");
    $grund = $this->app->Secure->GetPOST("grund");
    $adresse = $this->app->Secure->GetPOST("adresse");
    $projekt = $this->app->Secure->GetPOST("projekt");
    $menge = $this->app->Secure->GetPOST("menge");
    $submit = $this->app->Secure->GetPOST("submit");
    $regal = $this->app->Secure->GetPOST("regal");
    if ($menge == "" || $menge == "0") $menge = 1;
    //session_close();
    //session_start();
    /*
    
    if($grund!="")
      $_SESSION[grund] = $grund;
    
    $grund = $_SESSION[grund];
    
    if($projekt!="")
      $_SESSION[projekt] = $projekt;
    
    $projekt= $_SESSION[projekt];
    
    */

		$nummer = explode(' ', $nummer);
		$nummer = $nummer[0];


		$projekt = explode(' ', $projekt);
		$projekt = $projekt[0];

		$regal_id = $this->app->DB->Select("SELECT id FROM lager_platz WHERE kurzbezeichnung='$regal' LIMIT 1");
    if(is_numeric($regal_id))
      $regal = $regal_id;

    if ($submit != "") {
      //projekt pruefen
			
      $checkprojekt = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE abkuerzung='$projekt' LIMIT 1");
      $projektid = $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$projekt' LIMIT 1");
      if ($projekt == "" || $checkprojekt != $projekt) {
        //$error++;
        //$this->app->Tpl->Set(MSGPROJEKT,"<font color=\"red\">Projekt gibt es nicht!</font>");
        $projektid = $this->app->DB->Select("SELECT standardprojekt  FROM firma WHERE id='" . $this->app->User->GetFirma() . "' LIMIT 1");
      }
      //adresse pruefen
      $adressearray = split(' ', $adresse);
      $checkadresse = $this->app->DB->Select("SELECT id FROM adresse WHERE id='{$adressearray[0]}' LIMIT 1");
      if (!is_numeric($adressearray[0]) || $adressearray[0] != $checkadresse) {
        $error++;
        $this->app->Tpl->Set(MSGADRESSE, "<font color=\"red\">Dies ist keine Adresse aus dem System</font>");
      }
      if (!is_numeric($menge) || $menge == 0) {
        $error++;
        $this->app->Tpl->Set(MSGMENGE, "<font color=\"red\">Wert ist keine Zahl oder Null.</font>");
      }
      $checkartikel = $this->app->DB->Select("SELECT nummer FROM artikel WHERE nummer='{$nummer}' LIMIT 1");
      $artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='{$nummer}' LIMIT 1");
      $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE nummer='{$nummer}' LIMIT 1");
      if (!is_numeric($checkartikel) || $nummer != $checkartikel) {
        $error++;
        $this->app->Tpl->Set(MSGARTIKEL, "<font color=\"red\">Diese Artikelnummer gibt es nicht</font>");
      }
      //z.B. es liegen 1 1 5 und man will 6 haben
      $checkregal = $this->app->DB->Select("SELECT id FROM lager_platz WHERE id='$regal' LIMIT 1");
      if (($regal != "" && $checkregal == $regal) && $error == 0) {
        //regal gibt schon mal liegt jetzt der artikel noch in diesem regal?
        $summe = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE lager_platz='$regal' AND artikel='$artikel'");
        if ($summe <= 0) {
          $this->app->Tpl->Set(MESSAGELAGER, "<div class=\"error\">Artikel gibt es in diesem Regal nicht!</div>");
        } else if ($summe < $menge) {
          $this->app->Tpl->Set(MESSAGELAGER, "<div class=\"error\">Zu wenig Artikel im Regal! Bitte kleinere Menge w&auml;hlen! (Summe: $summe)</div>");
        } else {
          //echo "alles passt: regal $regal artikel: $artikel menge:$menge";
          // buche bewegung mit grund
          $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz,artikel,menge,vpe,eingang,zeit,referenz,bearbeiter,projekt,firma)
	     VALUES('','$regal','$artikel','$menge','einzeln','0',NOW(),'$grund fuer $adresse','" . $this->app->User->GetName() . "','$projektid','" . $this->app->User->GetFirma() . "')");
          // wenn enticklung auf mitarbeiter buchen
          if ($grund == "Entwicklungsmuster") $this->app->DB->Insert("INSERT INTO projekt_inventar (id,artikel,menge,bestellung, projekt,   adresse,	mitarbeiter,   vpe,zeit) VALUES ('','$artikel','$menge','','$projekt','$adresse','" . $this->app->User->GetName() . "', 'einzeln',NOW())");
          //ziehe menge ab von lager_platz_inhalt
          $tmpcheck = $this->app->DB->Select("SELECT id FROM lager_platz_inhalt WHERE lager_platz='$regal' AND artikel='$artikel' AND menge >='$menge' LIMIT 1");
          // wenn es ein lager mit genug gibt nimm dieses
          if ($tmpcheck > 0) {
            $summezumchecken = $this->app->DB->Select("SELECT menge FROM lager_platz_inhalt WHERE id='$tmpcheck' LIMIT 1");
            $summezumcheckenneu = $summezumchecken - $menge;
            if ($summezumcheckenneu <= 0) $this->app->DB->Delete("DELETE FROM lager_platz_inhalt WHERE id='$tmpcheck' LIMIT 1");
            else $this->app->DB->Update("UPDATE lager_platz_inhalt SET menge='$summezumcheckenneu' WHERE id='$tmpcheck' LIMIT 1");
          } else {
            // lager solange aus bis genug ausgelagert sind
            $nochoffen = $menge;
            while ($nochoffen > 0) {
              $tmpcheck = $this->app->DB->Select("SELECT id FROM lager_platz_inhalt WHERE lager_platz='$regal' AND artikel='$artikel' LIMIT 1");
              $tmpcheckmenge = $this->app->DB->Select("SELECT menge FROM lager_platz_inhalt WHERE id='$tmpcheck' LIMIT 1");
              if ($tmpcheckmenge <= $nochoffen) {
                $this->app->DB->Delete("DELETE FROM lager_platz_inhalt WHERE id='$tmpcheck' LIMIT 1");
                $nochoffen = $nochoffen - $tmpcheckmenge;
              } else {
                $summezumcheckenneu = $tempcheckmenge - $nochoffen;
                $this->app->DB->Update("UPDATE lager_platz_inhalt SET menge='$summezumcheckenneu' WHERE id='$tmpcheck' LIMIT 1");
                $nochoffen = 0;
              }
            }
          }
          header("Location: index.php?module=lager&action=buchenauslagern");
          exit;
        }
      } else {
        //$error++;
        if ($regal != "") {
          $msgregal = "<font color=\"red\"><br>Dieses Regal gibt es nicht!</font>";
          $this->app->Tpl->Set(MESSAGELAGER, "<div class=\"error\">$msgregal</div>");
          $regalcheck = 0;
        }
      }
      if ($error == 0 && $regalcheck == 0) {
        $standardbild = $this->app->DB->Select("SELECT standardbild FROM artikel WHERE id='$artikel' LIMIT 1");
        if ($standardbild == "") $standardbild = $this->app->DB->Select("SELECT datei FROM datei_stichwoerter WHERE subjekt='Shopbild' AND objekt='Artikel' AND parameter='$artikel' LIMIT 1");
        $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bezeichnung:</td><td>$name_de</td></tr>");
        if ($standardbild > 0) $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Bild:</td><td align=\"center\"><img src=\"index.php?module=dateien&action=send&id=$standardbild\" width=\"110\"></td></tr>");

		    $lagermeist = $this->app->DB->SelectArr("SELECT lager_platz, SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel' GROUP BY lager_platz ORDER by 1 DESC LIMIT 1");
        $lagerbezeichnung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='{$lagermeist[0]['lager_platz']}' LIMIT 1");

				if($lagerbezeichnung=="")
				{
 					$lagerplatz = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel' LIMIT 1");
        	$lagerbezeichnung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='$lagerplatz' LIMIT 1");
				}


        $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr ><td>Regalvorschlag:</td><td align=\"left\"><font size=\"5\">$lagerbezeichnung</font></td></tr>");
        $this->app->Tpl->Add(ZWISCHENLAGERINFO, "<tr valign=\"top\"><td>Regal:</td><td align=\"left\"><input type=\"text\" name=\"regal\" id=\"regal\" style=\"background-color: red\" style=\"background-color: red\"><br>Jetzt Regal abscannen!$msgregal</td></tr>");
        // letzt einstellung von grad
        $this->app->Tpl->Add(ZWISCHENLAGERINFO, '<script type="text/javascript">
	document.getElementById("regal").focus();
	</script>');
      } else if ($error == 0) {
        echo "speichern adresse $checkadresse projekt $projekt menge $menge";
      }
    }
    if ($nummer == "") $this->app->Tpl->Set(ARTIKELSTYLE, "style=\"background-color: red\"");
    $this->app->Tpl->Set(MENGE, $menge);

		$art_name = $this->app->DB->Select("SELECT CONCAT(nummer) FROM artikel WHERE nummer='$nummer' LIMIT 1");
    $this->app->Tpl->Set(NUMMER, $art_name);

		$pr_name = $this->app->DB->Select("SELECT CONCAT(abkuerzung) FROM projekt WHERE abkuerzung='$projekt' LIMIT 1");
    $this->app->Tpl->Set(ADRESSE, $adresse);
    if ($_SESSION[grund] == "Entwicklungsmuster") $this->app->Tpl->Set(MUSTER, "selected");
    if ($_SESSION[grund] == "RMA") $this->app->Tpl->Set(RMA, "selected");
    if ($_SESSION[grund] == "Alte Bestellung") $this->app->Tpl->Set(ALTE, "selected");
    if ($_SESSION[grund] == "Produktion") $this->app->Tpl->Set(PRODUKTION, "selected");
    if ($_SESSION[grund] == "Differenz") $this->app->Tpl->Set(DIFFERENZ, "selected");
    //$this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");
    $this->app->YUI->AutoComplete("projekt", "projektname", 1);
    $this->app->YUI->AutoComplete("adresse", "adresse");
		$this->app->YUI->Autocomplete('nummer','lagerartikelnummer');
    $this->app->YUI->Autocomplete('regal','lagerplatz');
    //$this->app->YUI->AutoComplete(ADRESSEAUTO,"adresse",array('id','name','kundennummer'),"CONCAT(id,' ',name)");
    $this->app->Tpl->Set(PROJEKT, $pr_name);
    $this->app->Tpl->Parse(TAB1, "auslagern.tpl");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
  }



  function LagerBuchenMenu() {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lager");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=buchenzwischenlager&id=$id", "Zwischenlager");
    //$this->app->erp->MenuEintrag("index.php?module=lager&action=artikelfuerlieferungen&id=$id","Artikel f&uuml;r Lieferungen");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=bucheneinlagern&id=$id", "Einlagern");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=buchenauslagern&id=$id", "Auslagern");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=buchen", "Zur&uuml;ck zur &Uuml;bersicht");
  }
  function LagerReservierungen() {
    $this->app->Tpl->Add(TABS, "<li><h2>Reservierungen</h2></li>");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Inhalt");
    $this->app->Tpl->Set(SUBSUBHEADING, "Reservierungen Stand " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT adr.name as kunde, a.name_de as Artikel,r.menge,p.abkuerzung as projekt,r.grund, r.id FROM lager_reserviert r LEFT JOIN artikel a ON a.id=r.artikel LEFT JOIN projekt p ON 
	p.id=r.projekt LEFT JOIN adresse adr ON r.adresse=adr.id WHERE r.firma='{$this->app->User->GetFirma() }'");
    $table->DisplayNew(INHALT, "<a href=\"#\" onclick=\"if(!confirm('Artikel aus Reservierungen nehmen?')) return false; else window.location.href='index.php?module=lager&action=artikelentfernenreserviert&reservierung=%value%';\"><img src=\"./themes/[THEME]/images/delete.gif\"></a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }
  function LagerProduktionslager() {
    $this->app->Tpl->Add(TABS, "<li><h2>Produktionslager</h2></li>");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Inhalt");
    $this->app->Tpl->Set(SUBSUBHEADING, "Produktionslager Stand " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.name_de as Artikel,z.menge,z.vpe, p.abkuerzung, z.id FROM produktionslager z LEFT JOIN artikel a ON a.id=z.artikel LEFT JOIN projekt p ON 
	p.id=z.projekt WHERE z.firma='{$this->app->User->GetFirma() }'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bewegungpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Info</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }

  function LagerRegalEtiketten() {
    $id = $this->app->Secure->GetGET("id");
    $platz = $this->app->Secure->GetGET("platz");


    if ($platz == "") $arr = $this->app->DB->SelectArr("SELECT id,kurzbezeichnung FROM lager_platz WHERE id='$id'");
    else $arr = $this->app->DB->SelectArr("SELECT id,kurzbezeichnung FROM lager_platz WHERE lager='$id' AND id='$platz' LIMIT 1");

    for ($i = 0;$i < count($arr);$i++) {
      $arr[$i][id] = str_pad($arr[$i][id], 7, '0', STR_PAD_LEFT);
      HttpClient::quickGet("http://192.168.0.178/druck_regal.php?nr={$arr[$i][id]}&label={$arr[$i][kurzbezeichnung]}");
    }
    $ref = $_SERVER['HTTP_REFERER'];
    header("Location: $ref");
		exit;

  }

  function LagerArtikelfuerlieferungen() {
    //$this->LagerBuchenMenu();
    $artikel = $this->app->Secure->GetGET("artikel");
    $menge = $this->app->Secure->GetGET("menge");
    $lager = $this->app->Secure->GetGET("lager");
    $projekt = $this->app->Secure->GetGET("projekt");
    $produktion = $this->app->Secure->GetGET("produktion");
    $lagerplatzid = $this->app->Secure->GetGET("lagerplatzid");
    $cmd = $this->app->Secure->GetGET("cmd");

		if($cmd=="produktion")
		{
			$this->app->Tpl->Set(TABTEXT, "Artikel f&uuml;r Produktion");
			$this->app->Tpl->Set(KURZUEBERSCHRIFT, "Artikel f&uuml;r Produktion");
		} else {
			$this->app->Tpl->Set(TABTEXT, "Artikel f&uuml;r Lieferungen");
			$this->app->Tpl->Set(KURZUEBERSCHRIFT, "Artikel f&uuml;r Lieferungen");
		}

    //echo "lager $lager artikel $artikel menge $menge lp $lagerplatzid";
    if ($lager != "" && $artikel != "" && $menge != "" && $lagerplatzid) {
      // schaue obs den artikel in der menge in dem lager gibt
      //echo "nehme $artikel insgesamt $menge mal aus $lager";
      $checklagerplatz = $this->app->DB->Select("SELECT lager_platz FROM lager_platz_inhalt  WHERE id='$lagerplatzid' AND artikel='$artikel'");
      $checkmenge = $this->app->DB->Select("SELECT menge FROM lager_platz_inhalt WHERE id='$lagerplatzid' AND artikel='$artikel'");
      if ($checklagerplatz != $lager) {
        $this->app->Tpl->Set(MESSAGE, "<div class=\"error\">Falsches Regal gescannt!</div>");
      } else if ($menge > $checkmenge) {
        $this->app->Tpl->Set(MESSAGE, "<div class=\"error\">Problem: Es gibt nicht soviele im Regal wie angegeben!</div>");
      } else {
        // platz anzahl anpassen
        $mengeneu = $checkmenge - $menge;
        if ($menge < $checkmenge) $this->app->DB->Update("UPDATE lager_platz_inhalt SET menge='$mengeneu' WHERE id='$lagerplatzid' LIMIT 1");
        else $this->app->DB->Update("DELETE FROM lager_platz_inhalt WHERE id='$lagerplatzid' LIMIT 1");
        // rein ins zwischenlager
				if($cmd!="produktion")
				{
					$grund = "Artikel f&uuml;r Lieferungen " . date('d.m.Y');
					$this->app->DB->Insert("INSERT INTO zwischenlager (id,bearbeiter,projekt,artikel,menge,vpe,grund,richtung,objekt,parameter,firma) 
						VALUES ('','" . $this->app->User->GetName() . "','$projekt','$artikel','$menge','$vpe','$grund','Ausgang','lieferung',DATE_FORMAT(NOW(),'%Y-%m-%d'),'" . $this->app->User->GetFirma() . "')");
					$tmparrres = $this->app->DB->SelectArr("SELECT * FROM lager_reserviert WHERE objekt='lieferschein' AND artikel='$artikel' AND firma='" . $this->app->User->GetFirma() . "'");
				} else {
					$produktionsnummer = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$produktion' LIMIT 1");
					$grund = "Artikel f&uuml;r Produktion $produktionsnummer " . date('d.m.Y');
					$tmparrres = $this->app->DB->SelectArr("SELECT * FROM lager_reserviert WHERE objekt='produktion' AND parameter='$produktion' AND artikel='$artikel' AND firma='" . $this->app->User->GetFirma() . "'");
				}
				
        // bewegung buchen
        $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz,artikel,menge,vpe,eingang,zeit,referenz,bearbeiter,projekt,firma) VALUES 
	    ('','$lager','$artikel','$menge','$vpe','0',NOW(),'$grund','" . $this->app->User->GetName() . "','$projekt','" . $this->app->User->GetFirma() . "')");

        // reservierung loeschen korrekte anzahl
        // mit einer schleife delete oder update letztens wenn etwas ueberig ist
        //$tmparrres = $this->app->DB->SelectArr("SELECT * FROM lager_reserviert WHERE objekt='lieferschein' AND artikel='$artikel' AND projekt='$projekt' AND firma='".$this->app->User->GetFirma()."'");

        $geloescht = 0;
        for ($u = 0;$u < count($tmparrres);$u++) {
          // wenn die menge der lieferung kleiner als menge dann menge loeschen
          if ($tmparrres[$u][menge] >= ($menge - $geloescht)) {
            // DELETE
            $neuerwert = $tmparrres[$u][menge] - ($menge - $geloescht);
            $this->app->DB->Update("UPDATE lager_reserviert SET menge='$neuerwert' WHERE id='{$tmparrres[$u][id]}' LIMIT 1");
            $this->app->DB->Update("DELETE FROM lager_reserviert WHERE menge='0' LIMIT 1");
            break;
          } else {
            //wieviel muss man denn abziehen?
            //$soviel = $menge - $geloescht;
            $geloescht = $geloescht + $tmparrres[$u][menge];
            $this->app->DB->Update("DELETE FROM lager_reserviert WHERE id='{$tmparrres[$u][id]}' LIMIT 1");
            //break;
          }
          if ($geloescht >= $menge) break;
        }
        header("Location: index.php?module=lager&action=artikelfuerlieferungen&cmd=$cmd");
        exit;
      }
    }
		if($cmd!="produktion")
			$this->LagerAuslagernProjektbasiert();
		else
			$this->LagerAuslagernProduktionbasiert();
	}

	function LagerAuslagernProduktionbasiert()
	{
		$result = $this->app->DB->SelectArr("SELECT parameter FROM lager_reserviert WHERE objekt='produktion' GROUP BY parameter");
    $gesamtanzahlartikel = 0;
    for ($w = 0;$w < count($result);$w++) {
			$this->app->Tpl->Set(INHALT, "");
			$produktion = $result[$w][parameter];

			$bezeichnung = $this->app->DB->Select("SELECT bezeichnung FROM produktion WHERE id='$produktion' LIMIT 1");
			$nummer = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$produktion' LIMIT 1");
      $this->app->Tpl->Add(INHALT, "<h2>Produktion $nummer: $bezeichnung <a href=\"index.php?module=produktion&action=pdf&id=$produktion\">PDF</a></h2>");
			$artikellistesumm = $this->app->DB->SelectArr("SELECT DISTINCT artikel FROM lager_reserviert WHERE objekt='produktion' AND parameter='$produktion'");
      if (count($artikellistesumm) == 0) continue;

		 $artikelliste = $this->app->DB->SelectArr("SELECT DISTINCT artikel FROM lager_reserviert WHERE objekt='produktion' AND parameter='$produktion'");

     $gesamtanzahlartikel =$this->LagerAuslagernArtikelliste($artikelliste,"",$produktion);
		}

    if ($gesamtanzahlartikel <= 0) $this->app->Tpl->Set(MESSAGE, "<div class=\"info\">Aktuell gibt es keine Artikel f&uuml;r Lieferungen, da keine offenen Auftr&auml;ge im Autoversand sind.</div>");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
	}

	function LagerAuslagernProjektbasiert()
	{
    $projekt = 1;
    $projektearr = $this->app->DB->SelectArr("SELECT id FROM projekt WHERE autoversand='1' AND firma='" . $this->app->User->GetFirma() . "'");
    $projektearr[] = 0;
    $gesamtanzahlartikel = 0;
    // start projekt schleife
    for ($w = 0;$w < count($projektearr);$w++) {
      $this->app->Tpl->Set(INHALT, "");
      $projekt = $projektearr[$w][id];
      $projektName = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$projekt' LIMIT 1");
      if ($projekt == 0 || $projekt == "") $projektName = "Ohne Projekt";
      $artikellistesumm = $this->app->DB->SelectArr("SELECT DISTINCT artikel FROM lager_reserviert WHERE objekt='lieferschein' AND projekt='$projekt' AND firma='" . $this->app->User->GetFirma() . "'");
      if (count($artikellistesumm) == 0) continue;
      $this->app->Tpl->Add(INHALT, "<h2>$projektName Lieferungen Stand " . date('d.m.Y') . "</h2>");

      $artikelliste = $this->app->DB->SelectArr("SELECT DISTINCT artikel FROM lager_reserviert WHERE objekt='lieferschein' AND projekt='$projekt' AND firma='" . $this->app->User->GetFirma() . "'");
			$gesamtanzahlartikel =$this->LagerAuslagernArtikelliste($artikelliste,$projekt);

	    } // ende projekt schleife
    if ($gesamtanzahlartikel <= 0) $this->app->Tpl->Set(MESSAGE, "<div class=\"info\">Aktuell gibt es keine Artikel f&uuml;r Lieferungen, da keine offenen Auftr&auml;ge im Autoversand sind.</div>");
    $this->app->Tpl->Parse(PAGE, "tabview.tpl");
  }



	function LagerAuslagernArtikelliste($artikelliste,$projekt="",$produktion="")
	{

			$cmd = $this->app->Secure->GetGET("cmd");
      $htmltable = new HTMLTable(0, "100%", "", 3, 1);
			if ($this->app->User->GetType() == "admin") $htmltable->AddRowAsHeading(array('Menge', 'Nummer', 'Artikel', 'Projekt', 'Regal', 'Regal', 'Aktion', 'Entfernen'));
      else $htmltable->AddRowAsHeading(array('Menge', 'Nummer', 'Artikel', 'Projekt', 'Regal', 'Regal', 'Aktion'));
      $htmltable->ChangingRowColors('#e0e0e0', '#fff');
      $tmpanzahl = 0;

      for ($i = 0;$i < count($artikelliste);$i++) {
        $gesamtanzahlartikel++;
        $artikel = $artikelliste[$i][artikel];
        $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
        $name_de = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
        //wieviel stueck braucht man denn von dem artikel?
	if(is_numeric($projekt))
					$gesamtbedarf = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE objekt='lieferschein' AND projekt='$projekt' AND artikel='$artikel' AND firma='" . $this->app->User->GetFirma() . "'");
				else
        $gesamtbedarf = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE objekt='produktion' AND parameter='$produktion' AND artikel='$artikel' AND firma='" . $this->app->User->GetFirma() . "'");
        //$artikel_in_regalen = $this->app->DB->SelectArr("SELECT * FROM lager_platz_inhalt WHERE artikel='$artikel' AND projekt='$projekt'");

				// standardlager artikel 
				$standardlagerartikel = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel'");
        // Zeige nur Artikel an die im Lager sind!

        $tmp_check_standardlager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel' AND lager_platz='$standardlagerartikel'");

				// erst standarlager ausraeumen bis zu wenig drin ist
				if($tmp_check_standardlager>=$gesamtbedarf)
        	$artikel_in_regalen = $this->app->DB->SelectArr("SELECT * FROM lager_platz_inhalt WHERE artikel='$artikel' AND lager_platz='$standardlagerartikel'");
				else
        	$artikel_in_regalen = $this->app->DB->SelectArr("SELECT * FROM lager_platz_inhalt WHERE artikel='$artikel'");


        for ($j = 0;$j < count($artikel_in_regalen);$j++) {
          $htmltable->NewRow();
          $tmpanzahl++;
          $menge_im_platz = $artikel_in_regalen[$j][menge];
          $kurzbezeichnung = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz WHERE id='{$artikel_in_regalen[$j][lager_platz]}' LIMIT 1");
          if ($menge_im_platz <= $gesamtbedarf) {
            $tmpmenge = $menge_im_platz;
          } else {
            $tmpmenge = $gesamtbedarf;
          }
          $rest = $menge_im_platz - $tmpmenge; //$this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel' AND firma='".$this->app->User->GetFirma()."'") - $tmpmenge;
          if ($rest == 0) $rest = "-";
          if ($tmpanzahl == 1) $erstes = "erstes";
          else $erstes = "";
          $htmltable->AddCol($tmpmenge);
          $htmltable->AddCol($nummer);
          $htmltable->AddCol($name_de);
          $htmltable->AddCol($this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$projekt' LIMIT 1"));
          $htmltable->AddCol($kurzbezeichnung);
          //$htmltable->AddCol($rest);

          $htmltable->AddCol("Regal: <input type=\"text\" size=\"10\" id=\"$erstes\" 
	    onchange=\"if(!confirm('Wurde $tmpmenge mal $name_de entnommen?')) return false; else window.location.href='index.php?module=lager&action=artikelfuerlieferungen&cmd=$cmd&artikel=$artikel&menge=$tmpmenge&projekt=$projekt&produktion=$produktion&lagerplatzid={$artikel_in_regalen[$j][id]}&lager='+this.value;\">");
          $htmltable->AddCol("<img src=\"./themes/[THEME]/images/einlagern.png\">");
          if ($this->app->User->GetType() == "admin") $htmltable->AddCol("<a href=\"#\" onclick=\"if(!confirm('Artikel aus Lieferungen und Reservierungen nehmen?')) return false; else window.location.href='index.php?module=lager&action=artikelentfernen&produktion=$produktion&projekt=$projekt&artikel=$artikel&cmd=$cmd';\"><img src=\"./themes/[THEME]/images/delete.gif\"></a>");
          $gesamtbedarf = $gesamtbedarf - $tmpmenge;
          if ($gesamtbedarf == 0) break;
        }
      }
      //bestimme regalplaetze fuer artikel
      $this->app->Tpl->Add(INHALT, $htmltable->Get());
      // und enter abfangen!!!
      $this->app->Tpl->Add(INHALT, "<script type=\"text/javascript\">document.getElementById(\"erstes\").focus(); </script>");
      //$table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bucheneinlagern&cmd=zwischenlager&id=%value%\"><img border=\"0\" src=\"./themes/[THEME]/images/einlagern.png\"></a>");
      $this->app->Tpl->Parse(TAB1, "rahmen70_ohneform.tpl");
  return $gesamtanzahlartikel;
			}

  function LagerZwischenlager() {
    $this->app->Tpl->Add(TABS, "<li><h2>Zwischenlager</h2></li>");
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Inhalt");
    $this->app->Tpl->Set(SUBSUBHEADING, "Zwischenlager Stand " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT a.name_de,z.menge,z.vpe,z.grund,z.richtung, p.abkuerzung, z.id FROM zwischenlager z LEFT JOIN artikel a ON a.id=z.artikel LEFT JOIN projekt p ON 
	p.id=z.projekt WHERE z.firma='{$this->app->User->GetFirma() }'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bewegungpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Info</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }
  function LagerBewegung() {
    $this->LagerMenu();
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Lager Bewegungen");
    $lager = $this->app->DB->Select("SELECT bezeichnung FROM lager WHERE id='$id' ");
    $this->app->Tpl->Set(SUBSUBHEADING, "Bewegungen Lager: $lager bis zum " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT p.kurzbezeichnung as Lagerplatz, 
      p.id FROM lager_platz p 
      WHERE lager='$id'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=bewegungpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Info</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }
  function LagerBewegungPopup() {
		$id = $this->app->Secure->GetGET("id");

		$lager = $this->app->DB->Select("SELECT lager FROM lager_platz WHERE id='$id'");

    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lager Bewegungen");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=bewegung&id=$lager", "Zur&uuml;ck zur &Uuml;bersicht");

      $id = $this->app->Secure->GetGET("id");
      $this->app->Tpl->Set(TABNAME, "Lager Bewegungen");
      $lager = $this->app->DB->Select("SELECT l.bezeichnung FROM lager_platz p LEFT JOIN lager l ON p.lager=l.id WHERE p.id='$id'");
      $platz = $this->app->DB->Select("SELECT kurzbezeichnung FROM lager_platz p WHERE id='$id'");
      $this->app->Tpl->Set(SUBSUBHEADING, "Bewegungen Lager: $lager, Platz: $platz bis zum " . date('d.m.Y'));
      // easy table mit arbeitspaketen YUI als template
      $table = new EasyTable($this->app);
      $table->Query("SELECT p.kurzbezeichnung as Lagerplatz, a.nummer, a.name_de, i.menge, if(i.eingang,'Eingang','Ausgang') as Richtung, DATE_FORMAT(i.zeit,'%d.%m.%Y') as datum, i.referenz,
	i.id FROM lager_bewegung i LEFT JOIN lager_platz p ON p.id=i.lager_platz LEFT JOIN artikel a ON i.artikel=a.id
	WHERE p.id='$id' Order by datum");
      $table->DisplayNew(TAB1, "<a href=\"index.php?module=lager&action=platzeditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Info</a>");
     //$this->app->Tpl->Parse(PAGE, "rahmen70.tpl");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }
  function LagerBestand() {
    $this->LagerMenu();
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Lager Inventur-Liste");
    $lager = $this->app->DB->Select("SELECT bezeichnung FROM lager WHERE id='$id' ");
    $this->app->Tpl->Set(SUBSUBHEADING, "Bestand Lager: $lager " . date('d.m.Y'));
    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT p.kurzbezeichnung as lagerplatz, a.name_de as artikel,a.nummer as nummer, SUM(i.menge) as menge, r.menge as reserviert,
      a.id FROM lager_platz p LEFT JOIN lager_platz_inhalt i ON p.id=i.lager_platz LEFT JOIN artikel a ON i.artikel=a.id
      LEFT JOIN lager_reserviert r ON r.artikel=a.id
      WHERE lager='$id' GROUP by p.kurzbezeichnung,a.nummer");

    $table->DisplayNew(INHALT, "<a href=\"index.php?module=artikel&action=lager&id=%value%\" target=\"_blank\">Lagerbestand</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }

  function LagerInventur() {


    $this->LagerMenu();
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(TABNAME, "Lager Inventur");
    $this->app->Tpl->Set(SUBSUBHEADING, "Inventur " . date('d.m.Y'));

//  $this->app->YUI->TableSearch(TAB1, "lagerplatzinventurtabelle");
//    $this->app->Tpl->Parse(PAGE, "lageruebersicht.tpl");



    // easy table mit arbeitspaketen YUI als template
    $table = new EasyTable($this->app);
    $table->Query("SELECT p.kurzbezeichnung, a.nummer, i.menge, '<input type=text size=4>' as Inventur,
      i.id FROM lager_platz p LEFT JOIN lager_platz_inhalt i ON p.id=i.lager_platz LEFT JOIN artikel a ON i.artikel=a.id
      LEFT JOIN artikel_reserviert r ON r.artikel=a.id
      WHERE lager='$id'");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=platzeditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Info</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen_submit.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");

    $this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }

  function LagerPlatz() {
    $this->LagerMenu();
    $id = $this->app->Secure->GetGET("id");
    // neues arbeitspaket
    $widget = new WidgetLager_platz(&$this->app, TAB2);
		$msg = base64_encode("<div class=\"error2\">Der Lagerplatz wurde angelegt!</div>");
    $widget->form->SpecialActionAfterExecute("close_refresh", "index.php?module=lager&action=platz&id=$id&msg=$msg");
    $widget->Create();

    $this->app->Tpl->Set(SUBSUBHEADING, "Lagerpl&auml;tze");


    $this->app->YUI->TableSearch(TAB1, "lagerplatztabelle");
//    $this->app->Tpl->Parse(PAGE, "lageruebersicht.tpl");


    // easy table mit arbeitspaketen YUI als template
/*
    $table = new EasyTable($this->app);
    $table->Query("SELECT kurzbezeichnung as lagerplatz,  
      id FROM lager_platz
      WHERE lager='$id' ORDER by lagerplatz");
    $table->DisplayNew(INHALT, "<a href=\"index.php?module=lager&action=platzeditpopup&frame=false&id=%value%\" 
        onclick=\"makeRequest(this);return false\">Bearbeiten</a>&nbsp;<a href=\"index.php?module=lager&action=regaletiketten&id=$id&platz=%value%\">Drucken</a>");
    $this->app->Tpl->Parse(TAB1, "rahmen70.tpl");
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
 */   
		$this->app->Tpl->Parse(PAGE, "lagerplatzuebersicht.tpl");
  }
  function LagerPlatzEditPopup() {
    $frame = $this->app->Secure->GetGET("frame");
    $id = $this->app->Secure->GetGET("id");
      // nach page inhalt des dialogs ausgeben
      $widget = new WidgetLager_platz(&$this->app,TAB1);
      $sid = $this->app->DB->Select("SELECT lager FROM lager_platz WHERE id='$id' LIMIT 1");
      $widget->form->SpecialActionAfterExecute("close_refresh", "index.php?module=lager&action=platz&id=$sid");
      $widget->Edit();
			$this->app->Tpl->Set(TABNAME, "Lagerplatz");
    	$this->app->Tpl->Parse(PAGE, "tabeinzeln.tpl");
  }
  function LagerCreate() {

    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lager anlegen");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=list", "Zur&uuml;ck zur &Uuml;bersicht");
    parent::LagerCreate();
  }
  function LagerList() {
    //    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Lager&uuml;bersicht");
    //    $this->app->erp->MenuEintrag("index.php?module=lager&action=create","Neues Lager anlegen");
    //parent::LagerList();
    //$this->app->Tpl->Add(TABS,"<li><h2 class=\"allgemein\">Allgemein</h2></li>");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=create", "Neues Lager anlegen");
    $this->app->erp->MenuEintrag("index.php?module=artikel&action=lagerlampe", "Lagerlampen");
    //$this->app->Tpl->Add(TABS,"<li><a  href=\"index.php\">Zur&uuml;ck zur &Uuml;bersicht</a></li>");
    $this->app->Tpl->Set(UEBERSCHRIFT, "Lagerverwaltung");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lagerverwaltung");
    $this->app->YUI->TableSearch(TAB1, "lagertabelle");
    $this->app->Tpl->Parse(PAGE, "lageruebersicht.tpl");
  }
  function LagerMenu() {
    $id = $this->app->Secure->GetGET("id");
    $this->app->Tpl->Set(KURZUEBERSCHRIFT, "Lagerverwaltung");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=edit&id=$id", "Lager");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=platz&id=$id", "Lagerpl&auml;tze");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=bestand&id=$id", "Inventur-Liste");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=bewegung&id=$id", "Bewegungen");
//    $this->app->erp->MenuEintrag("index.php?module=lager&action=inventur&id=$id", "Inventur");
    $this->app->erp->MenuEintrag("index.php?module=lager&action=list", "Zur&uuml;ck zur &Uuml;bersicht");
  }
  function LagerEdit() {
    //$this->app->Tpl->Set(STEUERSATZOPTIONS,$this->app->erp->GetSelect($this->app->erp->GetSteuersatz(),$steuersatz);
    // aktiviere tab 1
    $this->app->Tpl->Set(AKTIV_TAB1, "selected");
    parent::LagerEdit();
    $this->LagerMenu();
  }
  function LagerEtiketten() {
    $id = $this->app->Secure->GetGET("id");
    $this->LagerMenu();
    $this->app->Tpl->Set(PAGE, "<br><br><br>Etiketten");
    /*
    $barcode = $this->app->DB->Select("SELECT barcode FROM lager WHERE id='{$id}' LIMIT 1");
    $nummer = $this->app->DB->Select("SELECT nummer FROM lager WHERE id='{$id}' LIMIT 1");
    
    $tmp = new etiketten(&$app);
    $tmp->Lager($barcode,$nummer,65);
    $tmp->Druck();
    exit;
    */
  }
}
?>
