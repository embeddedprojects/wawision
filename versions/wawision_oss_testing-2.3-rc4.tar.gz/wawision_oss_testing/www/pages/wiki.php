<?php

class Wiki {
  var $app;
  
  function Wiki($app) {
    $this->app=&$app;
    $this->app->ActionHandlerInit($this);
	
    $this->app->ActionHandler("create","WikiCreate");
    $this->app->ActionHandler("edit","WikiEdit");
    $this->app->ActionHandler("delete","WikiDelete");
    $this->app->ActionHandler("rename","WikiRename");
    $this->app->ActionHandler("alle","WikiAlle");
    $this->app->ActionHandler("list","WikiList");

    $this->app->DefaultActionHandler("list");

    $this->app->ActionHandlerListen(&$app);
  }


	function WikiAlle()
	{

    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Wiki");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=alle","Alle Seiten anzeigen");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=list&name=Hauptseite","Zur&uuml;ck zur &Uuml;bersicht");
		$alle = $this->app->DB->SelectArr("SELECT name FROM wiki ORDER by name");
		
	  $this->app->Tpl->Set(TAB1,"<h1>Alle Seite nach alphabet sortiert:</h1><ul>");

		for($i=0;$i<count($alle);$i++)
		{
			$this->app->Tpl->Add(TAB1,"<li><a href=\"index.php?module=wiki&action=list&name=".$alle[$i]['name']."\">".$alle[$i]['name']."</a></li>");
		}
	  $this->app->Tpl->Add(TAB1,"</ul>");


		$this->app->Tpl->Set(TABTEXT,"Wiki");
		$this->app->Tpl->Parse(PAGE,"wiki.tpl");

	}

	function WikiCreateDialog()
	{

		$name = $this->app->Secure->GetGET("name");
		$this->app->Tpl->Set(TAB1,"<div class=\"info\">Seite: <b>$name</b> fehlt! Soll diese jetzt angelegt werden? <a href=\"index.php?module=wiki&action=create&name=$name\">Seite jetzt anlegen!</a></div>");

	}


function WikiDelete()
  {
    session_start();
    $name = $this->app->Secure->GetGET("name");
    $key = $this->app->Secure->GetGET("key");

    if($key==$_SESSION['deletekey'] && $name !="" && $key!="")
    { 
      //loeschen
      $_SESSION['deletekey'] = "";
      $this->app->DB->Delete("DELETE FROM wiki WHERE name='$name' LIMIT 1");
       header("Location: index.php?module=wiki&action=list");
        exit;
    }
    else if($name !="")
    { 
      $l=20;
      $c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxwz0123456789";
      for(;$l > 0;$l--) $s .= $c{rand(0,strlen($c))};
      $key = str_shuffle($s);

      $_SESSION['deletekey'] = $key;
        $this->app->Tpl->Set(TAB1,"<div class=\"error\">Seite: <b>$name</b> wirklich l&ouml;schen? <a href=\"index.php?module=wiki&action=delete&name=$name&key=$key\">Seite jetzt l&ouml;schen!</a></div>");
                $this->app->Tpl->Set(TABTEXT,"Wiki");
                $this->app->Tpl->Parse(PAGE,"wiki.tpl");
    }

  }


	function WikiRename()
  {
    $submit = $this->app->Secure->GetPOST("submit");
    $name = $this->app->Secure->GetGET("name");
    $newname = $this->app->Secure->GetPOST("newname");
    $this->WikiMenu();

		if($submit!="")
		{
			// pruefen ob name passt

			$checkname = $this->app->DB->Select("SELECT name FROM wiki WHERE name='$newname' LIMIT 1");

			if($checkname == $name)
			{
				$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Diesen Namen gibt es bereits. Bitte w&auml;hlen Sie einen anderen Namen.</div>"); 
				$name = $newname;
			}
			else if($newname=="")
			{
				$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Bitte geben Sie eine Namen an!</div>"); 
				$name = $newname;
			} else {
				// alle 
				$newname = str_replace(' ','_',$newname);
				$this->app->DB->UPDATE("UPDATE wiki SET name='$newname' WHERE name='$name' LIMIT 1");
      	header("Location: index.php?module=wiki&action=list&name=$newname");
				exit;

			}
		}
/*
    if($key==$_SESSION['deletekey'] && $name !="" && $key!="")
    { 
      //loeschen
      $_SESSION['deletekey'] = "";
      $this->app->DB->Delete("DELETE FROM wiki WHERE name='$name' LIMIT 1");
       header("Location: index.php?module=wiki&action=list");
        exit;
    }
    else if($name !="")
    { 
      $l=20;
      $c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxwz0123456789";
      for(;$l > 0;$l--) $s .= $c{rand(0,strlen($c))};
      $key = str_shuffle($s);

      $_SESSION['deletekey'] = $key;
        $this->app->Tpl->Set(TAB1,"<div class=\"error\">Seite: <b>$name</b> wirklich l&ouml;schen? <a href=\"index.php?module=wiki&action=delete&name=$name&key=$key\">Seite jetzt l&ouml;schen!</a></div>");
                $this->app->Tpl->Set(TABTEXT,"Wiki");
                $this->app->Tpl->Parse(PAGE,"wiki.tpl");
    }
*/               

								$this->app->Tpl->Set(TAB1,"<form action=\"\" method=\"post\">Neuer Name: <input type=\"text\" name=\"newname\" value=\"$name\" size=\"20\">&nbsp;<input type=\"submit\" value=\"umbenennen\" name=\"submit\"></form>");
								$this->app->Tpl->Set(TABTEXT,"Wiki");
                $this->app->Tpl->Parse(PAGE,"wiki.tpl");


  }



  function WikiCreate()
  {
		$name = $this->app->Secure->GetGET("name");
		if($name !="")
    {
      $wikiname = $this->app->DB->Select("SELECT name FROM wiki WHERE name='$name' LIMIT 1");

      if($wikiname != $name)
      {
				$this->app->DB->Insert("INSERT INTO wiki (name,content) VALUES ('$name','')");
				header("Location: index.php?module=wiki&action=edit&name=$name");
				exit;
			} else {
				header("Location: index.php?module=wiki&action=edit&name=$name");
				exit;
			}
		}
  }

  function WikiList()
  {
    $this->WikiMenu();

		$name = $this->app->Secure->GetGET("name");

		if($name !="")
		{
			$wikiname = $this->app->DB->Select("SELECT name FROM wiki WHERE name='$name' LIMIT 1");

			if($wikiname == $name)
			{
				$content = $this->app->DB->Select("SELECT content FROM wiki WHERE name='$name' LIMIT 1");
				$wikiparser = new WikiParser();
				$content = $wikiparser->parse($content);
				$index = $wikiparser->BuildIndex();
				if($index!==false) {
					$this->app->Tpl->Set('INDEX', $index);
					$this->app->Tpl->Parse('WIKIINDEX', 'wiki_index.tpl');
				}

				$this->app->Tpl->Set(TAB1,$content); // TODO Wiki Parser!!!!
			} else {
				$this->WikiCreateDialog();
			}

		} else {
			// hauptseite
			header("Location: index.php?module=wiki&action=list&name=Hauptseite");
			exit;
		}

		$this->app->Tpl->Set(TABTEXT,"Wiki");
		$this->app->Tpl->Parse(PAGE,"wiki.tpl");
  }

  function WikiMenu()
  {
		$name = $this->app->Secure->GetGET("name");
    $this->app->Tpl->Add(KURZUEBERSCHRIFT,"Wiki");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=edit&name=$name","Seite bearbeiten");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=rename&name=$name","Seite umbenennen");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=delete&name=$name","Seite l&ouml;schen");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=alle","Alle Seiten anzeigen");
    $this->app->erp->MenuEintrag("index.php?module=wiki&action=list&name=Hauptseite","Zur&uuml;ck zur &Uuml;bersicht");
  }


  function WikiEdit()
  {
    $this->WikiMenu();

		$name = $this->app->Secure->GetGET("name");
		$content = $this->app->Secure->GetPOST("content");

		$startseite_link = '';

		if($name !="")
		{
			// check if is valid page
			$wikiname = $this->app->DB->Select("SELECT name FROM wiki WHERE name='$name' LIMIT 1");

			$home_wikis = $this->app->DB->SelectArr("SELECT target FROM accordion");
			$found = false;
			for($i=0;$i<count($home_wikis);$i++)
				if($home_wikis[$i]['target']==$wikiname) {$found=true;break;}
			if($found) $startseite_link = "<input type=\"submit\" name=\"submitAndGoBack\" value=\"Speichern und zurück zur Startseite\" name=\"submit\">";


			if($wikiname != $name)	
			{
				// seite gibt es nicht!!!	
			} else { // wenn es seite gibt speichern
				if($this->app->Secure->GetPOST("submit")!="" || $this->app->Secure->GetPOST("submitAndGoBack")!="")
				{
					$this->app->DB->Update("UPDATE wiki SET lastcontent=content WHERE name='$name' LIMIT 1");
					$this->app->DB->Update("UPDATE wiki SET content='$content' WHERE name='$name' LIMIT 1");
					if($this->app->Secure->GetPOST("submitAndGoBack")!='')
						header("Location: index.php?module=welcome&action=start");
					else
						header("Location: index.php?module=wiki&action=list&name=$name");
					exit;
				}
				$content = $this->app->DB->Select("SELECT content FROM wiki WHERE name='$name' LIMIT 1");
			}
		} else {
			// Seite fehlt!!! soll diese angelegt werden?
			$this->WikiCreateDialog();
		}

		

		$this->app->Tpl->Set(TAB1,"<h1>Bearbeiten von Seite $name</h1><br><form action=\"\" method=\"post\"><textarea rows=\"25\" cols=\"120\" name=\"content\">$content</textarea><br><br>
			$startseite_link
			<input type=\"submit\" value=\"Speichern\" name=\"submit\">
			<input type=\"submit\" value=\"Vorschau\" name=\"vorschau\">
			</form>");
		$this->app->Tpl->Set(TABTEXT,"Wiki - Seite bearbeiten");
		$this->app->Tpl->Parse(PAGE,"wiki.tpl");
  }





}

?>
