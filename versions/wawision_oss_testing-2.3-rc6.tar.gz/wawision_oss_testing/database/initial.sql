INSERT INTO `user` (
`id` ,
`username` ,
`password` ,
`repassword` ,
`description` ,
`settings` ,
`parentuser` ,
`activ` ,
`externlogin` ,
`type` ,
`adresse` ,
`fehllogins` ,
`standarddrucker` ,
`firma` ,
`logdatei`
)
VALUES (
NULL , 'admin', ENCRYPT( 'admin' ) , '', 'Administrator', '', '0', '1','1', 'admin', '1', '0', '', '1', NOW( )
);

INSERT INTO `adresse` (`id`, `typ`, `marketingsperre`, `trackingsperre`, `rechnungsadresse`, `sprache`, `name`, `abteilung`, `unterabteilung`, `ansprechpartner`, `land`, `strasse`, `ort`, `plz`, `telefon`, `telefax`, `mobil`, `email`, `ustid`, `ust_befreit`, `passwort_gesendet`, `sonstiges`, `adresszusatz`, `kundenfreigabe`, `steuer`, `logdatei`, `kundennummer`, `lieferantennummer`, `mitarbeiternummer`, `konto`, `blz`, `bank`, `inhaber`, `swift`, `iban`, `waehrung`, `paypal`, `paypalinhaber`, `paypalwaehrung`, `projekt`, `partner`, `zahlungsweise`, `zahlungszieltage`, `zahlungszieltageskonto`, `zahlungszielskonto`, `versandart`, `kundennummerlieferant`, `zahlungsweiselieferant`, `zahlungszieltagelieferant`, `zahlungszieltageskontolieferant`, `zahlungszielskontolieferant`, `versandartlieferant`, `geloescht`, `firma`) VALUES
(1, '', '', 0, 0, '', 'Administrator', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, '', '', 0, '', NOW(), 0, 0, 0, '', '', '', '', '', '', '', '', '', '', 1, 0, '', '', '', '', '', '', '', '', '', '', '', 0, 1);

INSERT INTO `projekt` (
`id` ,
`name` ,
`abkuerzung` ,
`verantwortlicher` ,
`beschreibung` ,
`sonstiges` ,
`aktiv` ,
`farbe` ,
`autoversand` ,
`checkok` ,
`portocheck` ,
`automailrechnung` ,
`checkname` ,
`zahlungserinnerung` ,
`zahlungsmailbedinungen` ,
`folgebestaetigung` ,
`stornomail` ,
`kundenfreigabe_loeschen` ,
`autobestellung` ,
`speziallieferschein` ,
`lieferscheinbriefpapier` ,
`speziallieferscheinbeschriftung` ,
`firma` ,
`geloescht` ,
`logdatei`
)
VALUES (
NULL , 'Kein Projekt', 'KEINPROJEKT', '', 'Kein Projekt', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', ''
);

INSERT INTO `firma` (
`id` ,
`name` ,
`standardprojekt`
)
VALUES (
NULL , 'Musterfirma', '1'
);



INSERT INTO `geschaeftsbrief_vorlagen` (`id`, `sprache`, `betreff`, `text`, `subjekt`, `projekt`, `firma`) VALUES
(1, 'deutsch', 'Bestellung von embedded projects GmbH', 'Sehr geehrter Lieferant,\r\n\r\nanbei übersenden wir Ihnen unsere Bestellung zu. Bitte senden Sie uns als Bestätigung für den Empfang eine Auftragsbestätigung per Fax an: +49 821 27 95 99 20.', 'Bestellung', 1, 1),
(2, 'englisch', 'Order embedded projects GmbH', 'Dear Sir or Madam,\r\n\r\nenclosed we send our order. \r\nPlease send as acknowledgment a fax to the following number: +49 821 27 95 99 20 or send us an e-mail.', 'Bestellung', 1, 1),
(3, 'deutsch', 'Betreff: [BETREFFF]', 'Sehr geehrter [NAME]', 'Korrespondenz', 1, 1),
(7, 'deutsch', 'Auftragsbestätigung von embedded projects GmbH', 'Sehr geehrter Kunde,\r\n\r\nanbei übersenden wir Ihnen Ihre Auftragsbestätigung. ', 'Auftrag', 1, 1),
(5, 'deutsch', 'Lieferschein von embedded projects GmbH', 'Sehr geehrter Kunde,\r\n\r\nanbei übersenden wir Ihnen unseren Lieferschein zu.', 'Lieferschein', 1, 1),
(6, 'deutsch', 'Ihr Angebot von embedded projects GmbH', 'Sehr geehrter Herr \r\n\r\n\r\nanbei das gewünschte Angebot. Wir hoffen Ihnen die passenden Artikel anbieten zu können.', 'Angebot', 1, 1),
(8, 'deutsch', 'Ihre Rechnung von embedded projects GmbH', 'Sehr geehrter Herr/Frau [NAME],\r\n\r\n\r\nanbei finden Sie Ihre Rechnung. Gerne stehen wir Ihnen weiterhin zur Verfügung.\r\n\r\nIhre Rechnung ist im PDF-Format erstellt worden. Um sich die Rechnung ansehen zu können, klicken Sie auf den Anhang und es öffnet sich automatisch der Acrobat Reader. Sollten Sie keinen Acrobat Reader besitzen, haben wir für Sie den Link zum kostenlosen Download von Adobe Acrobat Reader mit angegeben. Er führt Sie automatisch auf die Downloadseite von Adobe. So können Sie sich Ihre Rechnung auch für Ihre Unterlagen ausdrucken.\r\n\r\nhttp://www.adobe.com/products/acrobat/readstep2.html', 'Rechnung', 1, 1),
(9, 'deutsch', 'Versand Ihrer Bestellung von embedded projects GmbH', 'Sehr geehrter Kunde,\r\n\r\nsoeben wurde Ihr Bestellung zusammengestellt und wird in Kürze unserem Versandunternehmen übergeben.\r\n\r\n[VERSAND]\r\n\r\nIhr embedded projects Team\r\n', 'Versand', 1, 1),
(10, 'deutsch', 'Eingang Ihrer Zahlung', 'Sehr geehrter Kunde,\r\n\r\n\r\nIhre Zahlung zum Auftrag Nr. [AUFTRAG] vom [DATUM] in Höhe von [GESAMT] EUR konnte zugeordnet werden.\r\n\r\n\r\nVielen Dank.\r\n\r\nIhr embedded projects Team\r\n', 'ZahlungOK', 1, 1),
(11, 'deutsch', 'Fehlbetrag bei Eingang Ihrer Zahlung', 'Sehr geehrter Kunde,\r\n\r\nbezüglich Ihrer Zahlung zum Auftrag Nr. [AUFTRAG] vom [DATUM] in Höhe von [GESAMT] EUR gab es bei der Zuordnung eine Zahlungsdifferenz von [REST] EUR.\r\n\r\n\r\nBitte überweisen Sie noch den Fehlbetrag in Höhe von [REST] EUR mit dem angegebenen Verwendungszweck auf unser Konto:\r\n\r\nVerwendungszweck: [AUFTRAG]\r\n\r\nembedded projects GmbH\r\nBLZ: 72070001\r\nKonto Nr.: 020746400\r\n\r\nFür Ausland:\r\n\r\nIBAN: DE75720700010020746400\r\nBIC: DEUTDEMM720\r\n\r\nBitte beachten Sie bei der Zahlung: eventuelle Gebühren dürfen nicht zu unseren Lasten gehen.\r\n\r\n\r\nIhr embedded projects Team\r\n', 'ZahlungDiff', 1, 1),
(12, 'deutsch', 'Stornierung Ihres Auftrags', 'Sehr geehrter Kunde,\r\n\r\n\r\nIhr Auftrag Nr. [AUFTRAG] vom [DATUM] wurde soeben aus unserem System storniert.\r\n\r\nBereits bezahltes Auftragsguthaben erstatten wir Ihnen in den nächsten Tagen auf dem gleichen Weg (Bank, Paypal, Kreditkarte, etc.) Ihrer Zahlung zurück. \r\n\r\nSollten Daten für die Zahlung fehlen, wird ein Sachbearbeiter mit Ihnen Kontakt aufnehmen.\r\n\r\nVielen Dank.\r\n\r\nIhr embedded projects Team\r\n', 'Stornierung', 1, 1),
(13, 'deutsch', 'Vorkasse Ihrer Bestellung', 'Sehr geehrter Kunde,\r\n\r\nbezüglich Ihres Auftrags Nr. [AUFTRAG] vom [DATUM] in Höhe von [GESAMT] EUR senden wir Ihnen die Zahlungsinformationen zu. \r\nSollten Sie zwischenzeitlich den Betrag überwiesen haben, sehen Sie diese E-Mail bitte als gegenstandslos an.\r\n\r\nBitte überweisen Sie den Betrag in Höhe von [REST] EUR mit dem angegebenen Verwendungszweck auf unser Konto:\r\n\r\nVerwendungszweck: [AUFTRAG]\r\nBetrag: [REST]\r\n\r\nembedded projects GmbH\r\nBank: Postbank Nürnberg\r\nBLZ: 76010085\r\nKonto Nr.: 900975857\r\n\r\n\r\nBitte beachten Sie bei der Zahlung: eventuelle Gebühren dürfen nicht zu unseren Lasten gehen.\r\n\r\nZwischenverkauf vorbehalten - sollte ein Artikel ausverkauft sein, werden wir Sie so schnell wie möglich mit der neuen Ware beliefern.\r\n\r\n\r\n\r\nIhr embedded projects Team\r\n', 'ZahlungMiss', 1, 1),
(14, 'deutsch', 'Vorkasse Ihrer Bestellung', 'Sehr geehrter Kunde,\r\n\r\nvielen Dank nochmals für Ihre Bestellung.\r\n\r\nBezüglich Ihres Auftrags Nr. [AUFTRAG] vom [DATUM] in Höhe von [GESAMT] EUR senden wir Ihnen die Zahlungsinformationen zu. Sollten Sie \r\nzwischenzeitlich den Betrag bereits überwiesen haben, sehen Sie diese E-Mail bitte als gegenstandslos an.\r\n\r\nBitte überweisen Sie den Betrag in Höhe von [REST] EUR mit dem angegebenen Verwendungszweck auf unser Konto:\r\n\r\nVerwendungszweck: [AUFTRAG]\r\nBetrag: [REST]\r\n\r\nembedded projects GmbH\r\nBank:Deutsche Bank\r\nBLZ: 72070001\r\nKonto Nr.: 020746401\r\n\r\nFür Ausland:\r\n\r\nIBAN: DE75720700010020746400\r\nBIC: DEUTDEMM720\r\n\r\nBitte beachten Sie bei der Zahlung: eventuelle Gebühren dürfen nicht zu unseren Lasten gehen.\r\n\r\n\r\nIhr embedded projects Team\r\n', 'ZahlungMiss', 1, 1),
(15, 'deutsch', 'Betriebsurlaub vom 09.08 bis 24.08.2010', 'Liebe Kunden,\r\n\r\nwir sind vom 09.08.2010 bis zum 24.08.2010 im Betriebsurlaub.\r\nIhre Anfragen werden deshalb erst wieder nach diesem Zeitraum bearbeitet.\r\n\r\nIhre Bestellungen werden in dieser Zeit statt täglich wöchentlich versendet.*\r\n\r\nWir wünschen Ihnen eine schöne Ferienzeit und bedanken uns für Ihr Verständnis.\r\n\r\nDas embedded projects Team\r\n\r\n\r\n\r\n*sofern sich die Ware bei uns im Lager befindet.', 'Betriebsurlaub', 0, 1),
(16, 'deutsch', 'Ihre Bestellung: Informationen Artikel [ARTIKEL]', 'Sehr geehrter embedded projects Kunde,\r\n\r\nvielen Dank für Ihre Bestellung. Auf Grund der großen\r\nNachfrage konnten wir nicht sofort alle Bestellungen \r\naufnehmen und beantworten.\r\n\r\nLeider gibt es bei dem Artikel [ARTIKEL] einen Lieferengpass. \r\nDie vorhandenen Artikel aus dem Lager sind an die schnellsten \r\nKäufer versendet worden.\r\n\r\n\r\nDa wir ein kleines Unternehmen sind und unser Lager nicht \r\nstündlich aktualisieren, wurde der Artikel leider nicht \r\nrechtzeitig gesperrt. \r\n\r\n\r\nBitte teilen Sie uns über folgenden Link mit, wie wir mit Ihrer \r\nBestellung verfahren sollen (es gibt einen kompatiblen \r\nErsatzartikel welcher im Lager vorhanden ist).\r\n\r\n\r\n===== LINK ZUR AUSWAHL ======\r\n\r\nhttp://www.eproo.de/index.php?module=exportlink&regkey=[REG]\r\n\r\n===== LINK ZUR AUSWAHL ======\r\n\r\nInfo zu Alternativen bei uns im Shop:\r\nDer Prozessor der Familie AT90 (kompatibel zu AT90USBKEY \r\nmit ausreichend Flash) befindet sich noch auf folgenden Produkt:\r\n\r\n\r\nOpenKUBUS (aus unserem Online-Shop), welcher einen \r\nkompatiblen Prozessor zum AT90USB Key bietet und ebenfalls mit Flip programmiert werden kann. (Im Lager vorhanden).\r\n\r\n\r\n\r\nBitte informieren Sie sich im Internet bzw. über bekannte \r\nForen, ob das Produkt eine  passende Wahl für Sie ist.\r\n\r\n\r\n\r\nVielen Dank für das Vertrauen und die Geduld. Wir halten Sie per E-Mail auf dem Laufenden.\r\n\r\nIhr embedded projects Team\r\n', 'AlternativArtikel', 0, 1),
(17, 'deutsch', 'Zusammenstellung Ihrer Bestellung', 'Sehr geehrter Kunde,\r\n\r\nsoeben wurde Ihr Bestellung zusammengestellt. Sie können Ihre Ware jetzt abholen. Sind Sie bereits bei uns gewesen, so sehen Sie diese E-Mail bitte als gegenstandslos an.\r\n\r\n[VERSAND]\r\n\r\nIhr embedded projects Team\r\n', 'Selbstabholer', 0, 1);


ALTER TABLE `produktion_position` ADD INDEX ( `artikel` ) ;
ALTER TABLE `produktion_position` ADD INDEX ( `produktion` ) ;
ALTER TABLE `bestellung_position` ADD INDEX ( `bestellung` , `artikel` ) ;
ALTER TABLE `lager_platz_inhalt` ADD INDEX ( `artikel` ) ;
ALTER TABLE `bestellung_position` ADD INDEX ( `abgeschlossen` ) ;
ALTER TABLE `bestellung_position` ADD INDEX ( `status` ) ;
ALTER TABLE `projekt` ADD INDEX ( `abkuerzung` ) ;
ALTER TABLE `bestellung_position` ADD INDEX ( `geliefert` ) ;
ALTER TABLE `bestellung_position` ADD INDEX ( `menge` ) ;
ALTER TABLE `auftrag_position` ADD INDEX ( `menge` , `geliefert` ) ;
ALTER TABLE `auftrag_position` ADD INDEX ( `auftrag` , `artikel` ) ;
ALTER TABLE `lager_reserviert` ADD INDEX ( `adresse` , `artikel` ) ;
ALTER TABLE `auftrag` ADD INDEX ( `kennen` ) ;


ALTER TABLE `firmendaten` ADD `next_angebot` VARCHAR( 255 ) NOT NULL AFTER `brieftext` ,
ADD `next_auftrag` VARCHAR( 255 ) NOT NULL AFTER `next_angebot` ,
ADD `next_gutschrift` VARCHAR( 255 ) NOT NULL AFTER `next_auftrag` ,
ADD `next_lieferschein` VARCHAR( 255 ) NOT NULL AFTER `next_gutschrift` ,
ADD `next_bestellung` VARCHAR( 255 ) NOT NULL AFTER `next_lieferschein` ,
ADD `next_rechnung` VARCHAR( 255 ) NOT NULL AFTER `next_bestellung` ,
ADD `next_kundennummer` VARCHAR( 255 ) NOT NULL AFTER `next_rechnung` ,
ADD `next_lieferantennummer` VARCHAR( 255 ) NOT NULL AFTER `next_kundennummer` ,
ADD `next_mitarbeiternummer` VARCHAR( 255 ) NOT NULL AFTER `next_lieferantennummer` ,
ADD `next_waren` VARCHAR( 255 ) NOT NULL AFTER `next_mitarbeiternummer` ,
ADD `next_sonstiges` VARCHAR( 255 ) NOT NULL AFTER `next_waren` ,
ADD `next_produktion` VARCHAR( 255 ) NOT NULL AFTER `next_sonstiges`;


