-- phpMyAdmin SQL Dump
-- version 3.5.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 30, 2012 at 06:19 PM
-- Server version: 5.5.24-0ubuntu0.12.04.1
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wawision-struct-1`
--

-- --------------------------------------------------------

 CREATE TABLE `newslettercache` (
`checksum` TEXT NOT NULL ,
`comment` VARCHAR( 255 ) NOT NULL
) ENGINE = MYISAM;

--
-- Table structure for table `abrechnungsartikel`
--

CREATE TABLE IF NOT EXISTS `abrechnungsartikel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `steuerklasse` varchar(255) NOT NULL,
  `rabatt` varchar(255) NOT NULL,
  `abgerechnet` int(1) NOT NULL,
  `startdatum` date NOT NULL,
  `lieferdatum` date NOT NULL,
  `abgerechnetbis` date NOT NULL,
  `wiederholend` int(1) NOT NULL,
  `zahlzyklus` int(10) NOT NULL,
  `abgrechnetam` date NOT NULL,
  `rechnung` int(10) NOT NULL,
  `projekt` int(10) NOT NULL,
  `adresse` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adresse`
--

CREATE TABLE IF NOT EXISTS `adresse` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typ` varchar(255) NOT NULL,
  `marketingsperre` varchar(255) NOT NULL,
  `trackingsperre` int(1) NOT NULL,
  `rechnungsadresse` int(1) NOT NULL,
  `sprache` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `ansprechpartner` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `mobil` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `passwort_gesendet` int(1) NOT NULL,
  `sonstiges` text NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `kundenfreigabe` int(1) NOT NULL,
  `steuer` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `kundennummer` int(11) NOT NULL,
  `lieferantennummer` int(11) NOT NULL,
  `mitarbeiternummer` int(11) NOT NULL,
  `konto` varchar(255) NOT NULL,
  `blz` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `inhaber` varchar(255) NOT NULL,
  `swift` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `paypal` varchar(255) NOT NULL,
  `paypalinhaber` varchar(255) NOT NULL,
  `paypalwaehrung` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `partner` int(11) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` varchar(255) NOT NULL,
  `zahlungszieltageskonto` varchar(255) NOT NULL,
  `zahlungszielskonto` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `kundennummerlieferant` varchar(255) NOT NULL,
  `zahlungsweiselieferant` varchar(255) NOT NULL,
  `zahlungszieltagelieferant` varchar(255) NOT NULL,
  `zahlungszieltageskontolieferant` varchar(255) NOT NULL,
  `zahlungszielskontolieferant` varchar(255) NOT NULL,
  `versandartlieferant` varchar(255) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `webid` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adresse_kontakhistorie`
--

CREATE TABLE IF NOT EXISTS `adresse_kontakhistorie` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adresse` int(10) NOT NULL,
  `grund` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `datum` datetime NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `adresse_rolle`
--

CREATE TABLE IF NOT EXISTS `adresse_rolle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adresse` int(10) NOT NULL,
  `projekt` int(11) NOT NULL,
  `subjekt` varchar(255) NOT NULL,
  `praedikat` varchar(255) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `von` date NOT NULL,
  `bis` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `angebot`
--

CREATE TABLE IF NOT EXISTS `angebot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `gueltigbis` date NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `anfrage` varchar(255) NOT NULL,
  `auftrag` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `retyp` varchar(255) NOT NULL,
  `rechnungname` varchar(255) NOT NULL,
  `retelefon` varchar(255) NOT NULL,
  `reansprechpartner` varchar(255) NOT NULL,
  `retelefax` varchar(255) NOT NULL,
  `reabteilung` varchar(255) NOT NULL,
  `reemail` varchar(255) NOT NULL,
  `reunterabteilung` varchar(255) NOT NULL,
  `readresszusatz` varchar(255) NOT NULL,
  `restrasse` varchar(255) NOT NULL,
  `replz` varchar(255) NOT NULL,
  `reort` varchar(255) NOT NULL,
  `reland` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `vertrieb` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `gesamtsumme` decimal(10,4) NOT NULL,
  `bank_inhaber` varchar(255) NOT NULL,
  `bank_institut` varchar(255) NOT NULL,
  `bank_blz` int(11) NOT NULL,
  `bank_konto` int(11) NOT NULL,
  `kreditkarte_typ` varchar(255) NOT NULL,
  `kreditkarte_inhaber` varchar(255) NOT NULL,
  `kreditkarte_nummer` varchar(255) NOT NULL,
  `kreditkarte_pruefnummer` varchar(255) NOT NULL,
  `kreditkarte_monat` int(11) NOT NULL,
  `kreditkarte_jahr` int(11) NOT NULL,
  `abweichendelieferadresse` int(1) NOT NULL,
  `abweichenderechnungsadresse` int(1) NOT NULL,
  `liefername` varchar(255) NOT NULL,
  `lieferabteilung` varchar(255) NOT NULL,
  `lieferunterabteilung` varchar(255) NOT NULL,
  `lieferland` varchar(255) NOT NULL,
  `lieferstrasse` varchar(255) NOT NULL,
  `lieferort` varchar(255) NOT NULL,
  `lieferplz` varchar(255) NOT NULL,
  `lieferadresszusatz` varchar(255) NOT NULL,
  `lieferansprechpartner` varchar(255) NOT NULL,
  `liefertelefon` varchar(255) NOT NULL,
  `liefertelefax` varchar(255) NOT NULL,
  `liefermail` varchar(255) NOT NULL,
  `autoversand` int(1) NOT NULL,
  `keinporto` int(1) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `vermerk` text NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ansprechpartner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `angebot_position`
--

CREATE TABLE IF NOT EXISTS `angebot_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `angebot` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `geliefert` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `angebot_protokoll`
--

CREATE TABLE IF NOT EXISTS `angebot_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `angebot` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ansprechpartner`
--

CREATE TABLE IF NOT EXISTS `ansprechpartner` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typ` varchar(255) NOT NULL,
  `sprache` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `bereich` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sonstiges` text NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `steuer` varchar(255) NOT NULL,
  `adresse` varchar(10) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `arbeitspaket`
--

CREATE TABLE IF NOT EXISTS `arbeitspaket` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adresse` int(10) NOT NULL,
  `aufgabe` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `beschreibung` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `projekt` int(10) NOT NULL,
  `zeit_geplant` int(10) NOT NULL,
  `kostenstelle` int(11) NOT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `abgabe` varchar(255) NOT NULL,
  `abgenommen` varchar(255) NOT NULL,
  `abgenommen_von` int(10) NOT NULL,
  `abgenommen_bemerkung` text NOT NULL,
  `initiator` int(10) NOT NULL,
  `art` varchar(255) NOT NULL,
  `abgabedatum` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typ` varchar(255) NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `checksum` text NOT NULL,
  `projekt` int(11) NOT NULL,
  `inaktiv` varchar(255) NOT NULL,
  `ausverkauft` int(1) NOT NULL,
  `warengruppe` varchar(255) NOT NULL,
  `name_de` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `kurztext_de` text NOT NULL,
  `kurztext_en` text NOT NULL,
  `beschreibung_de` text NOT NULL,
  `beschreibung_en` text NOT NULL,
  `uebersicht_de` text NOT NULL,
  `uebersicht_en` text NOT NULL,
  `links_de` text NOT NULL,
  `links_en` text NOT NULL,
  `startseite_de` text NOT NULL,
  `startseite_en` text NOT NULL,
  `standardbild` varchar(255) NOT NULL,
  `herstellerlink` varchar(255) NOT NULL,
  `hersteller` varchar(255) NOT NULL,
  `teilbar` varchar(255) NOT NULL,
  `nteile` varchar(255) NOT NULL,
  `seriennummern` varchar(255) NOT NULL,
  `lager_platz` varchar(255) NOT NULL,
  `lieferzeit` varchar(255) NOT NULL,
  `lieferzeitmanuell` varchar(255) NOT NULL,
  `sonstiges` text NOT NULL,
  `gewicht` varchar(255) NOT NULL,
  `endmontage` varchar(255) NOT NULL,
  `funktionstest` varchar(255) NOT NULL,
  `artikelcheckliste` varchar(255) NOT NULL,
  `stueckliste` int(1) NOT NULL,
  `juststueckliste` int(1) NOT NULL,
  `barcode` varchar(7) NOT NULL,
  `hinzugefuegt` varchar(255) NOT NULL,
  `pcbdecal` varchar(255) NOT NULL,
  `lagerartikel` int(1) NOT NULL,
  `porto` int(1) NOT NULL,
  `chargenverwaltung` int(1) NOT NULL,
  `provisionsartikel` int(1) NOT NULL,
  `gesperrt` int(1) NOT NULL,
  `sperrgrund` varchar(255) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `gueltigbis` date NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `klasse` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `shopartikel` int(1) NOT NULL,
  `unishopartikel` int(1) NOT NULL,
  `journalshopartikel` int(11) NOT NULL,
  `shop` int(11) NOT NULL,
  `katalog` int(1) NOT NULL,
  `katalogtext_de` text NOT NULL,
  `katalogtext_en` text NOT NULL,
  `katalogbezeichnung_de` varchar(255) NOT NULL,
  `katalogbezeichnung_en` varchar(255) NOT NULL,
  `neu` int(1) NOT NULL,
  `topseller` int(1) NOT NULL,
  `startseite` int(1) NOT NULL,
  `wichtig` int(1) NOT NULL,
  `mindestlager` int(11) NOT NULL,
  `mindestbestellung` int(11) NOT NULL,
  `partnerprogramm_sperre` int(1) NOT NULL,
  `internerkommentar` text NOT NULL,
  `intern_gesperrt` int(11) NOT NULL,
  `intern_gesperrtuser` int(11) NOT NULL,
  `intern_gesperrtgrund` text NOT NULL,
  `inbearbeitung` int(11) NOT NULL,
  `inbearbeitunguser` int(11) NOT NULL,
  `cache_lagerplatzinhaltmenge` int(11) NOT NULL,
  `internkommentar` text NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `anabregs_text` text,
  `autobestellung` int(1) NOT NULL DEFAULT '0',
  `produktion` int(1) DEFAULT NULL,
  `herstellernummer` varchar(255) DEFAULT NULL,
  `restmenge` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `artikelgruppen`
--

CREATE TABLE IF NOT EXISTS `artikelgruppen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `bezeichnung_en` varchar(255) NOT NULL,
  `shop` int(11) NOT NULL,
  `aktiv` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `artikel_artikelgruppe`
--

CREATE TABLE IF NOT EXISTS `artikel_artikelgruppe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `artikelgruppe` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `artikel_shop`
--

CREATE TABLE IF NOT EXISTS `artikel_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `shop` int(11) NOT NULL,
  `checksum` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `aufgabe`
--

CREATE TABLE IF NOT EXISTS `aufgabe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `aufgabe` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `prio` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `kostenstelle` int(11) NOT NULL,
  `initiator` int(11) NOT NULL,
  `angelegt_am` date NOT NULL,
  `startdatum` date NOT NULL,
  `startzeit` time NOT NULL,
  `intervall_tage` int(11) NOT NULL,
  `stunden` int(11) NOT NULL,
  `abgabe_bis` date NOT NULL,
  `abgeschlossen` int(1) NOT NULL,
  `abgeschlossen_am` date NOT NULL,
  `sonstiges` text NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aufgabe_erledigt`
--

CREATE TABLE IF NOT EXISTS `aufgabe_erledigt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `aufgabe` int(11) NOT NULL,
  `abgeschlossen_am` date NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auftrag`
--

CREATE TABLE IF NOT EXISTS `auftrag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `art` varchar(255) NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `internet` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `angebot` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `ansprechpartner` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `ust_inner` int(1) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `vertrieb` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `bank_inhaber` varchar(255) NOT NULL,
  `bank_institut` varchar(255) NOT NULL,
  `bank_blz` varchar(255) NOT NULL,
  `bank_konto` varchar(255) NOT NULL,
  `kreditkarte_typ` varchar(255) NOT NULL,
  `kreditkarte_inhaber` varchar(255) NOT NULL,
  `kreditkarte_nummer` varchar(255) NOT NULL,
  `kreditkarte_pruefnummer` varchar(255) NOT NULL,
  `kreditkarte_monat` varchar(255) NOT NULL,
  `kreditkarte_jahr` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `autoversand` int(1) NOT NULL,
  `keinporto` int(1) NOT NULL,
  `keinestornomail` int(1) NOT NULL,
  `abweichendelieferadresse` int(1) NOT NULL,
  `liefername` varchar(255) NOT NULL,
  `lieferabteilung` varchar(255) NOT NULL,
  `lieferunterabteilung` varchar(255) NOT NULL,
  `lieferland` varchar(255) NOT NULL,
  `lieferstrasse` varchar(255) NOT NULL,
  `lieferort` varchar(255) NOT NULL,
  `lieferplz` varchar(255) NOT NULL,
  `lieferadresszusatz` varchar(255) NOT NULL,
  `lieferansprechpartner` varchar(255) NOT NULL,
  `packstation_inhaber` varchar(255) NOT NULL,
  `packstation_station` varchar(255) NOT NULL,
  `packstation_ident` varchar(255) NOT NULL,
  `packstation_plz` varchar(255) NOT NULL,
  `packstation_ort` varchar(255) NOT NULL,
  `autofreigabe` int(1) NOT NULL,
  `freigabe` int(1) NOT NULL,
  `nachbesserung` int(1) NOT NULL,
  `gesamtsumme` decimal(10,2) NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `abgeschlossen` int(1) NOT NULL,
  `nachlieferung` int(1) NOT NULL,
  `lager_ok` int(1) NOT NULL,
  `porto_ok` int(1) NOT NULL,
  `ust_ok` int(1) NOT NULL,
  `check_ok` int(1) NOT NULL,
  `vorkasse_ok` int(1) NOT NULL,
  `nachnahme_ok` int(1) NOT NULL,
  `reserviert_ok` int(1) NOT NULL,
  `partnerid` int(11) NOT NULL,
  `folgebestaetigung` date NOT NULL,
  `zahlungsmail` date NOT NULL,
  `stornogrund` varchar(255) NOT NULL,
  `stornosonstiges` varchar(255) NOT NULL,
  `stornorueckzahlung` varchar(255) NOT NULL,
  `stornobetrag` decimal(10,2) NOT NULL,
  `stornobankinhaber` varchar(255) NOT NULL,
  `stornobankkonto` varchar(255) NOT NULL,
  `stornobankblz` varchar(255) NOT NULL,
  `stornobankbank` varchar(255) NOT NULL,
  `stornogutschrift` int(1) NOT NULL,
  `stornogutschriftbeleg` varchar(255) NOT NULL,
  `stornowareerhalten` int(1) NOT NULL,
  `stornomanuellebearbeitung` varchar(255) NOT NULL,
  `stornokommentar` text NOT NULL,
  `stornobezahlt` varchar(255) NOT NULL,
  `stornobezahltam` date NOT NULL,
  `stornobezahltvon` varchar(255) NOT NULL,
  `stornoabgeschlossen` int(1) NOT NULL,
  `stornorueckzahlungper` varchar(255) NOT NULL,
  `stornowareerhaltenretour` int(1) NOT NULL,
  `partnerausgezahlt` int(1) NOT NULL,
  `partnerausgezahltam` date NOT NULL,
  `kennen` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `keinetrackingmail` int(1) DEFAULT NULL,
  `zahlungsmailcounter` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auftrag_position`
--

CREATE TABLE IF NOT EXISTS `auftrag_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `auftrag` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `geliefert` int(11) NOT NULL,
  `geliefert_menge` int(11) NOT NULL,
  `explodiert` int(1) NOT NULL,
  `explodiert_parent` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auftrag_protokoll`
--

CREATE TABLE IF NOT EXISTS `auftrag_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auftrag` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `backup`
--

CREATE TABLE IF NOT EXISTS `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `name` varchar(1024) NOT NULL,
  `dateiname` varchar(2048) NOT NULL,
  `datum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `belege`
--
CREATE TABLE IF NOT EXISTS `belege` (
`id` int(11)
,`adresse` int(11)
,`datum` date
,`belegnr` int(11)
,`status` varchar(255)
,`land` varchar(255)
,`projekt` varchar(255)
,`typ` varchar(12)
);
-- --------------------------------------------------------

--
-- Table structure for table `bene`
--

CREATE TABLE IF NOT EXISTS `bene` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bestellung`
--

CREATE TABLE IF NOT EXISTS `bestellung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `bestellungsart` varchar(255) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `angebot` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vorname` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `abweichendelieferadresse` int(1) NOT NULL,
  `liefername` varchar(255) NOT NULL,
  `lieferabteilung` varchar(255) NOT NULL,
  `lieferunterabteilung` varchar(255) NOT NULL,
  `lieferland` varchar(255) NOT NULL,
  `lieferstrasse` varchar(255) NOT NULL,
  `lieferort` varchar(255) NOT NULL,
  `lieferplz` varchar(255) NOT NULL,
  `lieferadresszusatz` varchar(255) NOT NULL,
  `lieferansprechpartner` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `lieferantennummer` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `einkaeufer` varchar(255) NOT NULL,
  `keineartikelnummern` int(1) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungsstatus` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `gesamtsumme` decimal(10,4) NOT NULL,
  `bank_inhaber` varchar(255) NOT NULL,
  `bank_institut` varchar(255) NOT NULL,
  `bank_blz` int(11) NOT NULL,
  `bank_konto` int(11) NOT NULL,
  `paypalaccount` varchar(255) NOT NULL,
  `bestellbestaetigung` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `artikelnummerninfotext` int(1) DEFAULT NULL,
  `ansprechpartner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bestellung_position`
--

CREATE TABLE IF NOT EXISTS `bestellung_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bestellung` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnunglieferant` varchar(255) NOT NULL,
  `bestellnummer` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `geliefert` int(11) NOT NULL,
  `mengemanuellgeliefertaktiviert` int(11) NOT NULL,
  `manuellgeliefertbearbeiter` varchar(255) NOT NULL,
  `abgerechnet` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `abgeschlossen` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bestellung_protokoll`
--

CREATE TABLE IF NOT EXISTS `bestellung_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bestellung` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE IF NOT EXISTS `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chargenverwaltung`
--

CREATE TABLE IF NOT EXISTS `chargenverwaltung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `bestellung` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `datei`
--

CREATE TABLE IF NOT EXISTS `datei` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `titel` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `geloescht` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `firma` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `datei_stichwoerter`
--

CREATE TABLE IF NOT EXISTS `datei_stichwoerter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datei` int(10) NOT NULL,
  `subjekt` varchar(255) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `datei_version`
--

CREATE TABLE IF NOT EXISTS `datei_version` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datei` int(10) NOT NULL,
  `ersteller` varchar(255) NOT NULL,
  `datum` date NOT NULL,
  `version` int(5) NOT NULL,
  `dateiname` varchar(255) NOT NULL,
  `bemerkung` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `datev_buchungen`
--

CREATE TABLE IF NOT EXISTS `datev_buchungen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wkz` varchar(255) NOT NULL,
  `umsatz` decimal(10,2) NOT NULL,
  `gegenkonto` int(255) NOT NULL,
  `belegfeld1` varchar(255) NOT NULL,
  `belegfeld2` varchar(255) NOT NULL,
  `datum` date NOT NULL,
  `konto` varchar(255) NOT NULL,
  `haben` int(1) NOT NULL,
  `kost1` varchar(255) NOT NULL,
  `kost2` varchar(255) NOT NULL,
  `kostmenge` varchar(255) NOT NULL,
  `skonto` decimal(10,2) NOT NULL,
  `buchungstext` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `exportiert` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `kontoauszug` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dokumente`
--

CREATE TABLE IF NOT EXISTS `dokumente` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `adresse_from` int(11) NOT NULL,
  `adresse_to` int(11) NOT NULL,
  `typ` varchar(24) NOT NULL,
  `von` varchar(512) NOT NULL,
  `firma` varchar(512) NOT NULL,
  `an` varchar(512) NOT NULL,
  `email_an` varchar(255) NOT NULL,
  `firma_an` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `plz` varchar(16) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(32) NOT NULL,
  `datum` date NOT NULL,
  `betreff` varchar(1023) NOT NULL,
  `content` text NOT NULL,
  `signatur` tinyint(1) NOT NULL,
  `send_as` varchar(24) NOT NULL,
  `email` varchar(255) NOT NULL,
  `printer` int(2) NOT NULL,
  `fax` tinyint(2) NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dokumente_send`
--

CREATE TABLE IF NOT EXISTS `dokumente_send` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dokument` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `ansprechpartner` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `parameter` int(11) NOT NULL,
  `art` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `geloescht` int(1) NOT NULL,
  `versendet` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `drucker`
--

CREATE TABLE IF NOT EXISTS `drucker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `befehl` varchar(255) NOT NULL,
  `aktiv` int(1) NOT NULL,
  `firma` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dta`
--

CREATE TABLE IF NOT EXISTS `dta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `datum` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `konto` int(11) NOT NULL,
  `blz` int(11) NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `vz1` varchar(255) NOT NULL,
  `vz2` varchar(255) NOT NULL,
  `vz3` varchar(255) NOT NULL,
  `lastschrift` int(1) NOT NULL,
  `gutschrift` int(1) NOT NULL,
  `kontointern` int(10) NOT NULL,
  `datei` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dta_datei`
--

CREATE TABLE IF NOT EXISTS `dta_datei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `inhalt` text NOT NULL,
  `datum` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `art` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `einkaufspreise`
--

CREATE TABLE IF NOT EXISTS `einkaufspreise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `adresse` int(11) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `projekt` varchar(255) NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `ab_menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `preis_anfrage_vom` date NOT NULL,
  `gueltig_bis` date NOT NULL,
  `lieferzeit_standard` int(11) NOT NULL,
  `lieferzeit_aktuell` int(11) NOT NULL,
  `lager_lieferant` int(11) NOT NULL,
  `datum_lagerlieferant` date NOT NULL,
  `bestellnummer` varchar(255) NOT NULL,
  `bezeichnunglieferant` varchar(255) NOT NULL,
  `sicherheitslager` int(11) NOT NULL,
  `bemerkung` text NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `standard` int(1) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `emailbackup`
--

CREATE TABLE IF NOT EXISTS `emailbackup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `benutzername` varchar(255) NOT NULL,
  `passwort` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  `smtp` varchar(255) NOT NULL,
  `ticket` int(1) NOT NULL,
  `autoresponder` int(1) NOT NULL,
  `geschaeftsbriefvorlage` int(11) NOT NULL,
  `autoresponderbetreff` varchar(255) NOT NULL,
  `autorespondertext` text NOT NULL,
  `projekt` int(11) NOT NULL,
  `emailbackup` int(1) NOT NULL,
  `adresse` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `loeschtage` varchar(255) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `ticketqueue` varchar(255) DEFAULT NULL,
  `ticketprojekt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `emailbackup_mails`
--

CREATE TABLE IF NOT EXISTS `emailbackup_mails` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `webmail` int(10) NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sender` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `action` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `action_html` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `empfang` datetime NOT NULL,
  `anhang` varchar(255) NOT NULL,
  `gelesen` int(1) NOT NULL,
  `checksum` text NOT NULL,
  `adresse` int(11) NOT NULL,
  `spam` int(1) NOT NULL,
  `antworten` int(1) NOT NULL,
  `phpobj` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beschreibung` varchar(255) NOT NULL,
  `kategorie` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exportlink_sent`
--

CREATE TABLE IF NOT EXISTS `exportlink_sent` (
  `id` int(11) NOT NULL,
  `reg` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  `objekt` int(11) NOT NULL,
  `mail` int(11) NOT NULL,
  `ident` int(11) NOT NULL,
  `adresse` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `firma`
--

CREATE TABLE IF NOT EXISTS `firma` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `standardprojekt` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `firmendaten`
--

CREATE TABLE IF NOT EXISTS `firmendaten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firma` int(11) NOT NULL,
  `absender` varchar(1024) NOT NULL,
  `sichtbar` int(1) NOT NULL DEFAULT '1',
  `barcode` int(1) NOT NULL DEFAULT '0',
  `schriftgroesse` int(1) NOT NULL DEFAULT '0',
  `betreffszeile` int(1) NOT NULL DEFAULT '0',
  `dokumententext` int(1) NOT NULL DEFAULT '0',
  `tabellenbeschriftung` int(1) NOT NULL DEFAULT '0',
  `tabelleninhalt` int(1) NOT NULL DEFAULT '0',
  `zeilenuntertext` int(1) NOT NULL DEFAULT '0',
  `freitext` int(1) NOT NULL DEFAULT '0',
  `infobox` int(1) NOT NULL DEFAULT '0',
  `spaltenbreite` int(1) NOT NULL DEFAULT '0',
  `footer_0_0` varchar(255) NOT NULL,
  `footer_0_1` varchar(255) NOT NULL,
  `footer_0_2` varchar(255) NOT NULL,
  `footer_0_3` varchar(255) NOT NULL,
  `footer_0_4` varchar(255) NOT NULL,
  `footer_0_5` varchar(255) NOT NULL,
  `footer_1_0` varchar(255) NOT NULL,
  `footer_1_1` varchar(255) NOT NULL,
  `footer_1_2` varchar(255) NOT NULL,
  `footer_1_3` varchar(255) NOT NULL,
  `footer_1_4` varchar(255) NOT NULL,
  `footer_1_5` varchar(255) NOT NULL,
  `footer_2_0` varchar(255) NOT NULL,
  `footer_2_1` varchar(255) NOT NULL,
  `footer_2_2` varchar(255) NOT NULL,
  `footer_2_3` varchar(255) NOT NULL,
  `footer_2_4` varchar(255) NOT NULL,
  `footer_2_5` varchar(255) NOT NULL,
  `footer_3_0` varchar(255) NOT NULL,
  `footer_3_1` varchar(255) NOT NULL,
  `footer_3_2` varchar(255) NOT NULL,
  `footer_3_3` varchar(255) NOT NULL,
  `footer_3_4` varchar(255) NOT NULL,
  `footer_3_5` varchar(255) NOT NULL,
  `footersichtbar` int(1) NOT NULL DEFAULT '0',
  `hintergrund` varchar(255) NOT NULL,
  `logo` longblob NOT NULL,
  `logo_type` varchar(255) NOT NULL,
  `briefpapier` longblob NOT NULL,
  `briefpapier_type` varchar(255) NOT NULL,
  `benutzername` varchar(255) NOT NULL,
  `passwort` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `port` varchar(255) NOT NULL,
  `mailssl` int(1) NOT NULL DEFAULT '0',
  `signatur` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `absendername` varchar(255) NOT NULL,
  `bcc1` varchar(255) NOT NULL,
  `bcc2` varchar(255) NOT NULL,
  `firmenfarbe` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `steuernummer` varchar(255) NOT NULL,
	`startseite_wiki` varchar(255) NOT NULL,
  `datum` datetime NOT NULL,
  `projekt` int(11) DEFAULT NULL,
  `brieftext` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `geschaeftsbrief_vorlagen`
--

CREATE TABLE IF NOT EXISTS `geschaeftsbrief_vorlagen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sprache` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `subjekt` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gutschrift`
--

CREATE TABLE IF NOT EXISTS `gutschrift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `anlegeart` varchar(255) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `rechnung` int(11) NOT NULL,
  `rechnungid` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ustbrief` int(11) NOT NULL,
  `ustbrief_eingang` int(11) NOT NULL,
  `ustbrief_eingang_am` date NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `lieferschein` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `buchhaltung` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungsstatus` varchar(255) NOT NULL,
  `ist` decimal(10,2) NOT NULL,
  `soll` decimal(10,2) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `gesamtsumme` decimal(10,4) NOT NULL,
  `bank_inhaber` varchar(255) NOT NULL,
  `bank_institut` varchar(255) NOT NULL,
  `bank_blz` int(11) NOT NULL,
  `bank_konto` int(11) NOT NULL,
  `kreditkarte_typ` varchar(255) NOT NULL,
  `kreditkarte_inhaber` varchar(255) NOT NULL,
  `kreditkarte_nummer` varchar(255) NOT NULL,
  `kreditkarte_pruefnummer` varchar(255) NOT NULL,
  `kreditkarte_monat` int(11) NOT NULL,
  `kreditkarte_jahr` int(11) NOT NULL,
  `paypalaccount` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gutschrift_position`
--

CREATE TABLE IF NOT EXISTS `gutschrift_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gutschrift` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gutschrift_protokoll`
--

CREATE TABLE IF NOT EXISTS `gutschrift_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gutschrift` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `inhalt`
--

CREATE TABLE IF NOT EXISTS `inhalt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sprache` varchar(255) NOT NULL,
  `inhalt` varchar(255) NOT NULL,
  `kurztext` text NOT NULL,
  `html` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(512) NOT NULL,
  `keywords` varchar(512) NOT NULL,
  `inhaltstyp` varchar(255) NOT NULL,
  `sichtbarbis` datetime NOT NULL,
  `datum` date NOT NULL,
  `aktiv` int(1) NOT NULL,
  `shop` int(11) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `finalparse` varchar(255) NOT NULL,
  `navigation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jqcalendar`
--

CREATE TABLE IF NOT EXISTS `jqcalendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `ort` varchar(255) NOT NULL,
  `von` datetime NOT NULL,
  `bis` datetime NOT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kalender`
--

CREATE TABLE IF NOT EXISTS `kalender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT 'default',
  `farbe` varchar(15) NOT NULL DEFAULT '3300ff',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kalender_event`
--

CREATE TABLE IF NOT EXISTS `kalender_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kalender` int(11) NOT NULL DEFAULT '0',
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` longtext,
  `von` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bis` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `allDay` tinyint(1) NOT NULL DEFAULT '0',
  `color` varchar(7) NOT NULL DEFAULT '#6F93DB',
  `public` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kalender_temp`
--

CREATE TABLE IF NOT EXISTS `kalender_temp` (
  `tId` int(11) NOT NULL,
  `eId` int(11) NOT NULL,
  `szelle` varchar(15) NOT NULL,
  `nanzbelegt` int(11) NOT NULL,
  `ndatum` varchar(8) NOT NULL,
  `nbelegt` float NOT NULL,
  `nanzspalten` int(11) NOT NULL DEFAULT '0',
  `nposbelegt` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kalender_user`
--

CREATE TABLE IF NOT EXISTS `kalender_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` int(11) NOT NULL,
  `userid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kasse`
--

CREATE TABLE IF NOT EXISTS `kasse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `auswahl` varchar(255) NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `adresse` int(11) NOT NULL,
  `grund` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `steuergruppe` int(1) NOT NULL,
  `exportiert` int(1) NOT NULL,
  `exportiert_datum` date NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `konfiguration`
--

CREATE TABLE IF NOT EXISTS `konfiguration` (
  `name` varchar(255) NOT NULL,
  `wert` text NOT NULL,
  `adresse` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `konten`
--

CREATE TABLE IF NOT EXISTS `konten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `kurzbezeichnung` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `erstezeile` text NOT NULL,
  `datevkonto` int(10) NOT NULL,
  `blz` varchar(255) NOT NULL,
  `konto` varchar(255) NOT NULL,
  `swift` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `lastschrift` int(1) NOT NULL,
  `hbci` int(1) NOT NULL,
  `hbcikennung` text NOT NULL,
  `inhaber` varchar(255) NOT NULL,
  `aktiv` int(1) NOT NULL,
  `keineemail` int(1) NOT NULL,
  `firma` int(1) NOT NULL,
  `schreibbar` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kontoauszuege`
--

CREATE TABLE IF NOT EXISTS `kontoauszuege` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `konto` int(11) NOT NULL,
  `buchung` date NOT NULL,
  `vorgang` text NOT NULL,
  `soll` decimal(10,2) NOT NULL,
  `haben` decimal(10,2) NOT NULL,
  `gebuehr` decimal(10,2) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `fertig` int(1) NOT NULL,
  `datev_abgeschlossen` int(1) NOT NULL,
  `buchungstext` varchar(255) NOT NULL,
  `gegenkonto` varchar(255) NOT NULL,
  `belegfeld1` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `mailbenachrichtigung` int(11) NOT NULL,
  `pruefsumme` text NOT NULL,
  `internebemerkung` text,
  `importfehler` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kontoauszuege_zahlungsausgang`
--

CREATE TABLE IF NOT EXISTS `kontoauszuege_zahlungsausgang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `datum` date NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` int(11) NOT NULL,
  `kontoauszuege` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `abgeschlossen` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kontoauszuege_zahlungseingang`
--

CREATE TABLE IF NOT EXISTS `kontoauszuege_zahlungseingang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `datum` date NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` int(11) NOT NULL,
  `kontoauszuege` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `abgeschlossen` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kostenstelle`
--

CREATE TABLE IF NOT EXISTS `kostenstelle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `projekt` varchar(255) NOT NULL,
  `verantwortlicher` varchar(255) NOT NULL,
  `logdatei` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kostenstelle_buchung`
--

CREATE TABLE IF NOT EXISTS `kostenstelle_buchung` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `kostenstelle` int(10) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `datum` varchar(255) NOT NULL,
  `buchungstext` varchar(255) NOT NULL,
  `sonstiges` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kundevorlage`
--

CREATE TABLE IF NOT EXISTS `kundevorlage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lager`
--

CREATE TABLE IF NOT EXISTS `lager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `manuell` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lager_bewegung`
--

CREATE TABLE IF NOT EXISTS `lager_bewegung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lager_platz` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `eingang` int(1) NOT NULL,
  `zeit` datetime NOT NULL,
  `referenz` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lager_platz`
--

CREATE TABLE IF NOT EXISTS `lager_platz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lager` int(11) NOT NULL,
  `kurzbezeichnung` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `projekt` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lager_platz_inhalt`
--

CREATE TABLE IF NOT EXISTS `lager_platz_inhalt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lager_platz` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `bestellung` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lager_reserviert`
--

CREATE TABLE IF NOT EXISTS `lager_reserviert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `grund` varchar(255) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `datum` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieferadressen`
--

CREATE TABLE IF NOT EXISTS `lieferadressen` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typ` varchar(255) NOT NULL,
  `sprache` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sonstiges` text NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `steuer` varchar(255) NOT NULL,
  `adresse` varchar(10) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ansprechpartner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieferantvorlage`
--

CREATE TABLE IF NOT EXISTS `lieferantvorlage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieferschein`
--

CREATE TABLE IF NOT EXISTS `lieferschein` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `lieferscheinart` varchar(255) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `auftrag` varchar(255) NOT NULL,
  `auftragid` int(11) NOT NULL,
  `freitext` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `ansprechpartner` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `versand` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `inbearbeitung_user` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieferschein_position`
--

CREATE TABLE IF NOT EXISTS `lieferschein_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lieferschein` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `seriennummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `geliefert` int(11) NOT NULL,
  `abgerechnet` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieferschein_protokoll`
--

CREATE TABLE IF NOT EXISTS `lieferschein_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lieferschein` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `linkeditor`
--

CREATE TABLE IF NOT EXISTS `linkeditor` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `rule` varchar(1024) NOT NULL,
  `replacewith` varchar(1024) NOT NULL,
  `active` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logdatei`
--

CREATE TABLE IF NOT EXISTS `logdatei` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `befehl` varchar(255) NOT NULL,
  `statement` varchar(255) NOT NULL,
  `app` blob NOT NULL,
  `zeit` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `offenevorgaenge`
--

CREATE TABLE IF NOT EXISTS `offenevorgaenge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL,
  `beschriftung` text NOT NULL,
  `linkremove` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `paketannahme`
--

CREATE TABLE IF NOT EXISTS `paketannahme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `datum` datetime NOT NULL,
  `verpackungszustand` int(11) NOT NULL,
  `bemerkung` text NOT NULL,
  `foto` int(11) NOT NULL,
  `gewicht` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `vorlage` varchar(255) NOT NULL,
  `vorlageid` varchar(255) NOT NULL,
  `zahlung` varchar(255) NOT NULL,
  `betrag` decimal(10,4) NOT NULL,
  `status` varchar(255) NOT NULL,
  `beipack_rechnung` int(1) NOT NULL,
  `beipack_lieferschein` int(1) NOT NULL,
  `beipack_anschreiben` int(1) NOT NULL,
  `beipack_gesamt` int(10) NOT NULL,
  `bearbeiter_distribution` varchar(255) NOT NULL,
  `postgrund` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `paketdistribution`
--

CREATE TABLE IF NOT EXISTS `paketdistribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bearbeiter` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `paketannahme` int(11) NOT NULL,
  `adresse` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `etiketten` int(11) NOT NULL,
  `bemerkung` text NOT NULL,
  `bestellung_position` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `partner`
--

CREATE TABLE IF NOT EXISTS `partner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `netto` decimal(10,2) NOT NULL,
  `tage` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `partner_verkauf`
--

CREATE TABLE IF NOT EXISTS `partner_verkauf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auftrag` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `partner` int(11) NOT NULL,
  `freigabe` int(1) NOT NULL,
  `abgerechnet` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `produktion`
--

CREATE TABLE IF NOT EXISTS `produktion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `art` varchar(255) NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `internet` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `angebot` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `ansprechpartner` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `ust_inner` int(1) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `vertrieb` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `bank_inhaber` varchar(255) NOT NULL,
  `bank_institut` varchar(255) NOT NULL,
  `bank_blz` varchar(255) NOT NULL,
  `bank_konto` varchar(255) NOT NULL,
  `kreditkarte_typ` varchar(255) NOT NULL,
  `kreditkarte_inhaber` varchar(255) NOT NULL,
  `kreditkarte_nummer` varchar(255) NOT NULL,
  `kreditkarte_pruefnummer` varchar(255) NOT NULL,
  `kreditkarte_monat` varchar(255) NOT NULL,
  `kreditkarte_jahr` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `autoversand` int(1) NOT NULL,
  `keinporto` int(1) NOT NULL,
  `keinestornomail` int(1) NOT NULL,
  `abweichendelieferadresse` int(1) NOT NULL,
  `liefername` varchar(255) NOT NULL,
  `lieferabteilung` varchar(255) NOT NULL,
  `lieferunterabteilung` varchar(255) NOT NULL,
  `lieferland` varchar(255) NOT NULL,
  `lieferstrasse` varchar(255) NOT NULL,
  `lieferort` varchar(255) NOT NULL,
  `lieferplz` varchar(255) NOT NULL,
  `lieferadresszusatz` varchar(255) NOT NULL,
  `lieferansprechpartner` varchar(255) NOT NULL,
  `packstation_inhaber` varchar(255) NOT NULL,
  `packstation_station` varchar(255) NOT NULL,
  `packstation_ident` varchar(255) NOT NULL,
  `packstation_plz` varchar(255) NOT NULL,
  `packstation_ort` varchar(255) NOT NULL,
  `autofreigabe` int(1) NOT NULL,
  `freigabe` int(1) NOT NULL,
  `nachbesserung` int(1) NOT NULL,
  `gesamtsumme` decimal(10,2) NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `abgeschlossen` int(1) NOT NULL,
  `nachlieferung` int(1) NOT NULL,
  `lager_ok` int(1) NOT NULL,
  `porto_ok` int(1) NOT NULL,
  `ust_ok` int(1) NOT NULL,
  `check_ok` int(1) NOT NULL,
  `vorkasse_ok` int(1) NOT NULL,
  `nachnahme_ok` int(1) NOT NULL,
  `reserviert_ok` int(1) NOT NULL,
  `partnerid` int(11) NOT NULL,
  `folgebestaetigung` date NOT NULL,
  `zahlungsmail` date NOT NULL,
  `stornogrund` varchar(255) NOT NULL,
  `stornosonstiges` varchar(255) NOT NULL,
  `stornorueckzahlung` varchar(255) NOT NULL,
  `stornobetrag` decimal(10,2) NOT NULL,
  `stornobankinhaber` varchar(255) NOT NULL,
  `stornobankkonto` varchar(255) NOT NULL,
  `stornobankblz` varchar(255) NOT NULL,
  `stornobankbank` varchar(255) NOT NULL,
  `stornogutschrift` int(1) NOT NULL,
  `stornogutschriftbeleg` varchar(255) NOT NULL,
  `stornowareerhalten` int(1) NOT NULL,
  `stornomanuellebearbeitung` varchar(255) NOT NULL,
  `stornokommentar` text NOT NULL,
  `stornobezahlt` varchar(255) NOT NULL,
  `stornobezahltam` date NOT NULL,
  `stornobezahltvon` varchar(255) NOT NULL,
  `stornoabgeschlossen` int(1) NOT NULL,
  `stornorueckzahlungper` varchar(255) NOT NULL,
  `stornowareerhaltenretour` int(1) NOT NULL,
  `partnerausgezahlt` int(1) NOT NULL,
  `partnerausgezahltam` date NOT NULL,
  `kennen` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bezeichnung` varchar(255) DEFAULT NULL,
  `datumproduktion` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `produktionslager`
--

CREATE TABLE IF NOT EXISTS `produktionslager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `bemerkung` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `bestellung_pos` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `produzent` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `produktion_position`
--

CREATE TABLE IF NOT EXISTS `produktion_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `produktion` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `geliefert` int(11) NOT NULL,
  `geliefert_menge` int(11) NOT NULL,
  `explodiert` int(1) NOT NULL,
  `explodiert_parent` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `produktion_protokoll`
--

CREATE TABLE IF NOT EXISTS `produktion_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produktion` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `projekt`
--

CREATE TABLE IF NOT EXISTS `projekt` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `abkuerzung` varchar(255) NOT NULL,
  `verantwortlicher` text NOT NULL,
  `beschreibung` varchar(255) NOT NULL,
  `sonstiges` varchar(255) NOT NULL,
  `aktiv` varchar(255) NOT NULL,
  `farbe` varchar(255) NOT NULL,
  `autoversand` int(1) NOT NULL,
  `checkok` int(1) NOT NULL,
  `portocheck` int(1) NOT NULL,
  `automailrechnung` int(1) NOT NULL,
  `checkname` varchar(255) NOT NULL,
  `zahlungserinnerung` int(1) NOT NULL,
  `zahlungsmailbedinungen` varchar(255) NOT NULL,
  `folgebestaetigung` int(1) NOT NULL,
  `stornomail` int(1) NOT NULL,
  `kundenfreigabe_loeschen` int(1) NOT NULL,
  `autobestellung` int(1) NOT NULL,
  `speziallieferschein` int(1) NOT NULL,
  `lieferscheinbriefpapier` int(11) NOT NULL,
  `speziallieferscheinbeschriftung` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL,
  `logdatei` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `projekt_inventar`
--

CREATE TABLE IF NOT EXISTS `projekt_inventar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `bestellung` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `adresse` int(11) NOT NULL,
  `mitarbeiter` varchar(255) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prozessstarter`
--

CREATE TABLE IF NOT EXISTS `prozessstarter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `bedingung` varchar(255) NOT NULL,
  `art` varchar(255) NOT NULL,
  `startzeit` datetime NOT NULL,
  `letzteausfuerhung` datetime NOT NULL,
  `periode` varchar(255) NOT NULL,
  `typ` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `aktiv` int(1) NOT NULL,
  `mutex` int(1) NOT NULL,
  `mutexcounter` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rechnung`
--

CREATE TABLE IF NOT EXISTS `rechnung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `aborechnung` int(1) NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `anlegeart` varchar(255) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `auftrag` int(11) NOT NULL,
  `auftragid` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `freitext` text NOT NULL,
  `internebemerkung` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `ansprechpartner` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `ust_befreit` int(1) NOT NULL,
  `ustbrief` int(11) NOT NULL,
  `ustbrief_eingang` int(11) NOT NULL,
  `ustbrief_eingang_am` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `lieferschein` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `buchhaltung` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungsstatus` varchar(255) NOT NULL,
  `ist` decimal(10,2) NOT NULL,
  `soll` decimal(10,2) NOT NULL,
  `skonto_gegeben` decimal(10,2) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `versendet` int(1) NOT NULL,
  `versendet_am` datetime NOT NULL,
  `versendet_per` varchar(255) NOT NULL,
  `versendet_durch` varchar(255) NOT NULL,
  `versendet_mahnwesen` int(1) NOT NULL,
  `mahnwesen` varchar(255) NOT NULL,
  `mahnwesen_datum` date NOT NULL,
  `mahnwesen_gesperrt` int(1) NOT NULL,
  `mahnwesen_internebemerkung` text NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `datev_abgeschlossen` int(1) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `doppel` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rechnung_position`
--

CREATE TABLE IF NOT EXISTS `rechnung_position` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rechnung` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bezeichnung` varchar(255) NOT NULL,
  `beschreibung` text NOT NULL,
  `internerkommentar` text NOT NULL,
  `nummer` varchar(255) NOT NULL,
  `menge` float NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `lieferdatum` date NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rechnung_protokoll`
--

CREATE TABLE IF NOT EXISTS `rechnung_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rechnung` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rma`
--

CREATE TABLE IF NOT EXISTS `rma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `projekt` varchar(222) NOT NULL,
  `belegnr` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `freigabe` int(1) NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `vorname` varchar(255) NOT NULL,
  `abteilung` varchar(255) NOT NULL,
  `unterabteilung` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `adresszusatz` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `telefax` varchar(255) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `kundennummer` varchar(255) NOT NULL,
  `lieferantennummer` varchar(255) NOT NULL,
  `zahlungsweise` varchar(255) NOT NULL,
  `zahlungszieltage` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `bestellbestaetigung` int(1) NOT NULL,
  `freitext` varchar(255) NOT NULL,
  `zahlungszielskonto` int(11) NOT NULL,
  `zahlungszieltageskonto` int(11) NOT NULL,
  `bestellbestaetigungsdatum` date NOT NULL,
  `lieferdatum` date NOT NULL,
  `einkaeufer` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rma_artikel`
--

CREATE TABLE IF NOT EXISTS `rma_artikel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `wareneingang` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `lieferschein` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  `wunsch` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `artikel` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `angelegtam` date NOT NULL,
  `menge` int(11) NOT NULL,
  `techniker` text NOT NULL,
  `buchhaltung` text NOT NULL,
  `abgeschlossen` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seriennummern`
--

CREATE TABLE IF NOT EXISTS `seriennummern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seriennummer` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `beschreibung` varchar(255) NOT NULL,
  `lieferung` date NOT NULL,
  `lieferschein` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shopexport`
--

CREATE TABLE IF NOT EXISTS `shopexport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `typ` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `passwort` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `challenge` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `cms` int(1) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `geloescht` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `shopexport_kampange`
--

CREATE TABLE IF NOT EXISTS `shopexport_kampange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `banner` int(11) NOT NULL,
  `unterbanner` int(11) NOT NULL,
  `von` date NOT NULL,
  `bis` date NOT NULL,
  `link` text NOT NULL,
  `firma` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `aktiv` int(1) NOT NULL,
  `shop` int(11) NOT NULL,
  `artikel` varchar(255) NOT NULL,
  `aktion` varchar(255) NOT NULL,
  `geloescht` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shopexport_status`
--

CREATE TABLE IF NOT EXISTS `shopexport_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikelexport` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `bemerkung` text NOT NULL,
  `befehl` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `shopimport_auftraege`
--

CREATE TABLE IF NOT EXISTS `shopimport_auftraege` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `extid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `warenkorb` text NOT NULL,
  `imported` int(1) NOT NULL,
  `trash` int(1) NOT NULL,
  `projekt` int(11) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shopnavigation`
--

CREATE TABLE IF NOT EXISTS `shopnavigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichnung` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `bezeichnung_en` varchar(255) NOT NULL,
  `plugin` varchar(255) NOT NULL,
  `pluginparameter` varchar(255) NOT NULL,
  `shop` int(11) NOT NULL,
  `target` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stueckliste`
--

CREATE TABLE IF NOT EXISTS `stueckliste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `referenz` text NOT NULL,
  `place` varchar(255) NOT NULL,
  `layer` varchar(255) NOT NULL,
  `stuecklistevonartikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stundensatz`
--

CREATE TABLE IF NOT EXISTS `stundensatz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `satz` float NOT NULL,
  `typ` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `datum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE IF NOT EXISTS `ticket` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `schluessel` varchar(255) NOT NULL,
  `zeit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `projekt` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `quelle` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `adresse` int(11) NOT NULL,
  `kunde` varchar(255) NOT NULL,
  `warteschlange` varchar(255) NOT NULL,
  `mailadresse` varchar(255) NOT NULL,
  `prio` int(1) NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `zugewiesen` int(1) NOT NULL,
  `inbearbeitung` int(1) NOT NULL,
  `inbearbeitung_user` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `notiz` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schluessel` (`schluessel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_nachricht`
--

CREATE TABLE IF NOT EXISTS `ticket_nachricht` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket` varchar(255) NOT NULL,
  `verfasser` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `zeit` datetime NOT NULL,
  `zeitausgang` datetime NOT NULL,
  `text` text NOT NULL,
  `textausgang` text NOT NULL,
  `betreff` varchar(255) NOT NULL,
  `bemerkung` text NOT NULL,
  `medium` varchar(255) NOT NULL,
  `versendet` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket` (`ticket`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_vorlage`
--

CREATE TABLE IF NOT EXISTS `ticket_vorlage` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `projekt` int(10) NOT NULL,
  `vorlagenname` varchar(255) NOT NULL,
  `vorlage` text NOT NULL,
  `firma` int(11) NOT NULL,
  `sichtbar` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `unterprojekt`
--

CREATE TABLE IF NOT EXISTS `unterprojekt` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `projekt` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `verantwortlicher` varchar(255) NOT NULL,
  `aktiv` varchar(255) NOT NULL,
  `position` int(10) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `repassword` int(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `settings` text NOT NULL,
  `parentuser` int(11) DEFAULT NULL,
  `activ` int(11) DEFAULT '0',
  `type` varchar(100) DEFAULT '',
  `adresse` int(10) NOT NULL,
  `fehllogins` int(11) NOT NULL,
  `standarddrucker` int(1) NOT NULL,
  `firma` int(10) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `startseite` varchar(1024) DEFAULT NULL,
  `hwtoken` int(1) DEFAULT NULL,
  `hwkey` varchar(255) DEFAULT NULL,
  `hwcounter` int(11) DEFAULT NULL,
  `motppin` varchar(255) DEFAULT NULL,
  `motpsecret` varchar(255) DEFAULT NULL,
  `externlogin` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `useronline`
--

CREATE TABLE IF NOT EXISTS `useronline` (
  `user_id` int(5) NOT NULL DEFAULT '0',
  `login` int(1) NOT NULL DEFAULT '0',
  `sessionid` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(200) NOT NULL DEFAULT '',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userrights`
--

CREATE TABLE IF NOT EXISTS `userrights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `module` varchar(64) NOT NULL,
  `action` varchar(64) NOT NULL,
  `permission` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ustprf`
--

CREATE TABLE IF NOT EXISTS `ustprf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ustid` varchar(255) NOT NULL,
  `land` varchar(255) NOT NULL,
  `ort` varchar(255) NOT NULL,
  `plz` varchar(255) NOT NULL,
  `rechtsform` varchar(255) NOT NULL,
  `strasse` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `datum_online` datetime NOT NULL,
  `datum_brief` date NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `briefbestellt` date NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ustprf_protokoll`
--

CREATE TABLE IF NOT EXISTS `ustprf_protokoll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ustprf_id` int(11) NOT NULL,
  `zeit` datetime NOT NULL,
  `bemerkung` varchar(255) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `verbindlichkeit`
--

CREATE TABLE IF NOT EXISTS `verbindlichkeit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rechnung` varchar(255) NOT NULL,
  `zahlbarbis` date NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `umsatzsteuer` varchar(255) NOT NULL,
  `summenormal` decimal(10,4) NOT NULL,
  `summeermaessigt` decimal(10,4) NOT NULL,
  `skonto` int(11) NOT NULL,
  `skontobis` date NOT NULL,
  `freigabe` int(1) NOT NULL,
  `freigabemitarbeiter` varchar(255) NOT NULL,
  `bestellung` int(11) NOT NULL,
  `adresse` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `bezahlt` int(1) NOT NULL,
  `kontoauszuege` int(11) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `verkaufspreise`
--

CREATE TABLE IF NOT EXISTS `verkaufspreise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artikel` int(11) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `projekt` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `preis` decimal(10,4) NOT NULL,
  `waehrung` varchar(255) NOT NULL,
  `ab_menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `vpe_menge` int(11) NOT NULL,
  `angelegt_am` date NOT NULL,
  `gueltig_bis` date NOT NULL,
  `bemerkung` text NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `logdatei` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `firma` int(11) NOT NULL,
  `geloescht` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `versand`
--

CREATE TABLE IF NOT EXISTS `versand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `rechnung` int(11) NOT NULL,
  `lieferschein` int(11) NOT NULL,
  `versandart` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `gewicht` varchar(255) NOT NULL,
  `freigegeben` int(1) NOT NULL,
  `bearbeiter` varchar(255) NOT NULL,
  `versender` varchar(255) NOT NULL,
  `abgeschlossen` int(1) NOT NULL,
  `versendet_am` date NOT NULL,
  `versandunternehmen` varchar(255) NOT NULL,
  `tracking` varchar(255) NOT NULL,
  `download` int(11) NOT NULL,
  `firma` int(1) NOT NULL,
  `logdatei` datetime NOT NULL,
  `keinetrackingmail` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `warteschlangen`
--

CREATE TABLE IF NOT EXISTS `warteschlangen` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `warteschlange` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `webmail`
--

CREATE TABLE IF NOT EXISTS `webmail` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adresse` int(11) NOT NULL,
  `benutzername` varchar(255) NOT NULL,
  `passwort` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `webmail_mails`
--

CREATE TABLE IF NOT EXISTS `webmail_mails` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `webmail` int(10) NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sender` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bcc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `replyto` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `plaintext` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `htmltext` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `empfang` datetime NOT NULL,
  `anhang` int(1) NOT NULL,
  `gelesen` int(1) NOT NULL,
  `checksum` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `webmail_zuordnungen`
--

CREATE TABLE IF NOT EXISTS `webmail_zuordnungen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` int(11) NOT NULL,
  `zuordnung` varchar(255) NOT NULL,
  `parameter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wiki`
--

CREATE TABLE IF NOT EXISTS `wiki` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `lastcontent` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `zeiterfassung`
--

CREATE TABLE IF NOT EXISTS `zeiterfassung` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `art` varchar(255) NOT NULL,
  `adresse` int(10) NOT NULL,
  `von` datetime NOT NULL,
  `bis` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `aufgabe` varchar(255) NOT NULL,
  `beschreibung` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `arbeitspaket` int(10) NOT NULL,
  `buchungsart` varchar(255) NOT NULL,
  `kostenstelle` int(4) NOT NULL,
  `projekt` int(10) DEFAULT '0',
  `abgerechnet` int(10) NOT NULL,
  `logdatei` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zwischenlager`
--

CREATE TABLE IF NOT EXISTS `zwischenlager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bearbeiter` varchar(255) NOT NULL,
  `projekt` int(11) NOT NULL,
  `artikel` int(11) NOT NULL,
  `menge` int(11) NOT NULL,
  `vpe` varchar(255) NOT NULL,
  `grund` varchar(255) NOT NULL,
  `lager_von` varchar(255) NOT NULL,
  `lager_nach` varchar(255) NOT NULL,
  `richtung` varchar(255) NOT NULL,
  `erledigt` int(1) NOT NULL,
  `objekt` varchar(255) NOT NULL,
  `parameter` varchar(255) NOT NULL,
  `firma` int(11) NOT NULL,
  `logdatei` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

CREATE TABLE `accordion` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `position` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Structure for view `belege`
--
DROP TABLE IF EXISTS `belege`;

CREATE ALGORITHM=UNDEFINED DEFINER=`wawision`@`localhost` SQL SECURITY DEFINER VIEW `belege` AS select `auftrag`.`id` AS `id`,`auftrag`.`adresse` AS `adresse`,`auftrag`.`datum` AS `datum`,`auftrag`.`belegnr` AS `belegnr`,`auftrag`.`status` AS `status`,`auftrag`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `auftrag`.`projekt`)) AS `projekt`,'auftrag' AS `typ` from `auftrag` union all select `angebot`.`id` AS `id`,`angebot`.`adresse` AS `adresse`,`angebot`.`datum` AS `datum`,`angebot`.`belegnr` AS `belegnr`,`angebot`.`status` AS `status`,`angebot`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `angebot`.`projekt`)) AS `projekt`,'angebot' AS `typ` from `angebot` union all select `rechnung`.`id` AS `id`,`rechnung`.`adresse` AS `adresse`,`rechnung`.`datum` AS `datum`,`rechnung`.`belegnr` AS `belegnr`,`rechnung`.`status` AS `status`,`rechnung`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `rechnung`.`projekt`)) AS `projekt`,'rechnung' AS `typ` from `rechnung` union all select `bestellung`.`id` AS `id`,`bestellung`.`adresse` AS `adresse`,`bestellung`.`datum` AS `datum`,`bestellung`.`belegnr` AS `belegnr`,`bestellung`.`status` AS `status`,`bestellung`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `bestellung`.`projekt`)) AS `projekt`,'bestellung' AS `typ` from `bestellung` union all select `lieferschein`.`id` AS `id`,`lieferschein`.`adresse` AS `adresse`,`lieferschein`.`datum` AS `datum`,`lieferschein`.`belegnr` AS `belegnr`,`lieferschein`.`status` AS `status`,`lieferschein`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `lieferschein`.`projekt`)) AS `projekt`,'lieferschein' AS `typ` from `lieferschein` union all select `gutschrift`.`id` AS `id`,`gutschrift`.`adresse` AS `adresse`,`gutschrift`.`datum` AS `datum`,`gutschrift`.`belegnr` AS `belegnr`,`gutschrift`.`status` AS `status`,`gutschrift`.`land` AS `land`,(select `projekt`.`abkuerzung` AS `abkuerzung` from `projekt` where (`projekt`.`id` = `gutschrift`.`projekt`)) AS `projekt`,'gutschrift' AS `typ` from `gutschrift`;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
