<?php 

class WidgetGenverbindlichkeit
{

  private $app;            //application object  
  public $form;            //store form object  
  private $parsetarget;    //target for content

  public function WidgetGenverbindlichkeit($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    $this->Form();
  }

  public function verbindlichkeitDelete()
  {
    
    $this->form->Execute("verbindlichkeit","delete");

    $this->verbindlichkeitList();
  }

  function Edit()
  {
    $this->form->Edit();
  }

  function Copy()
  {
    $this->form->Copy();
  }

  public function Create()
  {
    $this->form->Create();
  }

  public function Search()
  {
    $this->app->Tpl->Set($this->parsetarget,"SUUUCHEEE");
  }

  public function Summary()
  {
    $this->app->Tpl->Set($this->parsetarget,"grosse Tabelle");
  }

  function Form()
  {
    $this->form = $this->app->FormHandler->CreateNew("verbindlichkeit");
    $this->form->UseTable("verbindlichkeit");
    $this->form->UseTemplate("verbindlichkeit.tpl",$this->parsetarget);

    $field = new HTMLInput("adresse","text","","30","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("rechnung","text","","20","","","","","","","0");
    $this->form->NewField($field);
    $this->form->AddMandatory("rechnung","notempty","Pflichfeld!",MSGRECHNUNG);

    $field = new HTMLInput("zahlbarbis","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("betrag","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLSelect("umsatzsteuer",0);
    $field->AddOption('Deutschland','deutschland');
    $field->AddOption('EU-Lieferung','eulieferung');
    $field->AddOption('Import','export');
    $this->form->NewField($field);

    $field = new HTMLInput("summenormal","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("summeermaessigt","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("skonto","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("skontobis","text","","20","","","","","","","0");
    $this->form->NewField($field);



  }

}

?>