<?php 

class WidgetGenartikel
{

  private $app;            //application object  
  public $form;            //store form object  
  private $parsetarget;    //target for content

  public function WidgetGenartikel($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    $this->Form();
  }

  public function artikelDelete()
  {
    
    $this->form->Execute("artikel","delete");

    $this->artikelList();
  }

  function Edit()
  {
    $this->form->Edit();
  }

  function Copy()
  {
    $this->form->Copy();
  }

  public function Create()
  {
    $this->form->Create();
  }

  public function Search()
  {
    $this->app->Tpl->Set($this->parsetarget,"SUUUCHEEE");
  }

  public function Summary()
  {
    $this->app->Tpl->Set($this->parsetarget,"grosse Tabelle");
  }

  function Form()
  {
    $this->form = $this->app->FormHandler->CreateNew("artikel");
    $this->form->UseTable("artikel");
    $this->form->UseTemplate("artikel.tpl",$this->parsetarget);

    $field = new HTMLCheckbox("ausverkauft","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("lagerartikel","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("inaktiv","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("porto","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("name_de","text","","70","50","","","","","","0");
    $this->form->NewField($field);
    $this->form->AddMandatory("name_de","notempty","Pflichtfeld!",MSGNAME_DE);

    $field = new HTMLInput("nummer","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("projekt","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLSelect("typ",0);
    $field->AddOption('Ware f&uuml;r Verkauf (700000)','produkt');
    $field->AddOption('Module / Hardware (600000)','module');
    $field->AddOption('Produktionsmaterial (400000)','produktion');
    $field->AddOption('Sonstiges (100000)','material');
    $field->AddOption('Fremdleistung (100000)','fremdleistung');
    $field->AddOption('Geb&uuml;hr / Miete (100000)','gebuehr');
    $this->form->NewField($field);

    $field = new HTMLInput("adresse","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLTextarea("kurztext_de",2,70);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("anabregs_text",2,70);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("internerkommentar",2,70);   
    $this->form->NewField($field);

    $field = new HTMLInput("hersteller","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("mindestlager","text","","5","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("herstellerlink","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("mindestbestellung","text","","5","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("herstellernummer","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("lager_platz","text","","10","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("rohsnummer","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("gewicht","text","","10","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLSelect("seriennummern",0);
    $field->AddOption('keine','keine');
    $field->AddOption('eigene erzeugen','eigene');
    $field->AddOption('originale nutzen','vomprodukt');
    $this->form->NewField($field);

    $field = new HTMLCheckbox("chargenverwaltung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("stueckliste","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("restmenge","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("juststueckliste","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("umsatzsteuer","","","ermaessigt","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("autobestellung","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("produktion","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("endmontage","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLTextarea("intern_gesperrtgrund",2,70);   
    $this->form->NewField($field);

    $field = new HTMLCheckbox("intern_gesperrt","","","1","0");
    $this->form->NewField($field);


    $field = new HTMLInput("name_en","text","","70","50","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLTextarea("kurztext_en",2,70);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("uebersicht_de",2,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("uebersicht_en",2,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("beschreibung_de",3,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("beschreibung_en",3,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("links_de",2,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("links_en",2,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("startseite_de",2,25);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("startseite_en",2,25);   
    $this->form->NewField($field);

    $field = new HTMLCheckbox("katalog","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("katalogbezeichnung_de","text","","40","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("katalogbezeichnung_en","text","","40","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLTextarea("katalogtext_de",6,40);   
    $this->form->NewField($field);

    $field = new HTMLTextarea("katalogtext_en",6,40);   
    $this->form->NewField($field);


    $field = new HTMLInput("shop","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("neu","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("partnerprogramm_sperre","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("autolagerlampe","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLSelect("lieferzeit",0);
    $field->AddOption('Ampel: gr&uuml;n','green');
    $field->AddOption('Ampel: gelb','yellow');
    $field->AddOption('Ampel: rot','red');
    $this->form->NewField($field);

    $field = new HTMLCheckbox("topseller","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("lieferzeitmanuell","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("startseite","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("lieferzeitmanuell_en","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("wichtig","text","","3","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("sonderaktion","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLInput("sonderaktion_en","text","","20","","","","","","","0");
    $this->form->NewField($field);

    $field = new HTMLCheckbox("variante","","","1","0");
    $this->form->NewField($field);

    $field = new HTMLInput("variante_von","text","","20","","","","","","","0");
    $this->form->NewField($field);


  }

}

?>