<?php

class erpAPI 
{

  function erpAPI(&$app)
  {
    $this->app=$app;
  }

	function StartseiteMenu()
	{
    $this->app->erp->MenuEintrag("index.php?module=aufgaben&action=list","Aufgaben");
    $this->app->erp->MenuEintrag("index.php?module=kalender&action=list","Kalender");
    $this->app->erp->MenuEintrag("index.php?module=zeiterfassung&action=create","Zeiterfassung");
    $this->app->erp->MenuEintrag("index.php?module=welcome&action=start","Zur&uuml;ck zur Startseite");
	}

  function calledOnceAfterLogin($type)
  {

    $this->UpgradeDatabase();

  }

	function ColorPicker() {
    $colors = array('#004704','#C40046','#832BA8','#FF8128','#7592A0');

    $out = "<option value=\"\" style=\"background-color: #FFFFFF\" onclick=\"this.parentElement.style.background='#FFFFFF'\">Keine</option>";
    for($i=0;$i<count($colors);$i++)
      $out .= "<option value=\"{$colors[$i]}\" style=\"background-color: {$colors[$i]}\" onclick=\"this.parentElement.style.background='{$colors[$i]}'\">&nbsp;</option>";

    return $out;
  }

  function KalenderList($parsetarget)
  {
    $this->app->Tpl->Set(KURZUEBERSCHRIFT,"Kalender");
    $this->app->Tpl->Set(TABTEXT,"Kalender");

    $submit = $this->app->Secure->GetPOST("submitForm");
    $mode = $this->app->Secure->GetPOST("mode");
    $eventid = $this->app->Secure->GetPOST("eventid");

    $titel = $this->app->Secure->GetPOST("titel");
    $datum = $this->app->Secure->GetPOST("datum");
    $datum_bis = $this->app->Secure->GetPOST("datum_bis");
    $allday = $this->app->Secure->GetPOST("allday");
    $public = $this->app->Secure->GetPOST("public");
    $von = $this->app->Secure->GetPOST("von");
    $bis = $this->app->Secure->GetPOST("bis");

    $personen = $this->app->Secure->GetPOST("personen");
    $color = $this->app->Secure->GetPOST("color");

    if($submit!="") {
      $von_datum =  $this->app->String->Convert("$datum $von", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
      $bis_datum =  $this->app->String->Convert("$datum_bis $bis", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");

      if($allday=='1') {
        $von_datum = $this->app->String->Convert("$datum 00:00", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
        $bis_datum = $this->app->String->Convert("$datum_bis 00:00", "%1.%2.%3 %4:%5", "%3-%2-%1 %4:%5");
        //$bis_datum = $datum_bis;
      }


      if($mode=="new") {
        $this->app->DB->Insert("INSERT INTO kalender_event (bezeichnung, von, bis, allDay, color, public) 
                                VALUES ('$titel', '$von_datum', '$bis_datum', '$allday', '$color', '$public')");
        $event = $this->app->DB->GetInsertID();
      }

      if($mode=="edit" && is_numeric($eventid)) {
        $this->app->DB->Update("UPDATE kalender_event SET bezeichnung='$titel', von='$von_datum', bis='$bis_datum', 
                                allDay='$allday', color='$color', public='$public' WHERE id='$eventid' LIMIT 1");
        $this->app->DB->Delete("DELETE FROM kalender_user WHERE event='$eventid'");
        $event = $eventid;
      }

      if($mode=="delete" && is_numeric($eventid)) {
        $this->app->DB->Delete("DELETE FROM kalender_event WHERE id='$eventid' LIMIT 1");
        $this->app->DB->Delete("DELETE FROM kalender_user WHERE event='$eventid'");
      }

      if($mode=="copy" && is_numeric($eventid)) {
        $cData = $this->app->DB->SelectArr("SELECT * FROM kalender_event WHERE id='$eventid' LIMIT 1");
        $this->app->DB->Insert("INSERT INTO kalender_event (bezeichnung, von, bis, allDay, color, public) 
                                VALUES ('{$cData[0]['bezeichnung']}', '{$cData[0]['von']}', '{$cData[0]['bis']}', 
                                        '{$cData[0]['allDay']}', '{$cData[0]['color']}', '{$cData[0]['public']}')");
        $event = $this->app->DB->GetInsertID();
      }

      // Schreibe Personen  
      if(is_numeric($event) && is_array($personen) && count($personen) && $mode!="delete") {
        for($p=0;$p<count($personen);$p++)
          $this->app->DB->Insert("INSERT INTO kalender_user (event, userid) VALUES ('$event', '{$personen[$p]}')");
      }
    }

    // Personen Auswahl
    $user = $this->app->User->GetID();
		if($this->app->Conf->WFdbType=="postgre")
    	$users = $this->app->DB->SelectArr("SELECT id, description FROM \"user\" WHERE activ='1' ORDER BY username");
		else
			$users = $this->app->DB->SelectArr("SELECT id, description FROM user WHERE activ='1' ORDER BY username");
    for($i=0; $i<count($users);$i++){
      $select = (($user==$users[$i]['id']) ? "selected" : "");
      $user_out .= "<option value=\"{$users[$i]['id']}\" $select>{$users[$i]['description']}</option>";
    }
    $this->app->Tpl->Set('PERSONEN', $user_out);


    $this->app->Tpl->Set('COLORS', $this->ColorPicker());
    $this->app->Tpl->Parse($parsetarget,"kalender.tpl");

  }


	function NavigationOSS()
	{

		$navarray[menu][web][0][first]  = array('wawision','welcome','main');
    $navarray[menu][web][0][sec][]  = array('Anmelden','welcome','login');

 // admin menu
    $menu = 0;
    $navarray[menu][admin][++$menu][first]  = array('Stammdaten','adresse','list');
    $navarray[menu][admin][$menu][sec][]  = array('Adressen','adresse','list');
    $navarray[menu][admin][$menu][sec][]  = array('Artikel','artikel','list');
    $navarray[menu][admin][$menu][sec][] = array('Projekte','projekt','list');

    $navarray[menu][admin][++$menu][first]  = array('Verkauf','auftrag','list');
    $navarray[menu][admin][$menu][sec][]  = array('Angebot','angebot','list');
    $navarray[menu][admin][$menu][sec][]  = array('Auftrag','auftrag','list');
    //$this->WFconf[menu][admin][$menu][sec][]  = array('Auftragsuche','auftrag','search');

    $navarray[menu][admin][++$menu][first]  = array('Einkauf','auftrag','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Preisanfrage','preisanfrage','list');
    $navarray[menu][admin][$menu][sec][]  = array('Bestellung','bestellung','list');

   // $navarray[menu][admin][$menu][sec][]  = array('Bestellvorschlag','bestellvorschlag','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Sammelbestellung','bestellung','sammel');

    $navarray[menu][admin][++$menu][first]  = array('Wareneingang','wareneingang','paketannahme');
    $navarray[menu][admin][$menu][sec][]  = array('Paket Annahme','wareneingang','paketannahme');
    $navarray[menu][admin][$menu][sec][]  = array('Paket Distribution','wareneingang','distribution');

    //$navarray[menu][admin][$menu][sec][]  = array('Retoursendung','wareneingang','rma');

    $navarray[menu][admin][++$menu][first]  = array('Buchhaltung','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Rechnungen','rechnung','list');
  //  $navarray[menu][admin][$menu][sec][]  = array('Zahlungseingang','zahlungseingang','list');
 //   $navarray[menu][admin][$menu][sec][]  = array('Verbindlichkeiten','verbindlichkeit','list');
    $navarray[menu][admin][$menu][sec][]  = array('Gutschriften/Storno','gutschrift','list');
 //   $navarray[menu][admin][$menu][sec][]  = array('Abolauf','rechnungslauf','rechnungslauf');
 //   $navarray[menu][admin][$menu][sec][]  = array('Mahnwesen','rechnung','mahnwesen');
//    $navarray[menu][admin][$menu][sec][]  = array('Kontoblatt','kontoblatt','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Lastschriften','rechnung','lastschrift');
//    $navarray[menu][admin][$menu][sec][]  = array('Ausgabe melden','buchhaltung','ausgabemelden');
//    $navarray[menu][admin][$menu][sec][]  = array('Lohnabrechnung','lohnabrechnung','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Stornierungen','stornierungen','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Briefe f&uuml;r Post','stornierungen','list');

    $navarray[menu][admin][++$menu][first]  = array('Marketing','marketing','list');
    $navarray[menu][admin][$menu][sec][]  = array('Verkaufszahlen','verkaufszahlen','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Partner Auszahlungen','partner','list');
 //   $navarray[menu][admin][$menu][sec][]  = array('Kampangen','marketing','kampangen');
 //   $navarray[menu][admin][$menu][sec][]  = array('Marketing Plan','marketing','list');
    $navarray[menu][admin][$menu][sec][]  = array('Quick-Mailing','mailing','list');
 //   $navarray[menu][admin][$menu][sec][]  = array('Katalog','katalog','list');


    $navarray[menu][admin][++$menu][first]  = array('Verwaltung','rechnung','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Artikel &Uuml;bersetzungen','uebersetzung','main');
   // $navarray[menu][admin][$menu][sec][]  = array('Massenartikel','massenartikel','edit');
  //  $navarray[menu][admin][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');
    //$navarray[menu][admin][$menu][sec][]  = array('Import St&uuml;ckliste','rechnung','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Fertigung planen','rechnung','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Pflichtenheft Tool','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Shop Import','shopimport','list');
    $navarray[menu][admin][$menu][sec][]  = array('Shop Export','shopexport','list');
    $navarray[menu][admin][$menu][sec][]  = array('Lagerlampen','artikel','lagerlampe');
    //$navarray[menu][admin][$menu][sec][]  = array('Artikel Reservierung','versanderzeugen','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Dateien','dateien','list'); 
    //$navarray[menu][admin][$menu][sec][]  = array('Scanner','ticket','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Gesetzliches E-Mail Backup','emailbackup','list');
  //  $navarray[menu][admin][$menu][sec][]  = array('Kassenbuch','kasse','list');
 //   $navarray[menu][admin][$menu][sec][]  = array('RMA Lieferungen','wareneingang','rmalist');


    $navarray[menu][admin][++$menu][first] = array('Lager','lager','list');
    $navarray[menu][admin][$menu][sec][]   = array('Lieferschein','lieferschein','list');
    $navarray[menu][admin][$menu][sec][]   = array('Lagerverwaltung','lager','list');
  //  $navarray[menu][admin][$menu][sec][]   = array('Reservierungen','lager','reservierungen');
  //  $navarray[menu][admin][$menu][sec][]   = array('Lager Kalkulation','lager','ausgehend');
 //   $navarray[menu][admin][$menu][sec][]   = array('Produktionslager','lager','produktionslager');
    $navarray[menu][admin][$menu][sec][]   = array('Ein- und auslagern','lager','buchen');
    $navarray[menu][admin][$menu][sec][]   = array('Zwischenlager','lager','buchenzwischenlager');
    $navarray[menu][admin][$menu][sec][]   = array('Artikel f&uuml;r Lieferungen','lager','artikelfuerlieferungen');


    $navarray[menu][admin][++$menu][first]  = array('Administration','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Einstellungen','einstellungen','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Ger&auml;teverwaltung','geraete','list');
    $navarray[menu][admin][$menu][sec][]  = array('Backup','backup','list','recover','delete','reset');
    //$navarray[menu][admin][$menu][sec][]  = array('Updates / Plugins','ticket','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Netzwerk','netzwerk','list');

    $navarray[menu][admin][++$menu][first]  = array('Mein Bereich','welcome','main');
    $navarray[menu][admin][$menu][sec][]  = array('Startseite','welcome','start');
    //$navarray[menu][admin][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][admin][$menu][sec][]  = array('Kalender','kalender','list');
    $navarray[menu][admin][$menu][sec][]  = array('Wiki','wiki','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Aufgaben','aufgaben','list');
  //  $navarray[menu][admin][$menu][sec][]  = array('E-Mail Archiv','webmail','list');
    $navarray[menu][admin][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','create');
    //$navarray[menu][admin][$menu][sec][]  = array('Urlaub','urlaub','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Krankheit / Fehltage','krankheit','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Fahrtenbuch','krankheit','list');
    $navarray[menu][admin][$menu][sec][]  = array('Abmelden','welcome','logout');

    return $navarray[menu][admin];


	}


	function NavigationCOM()
	{
 // admin menu
    $menu = 0;
/*
    $navarray[menu][mitarbeiter][++$menu][first]  = array('Mein EPROO','welcome','main');
    $navarray[menu][mitarbeiter][$menu][sec][]  = array('Startseite','welcome','start');
   // $navarray[menu][mitarbeiter][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][mitarbeiter][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','list');
    $navarray[menu][mitarbeiter][$menu][sec][]  = array('Wiki','wiki','list');
    $navarray[menu][mitarbeiter][$menu][sec][]  = array('Abmelden','welcome','logout');

 // admin menu
    $menu = 0;
  $navarray[menu][produktion][++$menu][first]  = array('Stammdaten','adresse','list');
    $navarray[menu][produktion][$menu][sec][]  = array('Artikel','artikel','list');

    $navarray[menu][produktion][++$menu][first]  = array('Wareneingang','wareneingang','paketannahme');
    $navarray[menu][produktion][$menu][sec][]  = array('Paket Annahme','wareneingang','paketannahme');
    $navarray[menu][produktion][$menu][sec][]  = array('Paket Distribution','wareneingang','distribution');

    $navarray[menu][produktion][++$menu][first] = array('Lager','lager','list');
    $navarray[menu][produktion][$menu][sec][]   = array('Ein- und auslagern','lager','bucheneinlagern');
    $navarray[menu][produktion][$menu][sec][]   = array('Artikel f&uuml;r Lieferungen','lager','artikelfuerlieferungen');
    //$navarray[menu][produktion][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');


    $navarray[menu][produktion][++$menu][first]  = array('Mein EPROO','welcome','main');
    $navarray[menu][produktion][$menu][sec][]  = array('Startseite','welcome','start');
   // $navarray[menu][produktion][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][produktion][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','list');
    $navarray[menu][produktion][$menu][sec][]  = array('Wiki','wiki','list');
    $navarray[menu][produktion][$menu][sec][]  = array('Abmelden','welcome','logout');




    $menu = 0;
  $navarray[menu][verwaltung][++$menu][first]  = array('Stammdaten','adresse','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Adressen','adresse','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Artikel','artikel','list');

    $navarray[menu][verwaltung][++$menu][first]  = array('Verkauf','auftrag','list');
//    $navarray[menu][verwaltung][$menu][sec][]  = array('Angebot','angebot','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Auftrag','auftrag','list');
//    $navarray[menu][verwaltung][$menu][sec][]  = array('Auftragsuche','auftrag','search');

    $navarray[menu][verwaltung][++$menu][first]  = array('Wareneingang','wareneingang','paketannahme');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Paket Annahme','wareneingang','paketannahme');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Paket Distribution','wareneingang','distribution');

    $navarray[menu][verwaltung][++$menu][first]  = array('Verwaltung','rechnung','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Etikettendrucker','etikettendrucker','list');
//    $navarray[menu][verwaltung][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');
//    $navarray[menu][verwaltung][$menu][sec][]  = array('Kassenbuch','kasse','list');
    $navarray[menu][verwaltung][++$menu][first] = array('Lager','lager','list');
    $navarray[menu][verwaltung][$menu][sec][]   = array('Zwischenlager','lager','buchenzwischenlager');
    $navarray[menu][verwaltung][$menu][sec][]   = array('Ein- und auslagern','lager','bucheneinlagern');
    $navarray[menu][verwaltung][$menu][sec][]   = array('Artikel f&uuml;r Lieferungen','lager','artikelfuerlieferungen');
    $navarray[menu][verwaltung][$menu][sec][]   = array('Artikel f&uuml;r Produktion','lager','artikelfuerlieferungen&cmd=produktion');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');


    $navarray[menu][verwaltung][++$menu][first]  = array('Mein EPROO','welcome','main');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Startseite','welcome','start');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Kalender','kalender','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Wiki','wiki','list');
    $navarray[menu][verwaltung][$menu][sec][]  = array('Abmelden','welcome','logout');


    $menu = 0;
    $navarray[menu][vollzugriff][++$menu][first]  = array('Stammdaten','adresse','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Adressen','adresse','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Artikel','artikel','list');
    $navarray[menu][vollzugriff][$menu][sec][] = array('Projekte','projekt','list');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Verkauf','auftrag','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Angebot','angebot','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Auftrag','auftrag','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Auftragsuche','auftrag','search');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Einkauf','auftrag','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Preisanfrage','preisanfrage','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Bestellung','bestellung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Produktionsplanung','produktion','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Bestellvorschlag','bestellvorschlag','list');

    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Sammelbestellung','bestellung','sammel');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Wareneingang','wareneingang','paketannahme');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Paket Annahme','wareneingang','paketannahme');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Paket Distribution','wareneingang','distribution');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Retoursendung','wareneingang','rma');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Buchhaltung','rechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Rechnungen','rechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Zahlungseingang','zahlungseingang','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Verbindlichkeiten','verbindlichkeit','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Gutschriften/Storno','gutschrift','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Abolauf','rechnungslauf','rechnungslauf');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Mahnwesen','rechnung','mahnwesen');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Kontoblatt','kontoblatt','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Lastschriften','rechnung','lastschrift');
//    $navarray[menu][vollzugriff][$menu][sec][]  = array('Ausgabe melden','buchhaltung','ausgabemelden');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Lohnabrechnung','lohnabrechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Stornierungen','stornierungen','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Kassenbuch','kasse','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Briefe f&uuml;r Post','stornierungen','list');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Marketing','marketing','list');
  	$navarray[menu][vollzugriff][$menu][sec][]  = array('Verkaufszahlen','verkaufszahlen','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Partner Auszahlungen','partner','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Kampangen','marketing','kampangen');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Marketing Plan','marketing','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Quick-Mailing','mailing','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Katalog','katalog','list');



    $navarray[menu][vollzugriff][++$menu][first]  = array('Verwaltung','rechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Artikel &Uuml;bersetzungen','uebersetzung','main');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Massenartikel','massenartikel','edit');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Import St&uuml;ckliste','rechnung','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Fertigung planen','rechnung','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Pflichtenheft Tool','rechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Shop Import','shopimport','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Shop Export','shopexport','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Lagerlampen','artikel','lagerlampe');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Artikel Reservierung','versanderzeugen','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Dateien','dateien','list'); 
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Scanner','ticket','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Gesetzliches E-Mail Backup','emailbackup','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('RMA Lieferungen','wareneingang','rmalist');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Linkeditor','linkeditor','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Etikettendrucker','etikettendrucker','list');


    $navarray[menu][vollzugriff][++$menu][first] = array('Lager','lager','list');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Lieferschein','lieferschein','list');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Lagerverwaltung','lager','list');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Reservierungen','lager','reservierungen');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Lager Kalkulation','lager','ausgehend');
//    $navarray[menu][vollzugriff][$menu][sec][]   = array('Produktionslager','lager','produktionslager');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Ein- und auslagern','lager','buchen');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Zwischenlager','lager','buchenzwischenlager');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Artikel f&uuml;r Lieferungen','lager','artikelfuerlieferungen');
    $navarray[menu][vollzugriff][$menu][sec][]   = array('Artikel f&uuml;r Produktionen','lager','artikelfuerlieferungen&cmd=produktion');


    $navarray[menu][vollzugriff][++$menu][first]  = array('Administration','rechnung','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Einstellungen','einstellungen','list');
//    $navarray[menu][vollzugriff][$menu][sec][]  = array('Ger&auml;teverwaltung','geraete','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Backup','backup','list','recover','delete','reset');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Updates / Plugins','ticket','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Netzwerk','netzwerk','list');

    $navarray[menu][vollzugriff][++$menu][first]  = array('Mein Bereich','welcome','main');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Startseite','welcome','start');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Kalender','kalender','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Aufgaben','aufgaben','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('E-Mail Archiv','webmail','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Urlaub','urlaub','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Krankheit / Fehltage','krankheit','list');
    //$navarray[menu][vollzugriff][$menu][sec][]  = array('Fahrtenbuch','krankheit','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Wiki','wiki','list');
    $navarray[menu][vollzugriff][$menu][sec][]  = array('Abmelden','welcome','logout');

*/
    $menu = 0;
    $navarray[menu][admin][++$menu][first]  = array('Stammdaten','adresse','list');
    $navarray[menu][admin][$menu][sec][]  = array('Adressen','adresse','list');
    $navarray[menu][admin][$menu][sec][]  = array('Artikel','artikel','list');
    $navarray[menu][admin][$menu][sec][] = array('Projekte','projekt','list');

    $navarray[menu][admin][++$menu][first]  = array('Verkauf','auftrag','list');
    $navarray[menu][admin][$menu][sec][]  = array('Angebot','angebot','list');
    $navarray[menu][admin][$menu][sec][]  = array('Auftrag','auftrag','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Auftragsuche','auftrag','search');

    $navarray[menu][admin][++$menu][first]  = array('Einkauf','auftrag','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Preisanfrage','preisanfrage','list');
    $navarray[menu][admin][$menu][sec][]  = array('Bestellung','bestellung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Produktionsplanung','produktion','list');
    $navarray[menu][admin][$menu][sec][]  = array('Bestellvorschlag','bestellvorschlag','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Sammelbestellung','bestellung','sammel');

    $navarray[menu][admin][++$menu][first]  = array('Wareneingang','wareneingang','paketannahme');
    $navarray[menu][admin][$menu][sec][]  = array('Paket Annahme','wareneingang','paketannahme');
    $navarray[menu][admin][$menu][sec][]  = array('Paket Distribution','wareneingang','distribution');
    //$navarray[menu][admin][$menu][sec][]  = array('Retoursendung','wareneingang','rma');

    $navarray[menu][admin][++$menu][first]  = array('Buchhaltung','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Rechnungen','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Zahlungseingang','zahlungseingang','list');
    $navarray[menu][admin][$menu][sec][]  = array('Verbindlichkeiten','verbindlichkeit','list');
    $navarray[menu][admin][$menu][sec][]  = array('Gutschriften/Storno','gutschrift','list');
    $navarray[menu][admin][$menu][sec][]  = array('Abolauf','rechnungslauf','rechnungslauf');
    $navarray[menu][admin][$menu][sec][]  = array('Mahnwesen','rechnung','mahnwesen');
    $navarray[menu][admin][$menu][sec][]  = array('Kontoblatt','kontoblatt','list');
    $navarray[menu][admin][$menu][sec][]  = array('Lastschriften','rechnung','lastschrift');
//    $navarray[menu][admin][$menu][sec][]  = array('Ausgabe melden','buchhaltung','ausgabemelden');
    $navarray[menu][admin][$menu][sec][]  = array('Lohnabrechnung','lohnabrechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Stornierungen','stornierungen','list');
    $navarray[menu][admin][$menu][sec][]  = array('Kassenbuch','kasse','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Briefe f&uuml;r Post','stornierungen','list');

    $navarray[menu][admin][++$menu][first]  = array('Marketing','marketing','list');
  	$navarray[menu][admin][$menu][sec][]  = array('Verkaufszahlen','verkaufszahlen','list');
    $navarray[menu][admin][$menu][sec][]  = array('Partner Auszahlungen','partner','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Kampangen','marketing','kampangen');
    //$navarray[menu][admin][$menu][sec][]  = array('Marketing Plan','marketing','list');
    $navarray[menu][admin][$menu][sec][]  = array('Quick-Mailing','mailing','list');
    $navarray[menu][admin][$menu][sec][]  = array('Katalog','katalog','list');



    $navarray[menu][admin][++$menu][first]  = array('Verwaltung','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Artikel &Uuml;bersetzungen','uebersetzung','main');
    $navarray[menu][admin][$menu][sec][]  = array('Massenartikel','massenartikel','edit');
    $navarray[menu][admin][$menu][sec][]  = array('Versand starten','versanderzeugen','offene');
    //$navarray[menu][admin][$menu][sec][]  = array('Import St&uuml;ckliste','rechnung','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Fertigung planen','rechnung','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Pflichtenheft Tool','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Shop Import','shopimport','list');
    $navarray[menu][admin][$menu][sec][]  = array('Shop Export','shopexport','list');
    $navarray[menu][admin][$menu][sec][]  = array('Lagerlampen','artikel','lagerlampe');
    //$navarray[menu][admin][$menu][sec][]  = array('Artikel Reservierung','versanderzeugen','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Dateien','dateien','list'); 
    //$navarray[menu][admin][$menu][sec][]  = array('Scanner','ticket','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Gesetzliches E-Mail Backup','emailbackup','list');
    $navarray[menu][admin][$menu][sec][]  = array('RMA Lieferungen','wareneingang','rmalist');
    $navarray[menu][admin][$menu][sec][]  = array('Linkeditor','linkeditor','list');
    $navarray[menu][admin][$menu][sec][]  = array('Etikettendrucker','etikettendrucker','list');


    $navarray[menu][admin][++$menu][first] = array('Lager','lager','list');
    $navarray[menu][admin][$menu][sec][]   = array('Lieferschein','lieferschein','list');
    $navarray[menu][admin][$menu][sec][]   = array('Lagerverwaltung','lager','list');
    $navarray[menu][admin][$menu][sec][]   = array('Reservierungen','lager','reservierungen');
    $navarray[menu][admin][$menu][sec][]   = array('Lager Kalkulation','lager','ausgehend');
//    $navarray[menu][admin][$menu][sec][]   = array('Produktionslager','lager','produktionslager');
    $navarray[menu][admin][$menu][sec][]   = array('Ein- und auslagern','lager','buchen');
    $navarray[menu][admin][$menu][sec][]   = array('Zwischenlager','lager','buchenzwischenlager');
    $navarray[menu][admin][$menu][sec][]   = array('Artikel f&uuml;r Lieferungen','lager','artikelfuerlieferungen');
    $navarray[menu][admin][$menu][sec][]   = array('Artikel f&uuml;r Produktionen','lager','artikelfuerlieferungen&cmd=produktion');


    $navarray[menu][admin][++$menu][first]  = array('Administration','rechnung','list');
    $navarray[menu][admin][$menu][sec][]  = array('Einstellungen','einstellungen','list');
//    $navarray[menu][admin][$menu][sec][]  = array('Ger&auml;teverwaltung','geraete','list');
    $navarray[menu][admin][$menu][sec][]  = array('Backup','backup','list','recover','delete','reset');
    //$navarray[menu][admin][$menu][sec][]  = array('Updates / Plugins','ticket','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Netzwerk','netzwerk','list');

    $navarray[menu][admin][++$menu][first]  = array('Mein Bereich','welcome','main');
    $navarray[menu][admin][$menu][sec][]  = array('Startseite','welcome','start');
    $navarray[menu][admin][$menu][sec][]  = array('Tickets','ticket','list');
    $navarray[menu][admin][$menu][sec][]  = array('Kalender','kalender','list');
    $navarray[menu][admin][$menu][sec][]  = array('Aufgaben','aufgaben','list');
    $navarray[menu][admin][$menu][sec][]  = array('E-Mail Archiv','webmail','list');
    $navarray[menu][admin][$menu][sec][]  = array('Zeiterfassung','zeiterfassung','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Urlaub','urlaub','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Krankheit / Fehltage','krankheit','list');
    //$navarray[menu][admin][$menu][sec][]  = array('Fahrtenbuch','krankheit','list');
    $navarray[menu][admin][$menu][sec][]  = array('Wiki','wiki','list');
    $navarray[menu][admin][$menu][sec][]  = array('Abmelden','welcome','logout');

		$type = $this->app->User->GetType();
		if($type=="admin") return $navarray[menu][admin];

		$permissions_module = $this->app->DB->SelectArr("SELECT module,action FROM userrights WHERE user='".$this->app->User->GetID()."' AND permission='1'");

		for($i=0;$i<count($permissions_module);$i++)
			$permission_module_new[] = $permissions_module[$i]["module"]."_".$permissions_module[$i]["action"];

		$menu = 0;
		$menu_no=1;
    foreach($navarray[menu][admin] as $key=>$value){
			//echo "haupt:".$value[first][0]."<br>";
			
			$menu++;
		  if(count($value[sec])>0){
		    foreach($value[sec] as $secnav){
					//echo $secnav[0]." ".$secnav[1]." ".$secnav[2]."<br>";
					$und_pos = stripos ( $secnav[2] , '&');
					if($und_pos>0)
						$secnav_check =  substr ( $secnav[2] , 0,stripos ( $secnav[2] , '&') );
					else
					$secnav_check = $secnav[2];
					if(@in_array($secnav[1]."_".$secnav_check,$permission_module_new))
					{
    				$navarray[menu][tmp][$menu][sec][]  = array($secnav[0],$secnav[1],$secnav[2]);
						$menu_no=0;
					}
				}
			}
			if($menu_no==0)
			$navarray[menu][tmp][$menu][first] = array($value[first][0],$value[first][1],'main');
			$menu_no=1;

		}
				
		return $navarray[menu][tmp];
	}


	function Version()
	{
		include("../version.php");

		$version = split('_',$version);

		return $version[0];
	}

	function Revision()
	{
		include("../version.php");
		return "2.3.".$version_revision;
	}

	function Config2Array($config)
	{
		$entries = explode (';', $config);
		// $entries enthält alle key => value paare
		foreach ($entries as $pair) {
    	preg_match("/(.+)=>(.+)$/", $pair, $matches);
    	$array[$matches[1]] = $matches[2];
		}  
		
		return array_filter($array);
	}


	function LiveImport($konto)
	{
		$zugangsdaten = $this->app->DB->Select("SELECT liveimport FROM konten WHERE id='$konto' LIMIT 1");
    $zugangsdaten = $this->app->erp->Config2Array($zugangsdaten);

		$kontotyp = $this->app->DB->Select("SELECT type FROM konten WHERE id='$konto' LIMIT 1");

    if(is_file("plugins/liveimport/$kontotyp/$kontotyp.php"))
    {
			include("plugins/liveimport/$kontotyp/$kontotyp.php");
		  $tmp = new $kontotyp();
		  return $tmp->Import($zugangsdaten);
    } else return "";

	}

  function AutoresponderBlacklist($mail)
  {
    $this->app->DB->Delete("DELETE FROM autoresponder_blacklist WHERE cachetime < date_sub(NOW(), INTERVAL 1 DAY)");

    $check = $this->app->DB->Select("SELECT mailaddress FROM autoresponder_blacklist WHERE mailaddress='$mail' LIMIT 1");

    if($check == $mail)
      return 1;
   
    $this->app->DB->Insert("INSERT INTO autoresponder_blacklist (mailaddress,cachetime) VALUES ('$mail',NOW())");  
    return 0;
  }

	function LieferadresseButton($adresse)
	{
		    $this->app->Tpl->Set(LIEFERADRESSEPOPUP,'
    <script>
  $(function() {
  $("#mehr2").button();
  });

function closeIframe()
{
    $(\'.externalSite\').dialog(\'close\');
    return false;
}

  </script>

  <a id="mehr2" style="font-size: 8pt; " href="index.php?module=adresse&action=lieferadressepopup&id='.$adresse.'&iframe=true" class="popup" title="Lieferadresse einf&uuml;gen">Lieferadresse einf&uuml;gen</a>');
//"<input type=\"button\" value=\"Ansprechpartner einf&uuml;gen\">");

	}


  function GetNavigationSelect($shop)
	{


    $oberpunkte = $this->app->DB->SelectArr("SELECT id, bezeichnung, bezeichnung_en, plugin,pluginparameter FROM shopnavigation WHERE parent=0  AND shop='$shop' ORDER BY position");

			$tmp = array();
		  foreach($oberpunkte as $punkt)
			{
				$tmp["{$punkt["id"]}"]=$punkt["bezeichnung"];
				$unterpunkte = $this->app->DB->SelectArr("SELECT id, bezeichnung, bezeichnung_en, plugin,pluginparameter FROM shopnavigation WHERE parent='".$punkt["id"]."' AND shop='$shop' ORDER BY position");

				foreach($unterpunkte as $upunkt)
					$tmp["{$upunkt["id"]}"]="&nbsp;&nbsp;&nbsp;".$upunkt["bezeichnung"];
			}

		return $tmp;
	}



	function AnsprechpartnerButton($adresse)
	{
		    $this->app->Tpl->Set(ANSPRECHPARTNERPOPUP,'
    <script>
  $(function() {
  $("#mehr").button();
  });

function closeIframe()
{
    $(\'.externalSite\').dialog(\'close\');
    return false;
}

  </script>

  <a id="mehr" style="font-size: 8pt; " href="index.php?module=adresse&action=ansprechpartnerpopup&id='.$adresse.'&iframe=true" class="popup" title="Ansprechpartner einf&uuml;gen">Ansprechpartner einf&uuml;gen</a>');
//"<input type=\"button\" value=\"Ansprechpartner einf&uuml;gen\">");

	}


  function ArtikelAnzahlLager($artikel)
  {
		return $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel'");
  }


  function ArtikelAnzahlReserviert($artikel)
  {
		return $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='$artikel'");
  }


	function MaxArtikelbezeichnung()
	{
		return 50;
	}

	function CleanString($value)
	{
		$value=trim($value);
    $value = $this->app->Secure->stripallslashes($value);
    $value = $this->app->Secure->smartstripslashes($value);
    //$value = htmlspecialchars($value,ENT_QUOTES);
    $value = str_replace('"','&Prime;',$value);
    $value = str_replace("'",'&prime;',$value);
		return $value;
	}


	function CleanDataBeforImport($data)
	{

		if(is_array($data))
		{
			foreach($data as $value=>$key)
			{
					$data[$key] = $this->CleanString($value);
			}

			return $data;

		} else {
				$data = $this->CleanString($data);
			return $data;	
		}

	}


	function Standardprojekt($table,$id)
	{
    $projekt = $this->app->DB->Select("SELECT projekt FROM `$table` WHERE id='$id' LIMIT 1");
    if($projekt<1)
    {
      $standardprojekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");
      $this->app->DB->Update("UPDATE `$table` SET projekt='".$standardprojekt."' WHERE id='".$id."' LIMIT 1");
    }
	}

	function UpgradeDatabase()
	{
		
		$this->CheckColumn("public","int(1)","kalender_event");
		$this->CheckColumn("vorname","varchar(255)","adresse");
		$this->CheckColumn("kalender_aufgaben","int(1)","adresse");	

		$this->CheckColumn("keinsteuersatz","int(1)","angebot");
		$this->CheckColumn("keinsteuersatz","int(1)","auftrag");
		$this->CheckColumn("keinsteuersatz","int(1)","rechnung");
		$this->CheckColumn("keinsteuersatz","int(1)","gutschrift");

		$this->CheckColumn("geloescht","int(1)","arbeitspaket");

		$this->CheckColumn("adresse_abrechnung","int(11)","zeiterfassung");
		$this->CheckColumn("abrechnen","int(1)","zeiterfassung");
		$this->CheckColumn("ist_abgerechnet","int(1)","zeiterfassung");

		$this->CheckColumn("reservierung","int(1)","projekt");

		$this->CheckColumn("stornorechnung","int(1)","gutschrift");
		$this->CheckColumn("startseite","int(1)","aufgabe");
		$this->CheckColumn("emailerinnerung","int(1)","aufgabe");
		$this->CheckColumn("emailerinnerung_tage","int(11)","aufgabe");

		$this->CheckColumn("vorankuendigung","int(11)","aufgabe");
		$this->CheckColumn("status","varchar(255)","aufgabe");

		$this->CheckColumn("angebotid","int(11)","auftrag");
		$this->CheckColumn("internetseite","text","adresse");

		$this->CheckColumn("importgroup","bigint","kontoauszuege");


		$this->CheckColumn("beschreibung_de","text","artikelgruppen");
		$this->CheckColumn("beschreibung_en","text","artikelgruppen");

		$this->CheckColumn("internebemerkung","text","gutschrift");
		$this->CheckColumn("internebemerkung","text","rechnung");

		$this->CheckColumn("ohne_briefpapier","int(1)","rechnung");
		$this->CheckColumn("ohne_briefpapier","int(1)","lieferschein");
		$this->CheckColumn("ohne_briefpapier","int(1)","angebot");
		$this->CheckColumn("ohne_briefpapier","int(1)","auftrag");
		$this->CheckColumn("ohne_briefpapier","int(1)","bestellung");
		$this->CheckColumn("ohne_briefpapier","int(1)","gutschrift");

		$this->CheckColumn("flattenedparts","longblob","emailbackup_mails");
		$this->CheckColumn("attachment","longblob","emailbackup_mails");

		$this->CheckColumn("internebemerkung","text","kontoauszuege");
		$this->CheckColumn("importfehler","int(1)","kontoauszuege");
		$this->CheckColumn("projekt","int(11)","firmendaten");

		$this->CheckColumn("liveimport","text","konten");
		$this->CheckColumn("liveimport_online","int(1)","konten");

		$this->CheckColumn("zahlungsmailcounter","int(1)","auftrag");

		$this->CheckColumn("ansprechpartner","varchar(255)","angebot");
		$this->CheckColumn("bezeichnung","varchar(255)","produktion");
		
		$this->CheckColumn("ticketqueue","varchar(255)","emailbackup");
		$this->CheckColumn("ticketprojekt","varchar(255)","emailbackup");

   $this->CheckTable("autoresponder_blacklist");
   $this->CheckColumn("cachetime","timestamp","autoresponder_blacklist");
   $this->CheckColumn("mailaddress","varchar(512)","autoresponder_blacklist");


		// accordion
		$this->CheckTable("accordion");
   	$this->CheckColumn("id","int(11)","accordion");
   	$this->CheckColumn("name","varchar(255)","accordion");
   	$this->CheckColumn("target","varchar(255)","accordion");
   	$this->CheckColumn("position","int(2)","accordion");




		//inhalt
   $this->CheckColumn("kurztext","text","inhalt");
   $this->CheckColumn("title","varchar(255)","inhalt");
   $this->CheckColumn("description","varchar(512)","inhalt");
   $this->CheckColumn("keywords","varchar(512)","inhalt");
   $this->CheckColumn("inhaltstyp","varchar(255)","inhalt");
   $this->CheckColumn("sichtbarbis","datetime","inhalt");
   $this->CheckColumn("datum","date","inhalt");
   $this->CheckColumn("template","varchar(255)","inhalt");
   $this->CheckColumn("finalparse","varchar(255)","inhalt");
   $this->CheckColumn("navigation","varchar(255)","inhalt");


		$this->CheckColumn("hwtoken","int(1)","user");
		$this->CheckColumn("hwkey","varchar(255)","user");
		$this->CheckColumn("hwcounter","int(11)","user");
		$this->CheckColumn("hwdatablock","varchar(255)","user");
		$this->CheckColumn("motppin","varchar(255)","user");
		$this->CheckColumn("motpsecret","varchar(255)","user");
		$this->CheckColumn("externlogin","int(1)","user");

		//wiki
		$this->CheckTable("wiki");
		$this->CheckColumn("name","varchar(255)","wiki");
		$this->CheckColumn("content","text","wiki");
		$this->CheckColumn("lastcontent","text","wiki");

		//tabelle backup
		$this->CheckTable("backup");
		$this->CheckColumn("adresse","int(11)","backup");
		$this->CheckColumn("name","varchar(255)","backup");
		$this->CheckColumn("dateiname","varchar(255)","backup");
		$this->CheckColumn("datum","datetime","backup");

		//Tabelle artikel_shop
		$this->CheckTable("artikel_shop");
		$this->CheckColumn("artikel","int(11)","artikel_shop");
		$this->CheckColumn("shop","int(11)","artikel_shop");
		$this->CheckColumn("checksum","text","artikel_shop");

		// Tabelle dokumente
		$this->CheckTable("dokumente");
		$this->CheckColumn("id","int(11)","dokumente");
		$this->CheckColumn("adresse_from","int(11)","dokumente");
		$this->CheckColumn("adresse_to","int(11)","dokumente");
		$this->CheckColumn("typ","varchar(24)","dokumente");
		$this->CheckColumn("von","varchar(512)","dokumente");
		$this->CheckColumn("firma","varchar(512)","dokumente");
		$this->CheckColumn("ansprechpartner","varchar(512)","dokumente");
		$this->CheckColumn("an","varchar(512)","dokumente");
		$this->CheckColumn("email_an","varchar(255)","dokumente");
		$this->CheckColumn("firma_an","varchar(255)","dokumente");
		$this->CheckColumn("adresse","varchar(255)","dokumente");
		$this->CheckColumn("plz","varchar(16)","dokumente");
		$this->CheckColumn("ort","varchar(255)","dokumente");
		$this->CheckColumn("land","varchar(32)","dokumente");
		$this->CheckColumn("datum","date","dokumente");
		$this->CheckColumn("betreff","varchar(1023)","dokumente");
		$this->CheckColumn("content","text","dokumente");
		$this->CheckColumn("signatur","tinyint(1)","dokumente");
		$this->CheckColumn("send_as","varchar(24)","dokumente");
		$this->CheckColumn("email","varchar(255)","dokumente");
		$this->CheckColumn("printer","int(2)","dokumente");
		$this->CheckColumn("fax","int(2)","dokumente");
		$this->CheckColumn("sent","int(1)","dokumente");
		$this->CheckColumn("deleted","int(1)","dokumente");
		$this->CheckColumn("created","datetime","dokumente");


		// Tabelle linkeditor
		$this->CheckTable("linkeditor");
		$this->CheckColumn("id","int(4)","linkeditor");
		$this->CheckColumn("rule","varchar(1024)","linkeditor");
		$this->CheckColumn("replacewith","varchar(1024)","linkeditor");
		$this->CheckColumn("active","varchar(1)","linkeditor");
		

		// Tabelle userrights
		$this->CheckTable("userrights");
		$this->CheckColumn("id","int(11)","userrights");
		$this->CheckColumn("user","int(11)","userrights");
		$this->CheckColumn("module","varchar(64)","userrights");
		$this->CheckColumn("action","varchar(64)","userrights");
		$this->CheckColumn("permission","int(1)","userrights");


		$this->CheckTable("newsletter_blacklist");
		$this->CheckColumn("email","varchar(255)","newsletter_blacklist");

		// Tabelle artikel
		$this->CheckColumn("herstellernummer","varchar(255)","artikel");
		$this->CheckColumn("restmenge","int(1)","artikel");
		$this->CheckColumn("lieferzeitmanuell_en","varchar(255)","artikel");
		$this->CheckColumn("variante","int(1)","artikel");
		$this->CheckColumn("variante_von","int(11)","artikel");

		//firmendaten
		$this->CheckColumn("email","varchar(255)","firmendaten");
		$this->CheckColumn("absendername","varchar(255)","firmendaten");
		$this->CheckColumn("bcc1","varchar(255)","firmendaten");
		$this->CheckColumn("bcc2","varchar(255)","firmendaten");
		$this->CheckColumn("firmenfarbe","varchar(255)","firmendaten");
		$this->CheckColumn("name","varchar(255)","firmendaten");
		$this->CheckColumn("strasse","varchar(255)","firmendaten");
		$this->CheckColumn("plz","varchar(255)","firmendaten");
		$this->CheckColumn("ort","varchar(255)","firmendaten");
		$this->CheckColumn("steuernummer","varchar(255)","firmendaten");
		$this->CheckColumn("brieftext","varchar(255)","firmendaten");
		$this->CheckColumn("startseite_wiki","varchar(255)","firmendaten");

		$this->CheckColumn("next_angebot","varchar(255)","firmendaten");
		$this->CheckColumn("next_auftrag","varchar(255)","firmendaten");
		$this->CheckColumn("next_rechnung","varchar(255)","firmendaten");
		$this->CheckColumn("next_lieferschein","varchar(255)","firmendaten");
		$this->CheckColumn("next_bestellung","varchar(255)","firmendaten");
		$this->CheckColumn("next_gutschrift","varchar(255)","firmendaten");
		$this->CheckColumn("next_kundennumer","varchar(255)","firmendaten");
		$this->CheckColumn("next_lieferantennummer","varchar(255)","firmendaten");
		$this->CheckColumn("next_mitarbeiternummer","varchar(255)","firmendaten");
		$this->CheckColumn("next_waren","varchar(255)","firmendaten");
		$this->CheckColumn("next_produktionen","varchar(255)","firmendaten");
		$this->CheckColumn("next_sonstiges","varchar(255)","firmendaten");

		$this->CheckColumn("seite_von_ausrichtung","varchar(255)","firmendaten");
		$this->CheckColumn("seite_von_sichtbar","int(1)","firmendaten");

		$this->CheckColumn("rechnung_header","text","firmendaten");
		$this->CheckColumn("lieferschein_header","text","firmendaten");
		$this->CheckColumn("angebot_header","text","firmendaten");
		$this->CheckColumn("auftrag_header","text","firmendaten");
		$this->CheckColumn("rechnung_header","text","firmendaten");
		$this->CheckColumn("gutschrift_header","text","firmendaten");
		$this->CheckColumn("bestellung_header","text","firmendaten");

		$this->CheckColumn("rechnung_footer","text","firmendaten");
		$this->CheckColumn("lieferschein_footer","text","firmendaten");
		$this->CheckColumn("angebot_footer","text","firmendaten");
		$this->CheckColumn("auftrag_footer","text","firmendaten");
		$this->CheckColumn("rechnung_footer","text","firmendaten");
		$this->CheckColumn("gutschrift_footer","text","firmendaten");
		$this->CheckColumn("bestellung_footer","text","firmendaten");

	  $this->CheckColumn("rechnung_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("lieferschein_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("angebot_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("auftrag_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("rechnung_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("gutschrift_ohnebriefpapier","int(1)","firmendaten");
		$this->CheckColumn("bestellung_ohnebriefpapier","int(1)","firmendaten");


		$this->CheckColumn("eu_lieferung_vermerk","text","firmendaten");

		$this->CheckColumn("rabatt","int(11)","angebot_position","DEFAULT '0' NOT NULL");
		$this->CheckColumn("rabatt","int(11)","rechnung_position","DEFAULT '0' NOT NULL");
		$this->CheckColumn("rabatt","int(11)","auftrag_position","DEFAULT '0' NOT NULL");
		$this->CheckColumn("rabatt","int(11)","gutschrift_position","DEFAULT '0' NOT NULL");

		$this->CheckColumn("wareneingang_kamera_waage","int(1)","firmendaten");
		$this->CheckColumn("layout_iconbar","int(1)","firmendaten");

		$this->CheckColumn("artikelnummerninfotext","int(1)","bestellung");
		$this->CheckColumn("abgeschlossen","int(1)","bestellung_position");

		$this->CheckColumn("doppel","int(1)","rechnung");
		$this->CheckColumn("schreibbar","int(1)","konten");

		$this->CheckColumn("ansprechpartner","varchar(255)","bestellung");

		$this->CheckColumn("ansprechpartner","varchar(255)","lieferadressen");

		$this->CheckColumn("keinetrackingmail","int(1)","auftrag");
		$this->CheckColumn("keinetrackingmail","int(1)","versand");
		$this->CheckColumn("parent","int(11)","datev_buchungen");

		$this->CheckColumn("startseite","varchar(1024)","user");
		$this->CheckColumn("webid","varchar(1024)","adresse");
		$this->CheckColumn("titel","varchar(1024)","adresse");
		$this->CheckColumn("anschreiben","varchar(1024)","adresse");


		$this->CheckColumn("geloescht","int(1)","shopexport");

		$this->CheckColumn("produktioninfo","text","artikel");
		$this->CheckColumn("sonderaktion","text","artikel");
		$this->CheckColumn("sonderaktion_en","text","artikel");
		$this->CheckColumn("anabregs_text","text","artikel");
		$this->CheckColumn("restmenge","int(1)","artikel");
		$this->CheckColumn("autobestellung","int(1)","artikel","DEFAULT '0' NOT NULL");
		$this->CheckColumn("autolagerlampe","int(1)","artikel","DEFAULT '0' NOT NULL");
		$this->CheckColumn("produktion","int(1)","artikel");
    $this->CheckColumn("herstellernummer","varchar(255)","artikel");
		$this->CheckColumn("datumproduktion","date","produktion");

    $this->CheckColumn("kundenartikelnummer","varchar(255)","verkaufspreise");

		$this->CheckColumn("allDay","int(1)","kalender_event");
		$this->CheckColumn("color","varchar(7)","kalender_event");
		
		$this->CheckColumn("ganztags","int(1)","aufgabe","DEFAULT '1' NOT NULL");

		$this->UpdateColumn("abgabe_bis","datetime","aufgabe");

		// Tabelle linkeditor
		$this->CheckTable("adresse_kontakte");
		$this->CheckColumn("id","int(11)","adresse_kontakte");
		$this->CheckColumn("adresse","int(11)","adresse_kontakte");
		$this->CheckColumn("bezeichnung","varchar(1024)","adresse_kontakte");
		$this->CheckColumn("kontakt","varchar(1024)","adresse_kontakte");
		
	}


	function CheckTable($table)
	{
		$found = false;
		$tables = mysql_list_tables ($this->app->Conf->WFdbname); 
		while (list ($temp) = mysql_fetch_array ($tables)) {
			if ($temp == $table) {
				$found = true;
			}
	  }
		if($found==false)
		{
			$sql = "CREATE TABLE `$table` (`id` INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`)) ENGINE = MyISAM"; 
			$this->app->DB->Update($sql);
		}	


	}

	function UpdateColumn($column,$type,$table,$default="NOT NULL")
	{
			//ALTER TABLE `aufgabe` CHANGE `abgabe_bis` `abgabe_bis` DATETIME NOT NULL 
		$fields = mysql_list_fields( $this->app->Conf->WFdbname, $table);
		$columns = mysql_num_fields($fields);
		for ($i = 0; $i < $columns; $i++) {$field_array[] = mysql_field_name($fields, $i);}
		if (in_array($column, $field_array))
		{
			//$result = mysql_query('ALTER TABLE '.$table.' ADD '.$column.' '.$type.' '.$default.';');
			$result = mysql_query('ALTER TABLE `'.$table.'` CHANGE `'.$column.'` `'.$column.'` '.$type.' '.$default.';');
		}

	}

	function CheckColumn($column,$type,$table,$default="")
	{
		$fields = mysql_list_fields( $this->app->Conf->WFdbname, $table);
		$columns = mysql_num_fields($fields);
		for ($i = 0; $i < $columns; $i++) {$field_array[] = mysql_field_name($fields, $i);}
		if (!in_array($column, $field_array))
		{
			$result = mysql_query('ALTER TABLE '.$table.' ADD '.$column.' '.$type.' '.$default.';');
		}
	}



  function NeueArtikelNummer($artikelart="",$firma="")
  {
    // neue artikel nummer holen
    if($firma=="") $firma = $this->app->User->GetFirma();
    if($artikelart=="produkt") $neue_nummer = $this->app->DB->Select("SELECT MAX(nummer) FROM artikel WHERE firma='".$firma."' AND nummer LIKE '7%'");
    else if($artikelart=="produktion") $neue_nummer = $this->app->DB->Select("SELECT MAX(nummer) FROM artikel WHERE firma='".$firma."' AND nummer LIKE '4%'");
    else if($artikelart=="module") $neue_nummer = $this->app->DB->Select("SELECT MAX(nummer) FROM artikel WHERE firma='".$firma."' AND nummer LIKE '6%'");
    else $neue_nummer = $this->app->DB->Select("SELECT MAX(nummer) FROM artikel WHERE firma='".$firma."' AND nummer LIKE '1%'");

    if($artikelart=="produkt" && ($neue_nummer=="" || $neue_nummer==0)) $neue_nummer = "700000";
    else if($artikelart=="module" && ($neue_nummer=="" || $neue_nummer==0)) $neue_nummer = "600000";
    else if($artikelart=="produktion" && ($neue_nummer=="" || $neue_nummer==0)) $neue_nummer = "400000";
    else if(($neue_nummer=="" || $neue_nummer==0)) $neue_nummer = "100000";

    $neue_nummer = $neue_nummer + 1;
    return $neue_nummer;
  }


  function LagerAusgehend($parsetarget,$ohne_in_bestellung=true,$produktion=false)
  {

    $htmltable = new HTMLTable(0,"100%","",3,1);


    $headings=array("Artikel","Nummer","Hersteller","Projekt","LA","In Bestellung","AB","reserv.","Fehlende");

    $htmltable->AddRowAsHeading($headings);

    $htmltable->ChangingRowColors('#e0e0e0','#fff');

    //$artikelarr = $this->app->DB->SelectArr("SELECT * FROM artikel WHERE (projekt=1 or projekt=2) AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lagerartikel=1 ORDER by endmontage DESC");

    if($produktion)
    $artikelarr = $this->app->DB->SelectArr("SELECT name_de,hersteller,endmontage,nummer,projekt,id FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lagerartikel=1 ORDER by hersteller DESC");
    else
    $artikelarr = $this->app->DB->SelectArr("SELECT name_de,hersteller,endmontage,nummer,projekt,id FROM artikel WHERE geloescht=0 AND firma='".$this->app->User->GetFirma()."' AND lagerartikel=1 ORDER by hersteller DESC");


    for($i=0;$i<count($artikelarr);$i++)
    {
      $projekt = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='{$artikelarr[$i][projekt]}' LIMIT 1");
      $name_de = $artikelarr[$i][name_de];
      $hersteller = $artikelarr[$i][hersteller];
      $adresse = $artikelarr[$i][adresse];

      //$name =  $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
      $nummer = $artikelarr[$i][nummer];
      $id= $artikelarr[$i][id];
      $endmontage= $artikelarr[$i][endmontage];


      $lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$id'");
      $inbestellung = 0; //$this->app->DB->Select("SELECT SUM(menge) FROM bestellung_position WHERE artikel='$id' AND geliefert < menge");

      // ganz alte auftraege stornieren!!!!! oder auftraege aelter als 3 monate ausblenden!!!!

			if($produktion)
			{
      $auftraege = $this->app->DB->Select("SELECT SUM(ap.menge -ap.geliefert_menge) FROM produktion_position ap, produktion a WHERE ap.artikel='$id' AND a.id=ap.produktion
	  AND (a.status!='abgeschlossen' AND a.status!='storniert' AND a.status!='angelegt') AND ap.geliefert!=1");
			} else {
			$auftraege = $this->app->DB->Select("SELECT SUM(ap.menge -ap.geliefert_menge) FROM auftrag_position ap, auftrag a WHERE ap.artikel='$id' AND a.id=ap.auftrag 
				AND (a.status!='abgeschlossen' AND a.status!='storniert' AND a.status!='angelegt') AND ap.geliefert!=1");

			}

      $reservierungen= $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='$id' AND datum >= NOW()");

      if($lager=="") $lager="-";
      if($auftraege<=0) $auftraege="-";
      if($reservierungen=="") $reservierungen="-";

      $fehlende = ($lager -$reservierungen + $inbestellung ) - $auftraege; //stornierungen raus z.b. grasshopper

      $inbestellung = $this->app->DB->Select("SELECT SUM(bp.menge) FROM bestellung_position bp, bestellung b WHERE b.id=bp.bestellung AND bp.artikel='$id' AND bp.geliefert < bp.menge AND (bp.abgeschlossen IS NULL OR bp.abgeschlossen=0) AND b.status='versendet' ");
      $angelegte_inbestellung = $this->app->DB->Select("SELECT SUM(bp.menge) FROM bestellung_position bp, bestellung b WHERE b.id=bp.bestellung AND bp.artikel='$id' AND bp.geliefert < bp.menge AND (bp.abgeschlossen IS NULL OR bp.abgeschlossen=0) AND ( b.status='angelegt' || b.status='freigegeben') ");
      $inbestellunggeliefert = $this->app->DB->Select("SELECT SUM(bp.geliefert) FROM bestellung_position bp WHERE bp.artikel='$id' AND bp.geliefert < bp.menge AND (bp.abgeschlossen IS NULL OR bp.abgeschlossen=0) ");
      $inbestellung = $inbestellung - $inbestellunggeliefert;

//      if($inbestellung >= abs($fehlende)) echo "hm";



      if($fehlende < 0) 
      {
	  //if($endmontage) $bold=1; else $bold=0;
   //$htmltable->AddCol($i+1);
	  if(($fehlende + $inbestellung) < 0) $color = "red"; else $color="";

          if($ohne_in_bestellung && $color!="red") continue;
          if(!$ohne_in_bestellung && $color=="red") continue;

          $htmltable->NewRow();

          $htmltable->AddCol("<font color=$color>".$name_de."</font>");
          $htmltable->AddCol("<a href=\"index.php?module=artikel&action=offeneauftraege&id=$id\" target=\"_blank\"><font color=$color>".$nummer."</font></a>");
          $htmltable->AddCol("<font color=$color>".$hersteller."</font>");
          $htmltable->AddCol("<font color=$color>".$projekt."</font>");
          $htmltable->AddCol("<font color=$color>".$lager."</font>");
        
        //$htmltable->AddCol($nummer);
        //$htmltable->AddCol($name);
        if($angelegte_inbestellung>0)
          $htmltable->AddCol($inbestellung." (<font color=\"green\">$angelegte_inbestellung</font>)");
        else
          $htmltable->AddCol($inbestellung);
        $htmltable->AddCol($auftraege);
        $htmltable->AddCol($reservierungen);

        if($bold)
        $htmltable->AddCol("<b><font color=red>".abs($fehlende)."</font></b>");
        else
        {
          $htmltable->AddCol(abs($fehlende));
        }
      }
    }

    $this->app->Tpl->Set($parsetarget,$htmltable->Get());

  }
 
	function LimitChar($file,$length,$minword=3)
  {
if (strlen($file) > $length)
{
$vartypesf = strrchr($file,".");
$vartypesf_len = strlen($vartypesf);
$word_l_w = substr($file,0,$length);
//$word_l_w = substr($file,0,($length/2 )* -1);
//$word_r_a = substr($word_r_w,0,-5);

return $word_l_w."...".$word_r_a.$vartypesf;
}
else
	return $file;
  }


  function LimitWord($word,$count)
  {
    $length = strlen($word);

    $parts= explode("\n", wordwrap($word, $count, "\n"));
    $word = $parts[0];

    if(strlen($word) < $length)
      $word.="...";

    return $word;
  }

  function MenuEintrag($link,$beschreibung)
  {

    //$this->app->Tpl->Add(TABS,"<img src=\"./themes/new/images/simpleForm_arrow.gif\" width=\"13\" height=\"9\" /> <a  href=\"$link\">$beschreibung</a><br>");
    $this->app->Tpl->Add(TABS,"<a href=\"$link\"><table width=\"150\"><tr><td>$beschreibung</td></tr></table></a>");
  }


  function SaldoAdresse($adresse)
  {
    // summe der zahlungseingaenge

    $summe_zahlungseingaenge  = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE adresse='$adresse'");
    
    // summe der zahlungsausgaenge
    $summe_zahlungsausgaenge  = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungsausgang WHERE adresse='$adresse'");

    // summe der rechnungen
    $summe_rechnungen  = $this->app->DB->Select("SELECT SUM(soll) FROM rechnung WHERE adresse='$adresse'");

    // summe skonto rechnungen
    $summe_rechnungen_skonto  = $this->app->DB->Select("SELECT SUM(skonto_gegeben) FROM rechnung WHERE adresse='$adresse'");

    // summe der gutschriften
    $summe_gutschriften  = $this->app->DB->Select("SELECT SUM(soll) FROM gutschrift WHERE adresse='$adresse'");

    return $summe_rechnungen - $summe_zahlungseingaenge - $summe_gutschriften + $summe_zahlungsausgaenge + $summe_rechnungen_skonto; 
  }


  function AuftragSaldo($id)
  {
      $rechnungArr = $this->app->DB->SelectArr("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, belegnr, gesamtsumme FROM auftrag WHERE id='$id' LIMIT 1");

      $auftragid = $id;

        // suche rechnungen fuer auftrag 
    $rechnungen = $this->app->DB->SelectArr("SELECT id FROM rechnung WHERE auftragid='$id'");
    for($i=0;$i<count($rechnungen);$i++)
    {
      $filter .=" OR (ke.objekt='rechnung' AND ke.parameter='{$rechnungen[$i][id]}')";
    }



      $eingangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, k.id as kontoauszuege, ke.betrag as betrag FROM kontoauszuege_zahlungseingang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='auftrag' AND ke.parameter='$auftragid') $filter");

      for($i=0;$i<count($eingangArr);$i++)
	  $einnahmen += $eingangArr[$i][betrag];

      $ausgangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m') as datum, ke.betrag as betrag FROM kontoauszuege_zahlungsausgang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='auftrag' AND ke.parameter='$auftragid') $filter");

      for($i=0;$i<count($ausgangArr);$i++)
	$ausgaben += $ausgangArr[$i][betrag];

      return((($rechnungArr[0][gesamtsumme])*-1) + $einnahmen - $ausgaben);
  }



  function GutschriftSaldo($id)
  {

    $gutschriftArr = $this->app->DB->SelectArr("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, belegnr, soll FROM gutschrift WHERE id='$id' LIMIT 1");
    $rechnungid = $this->app->DB->Select("SELECT rechnungid FROM gutschrift WHERE id='$id' LIMIT 1");
    $auftragid = $this->app->DB->Select("SELECT auftragid FROM rechnung WHERE id='$rechnungid' LIMIT 1");

    $eingangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, k.id as kontoauszuege, ke.betrag as betrag FROM kontoauszuege_zahlungseingang ke 
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='gutschrift' AND ke.parameter='$id') OR (ke.objekt='auftrag' AND ke.parameter='$auftragid' AND ke.parameter>0)
      OR (ke.objekt='rechnung' AND ke.parameter='$rechnungid'  AND ke.parameter>0)");

      for($i=0;$i<count($eingangArr);$i++)
	  $einnahmen += $eingangArr[$i][betrag];

       $gutschriften = $this->app->DB->SelectArr("SELECT belegnr, DATE_FORMAT(datum,'%d.%m.%Y') as datum,soll FROM gutschrift WHERE rechnungid='$id'");

    for($i=0;$i<count($gutschriften);$i++)
	  $einnahmen += $gutschriften[$i][soll];
 
      $ausgangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m') as datum, ke.betrag as betrag FROM kontoauszuege_zahlungsausgang ke 
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='gutschrift' AND ke.parameter='$id') OR (ke.objekt='rechnung' AND ke.parameter='$rechnungid'  AND ke.parameter>0)                     OR (ke.objekt='auftrag' AND ke.parameter='$auftragid'  AND ke.parameter>0)");


      for($i=0;$i<count($ausgangArr);$i++)
	$ausgaben += $ausgangArr[$i][betrag];

      return($einnahmen - $ausgaben);

      // eigentlich sollte es aber so sein:
      //return((($gutschriftArr[0][soll])*-1) + $einnahmen - $ausgaben);

  }



  function RechnungSaldo($id)
  {
      $rechnungArr = $this->app->DB->SelectArr("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum, belegnr, soll FROM rechnung WHERE id='$id' LIMIT 1");

      $auftragid = $this->app->DB->Select("SELECT auftragid FROM rechnung WHERE id='$id' LIMIT 1");

      // wenn es keinen auftrag gab
      if($auftragid > 0) 
      {
      $eingangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, k.id as kontoauszuege, ke.betrag as betrag FROM kontoauszuege_zahlungseingang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='rechnung' AND ke.parameter='$id') OR (ke.objekt='auftrag' AND ke.parameter='$auftragid')");
      } else {
      $eingangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m.%Y') as datum, k.id as kontoauszuege, ke.betrag as betrag FROM kontoauszuege_zahlungseingang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='rechnung' AND ke.parameter='$id') ");
      }
      for($i=0;$i<count($eingangArr);$i++)
	  $einnahmen += $eingangArr[$i][betrag];

       $gutschriften = $this->app->DB->SelectArr("SELECT belegnr, DATE_FORMAT(datum,'%d.%m.%Y') as datum,soll FROM gutschrift WHERE rechnungid='$id'");

    for($i=0;$i<count($gutschriften);$i++)
	  $einnahmen += $gutschriften[$i][soll];
 

      if($auftragid > 0) 
      {
      $ausgangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m') as datum, ke.betrag as betrag FROM kontoauszuege_zahlungsausgang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='rechnung' AND ke.parameter='$id') OR (ke.objekt='auftrag' AND ke.parameter='$auftragid')");
      } else {
      $ausgangArr = $this->app->DB->SelectArr("SELECT ko.bezeichnung as konto, DATE_FORMAT(ke.datum,'%d.%m') as datum, ke.betrag as betrag FROM kontoauszuege_zahlungsausgang ke
      LEFT JOIN kontoauszuege k ON ke.kontoauszuege=k.id LEFT JOIN konten ko ON k.konto=ko.id WHERE (ke.objekt='rechnung' AND ke.parameter='$id')");
      }

      for($i=0;$i<count($ausgangArr);$i++)
	$ausgaben += $ausgangArr[$i][betrag];

      return((($rechnungArr[0][soll])*-1) + $einnahmen - $ausgaben);
  }


  function AuftragExplodieren($auftrag,$typ="")
  { 
		if($typ=="produktion") {
			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($auftrag))
					$auftraege = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE status='freigegeben' AND id='$auftrag'");    
			}else
				$auftraege = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE status='freigegeben' AND id='$auftrag'");	
		}else {
			if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($auftrag))
					$auftraege = $this->app->DB->SelectArr("SELECT * FROM auftrag WHERE status='freigegeben' AND id='$auftrag'");    
			} else
				$auftraege = $this->app->DB->SelectArr("SELECT * FROM auftrag WHERE status='freigegeben' AND id='$auftrag'");
		}


    $adresse = $auftraege[0][adresse];
    $projekt = $auftraege[0][projekt];
    $status= $auftraege[0][status];
    if($status!='freigegeben')
      return;

		if($typ=="produktion")
    $artikelarr= $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE produktion='$auftrag' AND geliefert_menge < menge AND geliefert=0");
		else
    $artikelarr= $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$auftrag' AND geliefert_menge < menge AND geliefert=0");


    $treffer=0;
    // Lager Check
    $positionen_vorhanden = 0;
    $artikelzaehlen=0;
    //echo "{$auftraege[0][internet]} Adresse:$adresse Auftrag $auftrag";

    //echo "auftrag $auftrag anzahl:".count($artikelarr)."<br>";

    for($k=0;$k<count($artikelarr); $k++)
    {
      $menge = $artikelarr[$k][menge] - $artikelarr[$k][gelieferte_menge];
      $artikel = $artikelarr[$k][artikel];
      $artikel_position_id = $artikelarr[$k][id];
      // pruefe artikel 12 menge 4
      $lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='$artikel' LIMIT 1");
      //if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001"  && $artikelarr[$k][nummer]!="200002" && $lagerartikel==1)
      //if($lagerartikel==1)
      //if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001"  && $artikelarr[$k][nummer]!="200002" )
      {
	//echo "Artikel $artikel Menge $menge";
	// schaue ob es ein JUST Stuecklisten artikel ist der nicht explodiert ist
	$just_stueckliste = $this->app->DB->Select("SELECT  juststueckliste FROM artikel WHERE id='$artikel' LIMIT 1");
	if($typ=="produktion")
	{
		$explodiert = $this->app->DB->Select("SELECT explodiert FROM produktion_position WHERE id='$artikel_position_id' LIMIT 1");
		$menge = $this->app->DB->Select("SELECT menge  FROM produktion_position WHERE id='$artikel_position_id' LIMIT 1");
		$sort = $this->app->DB->Select("SELECT sort FROM produktion_position WHERE id='$artikel_position_id' LIMIT 1");
	} else {
		$explodiert = $this->app->DB->Select("SELECT explodiert FROM auftrag_position WHERE id='$artikel_position_id' LIMIT 1");
		$menge = $this->app->DB->Select("SELECT menge  FROM auftrag_position WHERE id='$artikel_position_id' LIMIT 1");
		$sort = $this->app->DB->Select("SELECT sort FROM auftrag_position WHERE id='$artikel_position_id' LIMIT 1");
	}
	$artikel_von_stueckliste = $this->app->DB->SelectArr("SELECT * FROM stueckliste WHERE stuecklistevonartikel='$artikel'"); 

	if($just_stueckliste=="1" && $explodiert=="1")
	{
	  foreach($artikel_von_stueckliste as $key=>$value)
	  {
	    $menge_st =$value[menge]*$menge;
			if($typ=="produktion")
				$this->app->DB->Update("UPDATE produktion_position SET menge='{$menge_st}' WHERE explodiert_parent='$artikel_position_id' AND artikel='{$value[artikel]}'");
			else
				$this->app->DB->Update("UPDATE auftrag_position SET menge='{$menge_st}' WHERE explodiert_parent='$artikel_position_id' AND artikel='{$value[artikel]}'");
	  }

	}
	else if($just_stueckliste=="1" && $explodiert=="0")
	{
	  $treffer++;
	  //hole artikel von stueckliste

	  // schiebe alle artikel nach hinten
	  $erhoehe_sort = count($artikel_von_stueckliste);
			if($typ=="produktion")
				$this->app->DB->Update("UPDATE produktion_position SET sort=sort+$erhoehe_sort WHERE produktion='$auftrag' AND sort > $sort");
			else
				$this->app->DB->Update("UPDATE auftrag_position SET sort=sort+$erhoehe_sort WHERE auftrag='$auftrag' AND sort > $sort");

	  foreach($artikel_von_stueckliste as $key=>$value)
	  {
	    $sort++;
	    $nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='{$value[artikel]}' LIMIT 1");
			if($typ=="produktion")
			{
				$exolpdodiert_id = $this->app->erp->AddAuftragPositionNummer($auftrag,$nummer,$value[menge],$projekt,1,false,"produktion");
				$this->app->DB->Update("UPDATE produktion_position SET explodiert_parent='$artikel_position_id',sort='$sort' WHERE id='$exolpdodiert_id' LIMIT 1");
			} else {
				$exolpdodiert_id = $this->app->erp->AddAuftragPositionNummer($auftrag,$nummer,$value[menge],$projekt,1);
				$this->app->DB->Update("UPDATE auftrag_position  SET explodiert_parent='$artikel_position_id',sort='$sort' WHERE id='$exolpdodiert_id' LIMIT 1");
			}
	  }

		if($typ=="produktion")
	  $this->app->DB->Update("UPDATE produktion_position SET explodiert='1' WHERE id='$artikel_position_id' LIMIT 1");
		else
	  $this->app->DB->Update("UPDATE auftrag_position SET explodiert='1' WHERE id='$artikel_position_id' LIMIT 1");
	}
      }
    }

    //achtung wenn selber artikel wieder in stueckliste ist dreht sich das programm dusselig hier!
    if($treffer >0)
      $this->app->erp->AuftragExplodieren($auftrag,$typ);
  }

  function ProduktionEinzelnBerechnen($auftrag)
  {
      $this->app->erp->AuftragExplodieren($auftrag,"produktion");

			$produktion = $auftrag;

			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($produktion)) {
      		$auftraege = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE id='$produktion'");    
      		$adresse = $auftraege[0][adresse];
      		$artikelarr= $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE produktion='$produktion' AND geliefert_menge < menge AND geliefert=0");
				}
			} else {
				$auftraege = $this->app->DB->SelectArr("SELECT * FROM produktion WHERE id='$produktion'");
        $adresse = $auftraege[0][adresse];
        $artikelarr= $this->app->DB->SelectArr("SELECT * FROM produktion_position WHERE produktion='$produktion' AND geliefert_menge < menge AND geliefert=0");
			}

      //pruefe ob es mindestens eine reservierung gibt
			if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($adresse))
      		$reservierte = $this->app->DB->Select("SELECT COUNT(id) FROM lager_reserviert WHERE adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");
			} else {
				$reservierte = $this->app->DB->Select("SELECT COUNT(id) FROM lager_reserviert WHERE adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");
			}

			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($produktion)) {
      		if($reservierte >0)
						$this->app->DB->Update("UPDATE produktion SET reserviert_ok='1' WHERE id='$produktion' LIMIT 1");
      		else 
						$this->app->DB->Update("UPDATE produktion SET reserviert_ok='0' WHERE id='$produktion' LIMIT 1");
				}
			} else {
				if($reservierte >0)
            $this->app->DB->Update("UPDATE produktion SET reserviert_ok='1' WHERE id='$produktion' LIMIT 1");
          else
            $this->app->DB->Update("UPDATE produktion SET reserviert_ok='0' WHERE id='$produktion' LIMIT 1");
			}


      // Lager Check
      $positionen_vorhanden = 0;
      $artikelzaehlen=0;
      //echo "{$auftraege[0][internet]} Adresse:$adresse Auftrag $produktion";
      for($k=0;$k<count($artikelarr); $k++)
      {
	$menge = $artikelarr[$k][menge] - $artikelarr[$k][gelieferte_menge];
	$artikel = $artikelarr[$k][artikel];
	$artikel_position_id = $artikelarr[$k][id];
	// pruefe artikel 12 menge 4
	// lagerartikel??

	if($this->app->Conf->WFdbType=="postgre") {
  	if(is_numeric($$artikelarr[$k][artikel])) {
			$lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
			$stueckliste= $this->app->DB->Select("SELECT stueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
			$juststueckliste= $this->app->DB->Select("SELECT juststueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
		}
	} else {
		$lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
    $stueckliste= $this->app->DB->Select("SELECT stueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
    $juststueckliste= $this->app->DB->Select("SELECT juststueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
	}

	//if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001"  && $artikelarr[$k][nummer]!="200002" && $lagerartikel==1)
	//echo $artikelarr[$k][artikel]." ";
	if($lagerartikel==1)
	{
	  if($this->app->erp->LagerCheck($adresse,$artikel,$menge)>0) $positionen_vorhanden++;
	  $artikelzaehlen++;
	}
      }

      //echo "$positionen_vorhanden $artikelzaehlen<hr>";

			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($produktion)) {
      		if($positionen_vorhanden==$artikelzaehlen)
						$this->app->DB->Update("UPDATE produktion SET lager_ok='1' WHERE id='$produktion' LIMIT 1");
      		else
						$this->app->DB->Update("UPDATE produktion SET lager_ok='0' WHERE id='$produktion' LIMIT 1");
      		$projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$produktion' LIMIT 1");
				}
			} else {
				if($positionen_vorhanden==$artikelzaehlen)
        	$this->app->DB->Update("UPDATE produktion SET lager_ok='1' WHERE id='$produktion' LIMIT 1");
        else
          $this->app->DB->Update("UPDATE produktion SET lager_ok='0' WHERE id='$produktion' LIMIT 1");
      	$projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$produktion' LIMIT 1");
			}

      // projekt check start
      if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($projekt)) {
					$projektcheck = $this->app->DB->Select("SELECT checkok FROM projekt WHERE id='$projekt' LIMIT 1");
      		$projektcheckname = $this->app->DB->Select("SELECT checkname FROM projekt WHERE id='$projekt' LIMIT 1");
      		$projektportocheck = $this->app->DB->Select("SELECT portocheck FROM projekt WHERE id='$projekt' LIMIT 1");
				}
			} else {
				$projektcheck = $this->app->DB->Select("SELECT checkok FROM projekt WHERE id='$projekt' LIMIT 1");
        $projektcheckname = $this->app->DB->Select("SELECT checkname FROM projekt WHERE id='$projekt' LIMIT 1");
        $projektportocheck = $this->app->DB->Select("SELECT portocheck FROM projekt WHERE id='$projekt' LIMIT 1");
			}

      if($projektcheck=="1")
      {
	//echo "projekt check $projektcheckname notwendig";
	include_once (dirname(__FILE__)."/../plugins/class.".$projektcheckname.".php");		

	$tmp = new unishop($this->app);

	if($this->app->Conf->WFdbType=="postgre") {
  	if(is_numeric($produktion)) {	
			if($tmp->CheckOK($produktion))
	  		$this->app->DB->Update("UPDATE produktion SET check_ok='1' WHERE id='$produktion' LIMIT 1");
			else
	  		$this->app->DB->Update("UPDATE produktion SET check_ok='0' WHERE id='$produktion' LIMIT 1");
		}
	} else {
		if($tmp->CheckOK($produktion))
      $this->app->DB->Update("UPDATE produktion SET check_ok='1' WHERE id='$produktion' LIMIT 1");
    else
      $this->app->DB->Update("UPDATE produktion SET check_ok='0' WHERE id='$produktion' LIMIT 1");
	}
      }
     else {
			if($this->app->Conf->WFdbType=="postgre") {
    		if(is_numeric($produktion))
       		$this->app->DB->Update("UPDATE produktion SET check_ok='1' WHERE id='$produktion' LIMIT 1");
			} else
					$this->app->DB->Update("UPDATE produktion SET check_ok='1' WHERE id='$produktion' LIMIT 1");
		 }


      // autopruefung anstubsen
      //$this->app->erp->AutoUSTPruefung($adresse);

      // UST Check
      // pruefe adresse 23 ust innerhalb 3 tagen vorhanden? wenn nicht schaue ob selber ordern kann wenn ja ordern und auf gruen

			if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($adresse))
	      	$ustprf = $this->app->DB->Select("SELECT id FROM ustprf WHERE to_char(datum_online,'YYYY-MM-DD')=to_char(NOW(),'YYYY-MM-DD') AND adresse='$adresse' AND status='erfolgreich' LIMIT 1");
			} else {
				$ustprf = $this->app->DB->Select("SELECT id FROM ustprf WHERE DATE_FORMAT(datum_online,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') AND adresse='$adresse' AND status='erfolgreich' LIMIT 1");
			}


			if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($produktion)) {
      		$ustid = $this->app->DB->Select("SELECT ustid FROM produktion WHERE id='$produktion' LIMIT 1");
      		$ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$produktion' LIMIT 1");
      		$land = $this->app->DB->Select("SELECT land FROM produktion WHERE id='$produktion' LIMIT 1");
				}
			} else {
				$ustid = $this->app->DB->Select("SELECT ustid FROM produktion WHERE id='$produktion' LIMIT 1");
        $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$produktion' LIMIT 1");
        $land = $this->app->DB->Select("SELECT land FROM produktion WHERE id='$produktion' LIMIT 1");
			}

      if($ust_befreit==0)
      {
          if($this->app->Conf->WFdbType=="postgre") {
        		if(is_numeric($produktion)) 
							$this->app->DB->Update("UPDATE produktion SET ust_ok='1' WHERE id='$produktion' LIMIT 1");
					} else {
						$this->app->DB->Update("UPDATE produktion SET ust_ok='1' WHERE id='$produktion' LIMIT 1");
					}

      } 
/*
      else if($ust_befreit==1)
      {
	if($ustprf >0 && $ustid!="")
          $this->app->DB->Update("UPDATE produktion SET ust_ok='1' WHERE id='$produktion' LIMIT 1");
	else
          $this->app->DB->Update("UPDATE produktion SET ust_ok='0' WHERE id='$produktion' LIMIT 1");
      } else {
	if($this->app->erp->Export($land))
          $this->app->DB->Update("UPDATE produktion SET ust_ok='1' WHERE id='$produktion' LIMIT 1");
	else
          $this->app->DB->Update("UPDATE produktion SET ust_ok='0' WHERE id='$produktion' LIMIT 1");
      }
*/
      // Porto Check
      // sind versandkosten im produktion
			if($this->app->Conf->WFdbType=="postgre") {
      	if(is_numeric($produktion)) {
      		$porto = $this->app->DB->Select("SELECT ap.id FROM produktion_position ap, artikel a WHERE ap.produktion='$produktion' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0
	AND a.id=ap.artikel LIMIT 1");
      		$keinporto = $this->app->DB->Select("SELECT keinporto FROM produktion WHERE id='$produktion' LIMIT 1");
      		$selbstabholer = $this->app->DB->Select("SELECT versandart FROM produktion WHERE id='$produktion' LIMIT 1");
      		$projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$produktion' LIMIT 1");
				}
			} else {
				$porto = $this->app->DB->Select("SELECT ap.id FROM produktion_position ap, artikel a WHERE ap.produktion='$produktion' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0
  AND a.id=ap.artikel LIMIT 1");
        $keinporto = $this->app->DB->Select("SELECT keinporto FROM produktion WHERE id='$produktion' LIMIT 1");
        $selbstabholer = $this->app->DB->Select("SELECT versandart FROM produktion WHERE id='$produktion' LIMIT 1");
        $projekt = $this->app->DB->Select("SELECT projekt FROM produktion WHERE id='$produktion' LIMIT 1");
			}

      // portocheck bei projekt

      if($selbstabholer=="selbstabholer" || $selbstabholer=="keinversand") $keinporto=1;

			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($produktion)) {
      		if($projektportocheck==1) {
      			if($porto > 0)
							$this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
      			else
							$this->app->DB->Update("UPDATE produktion SET porto_ok='0' WHERE id='$produktion' LIMIT 1");
      		} else {
						//projekt hat kein portocheck porto ist immer ok
						$this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
      		}

      		if($keinporto==1 || $selbstabholer=="selbstabholer") {
						$this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
						$this->app->DB->Update("UPDATE produktion_position ap, artikel a SET ap.preis='0' WHERE ap.produktion='$produktion' AND a.id=ap.artikel AND a.porto='1'");
      		}
				}
			} else {
				if($projektportocheck==1) {
            if($porto > 0)
              $this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
            else
              $this->app->DB->Update("UPDATE produktion SET porto_ok='0' WHERE id='$produktion' LIMIT 1");
          } else {
            //projekt hat kein portocheck porto ist immer ok
            $this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
          }

          if($keinporto==1 || $selbstabholer=="selbstabholer") {
            $this->app->DB->Update("UPDATE produktion SET porto_ok='1' WHERE id='$produktion' LIMIT 1");
            $this->app->DB->Update("UPDATE produktion_position ap, artikel a SET ap.preis='0' WHERE ap.produktion='$produktion' AND a.id=ap.artikel AND a.porto='1'");
          }
			}


      //Vorkasse Check
      //ist genug geld da? zusammenzaehlen der kontoauszuege_zahlungseingang
			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($produktion) && is_numeric($adresse))
      		$summe_eingang = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='produktion' AND parameter='$produktion' AND adresse='$adresse'");
				if(is_numeric($produktion)) {
      		$produktion_gesamtsumme = $this->app->DB->Select("SELECT gesamtsumme FROM produktion WHERE id='$produktion' LIMIT 1");
      		$zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM produktion WHERE id='$produktion' LIMIT 1");
      		$zahlungsweise = strtolower($zahlungsweise);
					if($summe_eingang>=$produktion_gesamtsumme || ($zahlungsweise=="rechnung" || $zahlungsweise=="nachnahme" || $zahlungsweise=="einzugsermaechtigung" || $zahlungsweise=="lastschrift" || $zahlungsweise=="bar"))
      { 
        $this->app->DB->Update("UPDATE produktion SET vorkasse_ok='1' WHERE id='$produktion' LIMIT 1");
      } else {
        $this->app->DB->Update("UPDATE produktion SET vorkasse_ok='0' WHERE id='$produktion' LIMIT 1");
      }

      $nachnahme = $this->app->DB->Select("SELECT COUNT(ap.id) FROM produktion_position ap, artikel a WHERE ap.produktion='$produktion' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0 AND a.id=ap.artikel");
			if($zahlungsweise=="nachnahme" && $nachnahme <2)
        $this->app->DB->Update("UPDATE produktion SET nachnahme_ok='0' WHERE id='$produktion' LIMIT 1");
      else
        $this->app->DB->Update("UPDATE produktion SET nachnahme_ok='1' WHERE id='$produktion' LIMIT 1");
				}
			} else {
				$summe_eingang = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='produktion' AND parameter='$produktion' AND adresse='$adresse'");
				$produktion_gesamtsumme = $this->app->DB->Select("SELECT gesamtsumme FROM produktion WHERE id='$produktion' LIMIT 1");
        $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM produktion WHERE id='$produktion' LIMIT 1");
      	$zahlungsweise = strtolower($zahlungsweise);
				if($summe_eingang>=$produktion_gesamtsumme || ($zahlungsweise=="rechnung" || $zahlungsweise=="nachnahme" || $zahlungsweise=="einzugsermaechtigung" || $zahlungsweise=="lastschrift" || $zahlungsweise=="bar"))
      { 
        $this->app->DB->Update("UPDATE produktion SET vorkasse_ok='1' WHERE id='$produktion' LIMIT 1");
      } else {
        $this->app->DB->Update("UPDATE produktion SET vorkasse_ok='0' WHERE id='$produktion' LIMIT 1");
      }
      $nachnahme = $this->app->DB->Select("SELECT COUNT(ap.id) FROM produktion_position ap, artikel a WHERE ap.produktion='$produktion' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0 AND a.id=ap.artikel");
			if($zahlungsweise=="nachnahme" && $nachnahme <2)
        $this->app->DB->Update("UPDATE produktion SET nachnahme_ok='0' WHERE id='$produktion' LIMIT 1");
      else
        $this->app->DB->Update("UPDATE produktion SET nachnahme_ok='1' WHERE id='$produktion' LIMIT 1");

			}
  }



  function AuftragEinzelnBerechnen($auftrag)
  {
      $this->app->erp->AuftragExplodieren($auftrag);

      $auftraege = $this->app->DB->SelectArr("SELECT * FROM auftrag WHERE id='$auftrag'");    
      $adresse = $auftraege[0][adresse];
      $artikelarr= $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$auftrag' AND geliefert_menge < menge AND geliefert=0");

      //pruefe ob es mindestens eine reservierung gibt
      $reservierte = $this->app->DB->Select("SELECT COUNT(id) FROM lager_reserviert WHERE adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");
      if($reservierte >0)
      {
	$this->app->DB->Update("UPDATE auftrag SET reserviert_ok='1' WHERE id='$auftrag' LIMIT 1");
      } else 
	$this->app->DB->Update("UPDATE auftrag SET reserviert_ok='0' WHERE id='$auftrag' LIMIT 1");

      // Lager Check
      $positionen_vorhanden = 0;
      $artikelzaehlen=0;
      //echo "{$auftraege[0][internet]} Adresse:$adresse Auftrag $auftrag";
      for($k=0;$k<count($artikelarr); $k++)
      {
	$menge = $artikelarr[$k][menge] - $artikelarr[$k][gelieferte_menge];
	$artikel = $artikelarr[$k][artikel];
	$artikel_position_id = $artikelarr[$k][id];
	// pruefe artikel 12 menge 4
	// lagerartikel??
	$lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
	$stueckliste= $this->app->DB->Select("SELECT stueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
	$juststueckliste= $this->app->DB->Select("SELECT juststueckliste FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
	//if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001"  && $artikelarr[$k][nummer]!="200002" && $lagerartikel==1)
	//echo $artikelarr[$k][artikel]." ";
	if($lagerartikel==1)
	{
	  if($this->app->erp->LagerCheck($adresse,$artikel,$menge)>0) $positionen_vorhanden++;
	  $artikelzaehlen++;
	}
      }

      //echo "$positionen_vorhanden $artikelzaehlen<hr>";
      if($positionen_vorhanden==$artikelzaehlen)
	$this->app->DB->Update("UPDATE auftrag SET lager_ok='1' WHERE id='$auftrag' LIMIT 1");
      else
	$this->app->DB->Update("UPDATE auftrag SET lager_ok='0' WHERE id='$auftrag' LIMIT 1");

      // projekt check start
      $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $projektcheck = $this->app->DB->Select("SELECT checkok FROM projekt WHERE id='$projekt' LIMIT 1");
      $projektcheckname = $this->app->DB->Select("SELECT checkname FROM projekt WHERE id='$projekt' LIMIT 1");
      $projektportocheck = $this->app->DB->Select("SELECT portocheck FROM projekt WHERE id='$projekt' LIMIT 1");


      if($projektcheck=="1")
      {
	//echo "projekt check $projektcheckname notwendig";
	include_once (dirname(__FILE__)."/../plugins/class.".$projektcheckname.".php");		

	$tmp = new unishop($this->app);
	if($tmp->CheckOK($auftrag))
	  $this->app->DB->Update("UPDATE auftrag SET check_ok='1' WHERE id='$auftrag' LIMIT 1");
	else
	  $this->app->DB->Update("UPDATE auftrag SET check_ok='0' WHERE id='$auftrag' LIMIT 1");

      }
     else
       $this->app->DB->Update("UPDATE auftrag SET check_ok='1' WHERE id='$auftrag' LIMIT 1");


      // autopruefung anstubsen
      //$this->app->erp->AutoUSTPruefung($adresse);

      // UST Check
      // pruefe adresse 23 ust innerhalb 3 tagen vorhanden? wenn nicht schaue ob selber ordern kann wenn ja ordern und auf gruen

      $ustprf = $this->app->DB->Select("SELECT id FROM ustprf WHERE DATE_FORMAT(datum_online,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') AND adresse='$adresse' AND status='erfolgreich' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM auftrag WHERE id='$auftrag' LIMIT 1");


      if($ust_befreit==0)
      {
          $this->app->DB->Update("UPDATE auftrag SET ust_ok='1' WHERE id='$auftrag' LIMIT 1");
      } 
/*
      else if($ust_befreit==1)
      {
	if($ustprf >0 && $ustid!="")
          $this->app->DB->Update("UPDATE auftrag SET ust_ok='1' WHERE id='$auftrag' LIMIT 1");
	else
          $this->app->DB->Update("UPDATE auftrag SET ust_ok='0' WHERE id='$auftrag' LIMIT 1");
      } else {
	if($this->app->erp->Export($land))
          $this->app->DB->Update("UPDATE auftrag SET ust_ok='1' WHERE id='$auftrag' LIMIT 1");
	else
          $this->app->DB->Update("UPDATE auftrag SET ust_ok='0' WHERE id='$auftrag' LIMIT 1");
      }
*/
      // Porto Check
      // sind versandkosten im auftrag
      $porto = $this->app->DB->Select("SELECT ap.id FROM auftrag_position ap, artikel a WHERE ap.auftrag='$auftrag' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0
	AND a.id=ap.artikel LIMIT 1");
      $keinporto = $this->app->DB->Select("SELECT keinporto FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $selbstabholer = $this->app->DB->Select("SELECT versandart FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$auftrag' LIMIT 1");


      // portocheck bei projekt



      if($selbstabholer=="selbstabholer" || $selbstabholer=="keinversand") $keinporto=1;

      if($projektportocheck==1)
      {
      if($porto > 0)
	$this->app->DB->Update("UPDATE auftrag SET porto_ok='1' WHERE id='$auftrag' LIMIT 1");
      else
	$this->app->DB->Update("UPDATE auftrag SET porto_ok='0' WHERE id='$auftrag' LIMIT 1");
      } else {
	//projekt hat kein portocheck porto ist immer ok
	$this->app->DB->Update("UPDATE auftrag SET porto_ok='1' WHERE id='$auftrag' LIMIT 1");
      }

      

      if($keinporto==1 || $selbstabholer=="selbstabholer")
      {
	$this->app->DB->Update("UPDATE auftrag SET porto_ok='1' WHERE id='$auftrag' LIMIT 1");
	$this->app->DB->Update("UPDATE auftrag_position ap, artikel a SET ap.preis='0' WHERE ap.auftrag='$auftrag' AND a.id=ap.artikel AND a.porto='1'");
      }


      //Vorkasse Check
      //ist genug geld da? zusammenzaehlen der kontoauszuege_zahlungseingang
      $summe_eingang = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$auftrag' AND adresse='$adresse'");
      $auftrag_gesamtsumme = $this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM auftrag WHERE id='$auftrag' LIMIT 1");

      $zahlungsweise = strtolower($zahlungsweise);
      if($summe_eingang>=$auftrag_gesamtsumme || ($zahlungsweise=="rechnung" || $zahlungsweise=="nachnahme" || $zahlungsweise=="einzugsermaechtigung" || $zahlungsweise=="lastschrift" || $zahlungsweise=="bar"))
      {
        $this->app->DB->Update("UPDATE auftrag SET vorkasse_ok='1' WHERE id='$auftrag' LIMIT 1");
      } else {
        $this->app->DB->Update("UPDATE auftrag SET vorkasse_ok='0' WHERE id='$auftrag' LIMIT 1");
      }

      //nachnahme gebuehr check!!!!
      //$nachnahme = $this->app->DB->Select("SELECT id FROM auftrag_position WHERE auftrag='$auftrag' AND nummer='200001' LIMIT 1");
      $nachnahme = $this->app->DB->Select("SELECT COUNT(ap.id) FROM auftrag_position ap, artikel a WHERE ap.auftrag='$auftrag' AND ap.artikel=a.id AND a.porto=1 AND ap.preis >= 0
	AND a.id=ap.artikel");

      if($zahlungsweise=="nachnahme" && $nachnahme <2)
        $this->app->DB->Update("UPDATE auftrag SET nachnahme_ok='0' WHERE id='$auftrag' LIMIT 1");
      else
        $this->app->DB->Update("UPDATE auftrag SET nachnahme_ok='1' WHERE id='$auftrag' LIMIT 1");
  }




  function EUR($betrag)
  {
    return number_format($betrag,2,",",".");
  }

  function ReplaceBetrag($db,$value,$fromform)
  { 
    // wenn ziel datenbank
    if($db)
    {
      return str_replace(',','.',$value);
    }
    // wenn ziel formular
    else
    {
      //return $abkuerzung;
      return str_replace('.',',',$value);
    }
  }

  function ReplaceMitarbeiter($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT CONCAT(mitarbeiternummer,' ',name) FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $kundennummer = substr($value,0,5);
      $name = substr($value,6);
      $id =  $this->app->DB->Select("SELECT id FROM adresse WHERE name='$name' AND mitarbeiternummer='$kundennummer'  AND geloescht=0 LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    {
      return $id;
    }
    // wenn ziel formular
    else
    {
      return $abkuerzung;
    }
  }


  function ReplaceArtikel($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;

			if($this->app->Conf->WFdbType=="postgre") {
        if(is_numeric($id))
      	$abkuerzung = $this->app->DB->Select("SELECT CONCAT(nummer,' ',name_de) as name FROM artikel WHERE id='$id' AND geloescht=0 LIMIT 1");
			} else
				$abkuerzung = $this->app->DB->Select("SELECT CONCAT(nummer,' ',name_de) as name FROM artikel WHERE id='$id' AND geloescht=0 LIMIT 1");
      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      if(strlen($value)>5)
      {
				$tmp = trim($value);
				$rest = substr($tmp, 0, 6);
					$id =  $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      } else $id=0;
      
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }


  function ReplaceDatum($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(strpos($value,'-') > 0) $dbformat = 1;

    // wenn ziel datenbank
    if($db)
    { 
      if($dbformat) return $value;
      else return $this->app->String->Convert($value,"%1.%2.%3","%3-%2-%1");
    }
    // wenn ziel formular
    else
    { 
      if($dbformat) return $this->app->String->Convert($value,"%1-%2-%3","%3.%2.%1");
      else return $value;
    }
  }



  function ReplaceAngebot($db,$value,$fromform)
  { 
		return $this->ReplaceANABRELSGSBE("angebot",$db,$value,$fromform);
  }

  function ReplaceLieferschein($db,$value,$fromform)
  { 
		return $this->ReplaceANABRELSGSBE("lieferschein",$db,$value,$fromform);
  }

  function ReplaceAuftrag($db,$value,$fromform)
  { 
		return $this->ReplaceANABRELSGSBE("auftrag",$db,$value,$fromform);
  }

  function ReplaceRechnung($db,$value,$fromform)
  { 
		return $this->ReplaceANABRELSGSBE("rechnung",$db,$value,$fromform);
  }



  function ReplaceANABRELSGSBE($table,$db,$value,$fromform)
	{
 		//value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT belegnr as name FROM $table WHERE id='$id' LIMIT 1");
      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
			$tmp = trim($value);
			//$id =  $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
			$id =  $this->app->DB->Select("SELECT id FROM $table WHERE belegnr='$tmp' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }

	}




  function ReplaceProjekt($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='$id' LIMIT 1");
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      $id =  $this->app->DB->Select("SELECT id FROM projekt WHERE abkuerzung='$value' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }

  function ReplaceLieferantennummer($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) { // wenn es eine id ist!
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT lieferantennummer as name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $abkuerzung = $value;
			$tmp = trim($value);
			$rest = substr($tmp, 0, 5);
			$id =  $this->app->DB->Select("SELECT id FROM adresse WHERE lieferantennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }


  function ReplaceKundennummer($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) { // wenn es eine id ist!
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT kundennummer as name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $abkuerzung = $value;
			$tmp = trim($value);
			$rest = substr($tmp, 0, 5);
			$id =  $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }



  function ReplaceKunde($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
			if($this->app->Conf->WFdbType=="postgre") {
				if(is_numeric($id))
      $abkuerzung = $this->app->DB->Select("SELECT CONCAT(kundennummer,' ',name) as name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
			} else {
			$abkuerzung = $this->app->DB->Select("SELECT CONCAT(kundennummer,' ',name) as name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
			}

      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      if(strlen($value)>=5)
      {
				$tmp = trim($value);
				$rest = substr($tmp, 0, 5);
				$id =  $this->app->DB->Select("SELECT id FROM adresse WHERE kundennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      } else $id=0;
      
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }


  function ReplaceLieferant($db,$value,$fromform)
  { 
    //value muss hier vom format ueberprueft werden
    $dbformat = 0;
    if(!$fromform) {
      $dbformat = 1;
      $id = $value;
      $abkuerzung = $this->app->DB->Select("SELECT CONCAT(lieferantennummer,' ',name) as name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
      if($id==0 || $id=="") $abkuerzung ="";
    } else {
      $dbformat = 0;
      $abkuerzung = $value;
      if(strlen($value)>5)
      {
	$tmp = trim($value);
	$rest = substr($tmp, 0, 5);
	$id =  $this->app->DB->Select("SELECT id FROM adresse WHERE lieferantennummer='$rest' AND geloescht=0 AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      } else $id=0;
      
    }

    // wenn ziel datenbank
    if($db)
    { 
      return $id;
    }
    // wenn ziel formular
    else
    { 
      return $abkuerzung;
    }
  }


  function CheckSamePage()
  {
    $id = $this->app->Secure->GetGET("id");
    $check_id  = strstr($_SERVER['HTTP_REFERER'], 'id=');
    if($check_id!="id=".$id)
      return true;
    else 
      return false;
  }

  function SeitenSperrAuswahl($ueberschrift,$meldung)
  {
   /* $this->app->Tpl->Set(SPERRMELDUNG,  '$("a#inline").fancybox({
      \'modal\': true,
      \'autoDimensions\': false,
      \'width\': 500,
      \'height\': 300
      });
      $(\'#inline\').click();');

    $this->app->Tpl->Set(SPERRMELDUNGNACHRICHT,'<a id="inline" href="#data"></a>
      <div style="display:none"><div id="data"><h2>'.$ueberschrift.'</h2><hr>von Benedikt Sauter<br><br><div class="info">'.$meldung.'</div>
      <br><br><center><a href="'.$_SERVER['HTTP_REFERER'].'">Jetzt Zur&uuml;ck zum letzten Schritt</a>&nbsp;|&nbsp;
      <a href="javascript:;" onclick="$.fancybox.close();">Bitte Fenster dennoch freigeben</a></center></div></div>');
*/

$this->app->Tpl->Set(SPERRMELDUNG,  '
    // a workaround for a flaw in the demo system (http://dev.jqueryui.com/ticket/4375), ignore!
    $( "#dialog:ui-dialog" ).dialog( "destroy" );
  
    $( "#dialog-message" ).dialog({
      modal: true,
      buttons: {
	Ok: function() {
	  $( this ).dialog( "close" );
	}
      }
    });
');


$this->app->Tpl->Set(SPERRMELDUNGNACHRICHT,'
<div id="dialog-message" title="'.$ueberschrift.'">
  <p style="font-size: 9pt">
    '.$meldung.'
  </p>
</div>
');
  }

  function SeitenSperrInfo($meldung)
  {
    $this->app->Tpl->Set(SPERRMELDUNG,  '$("a#inline").fancybox({
      \'hideOnContentClick\': true,
      \'autoDimensions\': false,
      \'width\': 500,
      \'height\': 300
      });
      $(\'#inline\').click();');

    $this->app->Tpl->Set(SPERRMELDUNGNACHRICHT,'<a id="inline" href="#data"></a>
      <div style="display:none"><div id="data"><h2>Infomeldung</h2><hr><br><br>'.$meldung.'</div></div>');

  }

  function EinkaufspreisBetrag($artikel,$menge,$lieferant,$projekt="")
  {
      $id = $artikel;
      $adresse = $lieferant;

      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT p.abkuerzung FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.id='$id' LIMIT 1");
      $projekt_id = $this->app->DB->Select("SELECT projekt FROM artikel WHERE id='$id' LIMIT 1");
      $ab_menge = $this->app->DB->Select("SELECT ab_menge FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");
      $ek = $this->app->DB->Select("SELECT preis FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");

      return $ek;
  }
    

  function Einkaufspreis($artikel,$menge,$lieferant,$projekt="")
  {
      $id = $artikel;
      $adresse = $lieferant;

      $name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$id' LIMIT 1");
      $nummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");
      $projekt = $this->app->DB->Select("SELECT p.abkuerzung FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.id='$id' LIMIT 1");
      $projekt_id = $this->app->DB->Select("SELECT projekt FROM artikel WHERE id='$id' LIMIT 1");
      $ab_menge = $this->app->DB->Select("SELECT ab_menge FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");
      $ek = $this->app->DB->Select("SELECT id FROM einkaufspreise WHERE artikel='$id' AND adresse='$adresse' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') LIMIT 1");

      return $ek;
  }
    


  function ArtikelVorschlagNachbestellen($artikel,$tage,$lager,$auftrag,$promonat,$inbestellung)
  {
/*
    $lager = $this->ArtikelImLager($artikel);
    $auftrag  = $this->ArtikelImAuftrag($artikel);

    $promonat = $this->ArtikelMittelwertMonat($artikel)/30*$tage; // bedarf fuer den zeitraum

    $inbestellung = $this->ArtikelBestellung($artikel);
*/
    $promonat = $promonat/30*$tage;

    if( $lager - $auftrag <= $promonat)
    {
      // falls noch nie was bestell worden ist
      if($promonat<=0)
	$ret = $auftrag - $inbestellung;
      else  
	$ret = $auftrag + $promonat - $inbestellung - $lager;
    }
    
    // mindest bestellmenge
    $mindestbestellung = $this->app->DB->Select("SELECT mindestbestellung FROM artikel WHERE id='$artikel' LIMIT 1");
    $mindestlager = $this->app->DB->Select("SELECT mindestlager FROM artikel WHERE id='$artikel' LIMIT 1");


    // im lager sind zu wenig
    if($mindestlager > 0 &&( ($lager - $auftrag) < $mindestlager) && (($inbestellung +$lager - $auftrag) <= $mindestlager))
      $ret = $mindestbestellung;

     if($ret >0 && $ret < $mindestbestellung)
      $ret = $mindestbestellung;

    if($ret <= 0) return ""; else return $ret;
  }

  function ArtikelBestellung($artikel)
  {

    //$summe_in_bestellung  = $this->app->DB->Select("SELECT SUM(bp.menge-bp.geliefert) FROM bestellung_position bp WHERE bp.artikel='$artikel' AND bp.geliefert < bp.menge AND bp.abgeschlossen!='1'");
    $summe_in_bestellung  = $this->app->DB->Select("SELECT SUM(bp.menge-bp.geliefert) FROM bestellung_position bp WHERE bp.artikel='$artikel' AND bp.geliefert < bp.menge AND bp.abgeschlossen IS NULL");
    

    if($summe_in_bestellung <= 0)
	return 0;

    return $summe_in_bestellung;
  }


  function ArtikelVerkaufGesamt($artikel)
  {

  $summe_im_auftrag  = $this->app->DB->Select("SELECT SUM(menge) FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$artikel' AND a.status='abgeschlossen'");
    if($summe_im_auftrag<=0) $summe_im_auftrag=0;
    return $summe_im_auftrag;
  }

  function ArtikelInProduktion($artikel)
  {

  $summe_im_auftrag  = $this->app->DB->Select("SELECT SUM(menge) FROM produktion_position ap LEFT JOIN produktion a ON a.id=ap.produktion WHERE ap.artikel='$artikel' AND a.status='freigegeben'");

    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW() AND objekt!='lieferschein'");
    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW()");
    return $summe_im_auftrag;

  }


  function ArtikelImAuftrag($artikel)
  {

  $summe_im_auftrag  = $this->app->DB->Select("SELECT SUM(menge) FROM auftrag_position ap LEFT JOIN auftrag a ON a.id=ap.auftrag WHERE ap.artikel='$artikel' AND a.status='freigegeben'");

    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW() AND objekt!='lieferschein'");
    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW()");
    return $summe_im_auftrag;

  }



  function ArtikelImLager($artikel)
  {

  $summe_im_lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel'");

    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW() AND objekt!='lieferschein'");
    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW()");
    return $summe_im_lager;

  }


  function Bestellvorschlag($artikel,$basis_monate=3)
  {
		if($basis_monate=="p") $basis_monate=0; // nur offene produktionen!
    $bedarf_in_zeitraum = $this->ArtikelMittelwertMonat($artikel,$basis_monate);
    return $bedarf_in_zeitraum;
  }

  
  // berechnet den mittelwert der letzten 6 monate wie oft der artikel verkauft worden ist pro monat
  function ArtikelMittelwertMonat($artikel,$basis_monate=3)
  {
      // wieviel wurden komplett verkauft
    $gesamt =  $this->app->DB->Select("SELECT SUM(menge) FROM auftrag_position ap, auftrag a WHERE a.id=ap.auftrag 
      AND ap.artikel='$artikel' AND a.status='abgeschlossen' AND DATE_SUB(CURDATE(),INTERVAL $basis_monate MONTH) <= a.datum");

/*
    $monate_gesamt  =  count($this->app->DB->SelectArr("SELECT COUNT(ap.menge), EXTRACT(MONTH FROM a.datum) as monat  FROM auftrag_position ap, auftrag a 
      WHERE a.id=ap.auftrag 
      AND ap.artikel='$artikel' AND a.status='abgeschlossen' AND DATE_SUB(CURDATE(),INTERVAL $basis_monate MONTH) <= a.datum"));
*/
//echo "-".$monate_gesamt;

      return round($gesamt/$basis_monate);

//    return $this->app->DB->Select("SELECT ROUND(SUM(menge)/12) FROM auftrag_position ap, auftrag a WHERE a.id=ap.auftrag 
//      AND EXTRACT(YEAR FROM a.datum)=EXTRACT(YEAR FROM NOW()) AND ap.artikel='$artikel'");
  }

  function ArtikelMittelwertTag($artikel)
  {
    return round($this->ArtikelMittelwertMonat($artikel)/30);
  }

  function get_emails ($str)
  {
    $emails = array();
    $pattern="/([\s]*)([_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*([ ]+|)@([ ]+|)([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,}))([\s]*)/i"; 
    //preg_match_all("/\b\w+\@w+[\-\.\w+]+\b/", $str, $output);
    preg_match_all($pattern, $str, $output);
    foreach($output[0] as $email) array_push ($emails, trim(strtolower($email)));
    if (count ($emails) >= 1) return $emails;
    else return false;
  }

  function MahnwesenSend($rechnungsid,$drucker="")
  {


    $mahnwesen = $this->app->DB->Select("SELECT mahnwesen FROM rechnung WHERE id='$rechnungsid' LIMIT 1");
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$rechnungsid' LIMIT 1");

    switch($mahnwesen)
    {
      case "zahlungserinnerung":
				$mailversand = $this->app->erp->GetKonfiguration("mahnwesen_ze_versand");
				$mailversandtext = $this->app->erp->GetKonfiguration("textz");
      break;
      case "mahnung1":
				$mailversand = $this->app->erp->GetKonfiguration("mahnwesen_m1_versand");
				$mailversandtext = $this->app->erp->GetKonfiguration("textm1");
      break;
      case "mahnung2":
				$mailversand = $this->app->erp->GetKonfiguration("mahnwesen_m2_versand");
	$mailversandtext = $this->app->erp->GetKonfiguration("textm2");
      break;
      case "mahnung3":
	$mailversand = $this->app->erp->GetKonfiguration("mahnwesen_m3_versand");
	$mailversandtext = $this->app->erp->GetKonfiguration("textm3");
      break;
      case "inkasso":
	$mailversand = $this->app->erp->GetKonfiguration("mahnwesen_ik_versand");
	$mailversandtext = $this->app->erp->GetKonfiguration("texti");
      break;
      default:
    }

    $email = $this->app->DB->Select("SELECT email FROM rechnung WHERE id='$rechnungsid' LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM rechnung WHERE id='$rechnungsid' LIMIT 1");


    if($email=="" || $email ==$this->GetFirmaMail())
      $mailversand = 0;
 
    $Brief = new RechnungPDF($this->app);

    if($mailversand)
    {
      // text von datenbank 
      //echo "rechnung $rechnungsid $email <br>";
    $Brief->GetRechnung($rechnungsid);
    $tmpbrief= $Brief->displayTMP();
      $body = $this->app->erp->MahnwesenBody($rechnungsid,$mahnwesen);
			if($this->app->erp->MahnwesenBetrag($rechnungsid)>0)
			{
      	$this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$email,$to_name,"Buchhaltung: Ihre offene Rechnung $belegnr",$body,array($tmpbrief));
			} else {
      	$this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$this->GetFirmaMail(),$this->GetFirmaName(),"Buchhaltung: SYSTEMFEHLER! Mahnbetrag <=0 0 bei Rechnung $belegnr",$body,array($tmpbrief));
			} 
      $per = "email";
    } else {
      //echo "rechnung $rechnungsid brief an drucker $drucker<br>";
      $Brief->GetRechnung($rechnungsid,$mahnwesen);
      $tmpbrief= $Brief->displayTMP();
      $this->app->printer->Drucken($drucker,$tmpbrief);

      unlink($tmpbrief);
/* kein doppel drucken
      $Brief2 = new RechnungPDF(&$this->app);
      $Brief2->GetRechnung($rechnungsid,"doppel");
      $tmpbrief= $Brief2->displayTMP();
      $this->app->printer->Drucken($drucker,$tmpbrief);
    unlink($tmpbrief);
*/
      $per = "brief";
    }
    // protokoll eintrag in rechnung protokoll ob per brief oder mail wann was rausging!

     $this->RechnungProtokoll($rechnungsid,ucfirst($mahnwesen)." versendet am ".date('d.m.Y')." ($per)");

    // status aendern fuer mahnung
    $this->app->DB->Update("UPDATE rechnung SET mahnwesen='$mahnwesen', mahnwesen_datum=NOW(),versendet_mahnwesen='1' WHERE id='$rechnungsid'");

  }


  function MahnwesenBetrag($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM rechnung WHERE id='$id' LIMIT 1");

      // OfferNo, customerId, OfferDate

      $soll = $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$id' LIMIT 1");
      $ist = $this->app->DB->Select("SELECT ist FROM rechnung WHERE id='$id' LIMIT 1");


		return $soll - $ist;

  }


  function MahnwesenBody($id,$als)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM rechnung WHERE id='$id' LIMIT 1");

      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM rechnung WHERE id='$id' LIMIT 1");
      $auftrag= $this->app->DB->Select("SELECT auftrag FROM rechnung WHERE id='$id' LIMIT 1");
      $buchhaltung= $this->app->DB->Select("SELECT buchhaltung FROM rechnung WHERE id='$id' LIMIT 1");
      $lieferschein = $this->app->DB->Select("SELECT lieferschein FROM rechnung WHERE id='$id' LIMIT 1");
      $lieferscheinid = $lieferschein;
      $lieferschein = $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$lieferschein' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM rechnung WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM rechnung WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$id' LIMIT 1");
      $doppel = $this->app->DB->Select("SELECT doppel FROM rechnung WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM rechnung WHERE id='$id' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM rechnung WHERE id='$id' LIMIT 1");
      $soll = $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$id' LIMIT 1");
      $ist = $this->app->DB->Select("SELECT ist FROM rechnung WHERE id='$id' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM rechnung WHERE id='$id' LIMIT 1");
      $mahnwesen_datum = $this->app->DB->Select("SELECT mahnwesen_datum FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM rechnung WHERE id='$id' LIMIT 1");

      $zahlungdatum = $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD(datum, INTERVAL $zahlungszieltage DAY),'%d.%m.%Y') FROM rechnung WHERE id='$id' LIMIT 1");

      $zahlungsweise = strtolower($zahlungsweise);

      if($als=="zahlungserinnerung")
      {
        $body = $this->app->erp->GetKonfiguration("textz");
        $tage = $this->app->erp->GetKonfiguration("mahnwesen_m1_tage");
        $footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else if($als=="mahnung1")
      {
        $body = $this->app->erp->GetKonfiguration("textm1");
        $mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m1_gebuehr");
        $tage = $this->app->erp->GetKonfiguration("mahnwesen_m2_tage");
        $footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else if($als=="mahnung2")
      {
        $body = $this->app->erp->GetKonfiguration("textm2");
        $tage = $this->app->erp->GetKonfiguration("mahnwesen_m3_tage");
        $mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m2_gebuehr");
        $footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else if($als=="mahnung3")
      {
        $body = $this->app->erp->GetKonfiguration("textm3");
        $tage = $this->app->erp->GetKonfiguration("mahnwesen_ik_tage");
        $mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m3_gebuehr");
        $footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else if($als=="inkasso")
      {
        $body = $this->app->erp->GetKonfiguration("texti");
        //$tage = $this->app->erp->GetKonfiguration("mahnwesen_ik_tage");
        $tage = 3; //eigentlich vorbei
        $mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_ik_gebuehr");
        $footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else
      {
          $body = "Sehr geehrte Damen und Herren,\n\nanbei Ihre Rechnung.";
          $footer = "$freitext"."\n\n".$zahlungsweisetext."\n\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.\n$steuer";
      }

      $datummahnung= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$mahnwesen_datum', INTERVAL $tage DAY),'%d.%m.%Y')");
      $datumrechnungzahlungsziel= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$datum', INTERVAL $zahlungszieltage DAY),'%d.%m.%Y')");

      $tage_ze = $zahlungszieltage + $this->app->erp->GetKonfiguration("mahnwesen_m1_tage");
      $datumzahlungserinnerung= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$datum', INTERVAL $tage_ze DAY),'%d.%m.%Y')");


      // checkstamp $this->app->erp->CheckStamp("jhdskKUHsiusakiakuhsd"); // errechnet aus laufzeit und kundenid // wenn es nicht drinnen ist darf es nicht gehen


      if($mahngebuehr=="" || !is_numeric($mahngebuehr))
        $mahngebuehr = 0;

      //$offen= "11,23";


      $body = str_replace("{RECHNUNG}",$belegnr,$body);
      $body = str_replace("{DATUMRECHNUNG}",$datum,$body);
      $body = str_replace("{TAGE}",$tage,$body);
      $body = str_replace("{OFFEN}",number_format($soll - $ist,2),$body);
      $body = str_replace("{SOLL}",$soll,$body);
      $body = str_replace("{IST}",$ist,$body);
      $body = str_replace("{DATUM}",$datummahnung,$body);
      $body = str_replace("{MAHNGEBUEHR}",$mahngebuehr,$body);

      $body = str_replace("{DATUMZAHLUNGSERINNERUNG}",$datumzahlungserinnerung,$body);
      $body = str_replace("{DATUMRECHNUNGZAHLUNGSZIEL}",$datumrechnungzahlungsziel,$body);

    return $body;
  }


  function AufragZuDTA($auftrag,$rechnung="1")
  {
    $arr = $this->app->DB->Select("SELECT belegnr, bank_inhaber, bank_konto, bank_blz, gesamtsumme, adresse, name FROM auftrag WHERE id='$auftrag'");

    
    if($rechnung=="1")
    {
      $arr[0][vz1] = "RE ".$this->app->DB->Select("SELECT belegnr FROM rechnung WHERE auftrag='{$arr[0][belegnr]}' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    } else
      $arr[0][vz1] = "";

    $this->app->DB->Insert("INSERT INTO dta (id,adresse,datum,name,konto,blz,betrag,vz1,firma)
      VALUES('','{$arr[0][adresse]}',NOW(),'{$arr[0][name]}','{$arr[0][konto]}','{$arr[0][blz]}','{$arr[0][betrag]}','{$arr[0][vz1]}','".$this->app->User->GetFirma()."')");

  }

  function PaketmarkeDHLEmbedded($parsetarget,$sid="")
  {
    if($sid=="")
      $sid= $this->app->Secure->GetGET("sid");

    $id = $this->app->Secure->GetGET("id");
    $drucken = $this->app->Secure->GetPOST("drucken");
    $anders = $this->app->Secure->GetPOST("anders");
    $land = $this->app->Secure->GetGET("land");
    $tracking_again = $this->app->Secure->GetGET("tracking_again");


    $versandmit= $this->app->Secure->GetPOST("versandmit");
    $trackingsubmit= $this->app->Secure->GetPOST("trackingsubmit");
    $versandmitbutton = $this->app->Secure->GetPOST("versandmitbutton");
    $tracking= $this->app->Secure->GetPOST("tracking");

    if($trackingsubmit!="")
    {

      if($sid=="versand")
      {
					// falche tracingnummer bei DHL da wir in der Funktion PaketmarkeDHLEmbedded sind
					if(strlen($tracking) < 12 || strlen($tracking) > 20)
					{
						header("Location: index.php?module=versanderzeugen&action=frankieren&id=$id&land=$land&tracking_again=1");
						exit;
					}
					else
					{
					$versand = "dhl";  
					$this->app->DB->Update("UPDATE versand SET versandunternehmen='$versand', tracking='$tracking',versendet_am=NOW(),abgeschlossen='1' WHERE id='$id' LIMIT 1");

					//versand mail an kunden
					$this->app->erp->Versandmail($id);

						header("Location: index.php?module=versanderzeugen&action=offene");
					}
					exit;
			}
   }

    if($versandmitbutton!="")
    {

      if($sid=="versand")
      {
	$this->app->DB->Update("UPDATE versand SET versandunternehmen='$versandmit',versendet_am=NOW(),abgeschlossen='1' WHERE id='$id' LIMIT 1");

	//versand mail an kunden
	$this->app->erp->Versandmail($id);

	header("Location: index.php?module=versanderzeugen&action=offene");
	exit;
      }
    }




   if($anders!="")
    {
      //header("Location: index.php?module=paketmarke&action=tracking");
      $this->app->Tpl->Add(TAB1,
    "<br><br><table width=\"60%\" style=\"background-color: #fff; border: solid 1px #000;\" align=\"center\">
<tr>
<td align=\"center\">
<br><br>
<h2>Methode:</h2><br><br>
<form action=\"\" method=\"post\">Versandart: <input name=\"versandmit\" type=\"text\" id=\"tracking\"><script type=\"text/javascript\">document.getElementById(\"tracking\").focus(); </script>&nbsp;<input type=\"submit\" name=\"versandmitbutton\" value=\"Speichern\"></form>
<br><br>
</td></tr></table>
<br><br>
");


    }
    else if($drucken!="" || $tracking_again=="1")
    {
			if($tracking_again!="1")
			{
      $nachnahme = $this->app->Secure->GetPOST("nachnahme");
      $betrag= $this->app->Secure->GetPOST("betrag");
      $versichert = $this->app->Secure->GetPOST("versichert");
      $extraversichert = $this->app->Secure->GetPOST("extraversichert");
      $name= $this->app->Secure->GetPOST("name");
      $name2= $this->app->Secure->GetPOST("name2");
      $name3= $this->app->Secure->GetPOST("name3");
      $land= $this->app->Secure->GetPOST("land");
      $plz= $this->app->Secure->GetPOST("plz");
      $ort= $this->app->Secure->GetPOST("ort");
      $strasse = $this->app->Secure->GetPOST("strasse");
      $hausnummer= $this->app->Secure->GetPOST("hausnummer");

      $rechnungsnummer = $this->app->DB->Select("SELECT rechnung FROM versand WHERE id='$id' LIMIT 1");
      $rechnungsnummer = "RE ".$this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$rechnungsnummer' LIMIT 1");

      $kg = 2;

      if($nachnahme=="" && $versichert=="" && $extraversichert=="")
      {
        $this->app->erp->EasylogPaketmarkeStandard($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg);
      } else if ($nachnahme=="1" && $versichert=="" && $extraversichert=="")
      {
        $this->app->erp->EasylogPaketmarkeNachnahme($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$rechnungsnummer);
      } else if ($versichert=="1" && $extraversichert=="" && $nachnahme=="")
      {
        $this->app->erp->EasylogPaketmarke2500($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg);
      } else if ($versichert=="1" && $extraversichert=="" && $nachnahme=="1")
      {
        $this->app->erp->EasylogPaketmarkeNachnahme2500($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$rechnungsnummer);
      } else if ($versichert=="" && $extraversichert=="1" && $nachnahme=="1")
      {
        $this->app->erp->EasylogPaketmarkeNachnahme25000($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$rechnungsnummer);
      } else if ($extraversichert=="1" && $versichert=="" && $nachnahme=="")
      {
        $this->app->erp->EasylogPaketmarke25000($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg);
      }
			}
      //insert into versand oder update


			if($tracking_again=="1")
			{
				$error_message_tracking = "<div class=\"error\">Fehlerhafte Trackingnummer!</div>";
			}

      //header("Location: index.php?module=paketmarke&action=tracking");
      $this->app->Tpl->Add(TAB1,
    "<br>$error_message_tracking<br><table width=\"60%\" style=\"background-color: #fff; border: solid 1px #000;\" align=\"center\">
<tr>
<td align=\"center\">
<br><br>
<h2>Tracking-Nummer Scannen:</h2><br><br>
<form action=\"\" method=\"post\">Tracking-Nummer: <input name=\"tracking\" type=\"text\" id=\"tracking\"><script type=\"text/javascript\">document.getElementById(\"tracking\").focus(); </script>&nbsp;<input type=\"submit\" name=\"trackingsubmit\" value=\"Speichern\"></form>
<br><br>
</td></tr></table>
<br><br>
");


    } else {

    if($sid=="rechnung")
      $rechnung = $id;
    else $rechnung ="";

    if($sid=="versand")
    { 
      $tid = $this->app->DB->Select("SELECT lieferschein FROM versand WHERE id='$id' LIMIT 1"); 
      $rechnung  = $this->app->DB->Select("SELECT rechnung FROM versand WHERE id='$id' LIMIT 1"); 
      $sid = "lieferschein";
    } else {
      $tid = $id;
    }


    if($sid=="rechnung" || $sid=="lieferschein" || $sid=="adresse")
    {
        $name = $this->app->DB->Select("SELECT name FROM $sid WHERE id='$tid' LIMIT 1");
        $name2 = $this->app->DB->Select("SELECT adresszusatz FROM $sid WHERE id='$tid' LIMIT 1");
        if($name2=="")
        {
          $name2 = $this->app->DB->Select("SELECT abteilung FROM $sid WHERE id='$tid' LIMIT 1");
          $abt=1;
        }
        $name3 = $this->app->DB->Select("SELECT ansprechpartner FROM $sid WHERE id='$tid' LIMIT 1");
        if($name3=="" && $abt!=1)
          $name3 = $this->app->DB->Select("SELECT abteilung FROM $sid WHERE id='$tid' LIMIT 1");

        $ort = $this->app->DB->Select("SELECT ort FROM $sid WHERE id='$tid' LIMIT 1");
        $plz = $this->app->DB->Select("SELECT plz FROM $sid WHERE id='$tid' LIMIT 1");
        $land = $this->app->DB->Select("SELECT land FROM $sid WHERE id='$tid' LIMIT 1");
        $strasse = $this->app->DB->Select("SELECT strasse FROM $sid WHERE id='$tid' LIMIT 1");
        $hausnummer = $this->app->erp->ExtractStreetnumber($strasse);

        $strasse = str_replace($hausnummer,"",$strasse);
        $strasse = str_replace('.',"",$strasse);

	if($strasse=="")
	{
	  $strasse = $hausnummer;
	  $hausnummer = 7;
	}

    }

    // wenn rechnung im spiel entweder durch versand oder direkt rechnung
    if($rechnung >0)
    {

        $zahlungsweise =  $this->app->DB->Select("SELECT zahlungsweise FROM rechnung WHERE id='$rechnung' LIMIT 1");
        $soll =  $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$rechnung' LIMIT 1");
        $this->app->Tpl->Set(BETRAG,$soll);

            if($zahlungsweise=="nachnahme")
              $this->app->Tpl->Set(NACHNAHME,"checked");

            if($soll >= 500 && $soll <= 2500)
              $this->app->Tpl->Set(VERSICHERT,"checked");

            if($soll > 2500)
              $this->app->Tpl->Set(EXTRAVERSICHERT,"checked");

      }
      $this->app->Tpl->Set(NAME,$name);
      $this->app->Tpl->Set(NAME2,$name2);
      $this->app->Tpl->Set(NAME3,$name3);
      $this->app->Tpl->Set(ORT,$ort);
      $this->app->Tpl->Set(PLZ,$plz);
      $this->app->Tpl->Set(STRASSE,$strasse);
      $this->app->Tpl->Set(HAUSNUMMER,$hausnummer);

			if($tracking_again!="1")
      $this->app->Tpl->Parse($parsetarget,"paketmarke.tpl");
    }
  }




  function ExtractStreetnumber($street)
  {            
//    preg_match("/([a-zA-Z\s\.\-\ß]+)\s(.*[0-9]+.*)/is", $street, $adresse);
 //  preg_match("/^([a-z\s]+)\s([0-9]+\s?[a-z]?)$/i", $street, $adresse);
// The regular expression that gets the first set of digits in the address

  $address = $street;
  $number = preg_replace('/^.*?(\d+).*$/i', '$1', $address);


   // suche erstes vorkommen
   $pos = strpos($address,$number);

   $result = substr  ( $address, $pos);
    

    return $result;
  }  

  function EasylogPaketmarkeStandard($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg)
  {
    $verfahren = 1;
    $produkt = 101;
    $service =""; 
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service);
  }


  function EasylogPaketmarkeNachnahme($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$nachnahmetext)
  {
    $verfahren = 1; //NATIONAL
    $produkt = 101; //EUROPACK NATINONAL
    $service =""; //Nachnahme
    $betrag = str_replace(".",",",$betrag);
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service,$betrag,$nachnahmetext);
  }

  function EasylogPaketmarkeNachnahme2500($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$nachnahmetext)
  {
    $verfahren = 1; //NATIONAL
    $produkt = 101; //EUROPACK NATINONAL
    $service ="119"; //Nachnahme
    $betrag = str_replace(".",",",$betrag);
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service,$betrag,$nachnahmetext);
  }

  function EasylogPaketmarkeNachnahme25000($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$betrag,$nachnahmetext)
  {
    $verfahren = 1; //NATIONAL
    $produkt = 101; //EUROPACK NATINONAL
    $service ="120"; //Nachnahme
    $betrag = str_replace(".",",",$betrag);
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service,$betrag,$nachnahmetext);
  }




  function EasylogPaketmarke2500($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg)
  {
    $verfahren = 1; //NATIONAL
    $produkt = 101; //EUROPACK NATINONAL
    $service ="119"; //bis 2500 eur versicherichert
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service);
  }

  function EasylogPaketmarke25000($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg)
  {
    $verfahren = 1; //NATIONAL
    $produkt = 101; //EUROPACK NATINONAL
    $service ="120"; //bis 25000 eur versicherichert
    $this->EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service);
  }



  function EasylogPaketmarke($name,$name2,$name3,$strasse,$hausnummer,$plz,$ort,$land,$kg,$verfahren,$produkt,$service,$betrag="",$nachnahmetext="")
  {
    $easylog_path = $this->app->Conf->WFeasylog;
    $datei = fopen( $easylog_path, "a+");
    if($betrag!="")
      $betrag = "114=$betrag";
    $anzahl = 1;

    if($land=="AT")
    {
      $verfahren = 1;
      $produkt= "666";
      $teilnahme = "02-AT";
    } else if ($land!="DE")
    {
      //WELT
      $verfahren = 53;
      $produkt= 5301;
      $teilnahme = "01-int";
    } else {
      //Deutschland
      $teilnahme = "01-nat";
      $verfahren = 1;
    }

    fwrite($datei,utf8_decode("$name;$name2;$name3;$strasse;$hausnummer;$plz;$ort;$land;$verfahren;$produkt;$service;$kg;$betrag;EUR;$anzahl;$nachnahmetext;$teilnahme\r\n"));
    fclose($datei);
  }


  function DatevEinnahmenExport($von,$bis,$export="0",$sort="datum")
  {
      function encodeToUtf8($string) {
       return mb_convert_encoding($string, "UTF-8", mb_detect_encoding($string, "UTF-8, ISO-8859-1, ISO-8859-15", true));
       }


      $rechnungen = $this->app->DB->SelectArr("SELECT name,adresse,belegnr,DATE_FORMAT(datum,'%d.%m.%Y') as datum2, soll as betrag, ust_befreit,land,ustid,skonto_gegeben FROM rechnung WHERE firma='".$this->app->User->GetFirma()."' AND 
	datum >='$von' AND datum<='$bis' AND belegnr>0 ORDER by $sort");

	foreach($rechnungen as $key=>$value)
	{

	  $tmp[datum2] = $value[datum2];
	  $tmp[betrag] = $value[betrag];
	  $tmp[konto] = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='".$value[adresse]."' LIMIT 1"); //kundennummer
	  $tmp[belegfeld1] = $value[belegnr]; 
	  $tmp[buchungstext] = $value[name]; 
	  $tmp[skonto_gegeben] = 0; // $value[skonto_gegeben]; 
	  $tmp[land] = $value[land]; 
	  $tmp[ustid] = str_replace(' ','',$value[ustid]); 

	  if($value[ust_befreit]==1 && $value[ustid]!="")
	    $tmp[gegenkonto]=4125; 
	  else if(($value[ust_befreit]==1 && $value[ustid]=="") || $value[ust_befreit]==2)
	    $tmp[gegenkonto]=4120; //Drittland
	  else if($value[ust_befreit]==0 && $value[land]=="DE")
	    $tmp[gegenkonto]=4400; //DE
	  else 
	    $tmp[gegenkonto]=4315;  //privat EU
	  $buchungenArr[]=$tmp;

          if($value[skonto_gegeben] > 0)
          {
          $tmp[datum2] = $value[datum2];
          $tmp[betrag] = -$value[skonto_gegeben];
          $tmp[konto] = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='".$value[adresse]."' LIMIT 1"); //kundennummer
          $tmp[belegfeld1] = $value[belegnr];
          $tmp[buchungstext] = "SKONTO ".$value[name];
          $tmp[skonto_gegeben] = 0; // $value[skonto_gegeben];
          $tmp[land] = $value[land];
	  $tmp[ustid] = str_replace(' ','',$value[ustid]); 

          if($value[ust_befreit]==1 && $value[ustid]!="")
            $tmp[gegenkonto]=4125;
          else if(($value[ust_befreit]==1 && $value[ustid]=="") || $value[ust_befreit]==2)
            $tmp[gegenkonto]=4120; //Drittland
          else if($value[ust_befreit]==0 && $value[land]=="DE")
            $tmp[gegenkonto]=4400; //DE
          else
            $tmp[gegenkonto]=4315;  //privat EU
          $buchungenArr[]=$tmp;


          }

	}

      $gutschriften= $this->app->DB->SelectArr("SELECT  name,adresse,belegnr,DATE_FORMAT(datum,'%d.%m.%Y') as datum2, soll as betrag, ust_befreit,land,ustid FROM gutschrift WHERE firma='".$this->app->User->GetFirma()."' AND 
	datum >='$von' AND datum<='$bis'  AND belegnr > 0 AND status!='storniert' ORDER by $sort");

	foreach($gutschriften as $key=>$value)
	{
	  $tmp[datum2] = $value[datum2];
	  $tmp[betrag] = $value[betrag];
	  $tmp[haben] = 1;
	  $tmp[konto] = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='".$value[adresse]."' LIMIT 1"); //kundennummer
	  $tmp[belegfeld1] = $value[belegnr]; 
	  $tmp[buchungstext] = $value[name]; 
	  $tmp[land] = $value[land]; 
	  $tmp[ustid] = str_replace(' ','',$value[ustid]); 

	  if($value[ust_befreit]==1 && $value[ustid]!="")
	    $tmp[gegenkonto]=4125; 
	  else if(($value[ust_befreit]==1 && $value[ustid]=="") || $value[ust_befreit]==2)
	    $tmp[gegenkonto]=4120; //Drittland
	  else if($value[ust_befreit]==0 && $value[land]=="DE")
	    $tmp[gegenkonto]=4400; //DE
	  else 
	    $tmp[gegenkonto]=4315;  //privat EU
	  $buchungenArr[]=$tmp;
	}

    // Wir werden eine PDF Datei ausgeben
    header('Content-type: application/text');

    // Es wird downloaded.pdf benannt
    $datum=$von."_".$bis; 
    header('Content-Disposition: attachment; filename="'.$datum.'_DATEV_EINNAHMEN_FORMAT3.csv"');

    for($i=0;$i<count($buchungenArr);$i++)
    {
      //if($buchungenArr[$i][skonto_gegeben]=="") $buchungenArr[$i][skonto_gegeben] =0;

      $betrag = $buchungenArr[$i][betrag];// - $buchungenArr[$i][skonto_gegeben];


      // ust id ersten beiden buchstaben abschneiden
      $buchungenArr[$i][ustid] = trim(ereg_replace("^[A-Za-z]{2}", "", $buchungenArr[$i][ustid])); 

      echo "\"".$buchungenArr[$i][datum2]."\";";
      echo "\"";

      if($buchungenArr[$i][haben]==1)
	echo "-";

      $buchungenArr[$i][betrag] = str_replace('.',',',$betrag);

      echo $buchungenArr[$i][betrag]."\";";
      //echo "\"".$buchungenArr[$i][skonto_gegeben]."\";";

      echo "\"".$buchungenArr[$i][konto]."\";";
      echo "\"".($buchungenArr[$i][belegfeld1])."\";";
      echo "\"".encodeToUtf8(substr($buchungenArr[$i][buchungstext],0,60))."\";";
      echo "\"".$buchungenArr[$i][land]."\";";
      echo "\"".$buchungenArr[$i][ustid]."\";";
      echo "\"".$buchungenArr[$i][gegenkonto]."\"";

      echo "\r\n";

    }
    exit;
  }

  function DatenBuchhaltungZM()
  {
    //SELECT datum,soll,ustid FROM `rechnung` WHERE ustid!='' AND datum >='2010-07-01' AND datum <='2010-09-30' AND land!='DE'
  }


  function DatevBuchhaltungExport($von,$bis,$export,$sort="gegenkonto",$defaultgegenkonto="")
  {
    // alles aus der tabelle datev_buchungen


  /*  $sql ="SELECT DATE_FORMAT(buchung,'%d.%m.%Y') as datum2, if(soll>0,soll,haben) as betrag, if(soll>0,'1','0') as haben, konto, 
      if(buchungstext='',vorgang,buchungstext) as buchungstext, gegenkonto, belegfeld1, '' as belegfeld2,id FROM kontoauszuege
      WHERE buchung<='$bis' AND buchung>='$von'  Order by konto, datum DESC";
*/


   // fuer 2010
    
    $sql ="SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum2, umsatz as betrag, haben, konto, buchungstext,gegenkonto, belegfeld1, belegfeld2 FROM datev_buchungen
      WHERE datum<='$bis' AND datum>='$von' AND gegenkonto!='7777' AND gegenkonto!='77777' AND gegenkonto!='6301' Order by konto,datum DESC";


      //WHERE firma='".$this->app->User->GetFirma()."' AND datum<='$bis' AND datum>='$von' AND gegenkonto!='77777' AND gegenkonto!='7777' AND gegenkonto!='6301' Order by konto,datum DESC";

    $buchungenArr = $this->app->DB->SelectArr($sql);
        // Wir werden eine PDF Datei ausgeben
    header('Content-type: application/text');

    // Es wird downloaded.pdf benannt
    $datum=$von."_".$bis;
    header('Content-Disposition: attachment; filename="'.$datum.'_DATEV_BUCHUNGEN_FORMAT3.csv"');

    for($i=0;$i<count($buchungenArr);$i++)
    {

      $buchungenArr[$i][buchungstext] = (substr($buchungenArr[$i][buchungstext],0,60));
      //konto 1 - 6 austauschen mit richtigen nummern!
      //if($buchungenArr[$i][konto]<20)
      //  $buchungenArr[$i][konto] = $this->app->DB->Select("SELECT datevkonto FROM konten WHERE id='".$buchungenArr[$i][konto]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      echo "\"".$buchungenArr[$i][datum2]."\";";
/*
      if($buchungenArr[$i][gegenkonto]>70000)
	$buchungenArr[$i][gegenkonto] = 5400;

      if($buchungenArr[$i][gegenkonto]==22222)
	$buchungenArr[$i][gegenkonto] = 4400;
*/
      echo "\"";

      if($buchungenArr[$i][haben]==0)
      echo "-";

      $buchungenArr[$i][betrag] = str_replace('.',',',$buchungenArr[$i][betrag]);

      echo $buchungenArr[$i][betrag]."\";";

      echo "\"".$buchungenArr[$i][konto]."\";";
      //if($buchungenArr[$i][gegenkonto]<=0 || $buchungenArr[$i][gegenkonto]<0) {


      // sollte nie wieder passieren
	//$buchungenArr[$i][gegenkonto]=$defaultgegenkonto;
	echo "\"".($buchungenArr[$i][belegfeld1])."\";";
	echo "\"".($buchungenArr[$i][buchungstext])."\";";
	echo "\"".$leerland."\";";
	echo "\"".$leerustid."\";";
	echo "\"".$buchungenArr[$i][gegenkonto]."\"";
      echo "\r\n";
    }
    exit;

  }



  function DatevBuchhaltungExportALT($von,$bis,$export,$sort="gegenkonto",$defaultgegenkonto="")
  {
    // alles aus der tabelle datev_buchungen


    $sql ="SELECT DATE_FORMAT(buchung,'%d.%m.%Y') as datum2, if(soll>0,soll,haben) as betrag, if(soll>0,'1','0') as haben, konto, 
      if(buchungstext='',vorgang,buchungstext) as buchungstext, gegenkonto, belegfeld1, '' as belegfeld2,id FROM kontoauszuege
      WHERE buchung<='$bis' AND buchung>='$von'  Order by konto, id";


  //  $sql ="SELECT DATE_FORMAT(datum,'%d.%m.%Y') as datum2, umsatz as betrag, haben, konto, buchungstext,gegenkonto, belegfeld1, belegfeld2 FROM datev_buchungen
  //    WHERE firma='".$this->app->User->GetFirma()."' AND datum<='$bis' AND datum>='$von' Order by $sort,datum,kontoauszug DESC";

    $buchungenArr = $this->app->DB->SelectArr($sql);
        // Wir werden eine PDF Datei ausgeben
    header('Content-type: application/text');

    // Es wird downloaded.pdf benannt
    $datum=$von."_".$bis;
    header('Content-Disposition: attachment; filename="'.$datum.'_DATEV_BUCHUNGEN.csv"');

    for($i=0;$i<count($buchungenArr);$i++)
    {

      //konto 1 - 6 austauschen mit richtigen nummern!
      if($buchungenArr[$i][konto]<20)
        $buchungenArr[$i][konto] = $this->app->DB->Select("SELECT datevkonto FROM konten WHERE id='".$buchungenArr[$i][konto]."' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      echo "\"".$buchungenArr[$i][datum2]."\";";
/*
      if($buchungenArr[$i][gegenkonto]>70000)
	$buchungenArr[$i][gegenkonto] = 5400;

      if($buchungenArr[$i][gegenkonto]==22222)
	$buchungenArr[$i][gegenkonto] = 4400;
*/
      echo "\"";

      if($buchungenArr[$i][haben]==1)
      echo "-";

      $buchungenArr[$i][betrag] = str_replace('.',',',$buchungenArr[$i][betrag]);

      echo $buchungenArr[$i][betrag]."\";";

      echo "\"".$buchungenArr[$i][konto]."\";";
      //if($buchungenArr[$i][gegenkonto]<=0 || $buchungenArr[$i][gegenkonto]<0) {


      // sollte nie wieder passieren
      if($buchungenArr[$i][gegenkonto]<=0 && 0) {
	// versuch gegenkonto zu finden
	$gegenkonto = $this->app->DB->Select("SELECT gegenkonto FROM datev_buchungen WHERE kontoauszug='{$buchungenArr[$i][id]}' LIMIT 1");
	$ausgang = $this->app->DB->Select("SELECT adresse FROM kontoauszuege_zahlungsausgang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");

	$ausgang_parameter = $this->app->DB->Select("SELECT parameter FROM kontoauszuege_zahlungsausgang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");
	$ausgang_objekt = $this->app->DB->Select("SELECT objekt FROM kontoauszuege_zahlungsausgang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");

	$eingang = $this->app->DB->Select("SELECT adresse FROM kontoauszuege_zahlungseingang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");

	$eingang_parameter = $this->app->DB->Select("SELECT parameter FROM kontoauszuege_zahlungseingang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");
	$eingang_objekt = $this->app->DB->Select("SELECT objekt FROM kontoauszuege_zahlungseingang WHERE kontoauszuege='{$buchungenArr[$i][id]}' LIMIT 1");


	$kundennummer_ausgang = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$ausgang' LIMIT 1");
	$kundennummer_eingang = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$eingang' LIMIT 1");

	if($gegenkonto>0)
	{
	  echo "\"".($buchungenArr[$i][belegfeld1])."\";";
	  echo "\"".($buchungenArr[$i][buchungstext])."\";";
	  echo "\"".$gegenkonto."\"";
	}
	else if($eingang >0)
	{
	  $buchungstext = $this->app->DB->Select("SELECT CONCAT(name,' ',kundennummer) FROM adresse WHERE id='$eingang' LIMIT 1");
	  $belegfeld1 = $this->app->DB->Select("SELECT belegnr FROM $eingang_objekt WHERE id='$eingang_parameter' LIMIT 1");
	  echo "\"".($belegfeld1)."\";";
	  echo "\"".($buchungstext)."\";";
	  echo "\"".$kundennummer_eingang."\"";
	} 
    	else if($ausgang >0)
	{
	  $buchungstext = $this->app->DB->Select("SELECT CONCAT(name,' ',kundennummer) FROM adresse WHERE id='$ausgang' LIMIT 1");
	  $belegfeld1 = $this->app->DB->Select("SELECT belegnr FROM $ausgang_objekt WHERE id='$ausgang_parameter' LIMIT 1");
	  echo "\"".($belegfeld1)."\";";
	  echo "\"".($buchungstext)."\";";
	  echo "\"".$kundennummer_ausgang."\"";
	} else {
	$buchungenArr[$i][gegenkonto]=$defaultgegenkonto;
	echo "\"".($buchungenArr[$i][belegfeld1])."\";";
	echo "\"".($buchungenArr[$i][buchungstext])."\";";
	echo "\"".$buchungenArr[$i][gegenkonto]."\"";


	}
      
      } else 
      {
	//$buchungenArr[$i][gegenkonto]=$defaultgegenkonto;
	echo "\"".($buchungenArr[$i][belegfeld1])."\";";
	echo "\"".($buchungenArr[$i][buchungstext])."\";";
	echo "\"".$buchungenArr[$i][gegenkonto]."\"";
      }
      echo "\r\n";
    }
    exit;

  }


  function DatevAbgleich()
  {
    //alles was bei zahlungseingang passiert muss hier ausgewertet werden! aktuell fehlen kundenrechnungen, auftragsguthaben

    //hole alle nicht datev_abgeschlossenen zahlungen der kontoauszuege

    //auftragsguthaben
    //rechnung betreff=rechnungsnummer
    //verbindlichkeit
  }


  function SetKonfiguration($name,$dezimal=false)
  {

    $this->app->DB->Delete("DELETE FROM konfiguration WHERE name='$name' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

    if($dezimal)
      $value = str_replace(',','.',$this->app->Secure->GetPOST($name));
    else
      $value = $this->app->Secure->GetPOST($name);

    $this->app->DB->Insert("INSERT INTO konfiguration (name,wert,firma,adresse) VALUES ('$name','$value','".$this->app->User->GetFirma()."','".$this->app->User->GetAdresse()."')");

  }


  function GetKonfiguration($name)
  {

    return $this->app->DB->Select("SELECT wert FROM konfiguration WHERE name='$name' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
  }




  function Folgebestaetigung($auftrag)
  {
    $to = $this->app->DB->Select("SELECT email FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$auftrag' LIMIT 1");

    $folgebestaetigung = $this->app->DB->Select("SELECT folgebestaetigung FROM projekt WHERE id='$projekt' LIMIT 1");    
    if($folgebestaetigung!=1)
      return 1;


    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $folgebestaetigung = $this->app->DB->Select("SELECT folgebestaetigung  FROM auftrag WHERE id='$auftrag' LIMIT 1");
  
//    echo $to." ".$to_name." ".$folgebestaetigung."<br>";

    //lieferengpass bei folendem artikel

    $arr = $this->app->DB->SelectArr("SELECT ap.nummer, ap.bezeichnung, ap.menge, (SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) as lager, 
      (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') as reserviert, 
      if(((SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) - (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') - ap.menge)>=0,'',
      ((SELECT SUM(lp.menge) FROM lager_platz_inhalt lp WHERE lp.artikel=ap.artikel) - (SELECT SUM(lr.menge) FROM lager_reserviert lr WHERE lr.artikel=ap.artikel AND lr.datum>=NOW() AND lr.objekt!='lieferschein') - ap.menge)
        ) as fehlend 
      FROM auftrag_position ap LEFT JOIN artikel a ON a.id=ap.artikel WHERE ap.auftrag='$auftrag' AND a.lagerartikel=1");


    foreach($arr as $value)
    {
      $artikel = $value[bezeichnung];
      $nummer = $value[nummer];
      $menge  = $value[menge];
      $lager  = $value[lager];
      $reserviert= $value[reserviert];


      if($lager-$reseviert < $menge)
      {
	  $artikelid = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' AND name_de='$artikel' LIMIT 1");
	  $vorrausichtliches_datum = $this->app->erp->LieferdatumEinkauf($artikelid);
	  if($vorrausichtliches_datum!='0000-00-00')
	    $datum = $this->app->String->Convert($vorrausichtliches_datum,"%1-%2-%3","%3.%2.%1");
	  else $datum = "Liefertermin vom Lieferant noch nicht bestaetigt";

	  $tabelle .= "---\r\n".$artikel."\r\nMenge: ".$menge."\r\nLiefertermin: ".$datum."\n\r\n\r";
      }
    }



    $text = 'Sehr geehrter Kunde der embedded projects GmbH,

leider kommt es bei der Auslieferung Ihrers Auftrags zu einem Lieferenpass bei 
folgenden Artikeln:

'.$tabelle.'

Wir stehen mit unseren Lieferanten in Verbindung um eine schnelle Lieferung zu ermöglichen. 
Sobald wir einen Liefertermin erhalten, werden wir Ihnen diesen mitteilen,
bzw. bei eintreffen der Ware den Auftrag umgehend versenden.

Wir danken für Ihr Verständniss.

Ihr embedded projects Team';

    $betreff = "Folgebestätigung für Auftrag $belegnr";


    // WENN LETZTE BESTAETIGUNG BEREITS 1 WOCHE ALT IST

    $tage = ceil((mktime($folgebestaetigung) - time())/60/60/24);

    if($folgebestaetigung=='0000-00-00' || ($folgebestaetigung!='0000-00-00' && $tage > 7))
    {
      $this->app->DB->Update("UPDATE auftrag SET folgebestaetigung=NOW() WHERE id='$auftrag' LIMIT 1");
      if($to!="" && $to_name!="")
	$this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text);
    }
    // wenn kein Datum ermittelt werden kann dann Datum wird soweit bekannt nachgereicht

  }

  function LieferdatumEinkauf($artikelid)
  {
    return '0000-00-00';
    //return '2010-04-21';
  }




  function MahnwesenBezahltcheck()
  {
    // klappere rechnungen mit gutschriften ab und setzte diese auf bezahlt wenn die summe passt.
    // bzw. mahne restbetrag an
    $arrRechnungen = $this->app->DB->SelectArr("SELECT r.datum, r.belegnr, r.soll, r.ist as ist, 
			r.mahnwesen_datum, r.zahlungsweise, r.zahlungszieltage, r.zahlungsstatus, r.mahnwesen, r.versendet_mahnwesen, r.id, r.auftragid, r.skonto_gegeben
      FROM rechnung r WHERE (r.zahlungsstatus!='bezahlt' OR r.ist!=r.soll) AND r.belegnr!=0 AND r.mahnwesen_gesperrt!=1");

    for($i=0;$i < count($arrRechnungen); $i++)
    {

      $rechnungsbelegnr = $arrRechnungen[$i][belegnr];
      $rechnungssoll = $arrRechnungen[$i][soll];
      $rechnungskonto = $arrRechnungen[$i][skonto_gegeben];
      $rechnungid= $arrRechnungen[$i][id];
      $auftragid = $arrRechnungen[$i][auftragid];


      $check = $this->app->DB->Select("SELECT id FROM gutschrift WHERE rechnungid='$rechnungid' AND status!='angelegt' LIMIT 1");
      $soll  = $this->app->DB->Select("SELECT soll FROM gutschrift WHERE rechnungid='$rechnungid' AND status!='angelegt' LIMIT 1");

      if($check > 0)
      {
				//echo "es gibt eine gs fuer $rechnungsbelegnr";
	
				if($soll >= $rechnungssoll)
				{
					$this->app->DB->Update("UPDATE rechnung SET ist=soll, zahlungsstatus='bezahlt' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
				}
     	}
      if($rechnungssoll==0)
				$this->app->DB->Update("UPDATE rechnung SET ist=soll, zahlungsstatus='bezahlt' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

			// pruefe ob passender auftrag mit gleicher summe bezahlt ist, dann ist rechnung auch bezahlt bzw buche auch die summen, wenn autrag zu wenig geld hat
      // pruefe ob es bezahlten auftrag gibt
			$id_zahlung = $this->app->DB->Select("SELECT id FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$auftragid' LIMIT 1");
  		if($id_zahlung > 0)
			{
				$betrag = $this->app->DB->Select("SELECT betrag FROM kontoauszuege_zahlungseingang 
					WHERE objekt='auftrag' AND parameter='$auftragid' AND id='$id_zahlung' AND (betrag='$soll' OR betrag>0) LIMIT 1");

				if($betrag <= $rechnungssoll && $betrag >0)
        	$this->app->DB->Update("UPDATE rechnung SET ist='$betrag', zahlungsstatus='bezahlt' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
			}
    
			$id_zahlung = $this->app->DB->Select("SELECT id FROM kontoauszuege_zahlungseingang WHERE objekt='rechnung' AND parameter='$rechnungid' LIMIT 1");
  		if($id_zahlung > 0)
			{
				$betrag = $this->app->DB->Select("SELECT betrag FROM kontoauszuege_zahlungseingang 
					WHERE objekt='rechnung' AND parameter='$rechnungid' AND id='$id_zahlung' AND (betrag='$soll' OR betrag>0) LIMIT 1");

				if($betrag <= $rechnungssoll && $betrag >0)
        	$this->app->DB->Update("UPDATE rechnung SET ist='$betrag', zahlungsstatus='bezahlt' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
			}
    

      $tage_rechnung  = $this->app->DB->Select("SELECT DATEDIFF(NOW(),'{$arrRechnungen[$i][datum]}')");

			// letzter status versendet
      $tage  = $this->app->DB->Select("SELECT DATEDIFF(NOW(),'{$arrRechnungen[$i][mahnwesen_datum]}')");

      $tage_ze= $arrRechnungen[$i][zahlungszieltage];

      if($tage_ze==0) $tage_ze = 14;

      $tage_m1 = $this->app->erp->GetKonfiguration("mahnwesen_m1_tage");
      $tage_m2 = $this->app->erp->GetKonfiguration("mahnwesen_m2_tage");
      $tage_m3 = $this->app->erp->GetKonfiguration("mahnwesen_m3_tage");
      $tage_ik = $this->app->erp->GetKonfiguration("mahnwesen_ik_tage");
      // bei wechsel immer eintrag in Rechnungs protokoll machen!!!!
     
      // versendet_mahnwesen auf '' setzten 


      // zahlungserinnerung
      if($arrRechnungen[$i][mahnwesen]=="" && ($tage_rechnung > $tage_ze))
      {
	$this->app->DB->Update("UPDATE rechnung SET mahnwesen='zahlungserinnerung', mahnwesen_datum=NOW(),versendet_mahnwesen='0' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      } elseif ($arrRechnungen[$i][mahnwesen]=="zahlungserinnerung" && $tage >= ($tage_m1) )
      {
	$this->app->DB->Update("UPDATE rechnung SET mahnwesen='mahnung1', mahnwesen_datum=NOW(),versendet_mahnwesen='0' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      } elseif ($arrRechnungen[$i][mahnwesen]=="mahnung1" && $tage > ($tage_m2))
      {
	$this->app->DB->Update("UPDATE rechnung SET mahnwesen='mahnung2', mahnwesen_datum=NOW(),versendet_mahnwesen='0' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      } elseif ($arrRechnungen[$i][mahnwesen]=="mahnung2" && $tage > ($tage_m3))
      {
	$this->app->DB->Update("UPDATE rechnung SET mahnwesen='mahnung3', mahnwesen_datum=NOW(),versendet_mahnwesen='0' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      } elseif ($arrRechnungen[$i][mahnwesen]=="mahnung3" && $tage > ($tage_ik))
      {
	$this->app->DB->Update("UPDATE rechnung SET mahnwesen='inkasso', mahnwesen_datum=NOW(),versendet_mahnwesen='0' WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

      } else {
	if($arrRechnungen[$i][versendet_mahnwesen]!=1)
	  $this->app->DB->Update("UPDATE rechnung SET mahnwesen_datum=NOW() WHERE id='$rechnungid' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
      }


    }




  }


  function Stornomail($auftrag)
  {
    $adresse = $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $stornomail = $this->app->DB->Select("SELECT stornomail FROM projekt WHERE id='$projekt' LIMIT 1");

    // KEINE STORNOMAIL
    if($stornomail!=1)
      return;


    $to = $this->app->DB->Select("SELECT email FROM auftrag WHERE id='$auftrag' LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM auftrag WHERE id='$auftrag' LIMIT 1");

    $parameter = $auftrag;

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$auftrag' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    $keinestornomail = $this->app->DB->Select("SELECT keinestornomail FROM auftrag WHERE id='$auftrag' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");

    if($belegnr>0 && $keinestornomail==0)
    {
      $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='Stornierung' AND sprache='deutsch' LIMIT 1");
      $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='Stornierung' AND sprache='deutsch' LIMIT 1");

      $text= str_replace('[AUFTRAG]',$belegnr,$text);
      $text= str_replace('[GESAMT]',$this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$parameter' LIMIT 1"),$text);
      $text= str_replace('[DATUM]',$this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM auftrag WHERE id='$parameter' LIMIT 1"),$text);

      if($to!="" && $to_name!="")
	$this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text);

    } 
  }

  function ExportlinkZahlungsmail()
  {
   $exports = $this->app->DB->SelectArr("SELECT * FROM exportlink_sent WHERE mail='0'");

    for($i=0;$i<count($exports);$i++)
    //for($i=0;$i<5;$i++)
    {
      // mail
      $adresse = $exports[$i][adresse];
      $reg= $exports[$i][reg];
      $artikelid = $exports[$i][objekt];

      $to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$adresse' LIMIT 1");
      $to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' LIMIT 1");
      $artikel = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikelid' LIMIT 1");

      $projekt=1;

      $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='AlternativArtikel' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");
      $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='AlternativArtikel' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");


      $betreff = str_replace('[ARTIKEL]',$artikel,$betreff);
      $text= str_replace('[ARTIKEL]',$artikel,$text);
      $text = str_replace('[AUFTRAG]',$auftrag,$text);

      $text = str_replace('[REG]',$reg,$text);
 
 
      $this->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text);
      echo $to_name." <".$to.">\r\n";

      $this->app->DB->Update("UPDATE exportlink_sent SET mail=1 WHERE reg='$reg' LIMIT 1");


    }





  }




  function AuftragZahlungsmail($id="",$force=0)
  {
    if(!is_numeric($id))
      $id = $this->app->Secure->GetGET("id");
    else $intern=1;

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
    $adresse= $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$id' LIMIT 1");


    $summeimauftrag = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$id'");
    $auftragssumme = $this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$id' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$id' LIMIT 1");
    $zahlungsmail = $this->app->DB->Select("SELECT zahlungserinnerung FROM projekt WHERE id='$projekt' LIMIT 1");
    
    // sind vorbedingungen erfuellt?
    $vorbedinungen = 0;
    $zahlungsmailbedinungen = $this->app->DB->Select("SELECT zahlungsmailbedinungen FROM projekt WHERE id='$projekt' LIMIT 1");

    if(preg_match("/lager_ok/",$zahlungsmailbedinungen))
    {
     $lager_ok = $this->app->DB->Select("SELECT lager_ok FROM auftrag WHERE id='$id' LIMIT 1");
     if($lager_ok==0)
      $vorbedinungen++;
    }

    
    // Kundencheck
    if(preg_match("/check_ok/",$zahlungsmailbedinungen))
    {
     $check_ok = $this->app->DB->Select("SELECT check_ok FROM auftrag WHERE id='$id' LIMIT 1");
      if($check_ok==0)
      $vorbedinungen++;
    }

    //echo "zahlungsmail $zahlungsmail $vorbedinungen $auftragssumme $belegnr\r\n ";
    
    if(($zahlungsmail > 0) && ($vorbedinungen==0) && ($auftragssumme>0) && ($belegnr>0))
    {
    	//echo "verschickt";
      $this->Zahlungsmail($adresse,$auftragssumme-$summeimauftrag,$belegnr,$force);
    }

    if($intern!=1)
    {
      header("Location: index.php?module=auftrag&action=edit&id=$id");
      exit;
    }

  }


	function AufgabenMail($aufgabe)
	{

					$arraufgabe = $this->app->DB->SelectArr("SELECT * FROM aufgabe WHERE id='$aufgabe' LIMIT 1");

					$adresse = $arraufgabe[0]["adresse"];

					$to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    			$to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

					$aufgabe_name = $arraufgabe[0]["aufgabe"];
					$beschreibung = $arraufgabe[0]["beschreibung"];
					$datum = $arraufgabe[0]["abgabe_bis"];


					$text = "Aufgabe: $aufgabe_name\r\n";
					$text .= "Abgabe bis: $datum\r\n";
					$text .= "Beschreibung: $beschreibung\r\n";

          $this->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,"Erinnerung Aufgabe: ".$aufgabe_name,$text);
	}


  function Zahlungsmail($adresse,$rest="",$auftrag="",$force=0)
  {
    $to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

    //$to = ""; //DEBUG

    $parameter = $this->app->DB->Select("SELECT id FROM auftrag WHERE belegnr='$auftrag' LIMIT 1");
    $internetnummer = $this->app->DB->Select("SELECT internet FROM auftrag WHERE belegnr='$auftrag' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE belegnr='$auftrag' LIMIT 1");
    $zahlungsmail = $this->app->DB->Select("SELECT zahlungserinnerung FROM projekt WHERE id='$projekt' LIMIT 1");
    $zahlungsmailcounter = $this->app->DB->Select("SELECT zahlungsmailcounter FROM auftrag WHERE belegnr='$auftrag' LIMIT 1");

    $gesamt = $this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$parameter' LIMIT 1");

    if($rest!="")
    {

      //Falls projekt mail vorhanden sonst globalen firmen standard
      if($gesamt-$rest==0)
      {
	$text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungMiss' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0')LIMIT 1");
	$betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungMiss' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");
      } else {
	$text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungDiff' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");
	$betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungDiff' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");
      }

      $text= str_replace('[REST]',$rest,$text);

      if($internetnummer>0)
	$text= str_replace('[AUFTRAG]',$internetnummer,$text);
      else
	$text= str_replace('[AUFTRAG]',$auftrag,$text);

      $text= str_replace('[GESAMT]',$this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$parameter' LIMIT 1"),$text);
      $gesamtsummecheck = $rest;
      $text= str_replace('[DATUM]',$this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM auftrag WHERE id='$parameter' LIMIT 1"),$text);


      //uebersicht zahlunsgeingaenge
      /*
      $zahlungen = $this->app->DB->SelectArr("SELECT DATE_FORMAT(datum,'%d.%m.%Y') as eingang, betrag FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$parameter'");

      foreach($zahlungen as $key=>$value)
      {
	$zahlunge_txt .= $value[0]."\t".$value[1]."\n";
      }
      $text = str_replace('[ZAHLUNGEN]',$zahlungen_txt,$text);
      */

    } else 
    {
      //TODO nette mail wenn kunde keine vorkasse macht, warum er das nicht macht etc.
      $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungOK' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");
      $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='ZahlungOK' AND sprache='deutsch' AND (projekt='$projekt' OR projekt='0') LIMIT 1");

      $gesamtsumme = $this->app->DB->Select("SELECT gesamtsumme FROM auftrag WHERE id='$parameter' LIMIT 1");

      $text= str_replace('[AUFTRAG]',$auftrag,$text);
      $text= str_replace('[GESAMT]',$gesamtsumme,$text);
      $gesamtsummecheck = $gesamtsumme;
      $text= str_replace('[DATUM]',$this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$parameter' LIMIT 1"),$text);
    }

    $zahlungsmailauftrag = $this->app->DB->Select("SELECT zahlungsmail FROM auftrag WHERE id='$parameter' LIMIT 1");

    //$tage = ceil((mktime($zahlungsmailauftrag) - time())/60/60/24);
    $tage = $this->app->DB->Select("SELECT DATEDIFF(NOW(),'$zahlungsmailauftrag')");

    //echo "Tage $tage $to_name mail $zahlungsmail datum $zahlungsmailauftrag<br>";

    if($to!="" && $to_name!="" && $zahlungsmail==1 && ($tage > 7 || $zahlungsmailauftrag=="0000-00-00" || $force==1))
    {
      $zahlungsmailcounter++;
      $this->app->DB->Update("UPDATE auftrag SET zahlungsmail=NOW(),zahlungsmailcounter='$zahlungsmailcounter' WHERE id='$parameter' LIMIT 1");
      if($gesamtsummecheck>1)
      {
        if($zahlungsmailcounter<2)
          $this->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text);
				// automatisch Reservierungen entfernen
				else {
					if($tage > 14) {
          	$this->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),
							"sauter@embedded-projects.net","Administrator","Systemmeldung: Offenen Auftrag $auftrag kl&auml;ren oder stornieren",$text);
					}
					}	
      }
      else
        $this->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$this->GetFirmaMail(),"Buchhaltung","Systemmeldung: Bitte Skonto geben",$text);
    }

  }


  function Rechnungsmail($id)
  {
    $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='Versand' AND sprache='deutsch' LIMIT 1");
    $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='Versand' AND sprache='deutsch' LIMIT 1");
    $adresse = $this->app->DB->Select("SELECT adresse FROM rechnung WHERE id='$id' LIMIT 1");
    $to = $this->app->DB->Select("SELECT email FROM rechnung WHERE id='$id'  LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM rechnung WHERE id='$id' LIMIT 1");


    $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='Rechnung' AND sprache='deutsch' LIMIT 1");
    $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='Rechnung' AND sprache='deutsch' LIMIT 1");
    $text = str_replace('[NAME]',$to_name,$text);


    if($to!="" && $to_name!="")
    {
      $Brief = new RechnungPDF($this->app);
      $Brief->GetRechnung($id);
      $tmpfile = $Brief->displayTMP();

        //$this->app->erp->DokumentSendShow(TAB1,"rechnung",$rechnung,$adresse);
        // temp datei wieder loeschen

      $this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text,array($tmpfile));
      $this->app->erp->RechnungProtokoll($id,"Rechnung versendet");

      unlink($tmpfile);

      // als versendet markieren

    }
  }



  function Versandmail($id)
  {
    $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='Versand' AND sprache='deutsch' LIMIT 1");
    $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE subjekt='Versand' AND sprache='deutsch' LIMIT 1");
    $adresse = $this->app->DB->Select("SELECT adresse FROM versand WHERE id='$id' LIMIT 1");
    $to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $trackingsperre = $this->app->DB->Select("SELECT trackingsperre FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");


    $tracking = $this->app->DB->Select("SELECT tracking FROM versand WHERE id='$id' LIMIT 1");
    $keinetrackingmail = $this->app->DB->Select("SELECT keinetrackingmail FROM versand WHERE id='$id' LIMIT 1");
    $versandunternehmen = $this->app->DB->Select("SELECT versandunternehmen FROM versand WHERE id='$id' LIMIT 1");

    if($versandunternehmen=="dhl" || $versandunternehmen=="dhlpremium")
    {
      $text = str_replace('[VERSAND]','DHL Versand: '.$tracking.' (http://www.dhl.de/)',$text);
      $notsend = 0;
    }
    else if ($versandunternehmen=="rma")
    {
      $notsend = 1;
    }
    else if($versandunternehmen=="selbstabholer")
    {
      $notsend = 0;
      // selbstabholer
      $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE subjekt='Selbstabholer' AND sprache='deutsch' LIMIT 1");
      $text = str_replace('[VERSAND]','',$text);
    } else {
			// bei allen anderen lieferarten keine mail
			$notsend = 1;
		}

    if($to!="" && $to_name!="" && $trackingsperre!=1 && $notsend==0 && $keinetrackingmail!=1)
    {
      $this->app->erp->MailSend($this->GetFirmaMail(),$this->GetFirmaName(),$to,$to_name,$betreff,$text);
    }
  }


  function KundeAnlegen($typ,$name,$abteilung,$unterabteilung,$ansprechpartner,$adresszusatz,$strasse,$land,$plz,$ort,$email,$telefon,$telefax,$ustid,$partner,$projekt)
  {
    $this->app->DB->Insert("INSERT INTO adresse (id,typ,name,abteilung,unterabteilung,ansprechpartner,adresszusatz,strasse,land,plz,ort,email,telefon,telefax,ustid,partner,projekt,firma)
      VALUES('','$typ','$name','$abteilung','$unterabteilung','$ansprechpartner','$adresszusatz','$strasse','$land','$plz','$ort','$email','$telefon','$telefax','$ustid','$partner','$projekt','".$this->app->User->GetFirma()."')");
    $adresse = $this->app->DB->GetInsertID();
   

    //adresse Kundennummer verpassen
    $this->KundennummerVergeben($adresse);
 
    $this->AddRolleZuAdresse($adresse, "Kunde", "von", "Projekt", $projekt);
    return $adresse;
  }

  function Steuerbefreit($land,$ustid)
  {
    if($land=="DE")
      return false;

    foreach($this->GetUSTEU() as $euland)
    { 
      if($land==$euland && $ustid!="")
        return true;
      else if ($land==$euland && $ustid=="")
        return false;
    }

    // alle anderen laender sind export!
    return true;
  }


  function ImportAuftrag($adresse,$warenkorb,$projekt)
  {
    //abweichende lieferadresse gibt es diese schon? wenn nicht zusätzlich in DB anlegen
    //$warenkorb[abweichendelieferadresse];

    //CreateAuftrag
    $auftrag = $this->app->erp->CreateAuftrag();
    $this->app->erp->AuftragProtokoll($auftrag,"Auftrag importiert vom Shop");


    $this->app->erp->LoadAuftragStandardwerte($auftrag,$adresse);

    $warenkorb[gesamtsumme] = str_replace(".","",$warenkorb[gesamtsumme]);
    $warenkorb[gesamtsumme] = str_replace(",",".",$warenkorb[gesamtsumme]);

    $vertrieb = "Online-Shop"; 

    if($warenkorb[lieferung]=="selbstabholer")
      $versand = "selbstabholer"; 
    else
      $versand = "versandunternehmen"; 

    if($warenkorb[lieferung]=="dhlpremium")
      $versand = "dhlpremium";

    if($warenkorb[lieferung]=="packstation")
      $versand = "packstation";

    if(strlen($warenkorb[lieferadresse_name])>3)
      $warenkorb[abweichendelieferadresse]="1";
    else
      $warenkorb[abweichendelieferadresse]="0";


    //belegnummer fuer auftrag erzeugen
    $belegnr = $this->app->DB->Select("SELECT MAX(belegnr) FROM auftrag WHERE firma='".$this->app->User->GetFirma()."'");
    if($belegnr <= 0) $belegnr = 200000; else $belegnr = $belegnr + 1;

    if($warenkorb[bestellnummer]!="") $warenkorb[bestellnummer] = "Ihre Bestellnummer: ".$warenkorb[bestellnummer];

    if($this->app->erp->Steuerbefreit($warenkorb[land],$warenkorb[ustid]))
      $ust_befreit=1;
    else
      $ust_befreit=0;

    if($this->app->erp->Export($warenkorb[land]))
      $ust_befreit=2;

    // E-Mail Adresse auf aktuellesten Stand bringen
    if($warenkorb[email]!="")
      $this->app->DB->Update("UPDATE adresse SET email='".$warenkorb[email]."' WHERE id='".$adresse."' LIMIT 1");

    $this->app->DB->Update("UPDATE auftrag SET
    belegnr='$belegnr',
    datum='{$warenkorb[bestelldatum]}',
    ustid='{$warenkorb[ustid]}',
    ust_befreit='{$ust_befreit}',
    internet='{$warenkorb[onlinebestellnummer]}',
    versandart='{$versand}',				   
    vertrieb='{$vertrieb}',
    zahlungsweise='{$warenkorb[zahlungsweise]}',
    freitext='{$warenkorb[bestellnummer]}',
    bank_inhaber='{$warenkorb[kontoinhaber]}',
    bank_institut='{$warenkorb[bank]}',
    bank_blz='{$warenkorb[blz]}',
    bank_konto='{$warenkorb[kontonummer]}',
    autoversand='1',
    abweichendelieferadresse='{$warenkorb[abweichendelieferadresse]}',
    ansprechpartner='{$warenkorb[ansprechpartner]}',
    liefername='{$warenkorb[lieferadresse_name]}',
    lieferland='{$warenkorb[lieferadresse_land]}',
    lieferstrasse='{$warenkorb[lieferadresse_strasse]}',
    lieferabteilung='{$warenkorb[lieferadresse_abteilung]}',
    lieferunterabteilung='{$warenkorb[lieferadresse_unterabteilung]}',
    lieferansprechpartner='{$warenkorb[lieferadresse_ansprechpartner]}',
    lieferort='{$warenkorb[lieferadresse_ort]}',
    lieferplz='{$warenkorb[lieferadresse_plz]}',
    lieferadresszusatz='{$warenkorb[lieferadresse_adresszusatz]}',
    packstation_inhaber='{$warenkorb[packstation_inhaber]}',
    packstation_station='{$warenkorb[packstation_nummer]}',
    packstation_ident='{$warenkorb[packstation_postidentnummer]}',
    packstation_plz='{$warenkorb[packstation_plz]}',
    packstation_ort='{$warenkorb[packstation_ort]}',
    partnerid='{$warenkorb[affiliate_ref]}',
    kennen='{$warenkorb[kennen]}',
    status='freigegeben',
    projekt='$projekt',
    gesamtsumme='{$warenkorb[gesamtsumme]}' WHERE id='$auftrag'");
    
    //artikelpositionen buchen
    foreach($warenkorb[articlelist] as $key=>$value)
    {

      // wenn es das produkt in dem projekt gibt
      $j_id = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='{$value[articleid]}' LIMIT 1");
      $check = $this->app->DB->Select("SELECT id FROM verkaufspreise WHERE artikel='$j_id' 
			AND (gueltig_bis='0000-00-00' OR gueltig_bis >=NOW()) AND ab_menge=1 
			AND ((objekt='Standard' AND adresse=0) OR (objekt='' AND adresse=0)) AND geloescht=0 LIMIT 1");
      if($check > 0)
      {
	//$this->AddAuftragPositionNummer($auftrag,$value[articleid],$value[quantity],$projekt,"",$value[price]);
        // netto preis errechnen
        // if($value[tax]=="0" || $value[tax]=="") $preis = $value[price];
        //  else $preis = ($value[price]/(100+$value[taxtype]))*100;

        if($this->app->erp->Steuerbefreit($warenkorb['land'],$warenkorb['ustid']))
        {
          //pruefen ob es versandkosten sind $warenkorb[land] // $preis
          $this->AddAuftragPositionNummer($auftrag,$value[articleid],$value[quantity],$projekt,"",true);
        }
        else
        {
          //pruefen ob es versandkosten sind $warenkorb[land] // $preis
          $this->AddAuftragPositionNummer($auftrag,$value[articleid],$value[quantity],$projekt,"");
        }

	$this->AddAuftragPositionNummerPartnerprogramm($auftrag,$value[articleid],$value[quantity],$projekt,$warenkorb[affiliate_ref]);
      }
      else
      {
	$j_nummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE nummer='{$value[articleid]}' LIMIT 1");
	$j_name = $this->app->DB->Select("SELECT name_de FROM artikel WHERE nummer='{$value[articleid]}' LIMIT 1");
	$j_projekt = $this->app->DB->Select("SELECT abkuerzung FROM projekt WHERE id='{$projekt}' LIMIT 1");
	$j_menge = $value[quantity];
	$j_preis = $value[price];
	
	$this->app->erp->AuftragProtokoll($auftrag,"Artikel nach Import nicht in interner Datenbank gefunden (Artikel: $j_nummer $j_name  Menge: $j_menge Preis: $j_preis) bzw. kein Verkaufspreis vorhanden.");
      }
      
    }
		

		// wenn reservierung aktiviert ist
		$reservierung = $this->app->DB->Select("SELECT reservierung FROM projekt WHERE id='$projekt' LIMIT 1");
		if($reservierung>=1)
			$this->AuftragReservieren($auftrag);


		
    $this->AuftragEinzelnBerechnen($auftrag);

  }


  function KundennummerVergeben($adresse)
  {
    $id = $adresse;
    $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");

    if($kundennummer==0 || $kundennummer==""){
      // pruefe ob rolle kunden vorhanden
      $check = $this->app->DB->Select("SELECT adresse FROM adresse_rolle WHERE adresse='$id' AND subjekt='Kunde' LIMIT 1");
      if($check!="")
      {
        $kundennummer = $this->app->erp->GetNextKundennummer();
        $this->app->DB->Update("UPDATE adresse SET kundennummer='$kundennummer' WHERE id='$id' AND kundennummer='0' LIMIT 1");
      } 
    }
  }


  function AdresseUSTCheck($adresse)
  {
    //wenn land DE

    $land = $this->app->DB->Select("SELECT land FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($land =="DE" || $land=="")
      return 0;

    foreach($this->GetUSTEU() as $euland)
    { 
      if($land==$euland)
        return 1;
    }

    // alle anderen laender sind export!
    return 2;


    //wenn land EU
/*
     
    $ustid = $this->app->DB->Select("SELECT ustid FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($ustid!="" && $land!="DE")
      return $this->AutoUSTPruefung($adresse);
*/

    return 1;
    // 0 wenn keine erfolgreiche pruefung heute da ist
  }


  function AutoUSTPruefung($adresse)
  {

    // schaue obs heute bereits eine pruefung gegeben hat die erfolgreich war
    $ustcheck = $this->app->DB->Select("SELECT id FROM ustprf WHERE DATE_FORMAT(datum_online,'%Y-%m-%d')=DATE_FORMAT(NOW(),'%Y-%m-%d') AND status='erfolgreich' AND adresse='$adresse' LIMIT 1");
    if($ustcheck>0 && is_numeric($ustcheck))
      return 1;


    $name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 
    $ustid = $this->app->DB->Select("SELECT ustid FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 
    $land = $this->app->DB->Select("SELECT land FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 
    $ort = $this->app->DB->Select("SELECT ort FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 
    $plz = $this->app->DB->Select("SELECT plz FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 
    $strasse  = $this->app->DB->Select("SELECT strasse FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1"); 

    if($land=="DE" || $ustid=="") return 0;


    $ustcheck = $this->app->DB->Select("SELECT id FROM ustprf WHERE status='' AND adresse='$adresse' LIMIT 1");
    if(!($ustcheck>0 && is_numeric($ustcheck))) 
    {
      $this->app->DB->Insert("INSERT INTO ustprf (id,adresse,name,ustid,land,ort,plz,rechtsform,strasse,datum_online,bearbeiter)
	VALUES('','$adresse','$name','$ustid','$land','$ort','$plz','$rechtsform','$strasse',NOW(),'".$this->app->User->GetName()."')");
      $ustprf_id = $this->app->DB->GetInsertID();
    }
    else
      $ustprf_id = $ustcheck;
   

    //$this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","AUTO Pr&uuml;fung gestartet", "'.$this->app->User->GetName().'")');

    $ustid = str_replace(" ","",$ustid);
    $ust = $ustid;
    $result = 0;

    if(!$this->app->erp->CheckUSTFormat($ust)){
        //$this->app->Tpl->Set(MESSAGE,"<div class=\"error\">UST-Nr. bzw. Format fuer Land ist nicht korrekt</div>");
	$this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","UST-Nr. bzw. Format fuer Land ist nicht korrekt", "'.$this->app->User->GetName().'")');
    }else{
        //$UstStatus = $this->app->erp->CheckUst("DE263136143","SE556459933901","Wind River AB","Kista","Finlandsgatan 52","16493","nein");        

        $UstStatus = $this->app->erp->CheckUst("DE263136143", $ust, $name, $ort, $strasse, $plz, $druck="nein");
        if(is_array($UstStatus))
        {
          $tmp = new USTID();
          $msg = $tmp->errormessages($UstStatus['ERROR_CODE']);

          if($UstStatus['ERROR_CODE']==200)
	  {
	    $this->app->DB->Delete("DELETE FROM ustprf_protokoll WHERE ustprf_id='$ustprf_id' AND bemerkung='UST g&uuml;ltig aber Name, Ort oder PLZ wird anders geschrieben'");
	    $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","UST g&uuml;ltig aber Name, Ort oder PLZ wird anders geschrieben", "'.$this->app->User->GetName().'")');
	  }
          else
	    $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","'.$UstStatus['ERROR_CODE'].'('.$msg.')", "'.$this->app->User->GetName().'")');

        } else if($UstStatus==1){

          //$this->app->Tpl->Set(STATUS,"<div style=\"background-color: green;\">Vollst&auml;ndig</div>");
	  $result = 1;

          // jetzt brief bestellen! 
          $UstStatus = $this->app->erp->CheckUst("DE263136143", $ust, $firmenname, $ort, $strasse, $plz, $druck="ja");
          $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","Online-Abfrage OK + Brief bestellt", "'.$this->app->User->GetName().'")');
          $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(), status="erfolgreich" WHERE id='.$ustprf_id.'');
      } else {
          $this->app->DB->Insert('INSERT INTO ustprf_protokoll (ustprf_id, zeit, bemerkung, bearbeiter)  VALUES ('.$ustprf_id.',"'.date("Y-m-d H:i:s").'","'.$UstStatus.'", "'.$this->app->User->GetName().'")');
          $this->app->DB->Update('UPDATE ustprf SET datum_online=NOW(), status="allgemeiner fehler" WHERE id='.$ustprf_id.'');
      }
    }


    return $result;
  }




  function LagerEinlagerVomZwischenlager($zwischenlagerid,$menge,$regal,$projekt)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
    $referenz  = $this->app->DB->Select("SELECT grund FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
    $vpe = $this->app->DB->Select("SELECT vpe FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
    $bestellung = $this->app->DB->Select("SELECT parameter FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");

    //if($zwischenlager=="" || $zwischenlagerid==0)
    //  return;

    // Bewegung
    $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz, artikel, menge,vpe, eingang,zeit,referenz, bearbeiter,projekt,firma,logdatei)
    VALUES('','$regal','$artikel','$menge','$vpe','1',NOW(),'$referenz','".$this->app->User->GetName()."','$projekt','".$this->app->User->GetFirma()."',NOW())");

    // inhalt buchen
    $this->app->DB->Insert("INSERT INTO lager_platz_inhalt (id,lager_platz,artikel,menge,vpe,bearbeiter,bestellung,projekt,firma,logdatei)
      VALUES ('','$regal','$artikel','$menge','$vpe','".$this->app->User->GetName()."','$bestellung','$projekt','".$this->app->User->GetFirma()."',NOW())");

    //zwischen lager entfernen
    // menge abziehen
    $menge_db = $this->app->DB->Select("SELECT menge FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
    if($menge_db - $menge > 0)
    {
      $tmp = $menge_db - $menge;
      $this->app->DB->Update("UPDATE zwischenlager SET menge='$tmp' WHERE id='$zwischenlagerid' LIMIT 1");
    } else {
      $this->app->DB->Update("DELETE FROM zwischenlager WHERE id='$zwischenlagerid' LIMIT 1");
    } 


     // wenn standardlager leer vom dem artikel buchen!! 
     $lagerplatz = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel' LIMIT 1"); 
     if($lagerplatz=="" || $lagerplatz==0) 
       $this->app->DB->Update("UPDATE artikel SET lager_platz='$regal' WHERE id='$artikel' LIMIT 1");
  }


  function Auslagern($artikel,$regal,$projekt)
  {
    // in das zwischenlager mit dem grund 

  }


  function LagerEinlagernDifferenz($artikel,$menge,$regal,$projekt)
  {

    $referenz  = "Differenz";
    $vpe = 'einzeln'; //TODO

    // Bewegung
    $this->app->DB->Insert("INSERT INTO lager_bewegung (id,lager_platz, artikel, menge,vpe, eingang,zeit,referenz, bearbeiter,projekt,firma,logdatei)
    VALUES('','$regal','$artikel','$menge','$vpe','1',NOW(),'$referenz','".$this->app->User->GetName()."','$projekt','".$this->app->User->GetFirma()."',NOW())");

    // inhalt buchen
    $this->app->DB->Insert("INSERT INTO lager_platz_inhalt (id,lager_platz,artikel,menge,vpe,bearbeiter,bestellung,projekt,firma,logdatei)
      VALUES ('','$regal','$artikel','$menge','$vpe','".$this->app->User->GetName()."','','$projekt','".$this->app->User->GetFirma()."',NOW())");

     // wenn standardlager leer vom dem artikel buchen!! 
     $lagerplatz = $this->app->DB->Select("SELECT lager_platz FROM artikel WHERE id='$artikel' LIMIT 1"); 
     if($lagerplatz=="" || $lagerplatz==0) 
       $this->app->DB->Update("UPDATE artikel SET lager_platz='$regal' WHERE id='$artikel' LIMIT 1");

  }


  // pruefe ob es artikel noch im lager gibt bzw. ob es eine reservierung gibt
  function LagerCheck($adresse,$artikel,$menge)
  {
    $summe_im_lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel'");

    //$artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND datum>=NOW() AND objekt!='lieferschein'");
    $artikel_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND datum>=NOW()");
    
    $artikel_fuer_adresse_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE artikel='".$artikel."' AND menge >='$menge' AND adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");

    //echo "im Lager: $summe_im_lager reservier: $artikel_reserviert reseveiert fuer adresse: $artikel_fuer_adresse_reserviert";

    if($artikel_fuer_adresse_reserviert>0)
      return 1;

    if(($summe_im_lager - $artikel_reserviert) >= $menge)
    {
      return 1;
    }
    else { return 0; }
  }

  function AngebotSuche($parsetarget)
  {
    $treffer = $this->app->Secure->GetPOST("treffer");
    if($treffer > 0 ) {
      $_SESSION[angebottreffer] = $treffer;
      $_SESSION[page] = 1;
    }
    else
      if($_SESSION[angebottreffer] <= 0)
        $_SESSION[angebottreffer] = 10;

    $this->app->Tpl->Set(TREFFER,$_SESSION[angebottreffer]);

    
    $suchwort= $this->app->Secure->GetPOST("suchwort");
    $name= $this->app->Secure->GetPOST("name");
    $plz= $this->app->Secure->GetPOST("plz");
    $angebot= $this->app->Secure->GetPOST("angebot");
    $kundennummer= $this->app->Secure->GetPOST("kundennummer");

    $_SESSION[angebotsuchwort]=$suchwort; //$this->app->Tpl->Set(SUCHWORT,$_SESSION[angebotsuchwort]);
    $_SESSION[angebotname]=$name; $this->app->Tpl->Set(NAME,$_SESSION[angebotname]);
    $_SESSION[angebotplz]=$plz; $this->app->Tpl->Set(PLZ,$_SESSION[angebotplz]); 
    $_SESSION[angebotangebot]=$angebot; $this->app->Tpl->Set(ANGEBOT,$_SESSION[angebotangebot]);
    $_SESSION[angebotkundennummer]=$kundennummer; $this->app->Tpl->Set(KUNDENNUMMER,$_SESSION[angebotkundennummer]);
    
    $suche = $this->app->Secure->GetPOST("suche");

    //$this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");

    if(($_SESSION[angebotsuchwort]!="" || $_SESSION[angebotname]!="" || $_SESSION[angebotplz]!="" || $_SESSION[angebotangebot]!="" || $_SESSION[angebotkundennummer]!="") && $suche!=""){

       //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
if($suchwort!="")
  {
return "SELECT DATE_FORMAT(a.datum,'%d.%m.%y') as vom, if(a.belegnr,a.belegnr,'ohne Nummer') as Angebot, ad.kundennummer as kunde, a.name, p.abkuerzung as projekt, a.status, a.id
      FROM angebot a, projekt p, adresse ad WHERE
        (a.plz LIKE '%$suchwort%' OR a.name LIKE '%$suchwort%' OR a.belegnr LIKE '%$suchwort%') 
      AND p.id=a.projekt AND a.adresse=ad.id
      order by a.datum DESC, a.id DESC";
} else {
return "SELECT DATE_FORMAT(a.datum,'%d.%m.%y') as vom, if(a.belegnr,a.belegnr,'ohne Nummer') as Angebot, ad.kundennummer as kunde, a.name, p.abkuerzung as projekt, a.status, a.id
      FROM angebot a, projekt p, adresse ad WHERE 
        (ad.kundennummer LIKE '%{$_SESSION[angebotkundennummer]}%' AND a.plz LIKE '%{$_SESSION[angebotplz]}%' 
    AND a.name LIKE '%{$_SESSION[angebotname]}%' AND a.belegnr LIKE '%{$_SESSION[angebotangebot]}%' ) 
      AND p.id=a.projekt AND a.adresse=ad.id
      order by a.datum DESC, a.id DESC";

}

/*
       return ("SELECT DISTINCT a.nummer, a.name_de as Artikel, p.abkuerzung, a.id FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE 
          a.name_de LIKE '%$name%' AND
          a.nummer LIKE '$nummer%'AND
          p.abkuerzung LIKE '%$projekt%'
          AND geloescht='0'
          ORDER by a.id DESC");
*/
//	SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
//      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Kunde' ORDER by a.id DESC

    } else {

	return "SELECT DATE_FORMAT(a.datum,'%d.%m.%y') as vom, if(a.belegnr,a.belegnr,'ohne Nummer') as Angebot, ad.kundennummer as kunde, a.name, p.abkuerzung as projekt, a.status, a.id
      FROM angebot a, projekt p, adresse ad WHERE p.id=a.projekt AND a.adresse=ad.id order by a.datum DESC, a.id DESC";

    }
    //$this->app->Tpl->Set(INHALT,"");
  }



  function WebmailSuche($parsetarget,$rolle)
  {
    $suche = $this->app->Secure->GetPOST("suche");

    $name = $this->app->Secure->GetPOST("name"); $this->app->Tpl->Set(SUCHENAME,$name);
    $nummer = $this->app->Secure->GetPOST("nummer"); $this->app->Tpl->Set(SUCHENUMMER,$nummer);
    $typ = $this->app->Secure->GetPOST("typ");

    $this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");

    $projekt = $this->app->Secure->GetPOST("projekt");  $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);
    $limit = $this->app->Secure->GetPOST("limit"); if($limit=="" || $limit ==0) $limit=10; $this->app->Tpl->Set(SUCHELIMIT,$limit);

    if($name!="" && $suche!="")
    {
      $_SESSION[name_webmailsuche] = $name;
    } elseif ($suche!="" && $name=="")
      $_SESSION[name_webmailsuche] = "";

    if($name=="" && $suche!="")
    {
      $_SESSION[name_artikel] = $name;
    } 

    $_SESSION[nummer] = $nummer;
    $_SESSION[projekt] = $projekt;

    $adresse = $this->app->User->getAdresse();

    if($name==""){ $name = $_SESSION[name_webmailsuche];  $this->app->Tpl->Set(SUCHENAME,$name);}
    if($nummer==""){$nummer= $_SESSION[nummer]; $this->app->Tpl->Set(SUCHENUMMER,$nummer);}
    if($projekt==""){$projekt= $_SESSION[projekt]; $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);}

    if($name!="" || $nummer!="" || $projekt!="") $suche ="suche";


    $this->app->Tpl->Parse($parsetarget,"webmailsuche.tpl");
    if(($name!="" || $nummer!="" || $projekt!="") && $suche!=""){


	return("SELECT DATE_FORMAT(e.empfang,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(e.subject,30),'...') as betreff, e.sender,e.id
            FROM     emailbackup_mails e
            WHERE    e.webmail IN (SELECT id FROM emailbackup WHERE emailbackup.adresse = '$adresse') 
	      AND e.sender LIKE '%$name%' AND
          e.subject LIKE '$nummer%'
	    ORDER BY e.empfang DESC");

          //p.abkuerzung LIKE '%$projekt%'

       //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
/*
       return("SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(tn.betreff,30),'...') as betreff, t.kunde, p.abkuerzung,
      tn.id FROM ticket_nachricht tn LEFT JOIN ticket t ON t.schluessel=tn.ticket LEFT JOIN projekt p ON p.id=t.projekt WHERE 
          t.kunde LIKE '%$name%' AND
          tn.betreff LIKE '$nummer%'AND
          p.abkuerzung LIKE '%$projekt%'
          ORDER by tn.zeit DESC");
*/
//	SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
//      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Kunde' ORDER by a.id DESC
    //       $table->Display(INHALT,"auftrag","kundeuebernehmen","In Auftrag einf&uuml;gen");
    } else {
	return "SELECT DATE_FORMAT(e.empfang,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(e.subject,30),'...') as betreff, e.sender,e.id
            FROM     emailbackup_mails e
            WHERE    webmail IN (SELECT id FROM emailbackup WHERE emailbackup.adresse = '$adresse')
            ORDER BY e.empfang DESC";

//	return "SELECT DATE_FORMAT(e.empfang,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(e.subject,30),'...') as betreff, e.sender, 
//      e.id FROM emailbackup_mails e WHERE 
 //     ORDER by e.empfang DESC";
    }



    //$this->app->Tpl->Set(INHALT,"");
  }


  function TicketArchivSuche($parsetarget,$rolle)
  {
    $suche = $this->app->Secure->GetPOST("suche");

    $name = $this->app->Secure->GetPOST("name"); $this->app->Tpl->Set(SUCHENAME,$name);
    $nummer = $this->app->Secure->GetPOST("nummer"); $this->app->Tpl->Set(SUCHENUMMER,$nummer);
    $typ = $this->app->Secure->GetPOST("typ");

    $this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");

    $projekt = $this->app->Secure->GetPOST("projekt");  $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);
    $limit = $this->app->Secure->GetPOST("limit"); if($limit=="" || $limit ==0) $limit=10; $this->app->Tpl->Set(SUCHELIMIT,$limit);

    if($name!="" && $suche!="")
    {
      $_SESSION[name_ticketarchiv] = $name;
    } elseif ($suche!="" && $name=="")
      $_SESSION[name_ticketarchiv] = "";


    if($name=="" && $suche!="")
    {
      $_SESSION[name_artikel] = $name;
    } 

    $_SESSION[nummer] = $nummer;
    $_SESSION[projekt] = $projekt;


    if($name==""){ $name = $_SESSION[name_ticketarchiv];  $this->app->Tpl->Set(SUCHENAME,$name);}
    if($nummer==""){$nummer= $_SESSION[nummer]; $this->app->Tpl->Set(SUCHENUMMER,$nummer);}
    if($projekt==""){$projekt= $_SESSION[projekt]; $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);}

    if($name!="" || $nummer!="" || $projekt!="") $suche ="suche";


    $this->app->Tpl->Parse($parsetarget,"ticketsuchearchiv.tpl");
    if(($name!="" || $nummer!="" || $projekt!="") && $suche!=""){


       //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
       return("SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(tn.betreff,30),'...') as betreff, t.kunde, p.abkuerzung,
      tn.id FROM ticket_nachricht tn LEFT JOIN ticket t ON t.schluessel=tn.ticket LEFT JOIN projekt p ON p.id=t.projekt WHERE 
          t.kunde LIKE '%$name%' AND
          tn.betreff LIKE '$nummer%'AND
          p.abkuerzung LIKE '%$projekt%'
          ORDER by tn.zeit DESC");

//	SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
//      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Kunde' ORDER by a.id DESC
    //       $table->Display(INHALT,"auftrag","kundeuebernehmen","In Auftrag einf&uuml;gen");
    } else {
	return "SELECT DATE_FORMAT(tn.zeit,'%d.%m.%Y %H:%i') as zeit,CONCAT(LEFT(tn.betreff,30),'...') as betreff, t.kunde, 
      tn.id FROM ticket as t, ticket_nachricht as tn WHERE t.schluessel=tn.ticket AND tn.status='beantwortet' AND t.zugewiesen=1 
      AND inbearbeitung!='1'
      ORDER by tn.zeitausgang DESC";
    }



    //$this->app->Tpl->Set(INHALT,"");
  }

  function ArtikelSuche($parsetarget,$rolle)
  {
    $suche = $this->app->Secure->GetPOST("suche");
    $suchwort= $this->app->Secure->GetPOST("suchwort");
      /* Auftrage fuer manuelle freigabe */

    $name = $this->app->Secure->GetPOST("name"); $this->app->Tpl->Set(SUCHENAME,$name);
    $nummer = $this->app->Secure->GetPOST("nummer"); $this->app->Tpl->Set(SUCHENUMMER,$nummer);
    $typ = $this->app->Secure->GetPOST("typ");

    $this->app->YUI->AutoComplete(PROJEKTAUTO,"projekt",array('name','abkuerzung'),"abkuerzung");

    $projekt = $this->app->Secure->GetPOST("projekt");  $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);
    $limit = $this->app->Secure->GetPOST("limit"); if($limit=="" || $limit ==0) $limit=10; $this->app->Tpl->Set(SUCHELIMIT,$limit);

    if($name!="" && $suche!="")
    {
      $_SESSION[name_artikel] = $name;
    } elseif ($suche!="" && $name=="")
      $_SESSION[name_artikel] = "";


    if($name=="" && $suche!="")
    {
      $_SESSION[name_artikel] = $name;
    } 

    $_SESSION[nummer] = $nummer;
    $_SESSION[projekt] = $projekt;


    if($name==""){ $name = $_SESSION[name_artikel];  $this->app->Tpl->Set(SUCHENAME,$name);}
    if($nummer==""){$nummer= $_SESSION[nummer]; $this->app->Tpl->Set(SUCHENUMMER,$nummer);}
    if($projekt==""){$projekt= $_SESSION[projekt]; $this->app->Tpl->Set(SUCHEPROJEKT,$projekt);}

    if($name!="" || $nummer!="" || $projekt!="") $suche ="suche";


    $this->app->Tpl->Parse($parsetarget,"artikelsuche.tpl");
    if(($name!="" || $nummer!="" || $projekt!="" || $suchwort!="") && $suche!=""){
if($suchwort!="")
  {

       return ("SELECT DISTINCT a.nummer, a.name_de as Artikel, p.abkuerzung, a.id FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE 
          (a.name_de LIKE '%$suchwort%' OR
          a.nummer LIKE '%$suchwort%') 
          AND geloescht='0'
          ORDER by a.id DESC");

} else {
       return ("SELECT DISTINCT a.nummer, a.name_de as Artikel, p.abkuerzung, a.id FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE 
          a.name_de LIKE '%$name%' AND
          a.nummer LIKE '%$nummer%' AND
          p.abkuerzung LIKE '%$projekt%'
          AND a.geloescht='0'
          ORDER by a.id DESC");
}

       //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");

//	SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
//      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Kunde' ORDER by a.id DESC
    //       $table->Display(INHALT,"auftrag","kundeuebernehmen","In Auftrag einf&uuml;gen");
    } else {

	return "SELECT DISTINCT a.nummer, a.name_de as Artikel, p.abkuerzung, a.id FROM artikel a LEFT JOIN projekt p ON p.id=a.projekt WHERE a.geloescht='0'
	  ORDER by a.id DESC";

    }
    //$this->app->Tpl->Set(INHALT,"");
  }

  function AdressSuche($parsetarget,$rolle)
  {
    $suche = $this->app->Secure->GetPOST("suche");
      /* Auftrage fuer manuelle freigabe */
    if($rolle!="")
      $this->app->Tpl->Set(SUBHEADING,"$rolle suchen");
    else
      $this->app->Tpl->Set(SUBHEADING,"Adresse suchen");

    $name = $this->app->Secure->GetPOST("name"); $this->app->Tpl->Set(SUCHENAME,$name);
    $typ = $this->app->Secure->GetPOST("typ");
    $ansprechpartner = $this->app->Secure->GetPOST("ansprechpartner");  $this->app->Tpl->Set(SUCHEANSPRECHPARTNER,$ansprechpartner);
    $abteilung= $this->app->Secure->GetPOST("abteilung");
    $unterabteilung= $this->app->Secure->GetPOST("unterabteilung");
    $adresszusatz= $this->app->Secure->GetPOST("adresszusatz");
    $email= $this->app->Secure->GetPOST("email");
    $telefon= $this->app->Secure->GetPOST("telefon");
    $telefax= $this->app->Secure->GetPOST("telefax");
    $ustid= $this->app->Secure->GetPOST("ustid");
    $land= $this->app->Secure->GetPOST("land");
    $plz= $this->app->Secure->GetPOST("plz");  $this->app->Tpl->Set(SUCHEPLZ,$plz);
    $ort= $this->app->Secure->GetPOST("ort");  $this->app->Tpl->Set(SUCHEORT,$ort);
    $strasse= $this->app->Secure->GetPOST("strasse");  $this->app->Tpl->Set(SUCHESTRASSE,$strasse);
    $kundennummer= $this->app->Secure->GetPOST("kundennummer");  $this->app->Tpl->Set(KUNDENNUMMER,$kundennummer);

    if($name!="" && $suche!="")
    {
      $_SESSION[name] = $name;
    } elseif ($suche!="" && $name=="")
      $_SESSION[name] = "";


    if($name=="" && $suche!="")
    {
      $_SESSION[name] = $name;
    } 

    $_SESSION[ort] = $ort;
    $_SESSION[plz] = $plz;


    if($name==""){ $name = $_SESSION[name];  $this->app->Tpl->Set(SUCHENAME,$name);}
    if($ort==""){$ort= $_SESSION[ort]; $this->app->Tpl->Set(SUCHEORT,$ort);}
    if($plz==""){$plz= $_SESSION[plz]; $this->app->Tpl->Set(SUCHEPLZ,$plz);}

    if($name!="" || $ort!="" || $plz!="") $suche ="suche";

    $this->app->Tpl->Parse($parsetarget,"kundensuche.tpl");

    if(($name!="" || $kundennummer!="" || $strasse!="" || $ort!="" || $plz!="") && $suche!=""){
       //Jeder der in Nachbesserung war egal ob auto oder manuell wandert anschliessend in Manuelle-Freigabe");
       return ("SELECT DISTINCT a.kundennummer, a.name, a.ort, a.telefon, a.email, a.id FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE 
          a.name LIKE '%$name%' AND 
          a.ansprechpartner LIKE '%$ansprechpartner%' AND 
          a.ort LIKE '%$ort%' AND 
          a.strasse LIKE '%$strasse%' AND 
          a.kundennummer LIKE '%$kundennummer%' AND 
          a.plz LIKE '%$plz%' AND a.geloescht=0 ORDER by a.id DESC");
          //a.plz LIKE '%$plz%' AND r.subjekt='$rolle' ORDER by a.id DESC");

//	SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
//      FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='Kunde' ORDER by a.id DESC
    //       $table->Display(INHALT,"auftrag","kundeuebernehmen","In Auftrag einf&uuml;gen");
    } else {

	return "SELECT DISTINCT a.name, a.ort, a.telefon, a.email, a.id
	FROM adresse a WHERE a.geloescht=0 ORDER by a.name ASC";
	//FROM adresse a LEFT JOIN adresse_rolle r ON a.id=r.adresse WHERE r.subjekt='$rolle' ORDER by a.id DESC";

    }
    //$this->app->Tpl->Set(INHALT,"");
  }

	function string2array ($string, $template){
  #search defined dividers
  preg_match_all ("|%(.+)%|U", $template, $template_matches);
  #replace dividers with "real dividers"
  $template = preg_replace ("|%(.+)%|U", "(.+)", $template);
  #search matches
  preg_match ("|" . $template . "|", $string, $string_matches);
  #[template_match] => $string_match
  foreach ($template_matches[1] as $key => $value){
     $output[$value] = $string_matches[($key + 1)];
  }
  return $output;
}


  function ImportKontoauszug($cvs,$konto)
  {
    //array vorbereiten
    $type = $this->app->DB->Select("SELECT type FROM konten WHERE id='$konto' LIMIT 1");
    $erstezeile = $this->app->DB->Select("SELECT erstezeile FROM konten WHERE id='$konto' LIMIT 1");


		// group all imports
		$stamp = time();

    switch($type)
    {
      case "deutschebank":
	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!
	if($erstezeile != utf8_encode($db_array[0]))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Deutsche Bank Homepage!</div>");
	  break;
	}  

	$doppelte = 0;
	$erfolgreiche = 0; 
	for($i=5;$i<count($db_array)-2;$i++)
	{
	  $zeile = $db_array[$i];
	  $datensatz = split(';',$zeile);
	 
	  $buchung = $this->app->String->Convert($datensatz[0],"%1.%2.%3","%3-%2-%1"); 
	  $vorgang = mysql_real_escape_string(str_replace('"','',$datensatz[2]));
	  $soll = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[3])));
	  $haben = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[4])));
	  $waehrung = $datensatz[5];
	  $gebuehr = 0;
	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo $buchung." ".$vorgang."<br>";
	    //echo "datensatz gibt schon";
	    $doppelte++;
	  } else {
  		$this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");


	    $erfolgreiche++;
	  }
	}
      break;
    case "vrbank":



	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!
	if($erstezeile != utf8_encode($db_array[0]))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der VR Net Bank Homepage!</div>");
	  break;
	}  

	$cvs = str_replace('"','',$cvs);
	$tmp = str_getcsv( $cvs, ';','');

	$i=33;
	$doppelte = 0;
	$erfolgreiche = 0; 

	while($i<count($tmp)-19) // ohne letzte beiden zeilen
	{
		if($i>33)
		{
			$buchung = $this->app->String->Convert(substr($tmp[$i],-10),"%1.%2.%3","%3-%2-%1");
			$haben_erkennung=substr($tmp[$i+9],0,-11);
		}
		else
		{
//	echo $tmp[$i];
			$buchung = $this->app->String->Convert($tmp[$i],"%1.%2.%3","%3-%2-%1");
			$haben_erkennung=str_replace('"','',substr($tmp[$i+9],0,-11));
		}
		if(trim($haben_erkennung)=="H")
		{
			$haben = str_replace('"','',$tmp[$i+8]);
			$soll = 0;
		} else {
			$soll = str_replace('"','',$tmp[$i+8]);
			$haben = 0;
		}

//echo "<br>HH".$buchung." ".$haben_erkennung." $haben $soll<br><br>";

		// zaehle 10 felder
		
//		echo str_replace('"','',$tmp[$i]);
//echo "<br>HH".$buchung."<br>";
		$vorgang = mysql_real_escape_string(utf8_encode($tmp[$i+6]));

//		$vorgang ="";

		$haben = str_replace(',','.',str_replace('.','',$haben));
		$soll = str_replace(',','.',str_replace('.','',$soll));
		$waehrung = 'EUR';
	  $gebuehr = 0;


		$i=$i+9;

	//"Buchungstag";"Valuta";"Auftraggeber/Zahlungsempfänger";"Empfänger/Zahlungspflichtiger";"Konto-Nr.";"BLZ";"Vorgang/Verwendungszweck";"Währung";"Umsatz";" "
	 	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo $buchung." ".$vorgang."<br>";
	    //echo "datensatz gibt schon";
	    $doppelte++;
	  } else {
		  $this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");


	    $erfolgreiche++;
	  }
	}
      break;
  case "postbank_201205":
  $db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);
  //pruefen ob es eine korrekte datei ist sonst abbrechen!!!

  if($erstezeile != utf8_encode($db_array[0]))
  {
    $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Post Bank Homepage!</div>");
    break;
  } 

  $doppelte = 0;
  $erfolgreiche = 0;
  //for($i=11;$i<count($db_array)-1;$i++) // vor dem 28.01 war es immer an pos 11 aber dann ab 10 warum auch immer
  for($i=10;$i<count($db_array)-1;$i++)
  {
    $zeile = $db_array[$i];
    $datensatz = split("\t",$zeile);

    $buchung = $this->app->String->Convert($datensatz[0],"%1.%2.%3","%3-%2-%1");
    $vorgang = mysql_real_escape_string(utf8_encode($datensatz[2]." ".$datensatz[3]." ".$datensatz[4]));

    // wenn minus aus soll sonst haben
    if(preg_match("/-/",$datensatz[6]))
    {
      $soll = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[6])));
      $haben = 0;
    }
    else {
      $soll = 0;
      $haben = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[6])));
    }

    $waehrung = 'EUR';
    $gebuehr = 0;

    $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

    $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

    if($check > 0)
    {
      //echo $buchung." ".$vorgang."<br>";
      //echo "datensatz gibt schon";
      $doppelte++;
    } else {
			$this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");


      $erfolgreiche++;
    }
  }
      break;

      case "postbank":
	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!


	if(utf8_decode($erstezeile) != ($db_array[0]))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Post Bank Homepage!</div>");
	  break;
	}  

	$doppelte = 0;
	$erfolgreiche = 0; 
        //$cvs = str_replace('"','',$cvs);
/*
*/
//        $tmp = str_getcsv( $cvs, ';','');

	//for($i=11;$i<count($db_array)-1;$i++) // vor dem 28.01 war es immer an pos 11 aber dann ab 10 warum auch immer
	for($i=8;$i<count($db_array)-1;$i++)
	{
	  $zeile = $db_array[$i];
          $zeile = str_replace('"','',$zeile);
	  $datensatz = split(";",$zeile);

	  $buchung = $this->app->String->Convert($datensatz[0],"%1.%2.%3","%3-%2-%1"); 
	  $vorgang = mysql_real_escape_string(utf8_encode(trim($datensatz[2])." ".trim($datensatz[3])." ".trim($datensatz[4])));

	  // wenn minus aus soll sonst haben
	  if(preg_match("/-/",$datensatz[6]))
	  {
	    $soll = substr(str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[6]))),0,-2);
	    $haben = 0;
	  }
	  else {
	    $soll = 0;
	    $haben = substr(str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[6]))),0,-2);
	  }

	  $waehrung = 'EUR';
	  $gebuehr = 0;
	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo "datensatz gibt schon<br>";
	    //echo $buchung." ".$vorgang."<br>";
	    $doppelte++;
	  } else {
	    //echo $buchung." ".$vorgang."<br>";
			$this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");


	    $erfolgreiche++;
	  }
	}
      break;
      case "paypal":
	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!

	if($erstezeile != utf8_encode(substr($db_array[0],0,strlen($erstezeile))))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Post Bank Homepage!</div>");
	  break;
	}  

	$doppelte = 0;
	$erfolgreiche = 0; 
	for($i=1;$i<count($db_array)-1;$i++)
	{
	  $zeile = $db_array[$i];
	  
	  $datensatz = split('","',$zeile);
	  $buchung = $this->app->String->Convert($datensatz[0],"%1.%2.%3","%3-%2-%1"); 
	  //$vorgang = utf8_encode($datensatz[3]." ".$datensatz[16]." ".$datensatz[13]); //eigentlich neu
	  $vorgang = mysql_real_escape_string(utf8_encode($datensatz[3]." ".$datensatz[15]." ".$datensatz[12])); // altes format


	  // wenn minus aus soll sonst haben
	  if(preg_match("/-/",$datensatz[7]))
	  {
	    $soll = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[7])));
	    $haben = 0;
	  }
	  else {
	    $soll = 0;
	    $haben = str_replace(',','.',str_replace('.','',str_replace('-','',$datensatz[7])));
	  }

	  $waehrung = $datensatz[6];
	  $gebuehr = str_replace(',','.',str_replace('.','',$datensatz[8]));
	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo $buchung." ".$vorgang."<br>";
	    //echo "datensatz gibt schon";
	    $doppelte++;
	  } else {
			$this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");


	    $erfolgreiche++;
	  }
	}
      break;
      case "kreditkarte":
	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!

	if($erstezeile != utf8_encode(substr($db_array[0],0,strlen($erstezeile))))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Post Bank Homepage!</div>");
	  break;
	}  

	$doppelte = 0;
	$erfolgreiche = 0; 
	for($i=1;$i<count($db_array)-1;$i++)
	{
	  $zeile = $db_array[$i];
	  
	  $datensatz = split('","',$zeile);
	  //2010-02-22 15:19:13
	  $buchung = $this->app->String->Convert($datensatz[0],"%1-%2-%3 %4:%5:%6","%1-%2-%3");
	  $buchung = str_replace('"','',$buchung);
	  //$vorgang = utf8_decode($datensatz[7]." ".$datensatz[8]." ".$datensatz[1]." ".$datensatz[31]);
	  $vorgang = mysql_real_escape_string(utf8_decode($datensatz[7]." ".$datensatz[8]." ".$datensatz[1]));

	  // wenn minus aus soll sonst haben
	  if($datensatz[5]=="REFUND_CAP")
	  {
	    $soll = str_replace(',','',str_replace('-','',$datensatz[2]));
	    $haben = 0;
	  }
	  else {
	    $soll = 0;
	    $haben = str_replace(',','',str_replace('-','',$datensatz[2]));
	  }


	  $waehrung = $datensatz[3];
	  $gebuehr = 0;
	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo $buchung." ".$vorgang."<br>";
	    //echo $buchung." ".$pruefsumme."<br>";
	    //echo "datensatz gibt schon";
	    $doppelte++;
	  } else {
 			$this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
        VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");

	    $erfolgreiche++;
	  }
	}
      break;
      case "kasse":
	$db_array = preg_split("/(\r\n)+|(\n|\r)+/",$cvs);     
	//pruefen ob es eine korrekte datei ist sonst abbrechen!!!

	if($erstezeile != utf8_encode(substr($db_array[0],0,strlen($erstezeile))))
	{
	  $this->app->Tpl->Set(ERROR,"<div class=\"error\">Die Datei ist keine korrekter CVS von der Post Bank Homepage!</div>");
	  break;
	}  

	$doppelte = 0;
	$erfolgreiche = 0; 
	for($i=1;$i<count($db_array)-1;$i++)
	{
	  $zeile = $db_array[$i];
	  
	  $datensatz = split('","',$zeile);
	  $buchung = $datensatz[0];
	  $buchung = str_replace('"','',$buchung);
	  $vorgang = mysql_real_escape_string(utf8_encode($datensatz[1]));


	  if($datensatz[2]=="einnahme")
	  {
	    $haben = $datensatz[3];
	    $soll="";
	  }
	  else
	  {
	    $soll = $datensatz[3];
	    $haben="";
	  }

	  $waehrung = $datensatz[4];
	  $waehrung= str_replace('"','',$waehrung);
	  $gebuehr = 0; //str_replace(',','.',str_replace('.','',$datensatz[8]));
	  
	  $pruefsumme = md5(serialize(array($buchung,$vorgang,$soll,$haben,$waehrung)));

	  $check = $this->app->DB->Select("SELECT id FROM kontoauszuege WHERE buchung='$buchung' AND konto='$konto' AND pruefsumme='$pruefsumme' LIMIT 1");

	  if($check > 0)  
	  {
	    //echo $buchung." ".$vorgang."<br>";
	    //echo "datensatz gibt schon";
	    $doppelte++;
	  } else {
	    $this->app->DB->Insert("INSERT INTO kontoauszuege (id,konto,buchung,vorgang,soll,haben,gebuehr,waehrung,fertig,bearbeiter,pruefsumme,importgroup)
	      VALUE ('','$konto','$buchung','$vorgang','$soll','$haben','$gebuehr','$waehrung',0,'".$this->app->User->GetName()."','$pruefsumme','$stamp')");
	    $erfolgreiche++;
	  }
	}
      break;




      default:;
    }

    if($doppelte>0)$this->app->Tpl->Set(ERROR,"<div class=\"error\">$doppelte Eintr&auml;ge wurden nicht importiert da sie bereits vorhanden waren!</div>");
    if($erfolgreiche>0)$this->app->Tpl->Add(ERROR,"<div class=\"info\">$erfolgreiche Eintr&auml;ge importiert.</div>");
  }

	function SelectLaenderliste($selected="")
  {
    if($selected=="") $selected="DE";

    $laender = array(
    //'Afghanistan'  => 'AF',
    //'&Auml;gypten'  => 'EG',
    //'Albanien'  => 'AL',
    //'Algerien'  => 'DZ',
    //'Andorra'  => 'AD',
    //'Angola'  => 'AO',
    //'Anguilla'  => 'AI',
    //'Antarktis'  => 'AQ',
    //'Antigua und Barbuda'  => 'AG',
    //'&Auml;quatorial Guinea'  => 'GQ',
    //'Argentinien'  => 'AR',
    //'Armenien'  => 'AM',
    //'Aruba'  => 'AW',
    //'Aserbaidschan'  => 'AZ',
    //'&Auml;thiopien'  => 'ET',
    //'Australien'  => 'AU',
    //'Bahamas'  => 'BS',
    //'Bahrain'  => 'BH',
    //'Bangladesh'  => 'BD',
    //'Barbados'  => 'BB',
    'Belgien'  => 'BE',
    //'Belize'  => 'BZ',
    //'Benin'  => 'BJ',
    //'Bermudas'  => 'BM',
    //'Bhutan'  => 'BT',
    //'Birma'  => 'MM',
    //'Bolivien'  => 'BO',
    //'Bosnien-Herzegowina'  => 'BA',
    //'Botswana'  => 'BW',
    //'Bouvet Inseln'  => 'BV',
    //'Brasilien'  => 'BR',
    //'Britisch-Indischer Ozean'  => 'IO',
    //'Brunei'  => 'BN',
    'Bulgarien'  => 'BG',
    //'Burkina Faso'  => 'BF',
    //'Burundi'  => 'BI',
    //'Chile'  => 'CL',
    //'China'  => 'CN',
    //'Christmas Island'  => 'CX',
    //'Cook Inseln'  => 'CK',
    //'Costa Rica'  => 'CR',
    'D&auml;nemark'  => 'DK',
    'Deutschland'  => 'DE',
    //'Djibuti'  => 'DJ',
    //'Dominika'  => 'DM',
    //'Dominikanische Republik'  => 'DO',
    //'Ecuador'  => 'EC',
    //'El Salvador'  => 'SV',
    //'Elfenbeink&uuml;ste'  => 'CI',
    //'Eritrea'  => 'ER',
    'Estland'  => 'EE',
    //'Falkland Inseln'  => 'FK',
    //'F&auml;r&ouml;er Inseln'  => 'FO',
    //'Fidschi'  => 'FJ',
    'Finnland'  => 'FI',
    'Frankreich'  => 'FR',
    //'Franz&ouml;sisch Guyana'  => 'GF',
    //'Franz&ouml;sisch Polynesien'  => 'PF',
    //'Franz&ouml;sisches S&uuml;d-Territorium'  => 'TF',
    //'Gabun'  => 'GA',
    //'Gambia'  => 'GM',
    //'Georgien'  => 'GE',
    //'Ghana'  => 'GH',
    //'Gibraltar'  => 'GI',
    //'Grenada'  => 'GD',
    'Griechenland'  => 'GR',
    //'Gr&ouml;nland'  => 'GL',
    'GroÃritannien'  => 'UK',
    'GroÃritannien (UK)'  => 'GB',
    //'Guadeloupe'  => 'GP',
    //'Guam'  => 'GU',
    //'Guatemala'  => 'GT',
    //'Guinea'  => 'GN',
    //'Guinea Bissau'  => 'GW',
    //'Guyana'  => 'GY',
    //'Haiti'  => 'HT',
    //'Heard und McDonald Islands'  => 'HM',
    //'Honduras'  => 'HN',
    //'Hong Kong'  => 'HK',
    //'Indien'  => 'IN',
    //'Indonesien'  => 'ID',
    //'Irak'  => 'IQ',
    //'Iran'  => 'IR',
    'Irland'  => 'IE',
    //'Island'  => 'IS',
    //'Israel'  => 'IL',
    'Italien'  => 'IT',
    //'Jamaika'  => 'JM',
    //'Japan'  => 'JP',
    //'Jemen'  => 'YE',
    //'Jordanien'  => 'JO',
    //'Jugoslawien'  => 'YU',
    //'Kaiman Inseln'  => 'KY',
    //'Kambodscha'  => 'KH',
    //'Kamerun'  => 'CM',
    //'Kanada'  => 'CA',
    //'Kap Verde'  => 'CV',
    //'Kasachstan'  => 'KZ',
    //'Kenia'  => 'KE',
    //'Kirgisistan'  => 'KG',
    //'Kiribati'  => 'KI',
    //'Kokosinseln'  => 'CC',
    //'Kolumbien'  => 'CO',
    //'Komoren'  => 'KM',
    //'Kongo'  => 'CG',
    //'Kongo, Demokratische Republik'  => 'CD',
    //'Kroatien'  => 'HR',
    //'Kuba'  => 'CU',
    //'Kuwait'  => 'KW',
    //'Laos'  => 'LA',
    //'Lesotho'  => 'LS',
    'Lettland'  => 'LV',
    //'Libanon'  => 'LB',
    //'Liberia'  => 'LR',
    //'Libyen'  => 'LY',
    'Liechtenstein'  => 'LI',
    'Litauen'  => 'LT',
    'Luxemburg'  => 'LU',
    //'Macao'  => 'MO',
    //'Madagaskar'  => 'MG',
    //'Malawi'  => 'MW',
    //'Malaysia'  => 'MY',
    //'Malediven'  => 'MV',
    //'Mali'  => 'ML',
    'Malta'  => 'MT',
    //'Marianen'  => 'MP',
    //'Marokko'  => 'MA',
    //'Marshall Inseln'  => 'MH',
    //'Martinique'  => 'MQ',
    //'Mauretanien'  => 'MR',
    //'Mauritius'  => 'MU',
    //'Mayotte'  => 'YT',
    //'Mazedonien'  => 'MK',
    //'Mexiko'  => 'MX',
    //'Mikronesien'  => 'FM',
    //'Mocambique'  => 'MZ',
    //'Moldavien'  => 'MD',
    //'Monaco'  => 'MC',
    //'Mongolei'  => 'MN',
    //'Montserrat'  => 'MS',
    //'Namibia'  => 'NA',
    //'Nauru'  => 'NR',
    //'Nepal'  => 'NP',
    //'Neukaledonien'  => 'NC',
    //'Neuseeland'  => 'NZ',
    //'Nicaragua'  => 'NI',
    'Niederlande'  => 'NL',
    //'Niederl&auml;ndische Antillen'  => 'AN',
    //'Niger'  => 'NE',
    //'Nigeria'  => 'NG',
    //'Niue'  => 'NU',
    //'Nord Korea'  => 'KP',
    //'Norfolk Inseln'  => 'NF',
    'Norwegen'  => 'NO',
    //'Oman'  => 'OM',
    '&Ouml;sterreich'  => 'AT',
    //'Pakistan'  => 'PK',
    //'Pal&auml;stina'  => 'PS',
    //'Palau'  => 'PW',
    //'Panama'  => 'PA',
    //'Papua Neuguinea'  => 'PG',
    //'Paraguay'  => 'PY',
    //'Peru'  => 'PE',
    //'Philippinen'  => 'PH',
    //'Pitcairn'  => 'PN',
    'Polen'  => 'PL',
    'Portugal'  => 'PT',
    //'Puerto Rico'  => 'PR',
    //'Qatar'  => 'QA',
    //'Reunion'  => 'RE',
    //'Ruanda'  => 'RW',
    'Rum&auml;nien'  => 'RO',
    //'Ru&szlig;land'  => 'RU',
    //'Saint Lucia'  => 'LC',
    //'Sambia'  => 'ZM',
    //'Samoa'  => 'AS',
    //'Samoa'  => 'WS',
    //'San Marino'  => 'SM',
    //'Sao Tome'  => 'ST',
    //'Saudi Arabien'  => 'SA',
    'Schweden'  => 'SE',
    'Schweiz'  => 'CH',
    //'Senegal'  => 'SN',
    //'Seychellen'  => 'SC',
    //'Sierra Leone'  => 'SL',
    //'Singapur'  => 'SG',
    'Slowakei'  => 'SK',
    'Slowenien'  => 'SI',
    //'Solomon Inseln'  => 'SB',
    //'Somalia'  => 'SO',
    //'South Georgia, South Sandwich Isl.'  => 'GS',
    'Spanien'  => 'ES',
    //'Sri Lanka'  => 'LK',
    //'St. Helena'  => 'SH',
    //'St. Kitts Nevis Anguilla'  => 'KN',
    //'St. Pierre und Miquelon'  => 'PM',
    //'St. Vincent'  => 'VC',
    //'S&uuml;d Korea'  => 'KR',
    //'S&uuml;dafrika'  => 'ZA',
    //'Sudan'  => 'SD',
    //'Surinam'  => 'SR',
    //'Svalbard und Jan Mayen Islands'  => 'SJ',
    //'Swasiland'  => 'SZ',
    //'Syrien'  => 'SY',
    //'Tadschikistan'  => 'TJ',
    //'Taiwan'  => 'TW',
    //'Tansania'  => 'TZ',
    //'Thailand'  => 'TH',
    //'Timor'  => 'TP',
    //'Togo'  => 'TG',
    //'Tokelau'  => 'TK',
    //'Tonga'  => 'TO',
    //'Trinidad Tobago'  => 'TT',
    //'Tschad'  => 'TD',
    'Tschechische Republik'  => 'CZ',
    //'Tunesien'  => 'TN',
    //'T&uuml;rkei'  => 'TR',
    //'Turkmenistan'  => 'TM',
    //'Turks und Kaikos Inseln'  => 'TC',
    //'Tuvalu'  => 'TV',
    //'Uganda'  => 'UG',
    //'Ukraine'  => 'UA',
    'Ungarn'  => 'HU',
    //'Uruguay'  => 'UY',
    //'Usbekistan'  => 'UZ',
    //'Vanuatu'  => 'VU',
    //'Vatikan'  => 'VA',
    //'Venezuela'  => 'VE',
    //'Vereinigte Arabische Emirate'  => 'AE',
    //'Vereinigte Staaten von Amerika'  => 'US',
    //'Vietnam'  => 'VN',
    //'Virgin Island (Brit.)'  => 'VG',
    //'Virgin Island (USA)'  => 'VI',
    //'Wallis et Futuna'  => 'WF',
    //'Wei&szlig;ru&szlig;land'  => 'BY',
    //'Westsahara'  => 'EH',
    //'Zentralafrikanische Republik'  => 'CF',
    //'Zimbabwe'  => 'ZW',
    'Zypern'  => 'CY'
    );

    foreach ($laender as $land => $kuerzel) {
      $options = $options."<option value=\"$kuerzel\"";
        if ($selected == $kuerzel) $options = $options." selected";
    $options = $options.">$land</option>\n";
    }
    return $options;
  }

  function GetSelectLaenderliste()
  {
    $laender = array(
    'Deutschland'  => 'DE',
    'Afghanistan'  => 'AF',
    '&Auml;gypten'  => 'EG',
    'Albanien'  => 'AL',
    'Algerien'  => 'DZ',
    'Andorra'  => 'AD',
    'Angola'  => 'AO',
    'Anguilla'  => 'AI',
    'Antarktis'  => 'AQ',
    'Antigua und Barbuda'  => 'AG',
    '&Auml;quatorial Guinea'  => 'GQ',
    'Argentinien'  => 'AR',
    'Armenien'  => 'AM',
    'Aruba'  => 'AW',
    'Aserbaidschan'  => 'AZ',
    '&Auml;thiopien'  => 'ET',
    'Australien'  => 'AU',
    'Bahamas'  => 'BS',
    'Bahrain'  => 'BH',
    'Bangladesh'  => 'BD',
    'Barbados'  => 'BB',
    'Belgien'  => 'BE',
    'Belize'  => 'BZ',
    'Benin'  => 'BJ',
    'Bermudas'  => 'BM',
    'Bhutan'  => 'BT',
    'Birma'  => 'MM',
    'Bolivien'  => 'BO',
    'Bosnien-Herzegowina'  => 'BA',
    'Botswana'  => 'BW',
    'Bouvet Inseln'  => 'BV',
    'Brasilien'  => 'BR',
    'Britisch-Indischer Ozean'  => 'IO',
    'Brunei'  => 'BN',
    'Bulgarien'  => 'BG',
    'Burkina Faso'  => 'BF',
    'Burundi'  => 'BI',
    'Chile'  => 'CL',
    'China'  => 'CN',
    'Christmas Island'  => 'CX',
    'Cook Inseln'  => 'CK',
    'Costa Rica'  => 'CR',
    'D&auml;nemark'  => 'DK',
    'Deutschland'  => 'DE',
    'Djibuti'  => 'DJ',
    'Dominika'  => 'DM',
    'Dominikanische Republik'  => 'DO',
    'Ecuador'  => 'EC',
    'El Salvador'  => 'SV',
    'Elfenbeink&uuml;ste'  => 'CI',
    'Eritrea'  => 'ER',
    'Estland'  => 'EE',
    'Falkland Inseln'  => 'FK',
    'F&auml;r&ouml;er Inseln'  => 'FO',
    'Fidschi'  => 'FJ',
    'Finnland'  => 'FI',
    'Frankreich'  => 'FR',
    'Franz&ouml;sisch Guyana'  => 'GF',
    'Franz&ouml;sisch Polynesien'  => 'PF',
    'Franz&ouml;sisches S&uuml;d-Territorium'  => 'TF',
    'Gabun'  => 'GA',
    'Gambia'  => 'GM',
    'Georgien'  => 'GE',
    'Ghana'  => 'GH',
    'Gibraltar'  => 'GI',
    'Grenada'  => 'GD',
    'Griechenland'  => 'GR',
    'Gr&ouml;nland'  => 'GL',
    'Großbritannien'  => 'UK',
    'Großbritannien (UK)'  => 'GB',
    'Guadeloupe'  => 'GP',
    'Guam'  => 'GU',
    'Guatemala'  => 'GT',
    'Guinea'  => 'GN',
    'Guinea Bissau'  => 'GW',
    'Guyana'  => 'GY',
    'Haiti'  => 'HT',
    'Heard und McDonald Islands'  => 'HM',
    'Honduras'  => 'HN',
    'Hong Kong'  => 'HK',
    'Indien'  => 'IN',
    'Indonesien'  => 'ID',
    'Irak'  => 'IQ',
    'Iran'  => 'IR',
    'Irland'  => 'IE',
    'Island'  => 'IS',
    'Israel'  => 'IL',
    'Italien'  => 'IT',
    'Jamaika'  => 'JM',
    'Japan'  => 'JP',
    'Jemen'  => 'YE',
    'Jordanien'  => 'JO',
    'Jugoslawien'  => 'YU',
    'Kaiman Inseln'  => 'KY',
    'Kambodscha'  => 'KH',
    'Kamerun'  => 'CM',
    'Kanada'  => 'CA',
    'Kap Verde'  => 'CV',
    'Kasachstan'  => 'KZ',
    'Kenia'  => 'KE',
    'Kirgisistan'  => 'KG',
    'Kiribati'  => 'KI',
    'Kokosinseln'  => 'CC',
    'Kolumbien'  => 'CO',
    'Komoren'  => 'KM',
    'Kongo'  => 'CG',
    'Kongo, Demokratische Republik'  => 'CD',
    'Kroatien'  => 'HR',
    'Kuba'  => 'CU',
    'Kuwait'  => 'KW',
    'Laos'  => 'LA',
    'Lesotho'  => 'LS',
    'Lettland'  => 'LV',
    'Libanon'  => 'LB',
    'Liberia'  => 'LR',
    'Libyen'  => 'LY',
    'Liechtenstein'  => 'LI',
    'Litauen'  => 'LT',
    'Luxemburg'  => 'LU',
    'Macao'  => 'MO',
    'Madagaskar'  => 'MG',
    'Malawi'  => 'MW',
    'Malaysia'  => 'MY',
    'Malediven'  => 'MV',
    'Mali'  => 'ML',
    'Malta'  => 'MT',
    'Marianen'  => 'MP',
    'Marokko'  => 'MA',
    'Marshall Inseln'  => 'MH',
    'Martinique'  => 'MQ',
    'Mauretanien'  => 'MR',
    'Mauritius'  => 'MU',
    'Mayotte'  => 'YT',
    'Mazedonien'  => 'MK',
    'Mexiko'  => 'MX',
    'Mikronesien'  => 'FM',
    'Mocambique'  => 'MZ',
    'Moldavien'  => 'MD',
    'Monaco'  => 'MC',
    'Mongolei'  => 'MN',
    'Montserrat'  => 'MS',
    'Namibia'  => 'NA',
    'Nauru'  => 'NR',
    'Nepal'  => 'NP',
    'Neukaledonien'  => 'NC',
    'Neuseeland'  => 'NZ',
    'Nicaragua'  => 'NI',
    'Niederlande'  => 'NL',
    'Niederl&auml;ndische Antillen'  => 'AN',
    'Niger'  => 'NE',
    'Nigeria'  => 'NG',
    'Niue'  => 'NU',
    'Nord Korea'  => 'KP',
    'Norfolk Inseln'  => 'NF',
    'Norwegen'  => 'NO',
    'Oman'  => 'OM',
    '&Ouml;sterreich'  => 'AT',
    'Pakistan'  => 'PK',
    'Pal&auml;stina'  => 'PS',
    'Palau'  => 'PW',
    'Panama'  => 'PA',
    'Papua Neuguinea'  => 'PG',
    'Paraguay'  => 'PY',
    'Peru'  => 'PE',
    'Philippinen'  => 'PH',
    'Pitcairn'  => 'PN',
    'Polen'  => 'PL',
    'Portugal'  => 'PT',
    'Puerto Rico'  => 'PR',
    'Qatar'  => 'QA',
    'Reunion'  => 'RE',
    'Ruanda'  => 'RW',
    'Rum&auml;nien'  => 'RO',
    'Ru&szlig;land'  => 'RU',
    'Saint Lucia'  => 'LC',
    'Sambia'  => 'ZM',
    'Samoa'  => 'AS',
    'Samoa'  => 'WS',
    'San Marino'  => 'SM',
    'Sao Tome'  => 'ST',
    'Saudi Arabien'  => 'SA',
    'Schweden'  => 'SE',
    'Schweiz'  => 'CH',
    'Senegal'  => 'SN',
    'Seychellen'  => 'SC',
    'Sierra Leone'  => 'SL',
    'Singapur'  => 'SG',
    'Slowakei -slowakische Republik-'  => 'SK',
    'Slowenien'  => 'SI',
    'Solomon Inseln'  => 'SB',
    'Somalia'  => 'SO',
    'South Georgia, South Sandwich Isl.'  => 'GS',
    'Spanien'  => 'ES',
    'Sri Lanka'  => 'LK',
    'St. Helena'  => 'SH',
    'St. Kitts Nevis Anguilla'  => 'KN',
    'St. Pierre und Miquelon'  => 'PM',
    'St. Vincent'  => 'VC',
    'S&uuml;d Korea'  => 'KR',
    'S&uuml;dafrika'  => 'ZA',
    'Sudan'  => 'SD',
    'Surinam'  => 'SR',
    'Svalbard und Jan Mayen Islands'  => 'SJ',
    'Swasiland'  => 'SZ',
    'Syrien'  => 'SY',
    'Tadschikistan'  => 'TJ',
    'Taiwan'  => 'TW',
    'Tansania'  => 'TZ',
    'Thailand'  => 'TH',
    'Timor'  => 'TP',
    'Togo'  => 'TG',
    'Tokelau'  => 'TK',
    'Tonga'  => 'TO',
    'Trinidad Tobago'  => 'TT',
    'Tschad'  => 'TD',
    'Tschechische Republik'  => 'CZ',
    'Tunesien'  => 'TN',
    'T&uuml;rkei'  => 'TR',
    'Turkmenistan'  => 'TM',
    'Turks und Kaikos Inseln'  => 'TC',
    'Tuvalu'  => 'TV',
    'Uganda'  => 'UG',
    'Ukraine'  => 'UA',
    'Ungarn'  => 'HU',
    'Uruguay'  => 'UY',
    'Usbekistan'  => 'UZ',
    'Vanuatu'  => 'VU',
    'Vatikan'  => 'VA',
    'Venezuela'  => 'VE',
    'Vereinigte Arabische Emirate'  => 'AE',
    'Vereinigte Staaten von Amerika'  => 'US',
    'Vietnam'  => 'VN',
    'Virgin Island (Brit.)'  => 'VG',
    'Virgin Island (USA)'  => 'VI',
    'Wallis et Futuna'  => 'WF',
    'Wei&szlig;ru&szlig;land'  => 'BY',
    'Westsahara'  => 'EH',
    'Zentralafrikanische Republik'  => 'CF',
    'Zimbabwe'  => 'ZW',
    'Zypern'  => 'CY'
    );

         $Values = array();
        while(list($Key,$Val) = each($laender))
        $Values[$Val] = $Key;

    return $Values;
  }

	function GetFirmaMail()
	{
		$email = $this->app->DB->Select("SELECT email FROM firmendaten WHERE firma='1' LIMIT 1");
		return $email;
	}

	function GetFirmaName()
	{
		$name = $this->app->DB->Select("SELECT name FROM firma WHERE id='1' LIMIT 1");
    return $name;
	}

  function GetSelectEmail($selected="")
  {
    $own = $this->app->User->GetEmail();
		$email_addr = $this->app->DB->SelectArr('SELECT email FROM firmendaten ORDER BY email');
		
		$emails = array();
    foreach($email_addr AS $mail)
      $emails[] = $mail['email'];

    if($own!='')
      $emails[] = $own;

    for($i=0;$i<count($emails);$i++)
    {
      if($emails[$i]==$selected) $mark="selected"; else $mark="";
	$tpl .="<option value=\"{$emails[$i]}\" $mark>{$emails[$i]}</option>";
    }
    return $tpl;
  }

  function GetSelectAnsprechpartner($adresse, $selected="")
  {
    $first = $this->app->DB->Select("SELECT CONCAT(ansprechpartner,' &lt;',email,'&gt;') FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $firstname = $this->app->DB->Select("SELECT ansprechpartner FROM adresse WHERE id='$adresse' LIMIT 1");
    if($firstname=="") $first = $this->app->DB->Select("SELECT CONCAT(name,' &lt;',email,'&gt;') FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

    $others = $this->app->DB->SelectArr("SELECT id, CONCAT(name,' (',bereich,')',' &lt;',email,'&gt;') as name FROM ansprechpartner WHERE adresse='$adresse'");

    $tpl ="<option value=\"0\">$first</option>";

    for($i=0;$i<count($others);$i++)
    {
      if($others[$i][id]==$selected) $mark="selected"; else $mark="";
	$tpl .="<option value=\"{$others[$i][id]}\" $mark>{$others[$i][name]}</option>";
    }
    return $tpl;
  }


  function GetSelectKonto($selected="")
  {

    $drucker = $this->app->DB->SelectArr("SELECT id,bezeichnung FROM konten WHERE firma='".$this->app->User->GetFirma()."'");
    for($i=0;$i<count($drucker);$i++)
    {
      if($drucker[$i][id]==$selected) $mark="selected"; else $mark="";
      $tpl .="<option value=\"{$drucker[$i][id]}\" $mark>{$drucker[$i][bezeichnung]}</option>";
    }
    return $tpl;
  }

  function GetSelectDrucker($selected="")
  {
    if($selected=="")
      $selected = $this->app->DB->Select("SELECT standarddrucker FROM user WHERE id='".$this->app->User->GetID()."' LIMIT 1");

    $drucker = $this->app->DB->SelectArr("SELECT id, name FROM  drucker WHERE firma='".$this->app->User->GetFirma()."' AND aktiv='1'");
		for($i=0;$i<count($drucker);$i++)
    {
      if($drucker[$i][id]==$selected) $mark="selected"; else $mark="";
      $tpl .="<option value=\"{$drucker[$i][id]}\" $mark>{$drucker[$i][name]}</option>";
    }
    return $tpl;
  }

  function Grusswort($sprache)
  {

    //abhaenig von Zeit usw.. passende Grußformel
/*
    return "Grüße aus dem sonnigen Ausgburg.";
    return "Grüße aus Ausgburg.";
    return "Frohe Ostern.";
    return "Schöne Feierabend.";
    return "Frohe Weihnachten.";
    return "Schönes Wochenende.";
*/
    if($sprache=="englisch") return "For further enquiries we are gladly available."."\n\nKind regards,";
    return "Für Rückfragen stehe ich Ihnen gerne zur Verfügung."."\n\nMit freundlichen Grüßen";
    
  }

  function DokumentSendVorlage($id)
  {
    $betreff = $this->app->DB->Select("SELECT betreff FROM dokumente_send WHERE id='$id' LIMIT 1");
    $text  = $this->app->DB->Select("SELECT text FROM dokumente_send WHERE id='$id' LIMIT 1");
  
    $this->app->Tpl->Set(BETREFF,$betreff);
    $this->app->Tpl->Set(TEXT,$text);
  }

  function Geschaeftsbriefvorlage($sprache,$subjekt)
  {
    $betreff = $this->app->DB->Select("SELECT betreff FROM geschaeftsbrief_vorlagen WHERE sprache = '$sprache' AND subjekt='$subjekt' LIMIT 1");
    $text = $this->app->DB->Select("SELECT text FROM geschaeftsbrief_vorlagen WHERE sprache = '$sprache' AND subjekt='$subjekt' LIMIT 1");
    $this->app->Tpl->Set(BETREFF,$betreff);
    $this->app->Tpl->Set(TEXT,$text);
  }

	function GetAnsprechpartner($data)
	{
		// $data: 'Admin <admin@test.de>'
		// return id, name, email

		$first = strpos($data, '<');
		$last = strpos($data, '>');

		$name = trim(substr($data, 0, $first));
		$email = trim(substr($data, $first+1, $last-($first+1)));
		
		$id = $this->app->DB->Select("SELECT id FROM adresse WHERE email='$mail' LIMIT 1"); 
		if(!(is_numeric($id) && $id<1))
			$id = $this->app->DB->Select("SELECT id FROM adresse WHERE name='$name' LIMIT 1");

		if(!is_numeric($id)) $id = 0;
	
		return array('id'=>$id, 'name'=>$name, 'email'=>$email);
	}


  function DokumentMask($parsetarget,$typ,$id,$adresse,$projekt="",$popup=false)
  {

	$this->app->Tpl->Set(SID,$id);
	$this->app->Tpl->Set(TYP,$typ);


	//echo "typ $typ<br>id $id adresse $adresse<br><br>";
	
        $betreff = $this->app->Secure->GetPOST("betreff");
        $projekt_submit = $this->app->Secure->GetPOST("projekt");
        $ansprechpartner = $this->app->Secure->POST["ansprechpartner"];
        $text = $this->app->Secure->GetPOST("text");
        $art = $this->app->Secure->GetPOST("senden");
	
	$partnerinfo = $this->GetAnsprechpartner($ansprechpartner);
	$ansprechpartner = $partnerinfo['id'];

	if($projekt=="" && $projekt_submit!="")
	  $projekt = $projekt_submit;

	// hole standard projekt von adresse
	if($projekt=="")
	  $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");


	// anschreiben
	//if($typ=="bestellung" || $typ=="lieferschein" || $typ=="rechnung" || $typ=="angebot" || ($typ=="brieffax" && $art!="email") )
	if($typ=="bestellung" || $typ=="angebot" || $typ=="lieferschein" || $typ=="auftrag" || ($typ=="brieffax" && $art!="email") )
	{
/*
	  // update status freigegebn auf versendet
	  $Brief = new BriefPDF(&$this->app);

	  if($art == "fax")
	    $Brief->GetBriefTMP($adresse,$betreff,$text,1);
	  else
	    $Brief->GetBriefTMP($adresse,$betreff,$text);

	  if($art !="email")
	    $tmpbrief= $Brief->displayTMP();
*/
	}

	// eigentliches dokument
	if($typ=="bestellung")
	{
	  // sende 
	  $Brief = new BestellungPDF($this->app);
	  $Brief->GetBestellung($id);
	  $tmpfile = $Brief->displayTMP();
	}
	// eigentliches dokument
	if($typ=="angebot")
	{
	  // sende 
	  $Brief = new AngebotPDF($this->app);
	  $Brief->GetAngebot($id);
	  $tmpfile = $Brief->displayTMP();
	}
	// eigentliches dokument
	if($typ=="lieferschein")
	{
	  // sende 
	  $Brief = new LieferscheinPDF($this->app);
	  $Brief->GetLieferschein($id);
	  $tmpfile = $Brief->displayTMP();
	}
	// eigentliches dokument
	if($typ=="auftrag")
	{
	  // sende 
	  $Brief = new AuftragPDF($this->app);
	  $Brief->GetAuftrag($id);
	  $tmpfile = $Brief->displayTMP();
	}
	// eigentliches dokument
	if($typ=="rechnung")
	{
	  // sende 
	  $Brief = new RechnungPDF($this->app);
	  $Brief->GetRechnung($id);
	  $tmpfile = $Brief->displayTMP();
	}

	// eigentliches dokument
	if($typ=="gutschrift")
	{
	  // sende 
	  $Brief = new GutschriftPDF($this->app);
	  $Brief->GetGutschrift($id);
	  $tmpfile = $Brief->displayTMP();
	}




/*
	if($typ=="brieffax" && $art!="email")
	{
	  // sende 
	  $Brief = new BriefPDF(&$this->app);
	  $Brief->GetBrief($id);
	  $tmpfile = $Brief->displayTMP();
	}
*/
	  if($art == "email")
	    $dateien = array($tmpfile);
	  else
	  {
	    if($typ=="brieffax")
	      $dateien = array($tmpbrief);
	    else
	      $dateien = array($tmpbrief,$tmpfile);
	  }
	  if($art == "brief") $drucker = $this->app->Secure->GetPOST("drucker_brief");
	  else if($art == "fax") $drucker = $this->app->Secure->GetPOST("drucker_fax");
	  else if ($art == "email") $drucker = $this->app->Secure->GetPOST("email_from");

	  if($this->app->Secure->GetPOST("submit")!="")
	  {

	    //echo "SENDEN";
	    $ret = $this->app->erp->DokumentSend($adresse,$typ,$id,$art,$betreff,$text,$dateien,$drucker,$ansprechpartner,$projekt, $partnerinfo['email'], $partnerinfo['name']);

	    // NEU ANLEGEN ODER UPDATE
	    if($typ=="brieffax")
	    {
		  $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE text='$text' AND betreff='$betreff' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
	    } else {
		  $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE dokument='$typ' AND parameter='$id' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1"); // GEHT bei BE RE LS
	    }

	    if(is_numeric($check) && $check >0)
	    {
	    if($typ=="brieffax")
	    { 
		// das dokument gibt es so bereits 1:1 hier braucht man nichts machen
		//echo "DAS DOKUMENT GIBT ES UNVERSENDET SO";
		$this->app->DB->Update("UPDATE dokumente_send SET versendet=1 WHERE id='$check' LIMIT 1");
	    }
	    else
	    {
		 $this->app->DB->Update("UPDATE dokumente_send SET betreff='$betreff', text='$text',versendet=1 WHERE dokument='$typ' AND parameter='$id' AND geloescht=0 AND versendet=0 LIMIT 1");  // GEHT bei RE, LS ..
	    }
	    } else {
	    if($typ=="brieffax")
	    {
		$this->app->DB->Insert("INSERT INTO dokumente_send 
		  (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner,versendet) VALUES ('','$typ',NOW(),'".$this->app->User->GetName()."',
		      '$adresse','$parameter','$art','$betreff','$text','$projekt','$ansprechpartner',1)");
		$tmpid = $this->app->DB->GetInsertID();
		$this->app->DB->Update("UPDATE dokumente_send SET parameter='$tmpid' WHERE id='$tmpid' LIMIT 1");
		//echo "INSERT brieffax dokument";
	    } else {
		//echo "anlegen begleitschreiben RE, LS";
		$this->app->DB->Insert("INSERT INTO dokumente_send 
		  (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner,versendet) VALUES ('','$typ',NOW(),'".$this->app->User->GetName()."',
		      '$adresse','$id','$art','$betreff','$text','$projekt','$ansprechpartner',1)");
	    }

	    }

	    //if($typ=="brieffax")
	    //  $id = $this->app->DB->GetInsertID();
	

	    if($ret == "")
	    {
	      $this->app->Tpl->Set($parsetarget,"<div class=\"info\">Dokument wurde erfolgreich versendet</div>");

	      /* Status gezielt von Dokument aendern */
	      if($typ=="bestellung")
	      {
		$this->app->DB->Update("UPDATE bestellung SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
		$this->app->erp->BestellungProtokoll($id,"Bestellung versendet");
	      } 
	      else if($typ=="angebot")
	      {
		$this->app->DB->Update("UPDATE angebot SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
		$this->app->erp->AngebotProtokoll($id,"Angebot versendet");
	      } 
	      else if($typ=="lieferschein")
	      {
		$this->app->DB->Update("UPDATE lieferschein SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
		$this->app->erp->LieferscheinProtokoll($id,"Lieferschein versendet");
	      } 
	      else if($typ=="auftrag")
	      {
		$this->app->DB->Update("UPDATE auftrag SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."' WHERE id='$id' LIMIT 1");
		$this->app->erp->AuftragProtokoll($id,"Auftrag versendet");
	      } 
	      else if ($typ=="rechnung")
	      {
		$this->app->DB->Update("UPDATE rechnung SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
		$this->app->erp->RechnungProtokoll($id,"Rechnung versendet");

	      }
	      else if ($typ=="gutschrift")
	      {
		$this->app->DB->Update("UPDATE gutschrift SET versendet=1, versendet_am=NOW(),
		  versendet_per='$art',versendet_durch='".$this->app->User->GetName()."',status='versendet' WHERE id='$id' LIMIT 1");
		$this->app->erp->GutschriftProtokoll($id,"Gutschrift versendet");

	      }

	    }
	    else
	      $this->app->Tpl->Set($parsetarget,"<div class=\"error\">$ret</div>");
	  } elseif ($this->app->Secure->GetPOST("speichern")!="") {
	      //echo "SPEICHERN";
	      // Nur speichern
	      $action =  $this->app->Secure->GetGET("action");
	      $module =  $this->app->Secure->GetGET("module");

	      if($module=="adresse")
	      {
		  $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE dokument='brieffax' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
	      } else {
		  $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE dokument='$typ' AND parameter='$id' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1"); // GEHT bei BE RE LS
	      } 

	      if($module=="adresse")
	      {
		$typ="brieffax";
		if(is_numeric($check))
		{
		  $this->app->DB->Insert("UPDATE  dokumente_send  SET betreff='$betreff',text='$text',bearbeiter='".$this->app->User->GetName()."' WHERE id='$check' LIMIT 1");
		  $this->app->Tpl->Set(MESSAGE,"<div class=\"info\">Die &Auml;nderungen wurden gespeichert.</div>");
		} else {
		    $this->app->DB->Insert("INSERT INTO dokumente_send 
		    (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner,versendet) VALUES ('','$typ',NOW(),'".$this->app->User->GetName()."',
		    '$adresse','$parameter','$art','$betreff','$text','$projekt','$ansprechpartner',0)");
		  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Es wurde ein neues Dokument wurde angelegt, da das alte Dokument bereits versendet worden ist.</div>");
		}
	      } else {

		if(is_numeric($check))
		{
		  $this->app->DB->Update("UPDATE  dokumente_send  SET betreff='$betreff',text='$text',bearbeiter='".$this->app->User->GetName()."' WHERE id='$check' LIMIT 1");
		  $this->app->Tpl->Set(MESSAGE,"<div class=\"info\">Die &Auml;nderungen wurden gespeichert.</div>");
		} else {
		  $parameter = $this->app->Secure->GetGET("id");
		  $this->app->DB->Insert("INSERT INTO dokumente_send 
		    (id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner,versendet) VALUES ('','$typ',NOW(),'".$this->app->User->GetName()."',
		    '$adresse','$parameter','$art','$betreff','$text','$projekt','$ansprechpartner',0)");
		  $this->app->Tpl->Set(MESSAGE,"<div class=\"error\">Es wurde ein neues Dokument wurde angelegt, da das alte Dokument bereits versendet worden ist.</div>");
		}
	      }
	      
	  }elseif($this->app->Secure->GetPOST("download")!="") {
			header("Location: index.php?module=adresse&action=briefpdf&sid=$id&id=$adresse");
			exit;
		}

        $this->app->Tpl->Set(DRUCKER,$this->app->erp->GetSelectDrucker());
        $this->app->Tpl->Set(EMAILEMPFAENGER,$this->app->erp->GetSelectEmail());
        $this->app->Tpl->Set(PROJEKT,$this->app->erp->GetProjektSelect($projekt));
//        $this->app->Tpl->Set(ANSPRECHPARTNER,$this->app->erp->GetSelectAnsprechpartner($adresse,$projekt));
				$tmp_mail = $this->app->DB->Select("SELECT email FROM $typ WHERE id='$id' LIMIT 1");
				$tmp_name = $this->app->DB->Select("SELECT ansprechpartner FROM $typ WHERE id='$id' LIMIT 1");
				if($tmp_name=="")
				$tmp_name = $this->app->DB->Select("SELECT name FROM $typ WHERE id='$id' LIMIT 1");
				
        $this->app->Tpl->Set(ANSPRECHPARTNER,$tmp_name." <".$tmp_mail.">");
        //$this->app->Tpl->Set(ANSPRECHPARTNER,$this->GetAdresseMail($adresse));
				$this->app->YUI->AutoComplete('ansprechpartner', 'emailname');	


        $this->app->erp->DokumentSendShow($parsetarget,$typ,$id,$adresse,$tmpfile,$popup);

        // temp datei wieder loeschen
        unlink($tmpfile);
        unlink($tmpbrief);
  }

	function GetAdresseMail($adresse) {
		$data = $this->app->DB->SelectArr("SELECT name, email FROM adresse WHERE id='$adresse' LIMIT 1");
		return "{$data[0]['name']} <{$data[0]['email']}>";
	}


  function DokumentSendShow($parsetarget,$dokument,$id,$adresse,$attachments="",$popup=false)
  {
      $sprache = $this->app->DB->Select("SELECT sprache FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
      $name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

      $testdata = $this->app->DB->SelectArr("SELECT betreff WHERE dokument='".$dokument."' AND parameter='$id' AND parameter!=0 ORDER BY zeit DESC LIMIT 1");

      switch($dokument)
      {
	case "bestellung":
	  if($tmp_data[0][betreff]!="")
	    $this->DokumentSendVorlage($id);
	  else
	  {
	    $this->Geschaeftsbriefvorlage($sprache,"Bestellung"); 
	    $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	    $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	  }
	break;
	case "angebot":
	  $this->Geschaeftsbriefvorlage($sprache,"Angebot"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	break;
	case "lieferschein":
	  $this->Geschaeftsbriefvorlage($sprache,"Lieferschein"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	break;
	case "rechnung":
	  $this->Geschaeftsbriefvorlage($sprache,"Rechnung"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	break;
	case "gutschrift":
	  $this->Geschaeftsbriefvorlage($sprache,"Gutschrift"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	break;

	case "auftrag":
	  $this->Geschaeftsbriefvorlage($sprache,"Auftrag"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	break;
	case "brieffax":
	  if($testdata!="")
	    $this->DokumentSendVorlage($id);
	  else
	  {
	  $this->Geschaeftsbriefvorlage($sprache,"Korrespondenz"); 
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->Grusswort($sprache));
	  $this->app->Tpl->Add(TEXT,"\n\n".$this->app->User->GetName());
	  }
	break;

	default: ;
      }


      $module = $this->app->Secure->GetGET("module");

      if($module=="adresse")
      {
	//echo "Fall 1";
	// genau das eine dokument
      $tmp = $this->app->DB->SelectArr("SELECT DATE_FORMAT(zeit,'%d.%m.%Y %H:%i') as zeit, text, betreff, id, adresse, bearbeiter,art, dokument, parameter, versendet FROM dokumente_send WHERE dokument='".$dokument."' 
      AND id='$id' AND parameter!=0  AND versendet=1 ORDER by zeit");
//echo ("SELECT DATE_FORMAT(zeit,'%d.%m.%Y %H:%i') as zeit, text, betreff, id, adresse, bearbeiter,art, dokument, parameter, versendet FROM dokumente_send WHERE dokument='".$dokument."' 
//       AND id='$id' parameter!=0  AND versendet=1 ORDER by zeit");

      }
      else
      {
	// alle passenden dokumente
      $tmp = $this->app->DB->SelectArr("SELECT DATE_FORMAT(zeit,'%d.%m.%Y %H:%i') as zeit, text, betreff, id, adresse, versendet, parameter, dokument bearbeiter,art FROM dokumente_send WHERE dokument='".$dokument."' AND parameter='$id'  AND parameter!=0 ORDER by zeit DESC");
	//echo "Fall 2";

      } 

      if(count($tmp)>0)
      {
	$this->app->Tpl->Set(HISTORIE,"<table align=\"left\" width=100%>");
	$this->app->Tpl->Add(HISTORIE,"<tr valign=\"top\"><td style=\"font-size: 8pt\"><b>Zeit</b></td><td style=\"font-size: 8pt\"><b>An</b></td><td style=\"font-size: 8pt\"><b>Von</b></td>
	  <td style=\"font-size: 8pt\"><b>Art</b></td><td style=\"font-size: 8pt\"><b>Versendet</b></td><td style=\"font-size: 8pt\"><b>PDF</b></td></tr>");
	for($i=0;$i<count($tmp);$i++)
	{

	  if($tmp[$i]['versendet']==0) $tmp[$i]['versendet'] = "nein"; else $tmp[$i]['versendet'] = "ja";
	  $tmp_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='{$tmp[$i]['adresse']}' AND geloescht=0 LIMIT 1");
	  $this->app->Tpl->Add(HISTORIE,'<tr valign="top"><td style="font-size: 8pt">'.$tmp[$i]['zeit'].'</td>
	<td style="font-size: 8pt">'.$tmp_name.'</td><td style="font-size: 8pt">'.$tmp[$i]['bearbeiter'].'</td>
	<td style="font-size: 8pt">'.ucfirst($tmp[$i]['art']).'</td>
	<td style="font-size: 8pt">'.ucfirst($tmp[$i]['versendet']).'</td>
	<td style="font-size: 8pt"><a href="index.php?module=adresse&action=briefpdf&sid='.$tmp[$i]['id'].'"><img src="./themes/[THEME]/images/pdf.png" border="0"></a></td>
	</tr>');
	}
	$this->app->Tpl->Add(HISTORIE,"</table>");

      } else { $this->app->Tpl->Set(HISTORIE,"<div class=\"info\">Dieses Dokument wurde noch nicht versendet!</div>"); }


      for($i=0;$i<count($attachments);$i++)
      {
	$this->app->Tpl->Add(ANHAENGE,"<a href=\"\">".basename($attachments)."</a>&nbsp;");
      }
      if(count($attachments)==0) $this->app->Tpl->Add(ANHAENGE,"keine Ah&auml;nge vorhanden");

      if(count($tmp)>0)
      {
	$this->app->Tpl->Set(BETREFF,$tmp[0][betreff]);
	$this->app->Tpl->Set(TEXT,$tmp[0][text]);
      }

      $this->app->Tpl->Set(EMPFAENGER,$name);
			$pTemplate = (($popup==true) ? 'dokument_absenden_popup.tpl' : 'dokument_absenden.tpl');
      $this->app->Tpl->Parse($parsetarget, $pTemplate);
  }

  function DokumentSend($adresse,$dokument, $parameter, $art,$betreff,$text,$dateien,$drucker="",$ansprechpartner="",$projekt="",$email_to="", $email_name_to="")
  {

    // $ret muss geleert werden wenn Dokument erfolgreich versendet wurde!!
    $ret = "Versandart $art noch nicht implementiert!";

    switch($art)
    {
      case "email": // signatur + dokument als anhang
		$ret = "";
		if($email_to!='') {
			$to = $email_to;
			$to_name = $email_name_to;
		}else{
	if($ansprechpartner!=0)
	{
	  $to = $this->app->DB->Select("SELECT email FROM ansprechpartner WHERE id='$ansprechpartner' LIMIT 1");
	  $to_name = $this->app->DB->Select("SELECT name FROM ansprechpartner WHERE id='$ansprechpartner' LIMIT 1");
	} else 
	{
	  $to = $this->app->DB->Select("SELECT email FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
	  $to_name = $this->app->DB->Select("SELECT name FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
	}
	}
	// wenn emailadresse from email from user name von benutzer sonst firmenname
	if($drucker==$this->app->User->GetEmail())
	  $from_name = $this->app->User->GetName();
	else
	  $from_name = $this->app->User->GetFirmaName();

	if($this->app->erp->MailSend($drucker,$from_name,$to,$to_name,$betreff,$text,$dateien))
	  $ret = "";
	else
	  $ret = "Die E-Mail konnte nicht versendet werden!";

      break;

      case "brief":
	foreach($dateien as $key=>$value)
	  $this->app->printer->Drucken($drucker,$value);
	$ret = "";  
      break;
 
      case "fax":
	foreach($dateien as $key=>$value)
	  $this->app->printer->Drucken($drucker,$value);
	$ret = "";  
      break;

      case "telefon":
	$ret = "";
      break;
    }
/*
$module = $this->app->Secure->GetGET("module");
    // UPDATE auf versendet
    if($ret =="")
    {
echo "insert 3";
if($module=="adresse") {
  $dokument="brieffax";
echo "if 1";
  $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE id='$parameter' AND dokument='$dokument' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
} else 
{
echo "if 2";
      // nur wenn es das dokument noch nicht gibt mit versendet=0
      $check = $this->app->DB->Select("SELECT id FROM dokumente_send WHERE parameter='$parameter' AND dokument='$dokument' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
}
      if($check<=0 || $check=="")
      {
    echo "insert 3 new";

      $this->app->DB->Insert("INSERT INTO dokumente_send 
	(id,dokument,zeit,bearbeiter,adresse,parameter,art,betreff,text,projekt,ansprechpartner,versendet) VALUES ('','$dokument',NOW(),'".$this->app->User->GetName()."',
	'$adresse','$parameter','$art','$betreff','$text','$projekt','$ansprechpartner',1)");

      $tmpid = $this->app->DB->GetInsertID();
      if($parameter==0 || $parameter=="")
	$this->app->DB->Update("UPDATE dokumente_send SET parameter='$tmpid' WHERE id='$tmpid' LIMIT 1");

      } else {
    echo "insert 3 update";
	if($module=="adresse")
	{
	  $this->app->DB->Update("UPDATE dokumente_send SET versendet=1 WHERE id='$parameter' AND dokument='$dokument' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
	}
	else
	{
	  $this->app->DB->Update("UPDATE dokumente_send SET versendet=1 WHERE parameter='$parameter' AND dokument='$dokument' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
	}

	//echo ("UPDATE dokumente_send SET versendet=1 WHERE parameter='$parameter' AND dokument='$dokument' AND geloescht=0 AND versendet=0 ORDER by id DESC LIMIT 1");
      }
    }
*/
    return $ret;
  }


  function NewEvent($beschreibung, $kategorie, $obejekt="",$parameter="")
  {

    $bearbeiter = $this->app->User->GetName();

    $this->app->DB->Insert("INSERT INTO event (id,beschreibung,kategorie,zeit,objekt,parameter,bearbeiter)
      VALUES('','$beschreibung','$kategorie',NOW(),'$objekt','$parameter','$bearbeiter')");

  }

  function UpdateChecksumShopartikel($projekt)
  {
    $tmp = $this->app->DB->SelectArr("SELECT id FROM artikel WHERE shop > 0");
    for($i=0;$i<count($tmp);$i++)
      $this->UpdateArtikelChecksum($tmp[$i][id],$projekt);
  }

  function UpdateArtikelChecksum($artikel,$projekt)
  {
    $tmp = $this->app->DB->SelectArr("SELECT typ,
      	nummer, projekt, inaktiv, warengruppe, name_de, name_en, kurztext_de, ausverkauft,
	kurztext_en , beschreibung_de, beschreibung_en,standardbild, herstellerlink, hersteller, uebersicht_de,uebersicht_en,links_de,links_en, startseite_de, startseite_en,
	lieferzeit , lieferzeitmanuell, wichtig,  gewicht, gesperrt,	sperrgrund,  gueltigbis,umsatzsteuer,  klasse,  adresse, shop, firma, neu,topseller,startseite,
	(SELECT MAX(preis) FROM verkaufspreise WHERE 
        artikel='$artikel' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND ab_menge = 1 AND (adresse='0' OR adresse='')) as preis
	FROM artikel WHERE id='$artikel' LIMIT 1");
	
//        artikel='$artikel' AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND ab_menge = 1 AND (objekt='Standard' OR objekt='')) as preis
    serialize($tmp);

    $checksum = md5(serialize($tmp));

    $this->app->DB->Update("UPDATE artikel SET checksum='$checksum' WHERE id='$artikel' LIMIT 1");
  }

  function GetStandardMarge()
  {
    return 40;
  }


  function GetStandardStundensatz()
  {
    return 57.62;
  }

  function GetProjektSelectMitarbeiter($adresse)
  {
    // Adresse ist Mitglied von Projekt xx
    // gibt man kein parameter an soll alles zurueck
    // entsprechen weitere parameter filtern die ausgabe
   $arr = $this->app->DB->SelectArr("SELECT adresse FROM bla bla where rolle=mitarbeiter von projekt xxx");
   foreach($arr as $value)
    {
      if($selected==$value) $tmp = "selected"; else $tmp="";
      $ret .= "<option value=\"$value\" $tmp>$value</option>";
    }
    return $ret;


  }

  function GetArtikelPreisvorlageProjekt($kunde,$projekt,$artikel,$menge)
  {
    //HACK!
    return $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE projekt='$projekt' AND artikel='$artikel'"); 
  }

  function GetAuftragSteuersatz($auftrag)
  {
    //ermitteln aus Land und UST-ID Prüfung
    return 1.19;
  }


	function GetSteuersatzNormal()
	{
		return 19;
	}

	function GetSteuersatzErmaessigt()
	{
		return 7;
	}



  function GetKreditkarten()
  {

    return array('MasterCard','Visa','American Express');
  }

  function GetKreditkartenSelect($selected)
  {
    foreach($this->GetKreditkarten() as $value)
    {
      if($selected==$value) $tmp = "selected"; else $tmp="";
      $ret .= "<option value=\"$value\" $tmp>$value</option>";
    }
    return $ret;
  }


  function GetKundeSteuersatz($kunde)
  {


  }

  function AddUSTIDPruefungKunde($kunde)
  {
    //gebunden an eine adresse


  }

  function GetVersandkosten($projekt)
  {

    return 3.32;
  }

  function AddArtikelAuftrag($artikel,$auftrag)
  {
    // an letzter stelle artikel einfuegen mit standard preis vom auftrag

  }

  function DelArtikelAuftrag($id)
  {
    //loesche artikel von auftrag und schiebe positionen nach


  }


  function GetAuftragStatus($auftrag)
  {



  }


  function Export($land)
  {
    if($land=="DE" || $land=="")
      return false;


    foreach($this->GetUSTEU() as $euland)
    {
      if($land==$euland)
        return false;
    }

    // alle anderen laender sind export!
    return true;
  }


  function GetUSTEU()
  {
    return
    array('BE','IT','RO',
	  'BG','LV','SE',
	  'DK','LT','SK',
	  'DE','LU','SI',
	  'EE','MT','ES',
	  'FI','NL','CZ',
	  'FR','AT','HU',
	  'GR','PL','GB',
	  'IE','PT','CY');
  }


  function CheckUSTFormat($ust)
  {
    $land = substr($ust,0,2);
    $nummer = substr($ust,2);

    switch($land)
    {
      case "BE":
	//zehn, nur Ziffern; (alte neunstellige USt-IdNrn. werden durch Voranstellen der Ziffer Ø ergänzt)
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land."0".$nummer;
	else if(is_numeric($nummer) && strlen($nummer)==10)
	  return $land.$nummer;
	else
	  return 0;
      break;

      case "BG":
	//   neun oder zehn, nur Ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else if(is_numeric($nummer) && strlen($nummer)==10)
	  return $land.$nummer;
	else
	  return 0;
      break;

      case "DK":
	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "DE":
	//neun, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else return 0;
      break;

      case "EE":
 	//neun, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else return 0;
      break;

      case "FI":
 	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "FR":
 	//elf, nur Ziffern bzw. die erste und / oder die zweite Stelle kann ein Buchstabe sein
	if(is_numeric($nummer) && strlen($nummer)==11)
	  return $land.$nummer;
	else if(ctype_digit(substr($nummer,0,1)) &&  is_numeric(substr($nummer,1)) && strlen($nummer)==11)
	  return $land.$nummer;
	else if(ctype_digit(substr($nummer,0,2)) &&  is_numeric(substr($nummer,2)) && strlen($nummer)==11)
	  return $land.$nummer;
	else return 0;
      break;

      case "EL":
 	//neun, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else return 0;
      break;


      case "IE":
 	//acht, die zweite Stelle kann und die letzte Stelle muss ein Buchstabe sein
	if(ctype_digit(substr($nummer,7,1)) &&  is_numeric(substr($nummer,0,7)) && strlen($nummer)==8)
	  return $land.$nummer;
	else if(ctype_digit(substr($nummer,7,1)) && ctype_digit(substr($nummer,1,1)) && is_numeric(substr($nummer,0,7)) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "IT":
 	//elf, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==11)
	  return $land.$nummer;
	else return 0;
      break;


      case "LV":
 	//elf, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==11)
	  return $land.$nummer;
	else return 0;
      break;

      case "LT":
 	//neu oder zwoelf, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else if(is_numeric($nummer) && strlen($nummer)==12)
	  return $land.$nummer;
	else return 0;
      break;

      case "LU":
 	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "MT":
 	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "AT":
 	//neun, nur ziffern die erste Stelle muss U sein
	if(is_numeric(substr($nummer,1,8)) && $nummer[0]=="U" && strlen($nummer)==9)
	  return $land.$nummer;
	else return 0;
      break;
  
      case "NL":
 	//neun, nur ziffern die erste Stelle muss U sein
	if(is_numeric(substr($nummer,0,9)) && $nummer[9]=="B" && strlen($nummer)==12)
	  return $land.$nummer;
	else return 0;
      break;



      case "PL":
 	//zehn, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==10)
	  return $land.$nummer;
	else return 0;
      break;

      case "PT":
 	//neun, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else return 0;
      break;


      case "RO":
 	//maximal zehn, nur ziffern, erste stelle !=0
	if(is_numeric($nummer) && strlen($nummer)>=10 && $nummer[0]!=0)
	  return $land.$nummer;
	else return 0;
      break;

      case "SE":
 	//zwölf, nur Ziffern, die beiden letzten Stellen bestehen immer aus der Ziffernkombination „Ø1“
	if(is_numeric($nummer) && strlen($nummer)==12 && $nummer[10] == 0 && $nummer[11]==1)
	  return $land.$nummer;
	else return 0;
      break;


      case "SK":
 	//zehn, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==10)
	  return $land.$nummer;
	else return 0;
      break;

      case "SI":
 	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "ES":
 	//neun, die erste und die letzte Stelle bzw. die erste oder die letzte Stelle kann ein Buchstabe sein
	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else if(is_numeric(substr($nummer,1,7)) && strlen($nummer)==9 && ctype_digit(substr($nummer,0,1)) && ctype_digit(substr($nummer,8,1)) )
	  return $land.$nummer;
	else if(is_numeric(substr($nummer,1,8)) && strlen($nummer)==9 && ctype_digit(substr($nummer,0,1)))
	  return $land.$nummer;
	else if(is_numeric(substr($nummer,0,8)) && strlen($nummer)==9 && ctype_digit(substr($nummer,8,1)))
	  return $land.$nummer;
	else return 0;
      break;

      case "CZ":
 	//   acht, neun oder zehn, nur Ziffern
	if(is_numeric($nummer) && strlen($nummer)>=8 && strlen($nummer)<=10)
	  return $land.$nummer;
	else return 0;
      break;

      case "HU":
 	//acht, nur ziffern
	if(is_numeric($nummer) && strlen($nummer)==8)
	  return $land.$nummer;
	else return 0;
      break;

      case "GB":
 	//neu oder zwoelf, nur ziffern, für Verwaltungen und Gesundheitswesen: fünf, die ersten zwei Stellen GD oder HA

	if(is_numeric($nummer) && strlen($nummer)==9)
	  return $land.$nummer;
	else if(is_numeric($nummer) && strlen($nummer)==12)
	  return $land.$nummer;
	else if(is_numeric(substr($nummer,2,3)) && $nummer[0]=="G" && $nummer[1]=="D")
	  return $land.$nummer;
	else if(is_numeric(substr($nummer,2,3)) && $nummer[0]=="H" && $nummer[1]=="A")
	  return $land.$nummer;
	else return 0;
      break;


      case "CY":
 	//neun, die letzte Stelle muss ein Buchstaben sein
	if(is_numeric(substr($nummer,0,8)) && strlen($nummer)==9 && ctype_digit(substr($nummer,8,1)))
	  return $land.$nummer;
	else return 0;
      break;


    }

  }
 
 
  function CheckUst($ust1,$ust2, $firmenname, $ort, $strasse, $plz, $druck="nein")
  {
    $tmp = new USTID();
    //$status = $tmp->check("DE263136143","SE556459933901","Wind River AB","Kista","Finlandsgatan 52","16493","ja");
    $status = $tmp->check($ust1, $ust2, $firmenname, $ort, $strasse, $plz, $druck,$onlinefehler);
    if($tmp->answer['Erg_Name'] == 'A')$tmp->answer['Erg_Name'] = '';     
    if($tmp->answer['Erg_Ort'] == 'A')$tmp->answer['Erg_Ort'] = '';     
    if($tmp->answer['Erg_Str'] == 'A')$tmp->answer['Erg_Str'] = '';     
    if($tmp->answer['Erg_PLZ'] == 'A')$tmp->answer['Erg_PLZ'] = '';     

        $erg = array(
	'ERG_NAME' => $tmp->answer['Erg_Name'],
	'ERG_ORT' => $tmp->answer['Erg_Ort'],
	'ERG_STR' => $tmp->answer['Erg_Str'],
	'ERG_PLZ' => $tmp->answer['Erg_PLZ'],
	'ERROR_CODE' => $tmp->answer['ErrorCode']);

    $error = 0;
    //1 wenn UST-ID. korrekt
    if($status == 1){
      if($tmp->answer['Erg_Name'] == 'B')$error++;
      if($tmp->answer['Erg_Ort'] == 'B')$error++;
      if($tmp->answer['Erg_Str'] == 'B')$error++;
      if($tmp->answer['Erg_PLZ'] == 'B')$error++;

      if($error > 0)
	return $erg;
      else{
        //Brief bestellen 
	//$status = $tmp->check($ust1, $ust2, $firmenname, $ort, $strasse, $plz, "ja");	
	return 1;
    }

    } else{
      //return "<h1>Meldung dringend melden: Status $status ($onlinefehler)</h1>";
      if(is_array($tmp->answer))
      {
	return $tmp->answer;
      }
      else return $onlinefehler;
    }
    //echo $tmp->check("DE2631361d3","SE556459933901","Wind River AB","Kista","Finlandsgatan 52","16493","ja");

  }

  function CreateTicket($projekt,$quelle,$kunde,$mailadresse,$betreff,$text,$timestamp="",$medium="email")
  {
    $i=rand(300,700);
    while(1)
    {
      $testschluessel = date('Ymd').sprintf("%04d",$i++);
      $check = $this->app->DB->Select("SELECT schluessel FROM ticket WHERE schluessel='$testschluessel' LIMIT 1");
      if($check=="") break;
    }

		$warteschlange = $this->app->DB->Select("SELECT ticketqueue FROM emailbackup WHERE benutzername='$quelle' LIMIT 1");
		$projekt = $this->app->DB->Select("SELECT projekt FROM emailbackup WHERE benutzername='$quelle' LIMIT 1");

    $sql = "INSERT INTO ticket (`id`, `schluessel`, `zeit`, `projekt`, `quelle`, `status`, `kunde`, `mailadresse`, `prio`, `betreff`,`warteschlange`)
      VALUES (NULL, '$testschluessel', FROM_UNIXTIME($timestamp), '$projekt', '$quelle', 'offen', '$kunde', '$mailadresse', 
      '3','$betreff','$warteschlange');";
    $this->app->DB->InsertWithoutLog($sql);


    $sql = "INSERT INTO `ticket_nachricht` (`id`, `ticket`, `zeit`,`text`,`betreff`,`medium`,`verfasser`, `mail`) 
     VALUES (NULL, '$testschluessel', FROM_UNIXTIME($timestamp), '$text','$betreff','$medium','$kunde', '$mailadresse');";

    $this->app->DB->InsertWithoutLog($sql);
    $id = $this->app->DB->GetInsertID();
    //  als rueckgabe ticketnachricht
    return $id;
  }


  function MailSendNoBCCHTML($from,$from_name,$to,$to_name,$betreff,$text,$files="")
  { 
  
    //$to = ""; // testmail

    $this->app->mail->ClearData();

    $this->app->mail->From       = $from;
    $this->app->mail->FromName   = utf8_decode($from_name);

    $this->app->mail->Subject    = utf8_decode($betreff);
    $this->app->mail->AddAddress($to, utf8_decode($to_name));

    $this->app->mail->Body = utf8_decode(str_replace('\r\n',"\n",$text).nl2br($this->Signatur()));

    $this->app->mail->IsHTML(true);

    for($i=0;$i<count($files);$i++)
      $this->app->mail->AddAttachment($files[$i]);

    if(!$this->app->mail->Send()) {
      $error =  "Mailer Error: " . $this->app->mail->ErrorInfo;
      return 0;
    } else {
      $error = "Message sent!";
      return 1;
    }


  }



  function MailSendNoBCC($from,$from_name,$to,$to_name,$betreff,$text,$files="")
  { 
  
    //$to = ""; // testmail

    $this->app->mail->ClearData();

    $this->app->mail->From       = $from;
    $this->app->mail->FromName   = utf8_decode($from_name);

    $this->app->mail->Subject    = utf8_decode($betreff);
    $this->app->mail->AddAddress($to, utf8_decode($to_name));

    $this->app->mail->Body = utf8_decode(str_replace('\r\n',"\n",$text).$this->Signatur());


    for($i=0;$i<count($files);$i++)
      $this->app->mail->AddAttachment($files[$i]);

    if(!$this->app->mail->Send()) {
      $error =  "Mailer Error: " . $this->app->mail->ErrorInfo;
      return 0;
    } else {
      $error = "Message sent!";
      return 1;
    }


  }


  function MailSend($from,$from_name,$to,$to_name,$betreff,$text,$files="")
  {


    $this->app->mail->ClearData();

    $this->app->mail->From       = $from;
    $this->app->mail->FromName   = utf8_decode($from_name);

    $this->app->mail->Subject    = utf8_decode($betreff);
    $this->app->mail->AddAddress($to, utf8_decode($to_name));

    $this->app->mail->Body = utf8_decode(str_replace('\r\n',"\n",$text).$this->Signatur());

    $bcc1 = $this->app->DB->Select("SELECT bcc1 FROM firmendaten WHERE firma='1' LIMIT 1");
    $bcc2 = $this->app->DB->Select("SELECT bcc2 FROM firmendaten WHERE firma='1' LIMIT 1");

    if($bcc1!="") $this->app->mail->AddBCC($bcc1);
    if($bcc2!="") $this->app->mail->AddBCC($bcc2);

    for($i=0;$i<count($files);$i++)
      $this->app->mail->AddAttachment($files[$i]);

    if(!$this->app->mail->Send()) {
      $error =  "Mailer Error: " . $this->app->mail->ErrorInfo;
      return 0;
    } else {
      $error = "Message sent!";
      return 1;
    }


  }

  function TicketMail($message)
  {
    $tmp = $this->app->DB->SelectArr("SELECT * FROM ticket_nachricht WHERE id='$message' LIMIT 1");


//		move_uploaded_file($_FILES['datei']['tmp_name'], "upload/datei.txt");
		if(is_file($_FILES['datei']['tmp_name']))
		{
			$this->app->mail->AddAttachment($_FILES['datei']['tmp_name'],$_FILES['datei']['name']);
		}


    $this->app->mail->From       = $this->GetFirmaMail();
    $this->app->mail->FromName   = $this->GetFirmaName();

    //$this->app->mail->AddBCC('');
		$bcc1 = $this->app->DB->Select("SELECT bcc1 FROM firmendaten WHERE firma='1' LIMIT 1");
    $bcc2 = $this->app->DB->Select("SELECT bcc2 FROM firmendaten WHERE firma='1' LIMIT 1");

    if($bcc1!="") $this->app->mail->AddBCC($bcc1);
    if($bcc2!="") $this->app->mail->AddBCC($bcc2);




    $this->app->mail->Subject    = utf8_decode("RE: ".$tmp[0]['betreff']." Ticket #".$tmp[0]['ticket']);
    $this->app->mail->AddAddress($tmp[0]['mail'], $tmp[0]['verfasser']);

    //$this->app->mail->Body = utf8_decode($tmp[0]['textausgang']."\r\n\r\nIhre Mail:\r\n\r\n".$tmp[0]['text'].$this->Signatur()); //TODO
    $this->app->mail->Body = utf8_decode($tmp[0]['textausgang']."\r\n\r\n".$this->Signatur());
    //echo $tmp[0]['mail'].'<br>';
    //echo isMailAdresse($tmp[0]['mail']);

    if(!$this->app->mail->Send()) {
      $error =  "Mailer Error: " . $this->app->mail->ErrorInfo;
      $this->app->DB->Update("UPDATE ticket_nachricht SET status='beantwortet',versendet='0' WHERE id=".$message);
      echo $error;
      return 0;
    } else {
      $error = "Message sent!";
      echo $error;
      $this->app->DB->Update("UPDATE ticket_nachricht SET status='beantwortet',versendet='1' WHERE id=".$message);
      return 1;
    }
  }

  function isMailAdr($mailadr){
   if(!eregi("^[_a-z0-9!#$%&\\'*+-\/=?^_`.{|}~]+(\.[_a-z0-9!#$%&\'*+-\\/=?^_`.{|}~]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $mailadr))
    return 0;
   else
    return 1;
  }

  function filterMailAdr($mailadr){
    eregi("(&lt;)+.*(&gt;)+", $mailadr, $matches);
    $mailadr = str_replace("&lt;", "",$matches[0]);
    $mailadr = str_replace("&gt;", "",$mailadr);
    if($this->isMailAdr($mailadr))
      return $mailadr;
    else
      return 0;
  }

  function Firmendaten($field)
  {
    $firmendatenid = $this->app->DB->Select("SELECT MAX(id) FROM firmendaten LIMIT 1"); 
    return $this->app->DB->Select("SELECT ".$field." FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");      
	}

  function Signatur()
  {
  
    $firmendatenid = $this->app->DB->Select("SELECT MAX(id) FROM firmendaten LIMIT 1");                                                                                                                                                           
    $signatur = $this->app->DB->Select("SELECT signatur FROM firmendaten WHERE id='".$firmendatenid."' LIMIT 1");      
    
    return "


".base64_decode($signatur);

  }


  function GetDatevKonten($konto="")
  {
    $konten = array(''=>'','1370'=>'Durchlaufende Posten','6800'=>'Porto');

    foreach($konten  as $key=>$value)
    {
      if($konto==$key) $selected="selected"; else $selected="";
      $tmp = str_replace("*","&nbsp;",str_pad ($key, 8,"*"));
      $ret .="<option value=\"$key\" $selected>$tmp $value</option>";
    }
    return $ret;
  }


  function GetQuelleTicket()
  {
    return array('Telefon','Fax','Brief','Selbstabholer');
  }


  function GetPrioTicketSelect($prio)
  {
    $prios = array('5'=>'sehr niedrig','4'=>'niedrig','3'=>'normal','2'=>'wichtig','1'=>'sehr wichtig');

    foreach($prios as $key=>$value)
    {
      if($prio==$key) $selected="selected"; else $selected="";
      $ret .="<option value=\"$key\" $selected>$value</option>";
    }
    return $ret;
  }


  function GetZeiterfassungArt()
  {
    return array('arbeit'=>'Arbeit','urlaub'=>'Urlaub','krankheit'=>'Krankheit','ueberstunden'=>'&Uuml;berstunden','feiertag'=>'Feiertag');
  }

  function GetVPE()
  {
    return array('einzeln'=>'Einzeln','tray'=>'Tray','rolle'=>'Rolle','stueckgut'=>'St&uuml;ckgut','stange'=>'Stange','palette'=>'Palette');
  }

  function GetUmsatzsteuerklasse()
  {
    return array('normal'=>'normal','ermaessigt'=>'erm&auml;&szlig;gt');
  }

  function GetEtikett()
  {
    return array('klein'=>'Artikelaufkleber klein','gross'=>'Artikelaufkleber gro&szlig;');
  }


  function GetWaehrung()
  {
    return array('EUR'=>'EUR','USD'=>'USD','CAD'=>'CAD');
  }


  function GetLager()
  {
    $tmp['zwischenlager'] = "Zwischenlager";

    $result = $this->app->DB->SelectArr("SELECT lp.id, CONCAT(l.bezeichnung,' ',lp.kurzbezeichnung) as kurzbezeichnung FROM lager_platz lp LEFT JOIN lager l ON lp.lager=l.id WHERE l.firma='1' AND l.manuell='1'");

    for($i=0;$i<count($result);$i++)
      $tmp[$result[$i][id]]=$result[$i][kurzbezeichnung];

    return $tmp;
  }

  function GetArtikelart()
  {
    return array('produkt'=>'Produkt','material'=>'Material','dienstleistung'=>'Dienstleistung','muster'=>'Muster',
		  'gebuehr'=>'Geb&uuml;hr','betriebsstoff'=>'Betriebsstoff','buerobedarf'=>'B&uuml;robedarf',
		  'inventar'=>'Inventar','porto'=>'Porto','literatur'=>'Literatur');
  }

  function GetWarteschlangeTicket()
  {

		$tmp = $this->app->DB->SelectArr("SELECT warteschlange,label FROM warteschlangen ORDER by warteschlange DESC");

		for($i=0;$i<count($tmp);$i++)
		{
			$tmp_array[$tmp[$i]['label']]=$tmp[$i]['warteschlange'];
		}

		return $tmp_array;
    //return array('verwaltung'=>'Verwaltung','technik'=>'Technik','buchhaltung'=>'Buchhaltung','unishop'=>'Uni-Shop','wawision'=>'waWision','journal'=>'Journal','bewerbung'=>'Bewerbung');
  }

  function GetWarteschlangeTicketSelect($warteschlange)
  {
    $prios = $this->GetWarteschlangeTicket();

    foreach($prios as $key=>$value)
    {
      if($warteschlange==$key) $selected="selected"; else $selected="";
      $ret .="<option value=\"$key\" $selected>$value</option>";
    }
    return $ret;
  }


  function GetWartezeitTicket($zeit)
  {
    $timestamp = strToTime($zeit, null);
  

    $td = $this->makeDifferenz($timestamp,time());
    return $td['day'][0] . ' ' . $td['day'][1] . ', ' . $td['std'][0] . ' ' . $td['std'][1] . 
    ', ' . $td['min'][0] . ' ' . $td['min'][1];// . ', ' . $td['sec'][0] . ' ' . $td['sec'][1];
  }

  function makeDifferenz($first, $second){
    
    if($first > $second)
        $td['dif'][0] = $first - $second;
    else
        $td['dif'][0] = $second - $first;
    
    $td['sec'][0] = $td['dif'][0] % 60; // 67 = 7

    $td['min'][0] = (($td['dif'][0] - $td['sec'][0]) / 60) % 60; 
    
    $td['std'][0] = (((($td['dif'][0] - $td['sec'][0]) /60)- 
    $td['min'][0]) / 60) % 24;
    
    $td['day'][0] = floor( ((((($td['dif'][0] - $td['sec'][0]) /60)- 
    $td['min'][0]) / 60) / 24) );
    
    $td = $this->makeString($td);
    
    return $td;
    
  }


  function makeString($td){
    
    if ($td['sec'][0] == 1)
        $td['sec'][1] = 'Sekunde';
    else 
        $td['sec'][1] = 'Sekunden';
    
    if ($td['min'][0] == 1)
        $td['min'][1] = 'Minute';
    else 
        $td['min'][1] = 'Minuten';
        
    if ($td['std'][0] == 1)
        $td['std'][1] = 'Stunde';
    else 
        $td['std'][1] = 'Stunden';
        
    if ($td['day'][0] == 1)
        $td['day'][1] = 'Tag';
    else 
        $td['day'][1] = 'Tage';
    
    return $td;
    
  }


  function GetProjektSelect($projekt,$color_selected="")
  {

    $sql = "SELECT id,name,farbe FROM projekt order by id";
    $tmp = $this->app->DB->SelectArr($sql);
    for($i=0;$i<count($tmp);$i++)
    {
      if($tmp[$i]['farbe']=="") $tmp[$i]['farbe']="white";
      if($projekt==$tmp[$i]['id']){
	$options = $options."<option value=\"{$tmp[$i]['id']}\" selected 
	  style=\"background-color:{$tmp[$i]['farbe']};\">{$tmp[$i]['name']}</option>";
	$color_selected = $tmp[$i]['farbe'];
      }
      else
        $options = $options."<option value=\"{$tmp[$i]['id']}\" 
	  style=\"background-color:{$tmp[$i]['farbe']};\">{$tmp[$i]['name']}</option>";
    }
    return $options;

  }

  function GetAdressName($id)
  {
		if($this->app->Conf->WFdbType=="postgre") {
			if(is_numeric($id))
    		$result = $this->app->DB->SelectArr("SELECT name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
		} else {
			$result = $this->app->DB->SelectArr("SELECT name FROM adresse WHERE id='$id' AND geloescht=0 LIMIT 1");
		}

    //return $result[0][vorname]." ".$result[0][name];
    return $result[0][name];
  }

  function GetAdressSubject()
  {
    return array('Kunde','Lieferant','Mitarbeiter','Ansprechpartner','Sponsor','Leser','Autor','Networking');
  }

  function GetAdressPraedikat()
  {
    return array('','von','fuer','ist');
  }

  function GetAdressObjekt()
  {
    return array('','Projekt');
  }


  function GetVersandartAuftrag()
  {
    return array('versandunternehmen'=>'Versandunternehmen','selbstabholer'=>'Selbstabholer','keinversand'=>'Kein Versand');
  }


  function GetVersandartLieferant()
  {
    return array('DHL','UPS','Hermes','DPD','GLS','Post','Spedition','Selbstabholer','Packstation');
  }



  function GetZahlungsstatusLieferant()
  {
    return array('offen','bezahlt');
  }

  function GetZahlungsweiseGutschrift()
  {
    return array('ueberweisung'=>'&Uuml;berweisung','bar'=>'Bar','paypal'=>'PayPal');
  }

  function GetZahlungsweiseLieferant()
  {
    return array('rechnung'=>'Rechnung','vorkasse'=>'Vorkasse','nachnahme'=>'Nachnahme','kreditkarte'=>'Kreditkarte','einzugsermaechtigung'=>'Einzugsermaechtigung','bar'=>'Bar','paypal'=>'PayPal','lastschrift'=>'Lastschrift');
  }

	function GetTypSelect()
	{
		return array('firma'=>'Firma','herr'=>'Herr','frau'=>'Frau','ausbildungsbetrieb'=>'Ausbildungsbetrieb');
	}

  function GetArtikelWarengruppe()
  {
    //return array('SMD','THT','EBG','BGP');
    $tmp = array('','Bauteil','Eval-Board','Adapter','Progammer','Ger&auml;t','Kabel','Software','Dienstleistung','Spezifikation');
    sort($tmp);
    return $tmp;
  }

  function GetStatusLieferschein()
  {
    return array('offen','freigegeben','versendet');
  }


  function GetStatusAuftrag()
  {
    return array('offen','freigegeben','abgeschlossen');
  }

  function GetStatusAngebot()
  {
    return array('offen','freigegeben','bestellt','angemahnt','empfangen');
  }


  function GetStatusGutschrift()
  {
    return array('offen','freigegeben','bezahlt');
  }

  function GetStatusRechnung()
  {
    return array('offen','freigegeben','gestellt','zahlungserinnerung','mahnung');
  }


  function GetStatusBestellung()
  {
    return array('offen','freigegeben','bestellt','angemahnt','empfangen');
  }

  function GetSelectAsso($array, $selected)
  {
    foreach($array as $key=>$value)
    {
      if($selected==$key) $tmp = "selected"; else $tmp="";
      $ret .= "<option value=\"$key\" $tmp>$value</option>";
    }
    return $ret;
  }


  function GetSelect($array, $selected)
  {
    foreach($array as $value)
    {
      if($selected==$value) $tmp = "selected"; else $tmp="";
      $ret .= "<option value=\"$value\" $tmp>$value</option>";
    }
    return $ret;
  }

  function AddRolleZuAdresse($adresse, $subjekt, $praedikat, $objekt, $parameter)
  {
    // Insert ....  
    $sql ="INSERT INTO adresse_rolle (id, adresse, subjekt, praedikat, objekt, parameter)
	    VALUES ('','$adresse','$subjekt','$praedikat','$objekt','$parameter')";
    $this->app->DB->Insert($sql);
    $id =  $this->app->DB->GetInsertID();


    // wenn adresse zum erstenmal die rolle erhält wird kundennummer bzw. lieferantennummer vergeben
    if($subjekt=="Kunde")
    {
      $kundennummer = $this->GetNextKundennummer();
      $this->app->DB->Update("UPDATE adresse SET kundennummer='$kundennummer' WHERE id='$adresse' AND kundennummer='0' LIMIT 1");
    }

    if($subjekt=="Lieferant")
    {
      $lieferantennummer = $this->GetNextLieferantennummer();
      $this->app->DB->Update("UPDATE adresse SET lieferantennummer='$lieferantennummer' WHERE id='$adresse' AND lieferantennummer='0' LIMIT 1");
    }

  }

  function AddArbeitszeit($adr_id, $vonZeit, $bisZeit, $aufgabe, $beschreibung, $projekt, $paketauswahl,$art,$kunde="",$abrechnen="0")
  {
    $insert = "";
    if($paketauswahl==0){
			if($abrechnen!="1") $abrechnen=0;
			if($projekt<=0) $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$kunde' LIMIT 1");
			if($projekt=="") $projekt=0;
      $insert = 'INSERT INTO zeiterfassung (adresse, von, bis, aufgabe, beschreibung, projekt, buchungsart,art,adresse_abrechnung,abrechnen) 
      VALUES ('.$adr_id.',"'.$vonZeit.'","'.$bisZeit.'","'.$aufgabe.'", "'.$beschreibung.'",'.$projekt.', "manuell","'.$art.'","'.$kunde.'","'.$abrechnen.'")';
    }else{
      $projekt = $this->app->DB->SelectArr("SELECT aufgabe, beschreibung, projekt, kostenstelle FROM arbeitspaket WHERE id = $paketauswahl");
      $myArr = $projekt[0];
      $insert = 'INSERT INTO zeiterfassung (adresse, von, bis, arbeitspaket, aufgabe, beschreibung, projekt, buchungsart,art) VALUES ('.$adr_id.',"'.$vonZeit.'","'.$bisZeit.'",'.$paketauswahl.' , "'.$myArr["aufgabe"].'", "'.$myArr["beschreibung"].'",'.$myArr["projekt"].', "AP","'.$art.'")';
    }
    $this->app->DB->Insert($insert);

      // wenn art=="AP" hole projekt und kostenstelle aus arbeitspaket beschreibung
      // und update zuvor angelegten datensatz
  }


  /**
   * \brief   Anlegen eines Arbeitspakets
   *
   *         Diese Funktion legt ein Arbeitspaket an.
   *
   * \param   aufgabe      Kurzbeschreibung (ein paar Woerter)  
   * \param   beschreibung  Textuelle Beschreibung 
   * \param   projekt      Projekt ID 
   * \param   zeit_geplant  Stundenanzahl Integer Wert
   * \param   kostenstelle  Kostenstelle 
   * \param   initiator            user id des Initiators
   * \param   abgabedatum   Datum fuer Abgabe 
   * \return                Status-Code
   *
   */
  function CreateArbeitspaket($adressse, $aufgabe,$beschreibung,$projekt,$zeit_geplant,$kostenstelle,$initiator,$abgabedatum="")
  {
      if(($abgabe != "") && ($beschreibung != "") && ($projekt != "") && ($zeit_geplant != "") && ($kostenstelle != "") && ($initiator != "")){
       $this->app->DB->Insert('INSERT INTO arbeitspakete                                                                                                                                   (adresse, aufgabe, beschreibung, projekt, zeit_geplant, kostenstelle, initiator, abgabedatum)                                                                VALUES (                                                                                                                                                      '.$adresse.',"'.$aufgabe.'", "'.$beschreibung.'", '.$projekt.', '.$zeit_geplant.','.$kostenstelle.', '.$initiator.',"'.$abgabedatum.'")');
       return 1;
      }else
       return 0;
  }

  function IsAdresseSubjekt($adresse,$subjekt)
  {
    $id = $this->app->DB->Select("SELECT id FROM adresse_rolle WHERE adresse='$adresse' AND subjekt='$subjekt' LIMIT 1");  
    if($id > 0)
      return 1;
    else return 0;
  }

  function AddOffenenVorgang($adresse, $titel, $href, $beschriftung="", $linkremove="")
  {
    $sql = "INSERT INTO offenevorgaenge (id,adresse,titel,href,beschriftung,linkremove) VALUES
	    ('','$adresse','$titel','$href','$beschriftung','$linkremove')";
    $this->app->DB->Insert($sql);
  }


  function RenameOffenenVorgangID($id,$titel)
  {
    $sql = "UPDATE offenevorgaenge SET titel='$titel' WHERE id='$id' LIMIT 1";
    $this->app->DB->Update($sql);
  }

  function RemoveOffenenVorgangID($id)
  {
    $sql = "DELETE FROM offenevorgaenge WHERE id='$id' LIMIT 1";
    $this->app->DB->Delete($sql);
  }

  function GetNextMitarbeiternummer()
  {
    $sql = "SELECT MAX(mitarbeiternummer) FROM adresse WHERE geloescht=0";
    $nummer = $this->app->DB->Select($sql) + 1;
    if($nummer==1)
      $nummer = 90000;
    return $nummer;
  }


  function GetNextKundennummer()
  {
    $sql = "SELECT MAX(kundennummer) FROM adresse WHERE geloescht=0";
    $nummer = $this->app->DB->Select($sql) + 1;
    if($nummer==1)
      $nummer = 10000;
    return $nummer;
  }

  function GetNextLieferantennummer()
  {
    $sql = "SELECT MAX(lieferantennummer) FROM adresse WHERE geloescht=0";
    $nummer = $this->app->DB->Select($sql) + 1;
    if($nummer==1)
      $nummer = 70000;
    return $nummer;
  }


  function LieferscheinProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO lieferschein_protokoll (id,lieferschein,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }

  function ProduktionProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO produktion_protokoll (id,auftrag,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }


  function AuftragProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO auftrag_protokoll (id,auftrag,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }

  function AngebotProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO angebot_protokoll (id,angebot,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }

  function BestellungProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO bestellung_protokoll (id,bestellung,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }

  function RechnungProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO rechnung_protokoll (id,rechnung,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }

  function GutschriftProtokoll($id,$text)
  {
    $this->app->DB->Insert("INSERT INTO gutschrift_protokoll (id,gutschrift,zeit,bearbeiter,grund) VALUES
      ('','$id',NOW(),'".$this->app->User->GetName()."','$text')"); 
  }


  function LoadLieferscheinStandardwerte($id,$adresse)
  {
    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $field = array('name','abteilung','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','kundennummer','projekt');
    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!="")
      {
				$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
				$this->app->Secure->POST[$value] = $arr[0][$value];
				$uparr[$value] = $arr[0][$value];
      }

      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }
    $uparr[adresse]=$adresse;
    $this->app->DB->UpdateArr("lieferschein",$id,"id",$uparr);
    $uparr="";

    //liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM kundevorlage WHERE adresse='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');
    foreach($field as $key=>$value)
    {
      //$uparr[$value] = $arr[0][$value];
      $this->app->Secure->POST[$value] = $arr[0][$value];
    }
    $this->app->DB->UpdateArr("lieferschein",$id,"id",$uparr);

    //standardprojekt
    //$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    //$this->app->Secure->POST[projekt] = $projekt;


  }


  function LoadProduktionStandardwerte($id,$adresse)
  {
    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $field = array('name','vorname','abteilung','ansprechpartner','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','kundennummer','projekt');

  	$rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse'	AND subjekt='Kunde' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

		if($rolle_projekt > 0)
		{
				$arr[0]['projekt'] = $rolle_projekt;
		}


    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!="" && 0) // immer projekt von adresse
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }

      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }
    $uparr[adresse]=$adresse;
    $this->app->DB->UpdateArr("produktion",$id,"id",$uparr);
    $uparr="";

    //liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM kundevorlage WHERE adresse='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');

    if($arr[0]['zahlungsweise']=="" && $this->app->Secure->POST['zahlungsweise']=="")
      $arr[0]['zahlungsweise']="rechnung";
    else if ($this->app->Secure->GetPOST("zahlungsweise")!="")
      $arr[0]['zahlungsweise'] = $this->app->Secure->GetPOST("zahlungsweise");


    if($arr[0]['zahlungszieltage']<=0 && $this->app->Secure->POST['zahlungszieltage']=="")
      $arr[0]['zahlungszieltage']="14";
    else if ($this->app->Secure->POST['zahlungszieltage']!="")
      $arr[0]['zahlungszieltage']=$this->app->Secure->POST['zahlungszieltage'];


    if($arr[0]['versandart']=="" && $this->app->Secure->POST['versandart']=="")
      $arr[0]['versandart']="versandunternehmen";
    else if ($this->app->Secure->POST['versandart']!="")
      $arr[0]['versandart']=$this->app->Secure->POST['versandart'];


    $this->app->Secure->POST['zahlungsweise'] = strtolower($arr[0]['zahlungsweise']);
    $this->app->Secure->POST['zahlungszieltage'] = strtolower($arr[0]['zahlungszieltage']);
    $this->app->Secure->POST['zahlungszieltageskonto'] = strtolower($arr[0]['zahlungszieltageskonto']);
    $this->app->Secure->POST['zahlungszielskonto'] = strtolower($arr[0]['zahlungszielskonto']);
    $this->app->Secure->POST['versandart'] = strtolower($arr[0]['versandart']);


    //if($zahlarr[zahlungsweise]=="") $zahlarr[zahlungsweise]="rechnung";
    //if($zahlarr[zahlungszieltage]=="") $zahlarr[zahlungszieltage]="14";

    //standardprojekt
    /*$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($projekt=="") $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $this->app->Secure->POST['projekt'] = $projekt;
    $arr[0]['projekt'] = $projekt;*/

    $this->app->DB->UpdateArr("produktion",$id,"id",$arr[0]);
  }




  function LoadAuftragStandardwerte($id,$adresse)
  {
    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $field = array('name','vorname','abteilung','ansprechpartner','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','kundennummer','projekt');

  	$rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse'	AND subjekt='Kunde' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

		if($rolle_projekt > 0)
		{
				$arr[0]['projekt'] = $rolle_projekt;
		}


    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!="" && 0) // immer projekt von adresse
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }

      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }
    $uparr[adresse]=$adresse;
    $this->app->DB->UpdateArr("auftrag",$id,"id",$uparr);
    $uparr="";

    //liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM kundevorlage WHERE adresse='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');

    if($arr[0]['zahlungsweise']=="" && $this->app->Secure->POST['zahlungsweise']=="")
      $arr[0]['zahlungsweise']="rechnung";
    else if ($this->app->Secure->GetPOST("zahlungsweise")!="")
      $arr[0]['zahlungsweise'] = $this->app->Secure->GetPOST("zahlungsweise");


    if($arr[0]['zahlungszieltage']<=0 && $this->app->Secure->POST['zahlungszieltage']=="")
      $arr[0]['zahlungszieltage']="14";
    else if ($this->app->Secure->POST['zahlungszieltage']!="")
      $arr[0]['zahlungszieltage']=$this->app->Secure->POST['zahlungszieltage'];


    if($arr[0]['versandart']=="" && $this->app->Secure->POST['versandart']=="")
      $arr[0]['versandart']="versandunternehmen";
    else if ($this->app->Secure->POST['versandart']!="")
      $arr[0]['versandart']=$this->app->Secure->POST['versandart'];


    $this->app->Secure->POST['zahlungsweise'] = strtolower($arr[0]['zahlungsweise']);
    $this->app->Secure->POST['zahlungszieltage'] = strtolower($arr[0]['zahlungszieltage']);
    $this->app->Secure->POST['zahlungszieltageskonto'] = strtolower($arr[0]['zahlungszieltageskonto']);
    $this->app->Secure->POST['zahlungszielskonto'] = strtolower($arr[0]['zahlungszielskonto']);
    $this->app->Secure->POST['versandart'] = strtolower($arr[0]['versandart']);


    //if($zahlarr[zahlungsweise]=="") $zahlarr[zahlungsweise]="rechnung";
    //if($zahlarr[zahlungszieltage]=="") $zahlarr[zahlungszieltage]="14";

    //standardprojekt
    /*$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($projekt=="") $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $this->app->Secure->POST['projekt'] = $projekt;
    $arr[0]['projekt'] = $projekt;*/

    $this->app->DB->UpdateArr("auftrag",$id,"id",$arr[0]);
  }




  function LoadAngebotStandardwerte($id,$adresse)
  {
    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

 $rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse' AND subjekt='Kunde' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

    if($rolle_projekt > 0)
    {
        $arr[0]['projekt'] = $rolle_projekt;
    }

    $field = array('name','abteilung','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','ust_befreit','email','telefon','telefax','projekt','ansprechpartner');
    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!="" && 0)
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }
    }
		$uparr['adresse'] = $adresse;
    $this->app->DB->UpdateArr("angebot",$id,"id",$uparr);
    $uparr="";

//liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM kundevorlage WHERE adresse='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');

    if($arr[0]['zahlungsweise']=="")
      $arr[0]['zahlungsweise']="rechnung";

    if($arr[0]['zahlungszieltage']<=0)
      $arr[0]['zahlungszieltage']="14";

    $this->app->Secure->POST['zahlungsweise'] = strtolower($arr[0]['zahlungsweise']);
    $this->app->Secure->POST['zahlungszieltage'] = strtolower($arr[0]['zahlungszieltage']);
    $this->app->Secure->POST['zahlungszieltageskonto'] = strtolower($arr[0]['zahlungszieltageskonto']);
    $this->app->Secure->POST['zahlungszielskonto'] = strtolower($arr[0]['zahlungszielskonto']);
    $this->app->Secure->POST['versandart'] = strtolower($arr[0]['versandart']);
/*
    foreach($field as $key=>$value)
    {
      $uparr[$value] = $arr[0][$value];
      $this->app->Secure->POST[$value] = $arr[0][$value];
    }
*/
    $this->app->DB->UpdateArr("angebot",$id,"id",$arr[0]);


    //standardprojekt
    //$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    //$this->app->Secure->POST[projekt] = $projekt;
  }


  function LoadGutschriftStandardwerte($id,$adresse)
  {
    if($id==0 || $id=="" || $adresse=="" || $adresse=="0") return;

    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
 $rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse' AND subjekt='Kunde' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

    if($rolle_projekt > 0)
    {
        $arr[0]['projekt'] = $rolle_projekt;
    }

    $field = array('name','abteilung','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','kundennummer','projekt');
    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!="" && 0)
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }


      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }

    $uparr[adresse] = $adresse;
    $uparr[ust_befreit] = $this->AdresseUSTCheck($adresse);
    $uparr[zahlungsstatusstatus]="offen";

    $this->app->DB->UpdateArr("gutschrift",$id,"id",$uparr);
    $uparr="";

//liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM kundevorlage WHERE adresse='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');

    if($arr[0]['zahlungsweise']=="")
      $arr[0]['zahlungsweise']="rechnung";

    if($arr[0]['zahlungszieltage']<=0)
      $arr[0]['zahlungszieltage']="14";

    $this->app->Secure->POST['zahlungsweise'] = strtolower($arr[0]['zahlungsweise']);
    $this->app->Secure->POST['zahlungszieltage'] = strtolower($arr[0]['zahlungszieltage']);
    $this->app->Secure->POST['zahlungszieltageskonto'] = strtolower($arr[0]['zahlungszieltageskonto']);
    $this->app->Secure->POST['zahlungszielskonto'] = strtolower($arr[0]['zahlungszielskonto']);
    $this->app->Secure->POST['versandart'] = strtolower($arr[0]['versandart']);
/*
    foreach($field as $key=>$value)
    {
      $uparr[$value] = $arr[0][$value];
      $this->app->Secure->POST[$value] = $arr[0][$value];
    }
*/
    $this->app->DB->UpdateArr("gutschrift",$id,"id",$arr[0]);


    //standardprojekt
    // $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse'  AND geloescht=0 LIMIT 1");
    // $this->app->Secure->POST[projekt] = $projekt;

  }



  function LoadRechnungStandardwerte($id,$adresse)
  {
    if($id==0 || $id=="" || $adresse=="" || $adresse=="0") return;

    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
 $rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse' AND subjekt='Kunde' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

    if($rolle_projekt > 0)
    {
        $arr[0]['projekt'] = $rolle_projekt;
    }
    $field = array('name','abteilung','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','kundennummer','projekt');

    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!=""&&0)
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }

      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }

    $uparr[adresse] = $adresse;
    $uparr[ust_befreit] = $this->AdresseUSTCheck($adresse);
    $uparr[zahlungsstatusstatus]="offen";

		if($this->Firmendaten("rechnung_ohnebriefpapier")=="1")
			$uparr[ohne_briefpapier] = "1";

    $this->app->DB->UpdateArr("rechnung",$id,"id",$uparr);
    $uparr="";

  //liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' LIMIT 1");
    $field = array('zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');

    if($arr[0]['zahlungsweise']=="")
      $arr[0]['zahlungsweise']="rechnung";

    if($arr[0]['zahlungszieltage']<=0)
      $arr[0]['zahlungszieltage']="14";

    $this->app->Secure->POST['zahlungsweise'] = strtolower($arr[0]['zahlungsweise']);
    $this->app->Secure->POST['zahlungszieltage'] = strtolower($arr[0]['zahlungszieltage']);
    $this->app->Secure->POST['zahlungszieltageskonto'] = strtolower($arr[0]['zahlungszieltageskonto']);
    $this->app->Secure->POST['zahlungszielskonto'] = strtolower($arr[0]['zahlungszielskonto']);
    $this->app->Secure->POST['versandart'] = strtolower($arr[0]['versandart']);
/*
    foreach($field as $key=>$value)
    {
      $uparr[$value] = $arr[0][$value];
      $this->app->Secure->POST[$value] = $arr[0][$value];
    }
*/
    $this->app->DB->UpdateArr("rechnung",$id,"id",$arr[0]);



    //standardprojekt
    // $projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse'  AND geloescht=0 LIMIT 1");
    // $this->app->Secure->POST[projekt] = $projekt;

  }



  function LoadBestellungStandardwerte($id,$adresse)
  {
    // standard adresse von lieferant       
    $arr = $this->app->DB->SelectArr("SELECT * FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
 $rolle_projekt = $this->app->DB->Select("SELECT parameter FROM adresse_rolle WHERE adresse='$adresse' AND subjekt='Lieferant' AND objekt='Projekt' AND (bis ='0000-00-00' OR bis <= NOW()) LIMIT 1");

    if($rolle_projekt > 0)
    {
        $arr[0]['projekt'] = $rolle_projekt;
    }
    $field = array('name','abteilung','unterabteilung','strasse','adresszusatz','plz','ort','land','ustid','email','telefon','telefax','lieferantennummer','projekt');
    foreach($field as $key=>$value)
    {
      if($value=="projekt" && $this->app->Secure->POST[$value]!=""&&0)
      {
	$uparr[$value] = $this->app->Secure->POST[$value];
      } else {
	$this->app->Secure->POST[$value] = $arr[0][$value];
	$uparr[$value] = $arr[0][$value];
      }
      //$this->app->Secure->POST[$value] = $arr[0][$value];
      //$uparr[$value] = $arr[0][$value];
    }
    $uparr[adresse] = $adresse;
    $this->app->DB->UpdateArr("bestellung",$id,"id",$uparr);
    $uparr="";

    //liefernantenvorlage
    $arr = $this->app->DB->SelectArr("SELECT 
      kundennummerlieferant as kundennummer,
      zahlungsweiselieferant as zahlungsweise,
      zahlungszieltagelieferant as zahlungszieltage,
      zahlungszieltageskontolieferant as zahlungszieltageskonto,
      zahlungszielskontolieferant as zahlungszielskonto,
      versandartlieferant as versandart
       FROM adresse WHERE id='$adresse' LIMIT 1");
    $field = array('kundennummer','zahlungsweise','zahlungszieltage','zahlungszieltageskonto','zahlungszielskonto','versandart');
    foreach($field as $key=>$value)
    {
      //$uparr[$value] = $arr[0][$value];
      $this->app->Secure->POST[$value] = $arr[0][$value];
    }


    $this->app->DB->UpdateArr("bestellung",$id,"id",$uparr);

    //standardprojekt
    //$projekt = $this->app->DB->Select("SELECT projekt FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    //$this->app->Secure->POST[projekt] = $projekt;
  }


  function CreateLieferschein($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM angebot WHERE firma='".$this->app->User->GetFirma()."'");
    //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $belegmax = 0;
		$ohnebriefpapier = $this->Firmendaten("lieferschein_ohnebriefpapier");
    $this->app->DB->Insert("INSERT INTO lieferschein (id,datum,bearbeiter,firma,belegnr,adresse,ohne_briefpapier) 
      VALUES ('',NOW(),'".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$belegmax','$adresse','".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }

  function AddLieferscheinPosition($lieferschein, $verkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    //$waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    //$vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM lieferschein_position WHERE angebot='$angebot' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO lieferschein_position (id,lieferschein,artikel,bezeichnung,nummer,menge,sort,lieferdatum,status,projekt,vpe) 
      VALUES ('','$lieferschein','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$sort','$datum','angelegt','$projekt','$vpe')");


echo ("INSERT INTO lieferschein_position (id,lieferschein,artikel,bezeichnung,nummer,menge,sort,lieferdatum,status,projekt,vpe) 
      VALUES ('','$lieferschein','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$sort','$datum','angelegt','$projekt','$vpe')");
  }


  function DeleteLieferschein($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM lieferschein_position WHERE lieferschein='$id'");
      $this->app->DB->Delete("DELETE FROM lieferschein_protokoll WHERE lieferschein='$id'");
      $this->app->DB->Delete("DELETE FROM lieferschein WHERE id='$id' LIMIT 1");
    }
  }



  function CreateProduktion($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM angebot WHERE firma='".$this->app->User->GetFirma()."'");
   //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $belegmax = 0;

    $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $this->app->DB->Insert("INSERT INTO produktion (id,datum,bearbeiter,firma,belegnr,autoversand,zahlungsweise,zahlungszieltage,status,projekt,adresse) 
      VALUES ('',NOW(),'".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$belegmax',1,'rechnung',14,'angelegt','$projekt','$adresse')");

    return $this->app->DB->GetInsertID();
  }


  function CreateAuftrag($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM angebot WHERE firma='".$this->app->User->GetFirma()."'");
   //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
		$ohnebriefpapier = $this->Firmendaten("auftrag_ohnebriefpapier");
    $belegmax = 0;

    $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $this->app->DB->Insert("INSERT INTO auftrag (id,datum,bearbeiter,firma,belegnr,autoversand,zahlungsweise,zahlungszieltage,status,projekt,adresse,ohne_briefpapier) 
      VALUES ('',NOW(),'".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$belegmax',1,'rechnung',14,'angelegt','$projekt','$adresse','".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }

  function AddAuftragPositionNummerPartnerprogramm($auftrag,$nummer,$menge,$projekt,$partner)
  {
    $artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1"); 
    // nur wenn artikel lager artikel und shop artikel fuer den partner und wenn artikel nicht gesperrt fuer partnerprogramm

    $check_partnerprogramm = $this->app->DB->Select("SELECT id FROM partner WHERE ref='$partner' AND projekt='$projekt' AND geloescht='0' LIMIT 1");

    $check_artikel = $this->app->DB->Select("SELECT partnerprogramm_sperre FROM artikel WHERE id='$artikel' LIMIT 1");


    $artikel_ok = $this->app->DB->Select("SELECT id FROM artikel WHERE id='$artikel' AND geloescht='0' AND projekt='$projekt' 
      AND porto='0' AND ( lagerartikel='1' OR juststueckliste='1' ) LIMIT 1");

    if(is_numeric($check_partnerprogramm) && $check_artikel==0 && $artikel_ok==$artikel)
    {
      $this->app->DB->Insert("INSERT INTO partner_verkauf (id,auftrag,artikel,menge,partner,freigabe,abgerechnet) 
	VALUES ('','$auftrag','$artikel','$menge','$partner',0,0)");
    }

  }
  

  function AddAuftragPositionNummer($auftrag,$nummer,$menge,$projekt,$nullpreis="",$taxfree=false,$typ="")
  {
    $artikel = $this->app->DB->Select("SELECT id FROM artikel WHERE nummer='$nummer' LIMIT 1"); 
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1"); 

   // $verkaufsid = $this->app->DB->Select("SELECT id FROM verkaufspreise WHERE artikel='$artikel' 
    //AND (gueltig_bis>=NOW() OR gueltig_bis='0000-00-00') AND ab_menge=1 AND geloescht=0 AND (adresse='0' OR adresse='') AND objekt='Standard' LIMIT 1"); 
    
     $verkaufsid = $this->app->DB->Select("SELECT id FROM verkaufspreise WHERE artikel='$artikel'                                             
                             AND (gueltig_bis='0000-00-00' OR gueltig_bis >=NOW()) AND ab_menge=1                                           
                                                     AND ((objekt='Standard' AND adresse=0) OR (objekt='' AND adresse=0)) AND geloescht=0 LIMIT 1");                   
                                                     
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkaufsid' LIMIT 1"); 

    if($nullpreis=="1")
      $preis = 0;

    // wenn mehr rein kam als geplant
    //if($taxfree==false)
    //{
      //$preis = $vkpreis;
      $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer FROM artikel WHERE id='$artikel' LIMIT 1");
    //} else {
    //  $umsatzsteuer = 0;
    //}

    $vpe  = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkaufsid' LIMIT 1"); 

   if($typ=="produktion")
    {
			$sort = $this->app->DB->Select("SELECT MAX(sort) FROM produktion_position WHERE produktion='$auftrag' LIMIT 1");
			$sort = $sort + 1;
			$this->app->DB->Insert("INSERT INTO produktion_position (id,produktion,artikel,bezeichnung,nummer,menge,preis, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$auftrag','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
		} else {
			$sort = $this->app->DB->Select("SELECT MAX(sort) FROM auftrag_position WHERE auftrag='$auftrag' LIMIT 1");
			$sort = $sort + 1;
			$this->app->DB->Insert("INSERT INTO auftrag_position (id,auftrag,artikel,bezeichnung,nummer,menge,preis, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$auftrag','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
		}

    return $this->app->DB->GetInsertID();
  }

  function AddAuftragPosition($auftrag, $verkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    //$waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer FROM artikel WHERE id='$artikel' LIMIT 1");
    //$vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM auftrag_position WHERE auftrag='$auftrag' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO auftrag_position (id,auftrag,artikel,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$auftrag','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }


  function DeleteProduktion($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM produktion_position WHERE produktion='$id'");
      $this->app->DB->Delete("DELETE FROM produktion_protokoll WHERE produktion='$id'");
      $this->app->DB->Delete("DELETE FROM produktion WHERE id='$id' LIMIT 1");
    }
  }

  function DeleteAuftrag($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM auftrag_position WHERE auftrag='$id'");
      $this->app->DB->Delete("DELETE FROM auftrag_protokoll WHERE auftrag='$id'");
      $this->app->DB->Delete("DELETE FROM auftrag WHERE id='$id' LIMIT 1");
    }
  }


  function CreateAngebot($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM angebot WHERE firma='".$this->app->User->GetFirma()."'");
    //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

		$ohnebriefpapier = $this->Firmendaten("angebot_ohnebriefpapier");
    $belegmax = 0;
    $this->app->DB->Insert("INSERT INTO angebot (id,datum,gueltigbis,bearbeiter,vertrieb,firma,belegnr,autoversand,zahlungsweise,zahlungszieltage,status,projekt,adresse,ohne_briefpapier ) 
      VALUES ('',NOW(),	DATE_ADD(curdate(), INTERVAL 28 DAY),'".$this->app->User->GetAdresse()."','".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$belegmax',1,'rechnung',14,'angelegt','$projekt','$adresse','".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }


  function AddAdressePosition($adresse, $verkauf,$menge,$datum)
  {
    $lieferdatum = $this->app->String->Convert($datum,"%1.%2.%3","%3-%2-%1");

    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $bezeichnung= $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer  FROM artikel WHERE id='$artikel' LIMIT 1");
    $vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM angebot_position WHERE angebot='$angebot' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO abrechnungsartikel (id,artikel,bezeichnung,nummer,menge,preis, sort,
					lieferdatum, steuerklasse, status,projekt,wiederholend,zahlzyklus,adresse,startdatum) 
         VALUES ('','$artikel','$bezeichnung','$bestellnummer','$menge','$preis','$sort','$lieferdatum',
				'$umsatzsteuer','angelegt','$projekt','$wiederholend','$zahlzyklus','$adresse','$startdatum')");

  }


  function AddAngebotPosition($angebot, $verkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $beschreibung = $this->app->DB->Select("SELECT anabregs_text FROM artikel WHERE id='$artikel' LIMIT 1"); 
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer  FROM artikel WHERE id='$artikel' LIMIT 1");
    $vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM angebot_position WHERE angebot='$angebot' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO angebot_position (id,angebot,artikel,beschreibung,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$angebot','$artikel','$beschreibung','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }




  function CopyBestellung($id)
  {
   // kopiere eintraege aus auftrag_position
    $this->app->DB->Insert("INSERT INTO bestellung (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,einkaeufer,zahlungsweise,zahlungszieltage,
      zahlungszieltageskonto,zahlungszielskonto,firma,'angelegt' as status,abweichendelieferadresse,liefername,lieferabteilung,lieferunterabteilung,
      lieferland,lieferstrasse,lieferort,lieferplz,lieferadresszusatz,lieferansprechpartner FROM bestellung WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("bestellung",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM bestellung_position WHERE bestellung='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO bestellung_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][bestellung]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("bestellung_position",$newposid,$pos[$i]);
      

      // vorraussichtliches lieferdatum anpassen TODO
    }
    $this->app->DB->Update("UPDATE bestellung_position SET geliefert=0, mengemanuellgeliefertaktiviert=0,abgeschlossen='0',abgerechnet='0' WHERE auftrag='$newid'");
    return $newid;
  }


  function CopyAuftrag($id)
  {
   // kopiere eintraege aus auftrag_position
    $this->app->DB->Insert("INSERT INTO auftrag (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,vertrieb,zahlungsweise,zahlungszieltage,
      zahlungszieltageskonto,zahlungszielskonto,firma,'angelegt' as status,abweichendelieferadresse,liefername,lieferabteilung,lieferunterabteilung,
      lieferland,lieferstrasse,lieferort,lieferplz,lieferadresszusatz,lieferansprechpartner,autoversand FROM auftrag WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("auftrag",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO auftrag_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][auftrag]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("auftrag_position",$newposid,$pos[$i]);
      

      // vorraussichtliches lieferdatum anpassen TODO
    }
    $this->app->DB->Update("UPDATE auftrag_position SET geliefert=0, geliefert_menge=0,explodiert='0',explodiert_parent='0' WHERE auftrag='$newid'");
    return $newid;
  }



  function CopyRechnung($id)
  {

   // kopiere eintraege aus rechnung_position
    $this->app->DB->Insert("INSERT INTO rechnung (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt,auftrag,auftragid,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,bearbeiter,
      firma FROM rechnung WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("rechnung",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM rechnung_position WHERE rechnung='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO rechnung_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][rechnung]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("rechnung_position",$newposid,$pos[$i]);

      // vorraussichtliches lieferdatum anpassen TODO
    }
    return $newid;
  }


  function CopyLieferschein($id)
  {

   // kopiere eintraege aus lieferschein_position
    $this->app->DB->Insert("INSERT INTO lieferschein (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt,auftrag,auftragid,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,bearbeiter,
      firma FROM lieferschein WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("lieferschein",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM lieferschein_position WHERE lieferschein='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO lieferschein_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][lieferschein]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("lieferschein_position",$newposid,$pos[$i]);

      // vorraussichtliches lieferdatum anpassen TODO
    }
    $this->app->DB->Update("UPDATE lieferschein_position SET geliefert=0, abgerechnet=0 WHERE lieferschein='$id'");
       
    return $newid;
  }


  function CopyAngebot($id)
  {

   // kopiere eintraege aus angebot_position
    $this->app->DB->Insert("INSERT INTO angebot (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt,anfrage,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,vertrieb,zahlungsweise,zahlungszieltage,
      zahlungszieltageskonto,zahlungszielskonto,firma FROM angebot WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("angebot",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM angebot_position WHERE angebot='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO angebot_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][angebot]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("angebot_position",$newposid,$pos[$i]);

      // vorraussichtliches lieferdatum anpassen TODO

    }
    $this->app->DB->Update("UPDATE angebot_position SET geliefert=0 WHERE angebot='$id'");
    return $newid;
  }

  function WeiterfuehrenAuftragZuLieferschein($id)
  {
    //angebot aus offene Angebote entfernen 
    $this->app->DB->Insert("INSERT INTO lieferschein (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT datum,projekt,belegnr as auftrag,freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,ansprechpartner,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,vertrieb,zahlungsweise,zahlungszieltage, id as auftragid,
      zahlungszieltageskonto,zahlungszielskonto,firma FROM auftrag WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("lieferschein",$newid,$arr[0]);

    $this->app->DB->Update("UPDATE lieferschein SET datum=NOW() WHERE id='$newid' LIMIT 1");

    $abweichendelieferadresse = $this->app->DB->Select("SELECT abweichendelieferadresse FROM auftrag WHERE id='$id' LIMIT 1");
    $tmparrliefer = $this->app->DB->SelectArr("SELECT * FROM auftrag WHERE id='$id' LIMIT 1");
    $versandart = $this->app->DB->Select("SELECT versandart FROM auftrag WHERE id='$id' LIMIT 1");

    //lieferadresse wenn abweichend!!!!
    if($abweichendelieferadresse && $versandart!="packstation")
    {
      //liefername  lieferland	lieferstrasse	lieferort   lieferplz	lieferadresszusatz 
      $this->app->DB->Update("UPDATE lieferschein SET name='{$tmparrliefer[0][liefername]}', abteilung='{$tmparrliefer[0][lieferabteilung]}',
	unterabteilung='{$tmparrliefer[0][lieferunterabteilung]}',strasse='{$tmparrliefer[0][lieferstrasse]}', 
	adresszusatz='{$tmparrliefer[0][lieferadresszusatz]}', plz='{$tmparrliefer[0][lieferplz]}',ort='{$tmparrliefer[0][lieferort]}',land='{$tmparrliefer[0][lieferland]}',ansprechpartner='{$tmparrliefer[0][lieferansprechpartner]}' WHERE id='$newid' LIMIT 1");
    }

    //lieferadresse wenn packstation
    if($versandart=="packstation")
    {
      //packstation_inhaber   packstation_station	  packstation_ident   packstation_plz	packstation_ort	  
      $this->app->DB->Update("UPDATE lieferschein SET name='{$tmparrliefer[0][packstation_inhaber]}', unterabteilung='',strasse='Packstation Nr. {$tmparrliefer[0][packstation_station]}', adresszusatz='{$tmparrliefer[0][packstation_ident]}', 
	plz='{$tmparrliefer[0][packstation_plz]}',ort='{$tmparrliefer[0][packstation_ort]}' WHERE id='$newid' LIMIT 1");
    }


    $pos = $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id'");
    for($i=0;$i<count($pos);$i++){

      /* nur lager artikel in den Lieferschein */
      $portoartikel = $this->app->DB->Select("SELECT porto FROM artikel WHERE id='{$pos[$i][artikel]}' LIMIT 1");

      if($portoartikel==0)
      {
				$this->app->DB->Insert("INSERT INTO lieferschein_position (id) VALUES('')");
				$newposid = $this->app->DB->GetInsertID();
				$pos[$i][lieferschein]=$newid;
				if($pos[$i][explodiert]) $pos[$i][bezeichnung] = $pos[$i][bezeichnung]." (Stückliste)";
				if($pos[$i][explodiert_parent]) $pos[$i][bezeichnung] = "-".$pos[$i][bezeichnung];
				$this->app->FormHandler->ArrayUpdateDatabase("lieferschein_position",$newposid,$pos[$i]);
      }

    }
    $this->app->DB->Update("UPDATE auftrag SET status='abgeschlossen' WHERE id='$id' LIMIT 1");

    // auftrag freigeben!!!

    return $newid;
  }

  function WeiterfuehrenRechnungZuGutschrift($id)
  {
    //angebot aus offene Angebote entfernen 
    $this->app->DB->Insert("INSERT INTO gutschrift (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum,projekt, belegnr as rechnung,
      freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,zahlungsweise,zahlungszieltage,ust_befreit, keinsteuersatz, id as rechnungid,
      zahlungszieltageskonto,zahlungszielskonto,firma FROM rechnung WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("gutschrift",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM rechnung_position WHERE rechnung='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO gutschrift_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][gutschrift]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("gutschrift_position",$newposid,$pos[$i]);
    }

    // wenn auftrag vorkasse rechnung als bezahlt markieren wenn genug geld vorhanden
 //   $this->GutschriftNeuberechnen($newid);

/*
    //summe zahlungseingaenge
    $summe_zahlungseingaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$id' AND firma='".$this->app->User->GetFirma()."'");
    $rechnungssumme = $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$newid' LIMIT 1");

    //if(($arr[0][zahlungsweise]=="vorkasse" || $arr[0][zahlungsweise]=="paypal" || $arr[0][zahlungsweise]=="kreditkarte") &&  $summe_zahlungseingaenge >= $rechnungssumme)
    if($summe_zahlungseingaenge >= $rechnungssumme)
    {

      if($summe_zahlungseingaenge >= $rechnungssumme) 
	$this->app->DB->Update("UPDATE rechnung SET ist=soll, zahlungsstatus='bezahlt' WHERE id='$newid' AND firma='".$this->app->User->GetFirma()."'");
      else
	$this->app->DB->Update("UPDATE rechnung SET ist='$summe_zahlungseingaenge', zahlungsstatus='' WHERE id='$newid' AND firma='".$this->app->User->GetFirma()."'");
    }  // was ist denn bei rechnung bar oder nachnahme wenn ein auftragsguthaben vorhanden ist

    $this->app->DB->Update("UPDATE auftrag SET status='abgeschlossen' WHERE id='$id' LIMIT 1");

    // auftrag freigeben!!!
*/
    return $newid;
  }


  function WeiterfuehrenAuftragZuRechnung($id)
  {
    //angebot aus offene Angebote entfernen 
    $this->app->DB->Insert("INSERT INTO rechnung (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();
    $arr = $this->app->DB->SelectArr("SELECT datum,projekt,gesamtsumme as soll, belegnr as auftrag, id as auftragid,
      freitext,adresse,name,abteilung,unterabteilung,ansprechpartner,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,vertrieb,zahlungsweise,zahlungszieltage,ust_befreit,keinsteuersatz,
      zahlungszieltageskonto,zahlungszielskonto,firma FROM auftrag WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("rechnung",$newid,$arr[0]);

    $this->app->DB->Update("UPDATE rechnung SET datum=NOW() WHERE id='$newid' LIMIT 1");

    $pos = $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO rechnung_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][rechnung]=$newid;

			if($pos[$i][explodiert]) $pos[$i][bezeichnung] = $pos[$i][bezeichnung]." (Stückliste)";
			if($pos[$i][explodiert_parent]) $pos[$i][bezeichnung] = "-".$pos[$i][bezeichnung];

      $this->app->FormHandler->ArrayUpdateDatabase("rechnung_position",$newposid,$pos[$i]);
    }

    // wenn auftrag vorkasse rechnung als bezahlt markieren wenn genug geld vorhanden
    $this->RechnungNeuberechnen($newid);
    //summe zahlungseingaenge
    $summe_zahlungseingaenge = $this->app->DB->Select("SELECT SUM(betrag) FROM kontoauszuege_zahlungseingang WHERE objekt='auftrag' AND parameter='$id' AND firma='".$this->app->User->GetFirma()."'");
    $rechnungssumme = $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$newid' LIMIT 1");

    //if(($arr[0][zahlungsweise]=="vorkasse" || $arr[0][zahlungsweise]=="paypal" || $arr[0][zahlungsweise]=="kreditkarte") &&  $summe_zahlungseingaenge >= $rechnungssumme)
    if($summe_zahlungseingaenge >= $rechnungssumme)
    {

      if($summe_zahlungseingaenge >= $rechnungssumme) 
	$this->app->DB->Update("UPDATE rechnung SET ist=soll, zahlungsstatus='bezahlt' WHERE id='$newid' AND firma='".$this->app->User->GetFirma()."'");
      else
	$this->app->DB->Update("UPDATE rechnung SET ist='$summe_zahlungseingaenge', zahlungsstatus='' WHERE id='$newid' AND firma='".$this->app->User->GetFirma()."'");
    }  // was ist denn bei rechnung bar oder nachnahme wenn ein auftragsguthaben vorhanden ist

    $this->app->DB->Update("UPDATE auftrag SET status='abgeschlossen' WHERE id='$id' LIMIT 1");

    // auftrag freigeben!!!

    return $newid;
  }

  function WeiterfuehrenAngebotZuAuftrag($id)
  {
    //angebot aus offene Angebote entfernen 
    $this->app->DB->Insert("INSERT INTO auftrag (id) VALUES ('')");
    $newid = $this->app->DB->GetInsertID();

    $arr = $this->app->DB->SelectArr("SELECT NOW() as datum, projekt,belegnr as angebot,
	freitext,adresse,name,abteilung,unterabteilung,strasse,adresszusatz,plz,ort,land,ustid,email,telefon,telefax,betreff,kundennummer,versandart,vertrieb,zahlungsweise,zahlungszieltage, id as angebotid,
      zahlungszieltageskonto,zahlungszielskonto,firma,abweichendelieferadresse,liefername,lieferabteilung,lieferunterabteilung,lieferland,lieferstrasse,lieferort,
      lieferplz,lieferadresszusatz,lieferansprechpartner,ust_befreit,keinsteuersatz,autoversand,keinporto,'angelegt' as status FROM angebot WHERE id='$id' LIMIT 1");
    $this->app->FormHandler->ArrayUpdateDatabase("auftrag",$newid,$arr[0]);

    $pos = $this->app->DB->SelectArr("SELECT * FROM angebot_position WHERE angebot='$id'");
    for($i=0;$i<count($pos);$i++){
      $this->app->DB->Insert("INSERT INTO auftrag_position (id) VALUES('')");
      $newposid = $this->app->DB->GetInsertID();
      $pos[$i][auftrag]=$newid;
      $this->app->FormHandler->ArrayUpdateDatabase("auftrag_position",$newposid,$pos[$i]);
    }

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$newid' LIMIT 1");
    $this->app->DB->Update("UPDATE angebot SET status='beauftragt', auftrag='$belegnr' WHERE id='$id' LIMIT 1");

    // auftrag freigeben!!!

    return $newid;
  }

  function DeleteAngebot($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM angebot_position WHERE angebot='$id'");
      $this->app->DB->Delete("DELETE FROM angebot_protokoll WHERE angebot='$id'");
      $this->app->DB->Delete("DELETE FROM angebot WHERE id='$id' LIMIT 1");
    }
  }


  function PaketannahmenAbschliessen()
  {
    $arr = $this->app->DB->SelectArr("SELECT id FROM paketannahme WHERE status!='abgeschlossen'"); 
    for($i=0;$i<count($arr);$i++)
    {


    }
  }

  function CreateBestellung($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM bestellung WHERE firma='".$this->app->User->GetFirma()."'");
    //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $belegmax = 0;
		$ohnebriefpapier = $this->Firmendaten("bestellung_ohnebriefpapier");

    $this->app->DB->Insert("INSERT INTO bestellung (id,datum,bearbeiter,firma,belegnr,adresse,status,artikelnummerninfotext,ohne_briefpapier) 
      VALUES ('',NOW(),'".$this->app->User->GetAdresse()."','".$this->app->User->GetFirma()."','$belegmax','$adresse','angelegt',1,'".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }

  function AddBestellungPosition($bestellung, $einkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $bezeichnunglieferant = $this->app->DB->Select("SELECT bezeichnunglieferant	FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $bestellnummer = $this->app->DB->Select("SELECT bestellnummer FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $preis = $this->app->DB->Select("SELECT preis FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $projekt = $this->app->DB->Select("SELECT projekt FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer	FROM artikel WHERE id='$artikel' LIMIT 1");
    if($umsatzsteuer=="") $umsatzsteuer="normal";
    $vpe = $this->app->DB->Select("SELECT vpe FROM einkaufspreise WHERE id='$einkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM bestellung_position WHERE bestellung='$bestellung' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO bestellung_position (id,bestellung,artikel,bezeichnunglieferant,bestellnummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$bestellung','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }


  function DeleteBestellung($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM bestellung WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM bestellung_position WHERE bestellung='$id'");
      $this->app->DB->Delete("DELETE FROM bestellung_protokoll WHERE bestellung='$id'");
      $this->app->DB->Delete("DELETE FROM bestellung WHERE id='$id' LIMIT 1");
    }
  }


  function CreateRechnung($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM bestellung WHERE firma='".$this->app->User->GetFirma()."'");
    //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $belegmax = 0;

		$ohnebriefpapier = $this->Firmendaten("rechnung_ohnebriefpapier");
    $this->app->DB->Insert("INSERT INTO rechnung (id,datum,bearbeiter,firma,belegnr,zahlungsweise,zahlungszieltage,status,projekt,adresse,auftragid,ohne_briefpapier) 
      VALUES ('',NOW(),'".$this->app->User->GetAdresse()."','".$this->app->User->GetFirma()."','$belegmax','rechnung',14,'angelegt','$projekt','$adresse',0,'".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }


  function CreateGutschrift($adresse="")
  {
    //$belegmax = $this->app->DB->Select("SELECT MAX(belegnr) FROM bestellung WHERE firma='".$this->app->User->GetFirma()."'");
    //if($belegmax==0) $belegmax = 10000;  else $belegmax++;
    $projekt = $this->app->DB->Select("SELECT standardprojekt FROM firma WHERE id='".$this->app->User->GetFirma()."' LIMIT 1");

    $belegmax = 0;
		$ohnebriefpapier = $this->Firmendaten("gutschrift_ohnebriefpapier");

    $this->app->DB->Insert("INSERT INTO gutschrift (id,datum,bearbeiter,firma,belegnr,zahlungsweise,zahlungszieltage,status,projekt,adresse,ohne_briefpapier) 
      VALUES ('',NOW(),'".$this->app->User->GetName()."','".$this->app->User->GetFirma()."','$belegmax','rechnung',14,'angelegt','$projekt','$adresse','".$ohnebriefpapier."')");

    return $this->app->DB->GetInsertID();
  }


  function AddGutschritPosition($gutschrift, $verkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer  FROM artikel WHERE id='$artikel' LIMIT 1");
    $vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM gutschrift_position WHERE rechnung='$gutschrift' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO gutschrift_position (id,gutschrift,artikel,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$gutschrift','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }


  function AddRechnungPositionManuell($rechnung, $artikel,$preis, $menge,$bezeichnung)
  {
    $bezeichnunglieferant = $bezeichnung;
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM artikel WHERE id='$artikel' LIMIT 1");
    //$waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $waehrung='EUR';
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer  FROM artikel WHERE id='$artikel' LIMIT 1");
    //$vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM rechnung_position WHERE rechnung='$rechnung' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO rechnung_position (id,rechnung,artikel,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$rechnung','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }



  function AddRechnungPosition($rechnung, $verkauf,$menge,$datum)
  {
    $artikel = $this->app->DB->Select("SELECT artikel FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $bezeichnunglieferant = $this->app->DB->Select("SELECT name_de FROM artikel WHERE id='$artikel' LIMIT 1");
    $bestellnummer = $this->app->DB->Select("SELECT nummer FROM artikel WHERE id='$artikel' LIMIT 1");
    $preis = $this->app->DB->Select("SELECT preis FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM verkaufspreise WHERE id='$verkauf' LIMIT 1");
    $waehrung = $this->app->DB->Select("SELECT waehrung FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $umsatzsteuer = $this->app->DB->Select("SELECT umsatzsteuer FROM artikel WHERE id='$artikel' LIMIT 1");
    $vpe = $this->app->DB->Select("SELECT vpe FROM verkaufspreise WHERE id='$verkauf' LIMIT 1"); 
    $sort = $this->app->DB->Select("SELECT MAX(sort) FROM rechnung_position WHERE rechnung='$rechnung' LIMIT 1");
    $sort = $sort + 1;
    $this->app->DB->Insert("INSERT INTO rechnung_position (id,rechnung,artikel,bezeichnung,nummer,menge,preis, waehrung, sort,lieferdatum, umsatzsteuer, status,projekt,vpe) 
      VALUES ('','$rechnung','$artikel','$bezeichnunglieferant','$bestellnummer','$menge','$preis','$waehrung','$sort','$datum','$umsatzsteuer','angelegt','$projekt','$vpe')");
  }

	function AuftragReservieren($id)
	{

		$id_check = $this->app->DB->Select("SELECT id FROM auftrag WHERE status!='storniert' AND status!='abgeschlossen' AND id='$id' LIMIT 1");

		// nicht reservieren wenn auftrag nicht offen ist
		if($id_check!=$id)
			return 0;

 		$artikelarr= $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id' AND geliefert!=1");

    $adresse = $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$id' LIMIT 1");
    $projekt = $this->app->DB->Select("SELECT projekt FROM auftrag WHERE id='$id' LIMIT 1");
    $belegnr= $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");

    //schaue artikel fuer artikel an wieviel geliefert wurde und ob bereits reservierungen vorliegen, wenn welche vorliegen auch reservieren auf 9999-01-01
    // Lager Check
    //echo "{$auftraege[0][internet]} Adresse:$adresse Auftrag $auftrag";
    for($k=0;$k<count($artikelarr); $k++)
    { 
      $menge = $artikelarr[$k][menge] - $artikelarr[$k][gelieferte_menge];
      $artikel = $artikelarr[$k][artikel];
      // pruefe artikel 12 menge 4
      $lagerartikel = $this->app->DB->Select("SELECT lagerartikel FROM artikel WHERE id='{$artikelarr[$k][artikel]}' LIMIT 1");
      //if($artikelarr[$k][nummer]!="200000" && $artikelarr[$k][nummer]!="200001")
      if($lagerartikel>=1)
      {
   
        	$anzahl_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert 
					 WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND objekt='auftrag' AND parameter='$id'");

					$zu_reservieren = $menge - $anzahl_reserviert;	

					if($zu_reservieren>0)
					{
					$this->app->DB->Insert("INSERT INTO lager_reserviert (id,adresse,artikel,menge,grund,projekt,firma,bearbeiter,datum,objekt,parameter)
        	VALUES('','$adresse','$artikel','$zu_reservieren','Auftrag f&uuml;r Auftrag $belegnr','$projekt',
        		'".$this->app->User->GetFirma()."','".$this->app->User->GetName()."','999-99-99','auftrag','$id')");
					}
/*
        //$this->app->erp->LagerCheck($adresse,$artikel,$menge)>0)
        $anzahl_lager = $this->app->DB->Select("SELECT SUM(menge) FROM lager_platz_inhalt WHERE artikel='$artikel'");
        $anzahl_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert 
						WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND datum>=NOW() AND objekt!='lieferschein'");

        $artikel_fuer_adresse_reserviert = $this->app->DB->Select("SELECT SUM(menge) FROM lager_reserviert WHERE 
							artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");

        //erstmal die bestehenden reservierungen fuer auftrag uebernehmen
        if($artikel_fuer_adresse_reserviert >0)
        {
          //reservierung anpassen an Artikel f&uuml;r Auftrag ....
          $this->app->DB->Update("UPDATE lager_reserviert  SET datum='9999-01-01' 
							WHERE artikel='".$artikel."' AND firma='".$this->app->User->GetFirma()."' AND adresse='$adresse' AND datum>=NOW() AND objekt!='lieferschein'");
  			}
*/
/*
      //ermittle menge der noch zu reserviernden artikel
      $reservierende_menge = $menge - $artikel_fuer_adresse_reserviert;

      //schauen ob lager - alle reservierungen noch reicht
      if( ($anzahl_lager - $anzahl_reserviert) >0)
      {
        if(($anzahl_lager - $anzahl_reserviert) <= $reservierende_menge)
          $menge = $anzahl_lager - $anzahl_reserviert;
        else
          $menge = $reservierende_menge;

      $this->app->DB->Insert("INSERT INTO lager_reserviert (id,adresse,artikel,menge,grund,projekt,firma,bearbeiter,datum)
        VALUES('','$adresse','$artikel','$menge','Auftrag f&uuml;r Auftrag $belegnr','$projekt',
        '".$this->app->User->GetFirma()."','".$this->app->User->GetName()."','999-99-99')");
      }
*/
      }
    }
	}
	


  function AuftragNeuberechnenAllen()
  {
    $arrAuftrag = $this->app->DB->SelectArr("SELECT id FROM auftrag WHERE status!='abgeschlossen' AND status!='storniert' order by datum");

    for($i=0;$i < count($arrAuftrag); $i++)
    {
      $this->AuftragNeuberechnen($arrAuftrag[$i][id]);
    }   
  }

  function BestellungNeuberechnen($id)
  {

    $belegnr = $this->app->DB->Select("SELECT belegnr FROM bestellung  WHERE id='$id' LIMIT 1");
    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM bestellung_position WHERE umsatzsteuer!='ermaessigt' AND bestellung='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM bestellung_position WHERE umsatzsteuer='ermaessigt' AND bestellung='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM bestellung_position WHERE bestellung='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM bestellung WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
	$rechnungsbetrag = $summeNetto;
      } else {
	$rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE bestellung SET gesamtsumme='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }

  }


  function AngebotNeuberechnen($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE umsatzsteuer!='ermaessigt' AND angebot='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE umsatzsteuer='ermaessigt' AND angebot='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM angebot WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
	$rechnungsbetrag = $summeNetto;
      } else {
	$rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE angebot SET gesamtsumme='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }
  }


  function ProduktionNeuberechnen($id)
  {
		if($this->app->Conf->WFdbType=="postgre") {
			if(is_numeric($id)) {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE umsatzsteuer!='ermaessigt' AND produktion='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE umsatzsteuer='ermaessigt' AND produktion='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE produktion='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
	$rechnungsbetrag = $summeNetto;
      } else {
	$rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE produktion SET gesamtsumme='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }
		}
		} else {
		$belegnr = $this->app->DB->Select("SELECT belegnr FROM produktion WHERE id='$id' LIMIT 1");
    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE umsatzsteuer!='ermaessigt' AND produktion='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE umsatzsteuer='ermaessigt' AND produktion='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM produktion_position WHERE produktion='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM produktion WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
  $rechnungsbetrag = $summeNetto;
      } else {
  $rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE produktion SET gesamtsumme='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }	
		}
  }



  function AuftragNeuberechnen($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE umsatzsteuer!='ermaessigt' AND auftrag='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE umsatzsteuer='ermaessigt' AND auftrag='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM auftrag WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
	$rechnungsbetrag = $summeNetto;
      } else {
	$rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE auftrag SET gesamtsumme='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }
  }



  function GutschriftNeuberechnen($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM gutschrift WHERE id='$id' LIMIT 1");
    $adresse =  $this->app->DB->Select("SELECT adresse FROM gutschrift WHERE id='$id' LIMIT 1");
//    $ust_befreit = $this->AdresseUSTCheck($adresse);
 //   $this->app->DB->Update("UPDATE gutschrift SET ust_befreit='$ust_befreit' WHERE id='$id' LIMIT 1");


    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE umsatzsteuer!='ermaessigt' AND gutschrift='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE umsatzsteuer='ermaessigt' AND gutschrift='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE gutschrift='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM gutschrift WHERE id='$id' LIMIT 1");
      if($ust_befreit>0)
      {
	$gutschriftsbetrag = $summeNetto;
      } else {
	$gutschriftsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE gutschrift SET soll='$gutschriftsbetrag' WHERE id='$id' LIMIT 1");
    }
  }


  function DeleteGutschrift($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM gutschrift WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM gutschrift_position WHERE gutschrift='$id'");
      $this->app->DB->Delete("DELETE FROM gutschrift_protokoll WHERE gutschrift='$id'");
      $this->app->DB->Delete("DELETE FROM gutschrift WHERE id='$id' LIMIT 1");
    }
  }

  function RechnungNeuberechnen($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$id' LIMIT 1");
    $adresse =  $this->app->DB->Select("SELECT adresse FROM rechnung WHERE id='$id' LIMIT 1");
    //$ust_befreit = $this->AdresseUSTCheck($adresse);
    //$this->app->DB->Update("UPDATE rechnung SET ust_befreit='$ust_befreit' WHERE id='$id' LIMIT 1");


    //if(!is_numeric($belegnr) || $belegnr==0)
    {
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE umsatzsteuer!='ermaessigt' AND rechnung='$id'");
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE umsatzsteuer='ermaessigt' AND rechnung='$id'");

      $summeNetto = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE rechnung='$id'");

      $ust_befreit = $this->app->DB->Select("SELECT ust_befreit FROM rechnung WHERE id='$id' LIMIT 1");

      if($ust_befreit>0)
      {
	$rechnungsbetrag = $summeNetto;
      } else {
	$rechnungsbetrag = $summeNetto + ($summeV*1.19-$summeV)+ ($summeR*1.07-$summeR);
      }
      $this->app->DB->Update("UPDATE rechnung SET soll='$rechnungsbetrag' WHERE id='$id' LIMIT 1");
    }
  }


  function DeleteRechnung($id)
  {
    $belegnr = $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$id' LIMIT 1");
    if(!is_numeric($belegnr) || $belegnr==0)
    {
      $this->app->DB->Delete("DELETE FROM rechnung_position WHERE rechnung='$id'");
      $this->app->DB->Delete("DELETE FROM rechnung_protokoll WHERE rechnung='$id'");
      $this->app->DB->Delete("DELETE FROM rechnung WHERE id='$id' LIMIT 1");
    }
  }


  function GetUserKalender($adresse)
  {
    return $this->app->DB->SelectArr("SELECT id, name, farbe FROM kalender WHERE id IN (SELECT kalender FROM kalender_user WHERE adresse = $adresse);");
  }

  function GetAllKalender($adresse="")
  {
    return $this->app->DB->SelectArr("SELECT id, name, farbe".($adresse!=""?", IFNULL((SELECT 1 FROM kalender_user WHERE adresse=$adresse AND kalender_user.kalender=kalender.id),0) zugriff":"")." FROM kalender;");
  }
  
  function GetUserKalenderIds($adresse)
  {
    $arr = array();
    foreach ($this->GetUserKalender($adresse) as $value)
      array_push($arr,$value["id"]);
    return $arr;
  }

  function GetAllKalenderIds($adresse="")
  {
    $arr = array();
    foreach ($this->GetAllKalender($adresse) as $value)
      array_push($arr,$value["id"]);
    return $arr;
  }
  
  function GetKalenderSelect($adresse,$selectedKalender=array())
  {
    $arr = $this->GetUserKalender($adresse);
    foreach($arr as $value)
    { 
      $tmp = (in_array($value["id"],$selectedKalender))?" selected=\"selected\"":"";
      $ret .= "<option value=\"".$value["id"]."\"$tmp>".$value["name"]."</option>";
    }
    return $ret;
  }

  function GetKwSelect($selectedKW="")
  {
    foreach(range(1,52) as $kw)
    { 
      $tmp = ($selectedKW==$kw)?" selected=\"selected\"":"";
      $ret .= "<option value=\"$kw\"$tmp>$kw</option>";
    }
    return $ret;
  }

  function GetYearSelect($selectedYear="", $yearsBefore=2, $yearsAfter=10)
  {
    foreach(range(date("Y")-$yearsBefore, date("Y")+$yearsAfter) as $year)
    { 
      $tmp = ($selectedYear==$year)?" selected=\"selected\"":"";
      $ret .= "<option value=\"$year\"$tmp>$year</option>";
    }
    return $ret;
  }

  function CreateDateiOhneInitialeVersion($titel,$beschreibung,$nummer,$ersteller,$without_log=false)
  {
    if(!$without_log)
    {
      $this->app->DB->Insert("INSERT INTO datei (id,titel,beschreibung,nummer,firma) VALUES
        ('','$titel','$beschreibung','$nummer','".$this->app->User->GetFirma()."')");
    } else {
      $this->app->DB->InsertWithoutLog("INSERT INTO datei (id,titel,beschreibung,nummer,firma) VALUES
        ('','$titel','$beschreibung','$nummer',1)");
    }

    $fileid = $this->app->DB->GetInsertID();
    //$this->AddDateiVersion($fileid,$ersteller,$name,"Initiale Version",$datei,$without_log);

    return  $fileid;
  }


  function CreateDatei($name,$titel,$beschreibung,$nummer,$datei,$ersteller,$without_log=false,$path="")
  {
    if(!$without_log)
    {
      $this->app->DB->Insert("INSERT INTO datei (id,titel,beschreibung,nummer,firma) VALUES
        ('','$titel','$beschreibung','$nummer','".$this->app->User->GetFirma()."')");
    } else {
      $this->app->DB->InsertWithoutLog("INSERT INTO datei (id,titel,beschreibung,nummer,firma) VALUES
        ('','$titel','$beschreibung','$nummer',1)");
    }

    $fileid = $this->app->DB->GetInsertID();
    $this->AddDateiVersion($fileid,$ersteller,$name,"Initiale Version",$datei,$without_log,$path);

    return  $fileid;
  }

  function AddDateiVersion($id,$ersteller,$dateiname, $bemerkung,$datei,$without_log=false,$path="")
  {
    // ermittle neue Version
    $version = $this->app->DB->Select("SELECT COUNT(id) FROM datei_version WHERE datei='$id'") + 1;

    // speichere werte ab 
    if(!$without_log)
    {
      $this->app->DB->Insert("INSERT INTO datei_version (id,datei,ersteller,datum,version,dateiname,bemerkung)
        VALUES ('','$id','$ersteller',NOW(),'$version','$dateiname','$bemerkung')");
    } else {
      $this->app->DB->InsertWithoutLog("INSERT INTO datei_version (id,datei,ersteller,datum,version,dateiname,bemerkung)
        VALUES ('','$id','$ersteller',NOW(),'$version','$dateiname','$bemerkung')");
    }
    $versionid = $this->app->DB->GetInsertID();

    //TODO Das ist keine lösung!
//    if($this->app->Conf->WFdbname=="")
//      $this->app->Conf->WFdbname="wawision";

    // Pfad anpassen
    if($path=="")
    {
    $path = str_replace("www/index.php", "", $_SERVER['SCRIPT_FILENAME']);
    $path = $path."userdata/dms/";
    $path_only = $path;
    $path = $path.$this->app->Conf->WFdbname;
    }  else { $path_only = $path;  }
    
    if(!is_dir($path))
    {
    
       $path_b = $path;
       if (substr(trim($path), -1) == DIRECTORY_SEPARATOR) {
        $path = substr(trim($path), 0, -1);
       }
        
      system("chmod 777 ".$path);
      $path = $path_b;
      system("mkdir ".$path);
      system("chmod 777 ".$path);
    }

    if(is_file($datei))
    {
      copy($datei,$path."/".$versionid);
    }
    else if(is_uploaded_file($datei))
      move_uploaded_file($datei,$path."/".$versionid);
    else {
      // ACHTUNG !!!! ANGRIFFSGEFAHR!!!!!
      $handle = fopen ($path."/".$versionid, "wb");
      fwrite($handle, $datei);
      fclose($handle);
    }
  }


  function AddDateiStichwort($id,$subjekt,$objekt,$parameter,$without_log=false)
  {
    if(!$without_log)
    {
      $this->app->DB->Insert("INSERT INTO datei_stichwoerter (id,datei,subjekt,objekt,parameter)
        VALUES ('','$id','$subjekt','$objekt','$parameter')");
    } else {
      $this->app->DB->InsertWithoutLog("INSERT INTO datei_stichwoerter (id,datei,subjekt,objekt,parameter)
        VALUES ('','$id','$subjekt','$objekt','$parameter')");
    }
  }

  function GetDateiName($id)
  {
    $version = $this->app->DB->Select("SELECT MAX(version) FROM datei_version WHERE datei='$id'");
    $newid = $this->app->DB->Select("SELECT dateiname FROM datei_version WHERE datei='$id' AND version='$version' LIMIT 1");

    return $newid;
  }

  function GetDateiPfad($id)
  {
    $version = $this->app->DB->Select("SELECT MAX(version) FROM datei_version WHERE datei='$id'");
    $newid = $this->app->DB->Select("SELECT id FROM datei_version WHERE datei='$id' AND version='$version' LIMIT 1");

    $path = "../userdata/dms/".$this->app->Conf->WFdbname."/".$newid;
    return $path;
  }


  function GetDatei($id)
  {
    $version = $this->app->DB->Select("SELECT MAX(version) FROM datei_version WHERE datei='$id'");
    $newid = $this->app->DB->Select("SELECT id FROM datei_version WHERE datei='$id' AND version='$version' LIMIT 1");
 
    $path = "../userdata/dms/".$this->app->Conf->WFdbname."/".$newid;

    return file_get_contents($path); 
  }

  function GetDateiSize($id) {
    $version = $this->app->DB->Select("SELECT MAX(version) FROM datei_version WHERE datei='$id'");
    $newid = $this->app->DB->Select("SELECT id FROM datei_version WHERE datei='$id' AND version='$version' LIMIT 1");
    $name = $this->app->DB->Select("SELECT dateiname FROM datei_version WHERE id='$newid' LIMIT 1");

    $path = "../userdata/dms/".$this->app->Conf->WFdbname."/".$newid;

    $size = filesize($path);

    if($size <= 1024)
      return $size." Byte";
    else if($size <= 1024*1024)
      return number_format(($size/1024),2)." KB"; 
    else
      return number_format(($size/1024/1024),2)." MB"; 

  }



  function SendDatei($id,$versionid="") {
    session_write_close();
    ob_end_clean();

    
    set_time_limit(0);
    $version = $this->app->DB->Select("SELECT MAX(version) FROM datei_version WHERE datei='$id'");
    $newid = $this->app->DB->Select("SELECT id FROM datei_version WHERE datei='$id' AND version='$version' LIMIT 1");

    if($versionid>0)
      $newid = $versionid;

    $name = $this->app->DB->Select("SELECT dateiname FROM datei_version WHERE id='$newid' LIMIT 1");



    $path = "../userdata/dms/".$this->app->Conf->WFdbname."/".$newid;
    //$name=basename($path);

    //filenames in IE containing dots will screw up the
    //filename unless we add this

    if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE"))
        $name = preg_replace('/\./', '%2e', $name, substr_count($name, '.') - 1);

    $contenttype= $this->content_type($name);

    //required, or it might try to send the serving     //document instead of the file
    header("Content-Type: $contenttype");
    header("Content-Length: " .(string)(filesize($path)) );
    header('Content-Disposition: inline; filename="'.$name.'"');

    if($file = fopen($path, 'rb')){
        while( (!feof($file)) && (connection_status()==0) ){
            print(fread($file, 1024*8));
            flush();
        }
        fclose($file);
    }
    return((connection_status()==0) and !connection_aborted());
  }

  
  function content_type($name) {
    // Defines the content type based upon the extension of the file
    $contenttype  = 'application/octet-stream';
    $contenttypes = array( 'html' => 'text/html',
                           'htm'  => 'text/html',
                           'txt'  => 'text/plain',
                           'gif'  => 'image/gif',
                           'jpg'  => 'image/jpeg',
                           'png'  => 'image/png',
                           'sxw'  => 'application/vnd.sun.xml.writer',
                           'sxg'  => 'application/vnd.sun.xml.writer.global',
                           'sxd'  => 'application/vnd.sun.xml.draw',
                           'sxc'  => 'application/vnd.sun.xml.calc',
                           'sxi'  => 'application/vnd.sun.xml.impress',
                           'xls'  => 'application/vnd.ms-excel',
                           'ppt'  => 'application/vnd.ms-powerpoint',
                           'doc'  => 'application/msword',
                           'rtf'  => 'text/rtf',
                           'zip'  => 'application/zip',
                           'mp3'  => 'audio/mpeg',
                           'pdf'  => 'application/pdf',
                           'tgz'  => 'application/x-gzip',
                           'gz'   => 'application/x-gzip',
                           'vcf'  => 'text/vcf' );

    $name = ereg_replace("§", " ", $name);
    foreach ($contenttypes as $type_ext => $type_name) {
        if (preg_match ("/$type_ext$/i",  $name)) $contenttype = $type_name;
    }
    return $contenttype;
  } 

  function Wochenplan($adr_id,$parsetarget){
    $this->app->Tpl->Set(SUBSUBHEADING, "Wochenplan");
    $this->app->Tpl->Set(INHALT,"");

    $anzWochentage = 5;
    $startStunde = 6;
    $endStunde = 22;

    $wochentage = $this->getDates($anzWochentage);

    $inhalt = "";
    for($i=$startStunde;$i<=$endStunde;$i++){ // fuelle Zeilen 06:00 bis 22:00
        $zeile = array();
        $zeileCount = 0;
        foreach($wochentage as $tag){ // hole Daten fuer Uhrzeit $i und Datum $tage
          $result = $this->checkCell($tag, $i, $adr_id);
          if($result[0]['aufgabe'] != "")
	  {
	    if($result[0]['adresse']==0) $color = '#ccc'; else $color='#BCEE68';
	    if($result[0]['prio']==1) $color = 'red';
	    
            $zeile[$zeileCount] = '<div style="background-color: '.$color.'">'.$result[0]['aufgabe'].'</div>';
	  }
          else
            $zeile[$zeileCount] = "&nbsp;";
          $zeileCount++;
        }
        //print_r($zeile);
        $inhalt = $inhalt.$this->makeRow($zeile, $anzWochentage,$i.":00");
    }
    $this->app->Tpl->Set(WOCHENDATUM, $this->makeRow($wochentage, $anzWochentage));
    $this->app->Tpl->Set(INHALT,$inhalt);

    $this->app->Tpl->Parse($parsetarget,"zeiterfassung_wochenplan.tpl");

    $this->app->Tpl->Add($parsetarget,"<table><tr><td style=\"background-color:#BCEE68\">".$this->app->User->GetName()."</td>
      <td style=\"background-color:red\">Prio: Sehr Hoch (".$this->app->User->GetName().")</td>
      <td style=\"background-color:#ccc\">Allgemein</td></tr></table>");
  }

  function getDates($anzWochentage){
    // hole Datum der Wochentage von Mo bis $anzWochentage
    $montag = $this->app->DB->Select("SELECT DATE_SUB(CURDATE(),INTERVAL WEEKDAY(CURDATE()) day)");
    $week = array();
    for($i=0;$i<$anzWochentage;$i++)
      $week[$i] = $this->app->DB->Select("SELECT DATE_ADD('$montag',INTERVAL $i day)");
  return $week;
  }

  function makeRow($data, $spalten, $erstefrei="frei"){
    // erzeuge eine Zeile in der Tabelle
    // $erstefrei = 1 -> erste Spalte ist leer

    $row = '<tr>';
      if($erstefrei=="frei")
        $row = $row.'<td class="wochenplan">&nbsp;</td>';
      else
        $row = $row.'<td class="wochenplan">'.$erstefrei.'</td>';
      for($i=0;$i<$spalten; $i++)
        $row = $row.'<td class="wochenplan">'.$data[$i].'</td>';
    $row = $row.'</tr>';
  return $row;
  }


  function KundeMitUmsatzsteuer($adresse)
  {
    $land = $this->app->DB->Select("SELECT land FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    $ustid = $this->app->DB->Select("SELECT ustid FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($land =="DE")
      return true;

    // wenn kunde EU
    foreach($this->GetUSTEU() as $value)
    {
      //echo $value;
      if($value==$land && $ustid!="") return false;
    }

    // alle anderen laender = export
    return false;
  }

  function AuftragMitUmsatzeuer($auftrag)
  {
    if($this->app->DB->Select("SELECT ust_befreit FROM auftrag WHERE id='$auftrag' LIMIT 1") ==0 )
      return true;
    else return false;


    $adresse = $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$auftrag' LIMIT 1");
    return $this->KundeMitUmsatzsteuer($adresse);
  }


  function GutschriftMitUmsatzeuer($gutschrift)
  {
    if($this->app->DB->Select("SELECT ust_befreit FROM gutschrift WHERE id='$gutschrift' LIMIT 1")==0)
      return true;
    else return false;

   // if($this->CheckLieferantEU($adresse))
    //  return false;
    
    // wenn lieferant DE dann mit 19% oder 7% einkaufen
    // wenn lieferant in der EU kann man mit 0% bezahlen 

    // wenn lieferant in der welt sowieso keine steuer sondern zoll

    // wenn wir von privat EU kaufen dann muss mit steuer gekauft werden! (SPAETER KANN ES SEIN)
    return false;
  }


  function RechnungMitUmsatzeuer($rechnung)
  {
    if($this->app->DB->Select("SELECT ust_befreit FROM rechnung WHERE id='$rechnung' LIMIT 1") == 0 )
      return true;
    else return false;

   // if($this->CheckLieferantEU($adresse))
    //  return false;
    
    // wenn lieferant DE dann mit 19% oder 7% einkaufen
    // wenn lieferant in der EU kann man mit 0% bezahlen 

    // wenn lieferant in der welt sowieso keine steuer sondern zoll

    // wenn wir von privat EU kaufen dann muss mit steuer gekauft werden! (SPAETER KANN ES SEIN)
    return false;
  }


  function AngebotMitUmsatzeuer($angebot)
  {
    if($this->app->DB->Select("SELECT ust_befreit FROM angebot WHERE id='$angebot' LIMIT 1") == 0 )
      return true;
    else return false;

   // if($this->CheckLieferantEU($adresse))
    //  return false;
    
    // wenn lieferant DE dann mit 19% oder 7% einkaufen
    // wenn lieferant in der EU kann man mit 0% bezahlen 

    // wenn lieferant in der welt sowieso keine steuer sondern zoll

    // wenn wir von privat EU kaufen dann muss mit steuer gekauft werden! (SPAETER KANN ES SEIN)
  }


  function BestellungMitUmsatzeuer($bestellung)
  {
   if($this->app->DB->Select("SELECT ust_befreit FROM bestellung WHERE id='$bestellung' LIMIT 1") == 0 )
      return true;
    else return false;
/*
    $adresse = $this->app->DB->Select("SELECT adresse FROM bestellung WHERE id='$bestellung' LIMIT 1");
    $land = $this->app->DB->Select("SELECT land FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");
    if($land =="DE")
      return true;
*/
   // if($this->CheckLieferantEU($adresse))
    //  return false;
    
    // wenn lieferant DE dann mit 19% oder 7% einkaufen
    // wenn lieferant in der EU kann man mit 0% bezahlen 

    // wenn lieferant in der welt sowieso keine steuer sondern zoll

    // wenn wir von privat EU kaufen dann muss mit steuer gekauft werden! (SPAETER KANN ES SEIN)
    return false;
  }


  function BesteuerungKunde($adresse)
  {
    if($this->AdresseUSTCheck($adresse)==0)
      return "steuer";
    else
      return "";

    // steuer muss gezahlt werden! steuer, euexport, exporr

    // wenn kunde im export muss keine steuer bezahlt werden!

    // wenn kunde  gepruefte ust id hat && lieferung nach EU geht (aber das land verlaesst!)

  }



  function CheckLieferantEU($adresse)
  {
    // lieferant aus der EU
    $land = $this->app->DB->Select("SELECT land FROM adresse WHERE id='$adresse' AND geloescht=0 LIMIT 1");

  }


  function CheckKundeEU($adresse)
  {

  }

  function checkCell($datum, $stunde, $adr_id){
    // ueberprueft ob in der Stunde eine Aufgabe zu erledigen ist
    //echo $datum." ".$stunde."<br>";
    return  $this->app->DB->SelectArr("SELECT aufgabe,adresse,prio
                                    FROM aufgabe
                                    WHERE DATE(startdatum) = '$datum'
                                     AND HOUR(TIME(startzeit)) <= $stunde 
                                     AND HOUR(TIME(startzeit)) + stunden >= $stunde
                                     AND (adresse = $adr_id OR adresse = 0)
                                    OR 
                                     ((DATE_SUB('$datum', INTERVAL MOD(DATEDIFF('$datum',DATE_FORMAT(startdatum, '%Y:%m:%d')),intervall_tage) day)='$datum'
                                     AND DATE_SUB('$datum', INTERVAL MOD(DATEDIFF('$datum',DATE_FORMAT(startdatum, '%Y:%m:%d')),intervall_tage) day)
                                         > abgeschlossen_am
                                     AND intervall_tage>0 AND (adresse=$adr_id OR adresse=0))
                                     AND HOUR(TIME(startzeit)) <= $stunde AND HOUR(TIME(startzeit)) + stunden >= $stunde) 
				    OR ( DATE (abgabe_bis) = '$datum' AND  abgeschlossen=0 AND adresse = $adr_id AND HOUR(TIME(startzeit)) = $stunde)
                                    LIMIT 1"); // letztes OR von Bene!
  }

  function WebmailSetReadStatus($mailid,$boolean)
  {
    $this->app->DB->Update("UPDATE emailbackup_mails SET gelesen = ".($boolean?1:0)." WHERE id = $mailid");
  }

  function checkPDF($file,$maxSize=0,$x=0,$y=0)
  {
  
    return "";  
  }
  function checkFile($file,$filetype,$maxSize=0)
  {
    if($file!="")
    { 
      if(is_array($file))
        $pfad = $file[tmp_name];
      else $pfad = $file;
    }
 
   $dbtype = mime_content_type($pfad);

		if($dbtype!=$filetype)
    	return "Falscher Dateityp! Es wird $filetype erwartet aber $dbtype wurde &uuml;bergeben!";

		else return "";
  }


  
  function checkImage($file,$maxSize=0,$x=0,$y=0)
  {
    // Prueft ein Bild auf Dateigroesse, Hoehe und Breite
    if($file!="")
    { 
      if(is_array($file))
        $pfad = $file[tmp_name];
      else $pfad = $file;
    }
    $typ = GetImageSize($pfad);
    $size = $file[size];


    if($maxSize==0)
      $fileSizeLimit =  16777216; // 16MB in BYTE, 100MB stehen in der upload_max_size
    else
      $fileSizeLimit = $maxSize;

    //if(0 < $typ[2] && $typ[2] < 4)
    if($typ[2]==2)
      { 
        if($size<$fileSizeLimit)
        { 
          if($typ[0]>$x && $x!=0)
            $error = "Das Bild ist zu breit.";
          if($typ[1]>$y && $y!=0)
            $error = "Das Bild ist zu hoch.";
        }else
          $error = "Die Datei darf eine Gr&ouml;&szlig;e von ".($fileSizeLimit/8388608)." MB nicht &uuml;berschreiten.";
      }else
        $error = "Die Datei muss vom Typ JPG sein";
    return $error;
  }

  function uploadImageIntoDB($file)
  {
    // Wandelt ein Bild fuer einen LONGBLOB um
    $pfad = $file[tmp_name];
    $typ = GetImageSize($pfad);

    // Bild hochladen
    $filehandle = fopen($pfad,'r');
    $filedata = base64_encode(fread($filehandle, filesize($pfad)));
    $dbtype = $typ['mime'];
    return array("image"=>$filedata,"type"=>$dbtype);
  }

  function uploadFileIntoDB($file)
  {
    // Wandelt ein Bild fuer einen LONGBLOB um
    $pfad = $file[tmp_name];

		$dbtype = mime_content_type($pfad);
    // Bild hochladen
    $filehandle = fopen($pfad,'r');
    $filedata = base64_encode(fread($filehandle, filesize($pfad)));
    return array("file"=>$filedata,"type"=>$dbtype);
  }



}

?>
