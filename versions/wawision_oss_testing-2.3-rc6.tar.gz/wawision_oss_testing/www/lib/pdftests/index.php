<?php
?>

<html>
<head>
<title>PDF tests</title>
</head>
<body>
	<iframe src="brief.php" style="position: absolute; top: 0px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok1"frameborder="0"></iframe>
	<iframe src="rechnung.php" style="position: absolute; top: 350px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok1"frameborder="0"></iframe>
	<iframe src="lieferschein.php" style="position: absolute; top: 700px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok2"frameborder="0"></iframe>	
	<iframe src="angebot.php" style="position: absolute; top: 1050px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok3"frameborder="0"></iframe>
	<iframe src="bestaetigung.php" style="position: absolute; top: 140px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok4"frameborder="0"></iframe>	
	<iframe src="gutschrift.php" style="position: absolute; top: 140px; left: 0px; height: 350px; width: 800px; border:0px; overflow: hidden;" name="pdfdok5"frameborder="0"></iframe>
	
	<iframe src="etikett1.php" style="position: absolute; top: 0px; left: 800px; height: 200px; width: 500px; border:0px; overflow: hidden;" name="etikett1"frameborder="0"></iframe>
	<iframe src="etikett2.php" style="position: absolute; top: 200px; left: 800px; height: 400px; width: 500px; border:0px; overflow: hidden;" name="etikett2"frameborder="0"></iframe>


</body>
</html>

