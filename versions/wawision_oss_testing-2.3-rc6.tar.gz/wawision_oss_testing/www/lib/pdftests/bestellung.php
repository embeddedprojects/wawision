<?php

error_reporting(E_ALL ^ E_NOTICE);
  include("../dokumente/class.superfpdf.php");

  include("../dokumente/class.briefpapier.php");
  include("../dokumente/class.bestellung.php");

  
  $myOffer = new BestellungPDF();
  $myOffer->GetBestellung(1);
  $myOffer->displayDocument();

?>

