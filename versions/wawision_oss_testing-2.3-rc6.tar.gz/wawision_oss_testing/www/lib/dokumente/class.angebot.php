<?php


class AngebotPDF extends Briefpapier {
  public $doctype;
  
  function AngebotPDF($app)
  {
    $this->app=&$app;
    //parent::Briefpapier();
    $this->doctype="angebot";
    $this->doctypeOrig="Angebot";
    parent::Briefpapier($this->app);
  } 


  function GetAngebot($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM angebot WHERE id='$id' LIMIT 1");
      //$this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"angebot");
            
      // OfferNo, customerId, OfferDate

      //$kundennummer = $this->app->DB->Select("SELECT kundennummer FROM angebot WHERE id='$id' LIMIT 1");
      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$adresse' LIMIT 1");
      $ustid= $this->app->DB->Select("SELECT ustid FROM angebot WHERE id='$id' LIMIT 1");
      $keinsteuersatz= $this->app->DB->Select("SELECT keinsteuersatz FROM angebot WHERE id='$id' LIMIT 1");
      $land= $this->app->DB->Select("SELECT land FROM angebot WHERE id='$id' LIMIT 1");
      $anfrage= $this->app->DB->Select("SELECT anfrage FROM angebot WHERE id='$id' LIMIT 1");
      $vertrieb= $this->app->DB->Select("SELECT vertrieb FROM angebot WHERE id='$id' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM angebot WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM angebot WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM angebot WHERE id='$id' LIMIT 1");

			$zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM angebot WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM angebot WHERE id='$id' LIMIT 1");


      $ohne_briefpapier = $this->app->DB->Select("SELECT ohne_briefpapier FROM angebot WHERE id='$id' LIMIT 1");

      if($ohne_briefpapier=="1")
      {
        $this->logofile = "";
        $this->briefpapier="";
      }

			$zahlungsweise = ucfirst($zahlungsweise);	

			//$zahlungstext = "\nZahlungsweise: $zahlungsweise ";
			$zahlungstext = "\n$zahlungsweise ";
			if($zahlungszieltage >0) $zahlungstext .= "zahlbar innerhalb $zahlungszieltage Tagen.";
			else
				$zahlungstext .= "zahlbar sofort.";

			if($zahlungszielskonto>0) $zahlungstext .= "\nSkonto $zahlungszielskonto% innerhalb $zahlungszieltageskonto Tagen";	

      if($belegnr<=0) $belegnr = "- Entwurf";

      $this->doctypeOrig="Angebot $belegnr";

      if($angebot=="") $angebot = "-";
      if($kundennummer=="") $kundennummer= "-";

      $this->setCorrDetails(array("Anfrage"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Bestelldatum"=>$datum,"Vertrieb"=>$vertrieb));
      if(!$this->app->erp->AngebotMitUmsatzeuer($id) && $ustid!=""  && $keinsteuersatz!="1")
      {
        //$steuer = "\nSteuerfreie innergemeinschaftliche Lieferung. Ihre USt-IdNr. $ustid Land: $land";
//        $steuer = "\nSteuerfrei nach § 4 Nr. 1b i.V.m. § 6 a UStG. Ihre USt-IdNr. $ustid Land: $land";
        $steuer = $this->app->erp->Firmendaten("eu_lieferung_vermerk");
        $steuer = str_replace('{USTID}',$ustid,$steuer);
        $steuer = str_replace('{LAND}',$land,$steuer);

      }

      $this->setTextDetails(array(
	  		"body"=>$this->app->erp->Firmendaten("angebot_header"),
	  		"footer"=>"$freitext\n\n$zahlungstext\n$steuer\n".$this->app->erp->Firmendaten("angebot_footer")));
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM angebot_position WHERE angebot='$id' ORDER By sort");
      if(!$this->app->erp->AngebotMitUmsatzeuer($id)) $this->ust_befreit=true;

      $summe_rabatt = $this->app->DB->Select("SELECT SUM(rabatt) FROM angebot_position WHERE angebot='$id'");
			if($summe_rabatt > 0) $this->rabatt=1;

			$summe = 0;
      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM angebot_position WHERE angebot='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
        if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";

   			$this->addItem(array('currency'=>$value[waehrung],
					'amount'=>$value[menge],
					'price'=>$value[preis],
					'tax'=>$value[umsatzsteuer],
					'itemno'=>$value[nummer],
					'desc'=>$value[beschreibung],
	    		"name"=>ltrim($value[bezeichnung]),
					"rabatt"=>$value[rabatt]));

					$netto_gesamt = $value[menge]*($value[preis]-($value[preis]/100*$value[rabatt]));
					$summe = $summe + $netto_gesamt;

					if($value[umsatzsteuer]=="" || $value[umsatzsteuer]=="normal")
					{
						$summeV = $summeV + (($netto_gesamt/100)*$this->app->erp->GetSteuersatzNormal());
					}
					else {
						$summeR = $summeR + (($netto_gesamt/100)*$this->app->erp->GetSteuersatzErmaessigt());
					}
      }
		/*	
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id'");
			// voller steuersatz
      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id' AND (umsatzsteuer='normal' or umsatzsteuer='')")/100 * 19;
			// reduzierter steuersatz
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM angebot_position WHERE angebot='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
     */ 

      if($this->app->erp->AngebotMitUmsatzeuer($id))
      {
				$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else {
				$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));
			}

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM angebot WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM angebot WHERE id='$id' LIMIT 1");
      //$tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      //$tmp_name = str_replace('.','',$tmp_name);

      $this->filename = $datum."_AN".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
