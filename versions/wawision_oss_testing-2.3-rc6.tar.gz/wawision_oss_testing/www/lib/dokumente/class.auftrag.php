<?php


class AuftragPDF extends Briefpapier {
  public $doctype;
  
  function AuftragPDF($app,$proforma="")
  {
    $this->app=&$app;
    //parent::Briefpapier();
    if($proforma=="")
    {
    $this->doctypeOrig="Auftrag";
    $this->doctype="auftrag";
    }
    else
    { 
    $this->doctypeOrig="Proformarechnung";
    $this->doctype="proforma";
    }
    parent::Briefpapier($this->app);
  } 


  function GetAuftrag($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM auftrag WHERE id='$id' LIMIT 1");
      //$this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"auftrag");


      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$adresse' LIMIT 1");

      $anfrage= $this->app->DB->Select("SELECT angebot FROM auftrag WHERE id='$id' LIMIT 1");
      $vertrieb= $this->app->DB->Select("SELECT vertrieb FROM auftrag WHERE id='$id' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM auftrag WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM auftrag WHERE id='$id' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM auftrag WHERE id='$id' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM auftrag WHERE id='$id' LIMIT 1");
      $keinsteuersatz = $this->app->DB->Select("SELECT keinsteuersatz FROM auftrag WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM auftrag WHERE id='$id' LIMIT 1");


      $telefax= $this->app->DB->Select("SELECT telefax FROM adresse WHERE id='$adresse' LIMIT 1");

      if($belegnr<=0) $belegnr = "- Entwurf";
      if($this->doctype=="auftrag")
      $this->doctypeOrig="Auftragsbestätigung $belegnr";
      else
      $this->doctypeOrig="Proformarechnung $belegnr";

      if($auftrag=="") $auftrag = "-";
      if($kundennummer=="") $kundennummer= "-";


      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM auftrag WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM auftrag WHERE id='$id' LIMIT 1");


      $ohne_briefpapier = $this->app->DB->Select("SELECT ohne_briefpapier FROM auftrag WHERE id='$id' LIMIT 1");

      if($ohne_briefpapier=="1")
      {
        $this->logofile = "";
        $this->briefpapier="";
      }

			$zahlungsweise = ucfirst($zahlungsweise);
      //$zahlungstext = "\nZahlungsweise: $zahlungsweise ";
      $zahlungstext = "\n$zahlungsweise ";
      if($zahlungszieltage >0) $zahlungstext .= "zahlbar innerhalb $zahlungszieltage Tagen.";
      else
        $zahlungstext .= "zahlbar sofort.";

      if($zahlungszielskonto>0) $zahlungstext .= "\nSkonto $zahlungszielskonto% innerhalb $zahlungszieltageskonto Tagen";



      
      if($telefax!="" && $telefax!=0)
				$this->setCorrDetails(array("Angebot"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Auftragsdatum"=>$datum,"Vertrieb"=>$vertrieb,"Ihre Faxnummer"=>$telefax));
      else
				$this->setCorrDetails(array("Angebot"=>$anfrage,"Ihre Kunden-Nr."=>$kundennummer,"Auftragsdatum"=>$datum,"Vertrieb"=>$vertrieb));

			if(!$this->app->erp->AuftragMitUmsatzeuer($id) && $keinsteuersatz!="1") 
			{
        $steuer = $this->app->erp->Firmendaten("eu_lieferung_vermerk");
        $steuer = str_replace('{USTID}',$ustid,$steuer);
        $steuer = str_replace('{LAND}',$land,$steuer);
			}

	    $this->setTextDetails(array(
	      "body"=>$this->app->erp->Firmendaten("auftrag_header"),
	      "footer"=>"$freitext\n\n$zahlungstext\n\n$steuerzeile\n\n".$this->app->erp->Firmendaten("auftrag_footer")));

      if(!$this->app->erp->AuftragMitUmsatzeuer($id)) $this->ust_befreit=true;
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM auftrag_position WHERE auftrag='$id' ORDER By sort");
      $summe_rabatt = $this->app->DB->Select("SELECT SUM(rabatt) FROM auftrag_position WHERE auftrag='$id'");
      if($summe_rabatt > 0) $this->rabatt=1;

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM auftrag_position WHERE auftrag='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
       // if($value[umsatzsteuer] == "" || $value[umsatzsteuer] ==0) $value[umsatzsteuer] = "normal";
        if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";

				//if(!$this->app->erp->AuftragMitUmsatzeuer($id)) $value[umsatzsteuer] = ""; 
				if($value[explodiert] > 0 ) $value[bezeichnung] = $value[bezeichnung]." (Stückliste)";
				if($value[explodiert_parent] > 0) { $value[preis] = "-"; $value[umsatzsteuer]="hidden"; $value[bezeichnung] = "-".$value[bezeichnung]; }

        $this->addItem(array('currency'=>$value[waehrung],
          'amount'=>$value[menge],
          'price'=>$value[preis],
          'tax'=>$value[umsatzsteuer],
          'itemno'=>$value[nummer],
          'desc'=>$value[beschreibung],
          "name"=>ltrim($value[bezeichnung]),
          "rabatt"=>$value[rabatt]));

          $netto_gesamt = $value[menge]*($value[preis]-($value[preis]/100*$value[rabatt]));
          $summe = $summe + $netto_gesamt;

          if($value[umsatzsteuer]=="" || $value[umsatzsteuer]=="normal")
          {
            $summeV = $summeV + (($netto_gesamt/100)*$this->app->erp->GetSteuersatzNormal());
          }
          else {
            $summeR = $summeR + (($netto_gesamt/100)*$this->app->erp->GetSteuersatzErmaessigt());
          }
      	}
/*
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id'");

      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id' AND (umsatzsteuer='normal' or umsatzsteuer='')")/100 * 19;
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM auftrag_position WHERE auftrag='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
 */     
      if($this->app->erp->AuftragMitUmsatzeuer($id))
      {
				$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else
      	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM auftrag WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$id' LIMIT 1");
      $tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      $tmp_name = str_replace('.','',$tmp_name);

      if($this->doctype=="auftrag")
      $this->filename = $datum."_AB".$belegnr.".pdf";
      else
      $this->filename = $datum."_PR".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
