<?php


class LieferscheinPDF extends Briefpapier {
  public $doctype;
  
  function LieferscheinPDF($app,$projekt="")
  {
    $this->app=&$app;
    //parent::Briefpapier();
    $this->doctype="lieferschein";
    $this->doctypeOrig="Lieferschein";
    parent::Briefpapier($this->app,$projekt);
  } 


  function GetLieferschein($id,$info="",$extrafreitext="")
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM lieferschein WHERE id='$id' LIMIT 1");

      // das muss vom lieferschein sein!!!!
      $this->setRecipientLieferadresse($id,"lieferschein");


      // OfferNo, customerId, OfferDate
      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM adresse WHERE id='$adresse' LIMIT 1");
      $auftrag = $this->app->DB->Select("SELECT auftragid FROM lieferschein WHERE id='$id' LIMIT 1");
      $auftrag = $this->app->DB->Select("SELECT belegnr FROM auftrag WHERE id='$auftrag' LIMIT 1");
      $bearbeiter = $this->app->DB->Select("SELECT bearbeiter FROM lieferschein WHERE id='$id' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM lieferschein WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM lieferschein WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM lieferschein WHERE id='$id' LIMIT 1");

			$ohne_briefpapier = $this->app->DB->Select("SELECT ohne_briefpapier FROM lieferschein WHERE id='$id' LIMIT 1");

      if($ohne_briefpapier=="1")
      {
        $this->logofile = "";
        $this->briefpapier="";
      }

      $this->doctype="deliveryreceipt";

      if($belegnr<=0) $belegnr = "- Entwurf";


      if($info=="")
	$this->doctypeOrig="Lieferschein $belegnr";
      else
	$this->doctypeOrig="Lieferschein$info $belegnr";

      if($lieferschein=="") $lieferschein = "-";
      if($kundennummer=="") $kundennummer= "-";

      //$this->setCorrDetails(array("Auftrag"=>$auftrag,"Ihre Kunden-Nr."=>$kundennummer,"Versand"=>$datum,"Versand"=>$bearbeiter));
      $this->setCorrDetails(array("Auftrag"=>$auftrag,"Ihre Kunden-Nr."=>$kundennummer,"Lieferdatum"=>$datum));

      $this->setTextDetails(array(
	  		"body"=>$this->app->erp->Firmendaten("lieferschein_header"),
	  		"footer"=>"$freitext\r\n$extrafreitext\r\n".$this->app->erp->Firmendaten("lieferschein_footer")));
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM lieferschein_position WHERE lieferschein='$id' ORDER By sort");

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM lieferschein_position WHERE lieferschein='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {

      if($value[seriennummer]!="")
      {
        if( $value[beschreibung]!="")  $value[beschreibung] =  $value[beschreibung]."\n";
	  $value[beschreibung] = "Seriennummer: ".$value[seriennummer]."\n\n";
      }

	$this->addItem(array('amount'=>$value[menge],'itemno'=>$value[nummer],'desc'=>$value[bemerkung],'desc'=>ltrim($value[beschreibung]),
	  "name"=>$value[bezeichnung]));
	//$this->addItem(array('currency'=>$value[waehrung],'amount'=>$value[menge],'price'=>$value[preis],'tax'=>$value[umsatzsteuer],'itemno'=>$value[bestellnummer],
	//  "name"=>$value[bezeichnunglieferant]));
      }
      

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM lieferschein WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$id' LIMIT 1");
      $tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      $tmp_name = str_replace('.','',$tmp_name);

      $this->filename = $datum."_LS".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
