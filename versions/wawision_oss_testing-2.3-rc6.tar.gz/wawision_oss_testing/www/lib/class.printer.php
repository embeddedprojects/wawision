<?php


class Printer
{

  function Printer(&$app)
  {
    $this->app=$app;
  }


  function Drucken($drucker,$dokument)
  {
    $befehl = $this->app->DB->Select("SELECT befehl FROM drucker WHERE id='$drucker' AND firma='".$this->app->User->GetFirma()."' LIMIT 1");
    exec("$befehl $dokument");
  }

}


?>
