<?
include ("_gen/widget.gen.projekt.php");

class WidgetProjekt extends WidgetGenProjekt 
{
  private $app;
  function WidgetProjekt($app,$parsetarget)
  {
    $this->app = $app;
    $this->parsetarget = $parsetarget;
    parent::WidgetGenProjekt($app,$parsetarget);
    $this->ExtendsForm();
    $this->ExtendsOutput();
  }

  function ExtendsForm()
  {
    $this->app->Secure->POST["firma"]=$this->app->User->GetFirma();
    $field = new HTMLInput("firma","hidden",$this->app->User->GetFirma());
    $this->form->NewField($field);

    $this->app->YUI->AutoComplete("abkuerzung","projektname",1);
/*
		$allowed = "/[^a-z0-9]/i"; 
		preg_replace($allowed,"",$this->app->Secure->POST["abkuerzung"]); 
		$this->app->Secure->POST["abkuerzung"]=strtoupper($this->app->Secure->POST["abkuerzung"]);
*/
//    $this->app->YUI->AutoComplete(ADRESSEAUTO,"adresse",array('name','ort','mitarbeiternummer'),"CONCAT(mitarbeiternummer,' ',name)","mitarbeiter");
    $this->app->YUI->AutoComplete("verantwortlicher","mitarbeitername");

    $this->form->ReplaceFunction("adresse",&$this,"ReplaceMitarbeiter");

  }

  function ExtendsOutput()
  //function __destruct()
  {
    // formatierte extra ausgaben aus datenbank
    //LIEFERSCHEINBRIEFPAPIER

    $id = $this->app->Secure->GetGET("id");

    $lieferscheinbriefpapier = $this->app->DB->Select("SELECT lieferscheinbriefpapier FROM projekt WHERE id='$id' LIMIT 1");

    $this->app->Tpl->Set(LIEFERSCHEINBRIEFPAPIEROPTIONS,"<option value=1>test $lieferscheinbriefpapier wert 1</option><option value=2>test $lieferscheinbriefpapier wert 2</option>");

  }


  function ReplaceMitarbeiter($db,$value)
  {
    return $this->app->erp->ReplaceMitarbeiter($db,$value);
  }


}
?>
