<?
if($_GET['code']==777)
{
echo "aus is";
//system("echo \"poweroff:\" > /tmp/systemjobs");
} else {
echo "falscher code! kein shutdown!";
}

?>
