<?php

$return = array();
$return[1] = array("Elias","Sophia","Felix","Ronja","Lilly","Leander");
$return[2] = array("VW","Porsche","Mercedes","Audi");
$return[3] = array("Handy","Kamera","Server","Laptop","PDA");
$return[4] = array("Handy","Kamera","Server","Laptop","PDA");

if($_GET["wunsch"]!="")
echo implode(",",$return[$_GET["wunsch"]]);

?>

