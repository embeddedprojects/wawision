<?
include ("_gen/shopexport.php");

class Onlineshops extends GenShopexport {
  var $app;
  
  function Onlineshops($app) {
    //parent::GenShopexport($app);
    $this->app=&$app;

    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("create","ShopexportCreate");
    $this->app->ActionHandler("edit","ShopexportEdit");
    $this->app->ActionHandler("list","ShopexportList");
    $this->app->ActionHandler("delete","ShopexportDelete");

    $this->app->ActionHandlerListen(&$app);

    $this->app = $app;
  }


  function ShopexportCreate()
  {
    $this->ShopexportMenu();
    parent::ShopexportCreate();
  }

  function ShopexportList()
  {
    $this->ShopexportMenu();
    parent::ShopexportList();
  }

  function ShopexportMenu()
  {
		$menu = $this->app->Secure->GetGET("menu");	
		if($menu=="1")
		{
			include("shopexport.php");
			$this->app->Tpl->Set(KURZUEBERSCHRIFT,"Einstellungen");
			Shopexport::ShopexportMenu();
		} else {
			$id = $this->app->Secure->GetGET("id");
			$this->app->Tpl->Add(KURZUEBERSCHRIFT,"Online-Shops");
			$this->app->erp->MenuEintrag("index.php?module=onlineshops&action=create","Online-Shop anlegen");
			if($this->app->Secure->GetGET("action")=="list")
				$this->app->erp->MenuEintrag("index.php?module=einstellungen&action=list","Zur&uuml;ck zur &Uuml;bersicht");
			else
				$this->app->erp->MenuEintrag("index.php?module=onlineshops&action=list","Zur&uuml;ck zur &Uuml;bersicht");

		}
  }

	function ShopexportDelete() 
	{
		$id = $this->app->Secure->GetGET('id');
		if(is_numeric($id)) {
			$this->app->DB->Delete("DELETE FROM shopexport WHERE id='$id' LIMIT 1");
		}
		header('Location: ./index.php?module=onlineshops&action=list');
		exit;
	}


  function ShopexportEdit()
  {
    $this->ShopexportMenu();
    parent::ShopexportEdit();
  }





}

?>
