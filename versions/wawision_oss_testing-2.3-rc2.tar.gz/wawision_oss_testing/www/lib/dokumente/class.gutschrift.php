<?php


class GutschriftPDF extends Briefpapier {
  public $doctype;
  
  function GutschriftPDF($app)
  {
    $this->app=&$app;
    //parent::Briefpapier();
    $this->doctype="gutschrift";
    $this->doctypeOrig="Gutschrift";
    parent::Briefpapier(&$this->app);
  } 


  function GetGutschrift($id)
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM gutschrift WHERE id='$id' LIMIT 1");
      //$this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"gutschrift");


      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM gutschrift WHERE id='$id' LIMIT 1");
      $rechnung = $this->app->DB->Select("SELECT rechnung FROM gutschrift WHERE id='$id' LIMIT 1");
      $buchhaltung= $this->app->DB->Select("SELECT buchhaltung FROM gutschrift WHERE id='$id' LIMIT 1");
      $lieferschein = $this->app->DB->Select("SELECT lieferschein FROM gutschrift WHERE id='$id' LIMIT 1");
      $lieferschein = $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$lieferschein' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM gutschrift WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM gutschrift WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM gutschrift WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM gutschrift WHERE id='$id' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM gutschrift WHERE id='$id' LIMIT 1");
      $keinsteuersatz = $this->app->DB->Select("SELECT keinsteuersatz FROM gutschrift WHERE id='$id' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM gutschrift WHERE id='$id' LIMIT 1");
      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM gutschrift WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM gutschrift WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM gutschrift WHERE id='$id' LIMIT 1");

      $zahlungdatum = $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD(datum, INTERVAL $zahlungszieltage DAY),'%d.%m.%Y') FROM gutschrift WHERE id='$id' LIMIT 1");

      $zahlungsweise = strtolower($zahlungsweise);
/*
      if($zahlungsweise=="gutschrift"&&$zahlungsstatus!="bezahlt")
      {
	$zahlungsweisetext = "Gutschrift zahlbar innerhalb $zahlungszieltage Tagen bis zum $zahlungdatum.";
	if($zahlungszielskonto!=0)
	  $zahlungsweisetext .=" (Skonto $zahlungszielskonto % innerhalb $zahlungszieltageskonto Tagen)";	
      } elseif($zahlungsweise=="bar")
      {
	$zahlungsweisetext = "Gutschrift: Barzahlung";
      } elseif($zahlungsweise=="nachnahme")
      {
	$zahlungsweisetext = "Gutschrift: Bezahlung per Nachnahme";
      } else {
	if($zahlungsstatus!="bezahlt")
	{
	  $zahlungsweisetext = "Die Gutschrift muss per Vorkasse bezahl werden. Zahlungsweise: ".ucfirst($zahlungsweise);
	}
	else
	{
	  $zahlungsweisetext = "Die Gutschrift wurde per Vorkasse (".ucfirst($zahlungsweise).") bezahlt";
	}
      }
 */     
      
      if($belegnr<=0) $belegnr = "- Entwurf";

      $this->doctypeOrig="Gutschrift $belegnr";

      if($gutschrift=="") $gutschrift = "-";
      if($kundennummer=="") $kundennummer= "-";

      if($auftrag==0) $auftrag = "-";
      if($lieferschein==0) $lieferschein= "-";

	//$this->setCorrDetails(array("Auftrag"=>$auftrag,"Datum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer,"Lieferschein"=>$lieferschein,"Buchhaltung"=>$buchhaltung));
	if($lieferschein!='-')
	$this->setCorrDetails(array("Rechnung"=>$rechnung,"Datum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer));
	else
	$this->setCorrDetails(array("Rechnung"=>$rechnung,"Datum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer));

      if(!$this->app->erp->GutschriftMitUmsatzeuer($id) && $keinsteuersatz!="1")
	$steuer = "\nSteuerfreie innergemeinschaftliche Lieferung. Ihre USt-IdNr. $ustid Land: $land";

      $this->setTextDetails(array(
	  "body"=>"Sehr geehrte Damen und Herren,\n\nanbei Ihre Gutschrift.", 
	  "footer"=>"$freitext".$zahlungsweisetext."\n\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.\n$steuer"));
      
      $artikel = $this->app->DB->SelectArr("SELECT * FROM gutschrift_position WHERE gutschrift='$id' ORDER By sort");

      if(!$this->app->erp->GutschriftMitUmsatzeuer($id)) $this->ust_befreit=true;

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM gutschrift_position WHERE gutschrift='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
//	if($value[umsatzsteuer] == "") $value[umsatzsteuer] = "normal";
            if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";

	$this->addItem(array('currency'=>$value[waehrung],'amount'=>$value[menge],'price'=>$value[preis],'tax'=>$value[umsatzsteuer],'itemno'=>$value[nummer],'desc'=>$value[beschreibung],
	  "name"=>$value[bezeichnung]));
      }
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE gutschrift='$id'");

      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE gutschrift='$id' AND (umsatzsteuer='normal' or umsatzsteuer='')")/100 * 19;
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM gutschrift_position WHERE gutschrift='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
      
      if($this->app->erp->GutschriftMitUmsatzeuer($id))
      {
	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else
      $this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));

      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM gutschrift WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM gutschrift WHERE id='$id' LIMIT 1");
      $tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      $tmp_name = str_replace('.','',$tmp_name);

      $this->filename = $datum."_GS".$belegnr.".pdf";
      $this->setBarcode($belegnr);
  }


}
?>
