<?php


class RechnungPDF extends Briefpapier {
  public $doctype;
  
  function RechnungPDF($app)
  {
    $this->app=&$app;
    //parent::Briefpapier();
    $this->doctype="rechnung";
    $this->doctypeOrig="Rechnung";
    parent::Briefpapier(&$this->app);
  } 


  function GetRechnung($id,$als="")
  {
      $adresse = $this->app->DB->Select("SELECT adresse FROM rechnung WHERE id='$id' LIMIT 1");
//      $this->setRecipientDB($adresse);
      $this->setRecipientLieferadresse($id,"rechnung");

      // OfferNo, customerId, OfferDate

      $kundennummer = $this->app->DB->Select("SELECT kundennummer FROM rechnung WHERE id='$id' LIMIT 1");
      $auftrag= $this->app->DB->Select("SELECT auftrag FROM rechnung WHERE id='$id' LIMIT 1");
      $buchhaltung= $this->app->DB->Select("SELECT buchhaltung FROM rechnung WHERE id='$id' LIMIT 1");
      $lieferschein = $this->app->DB->Select("SELECT lieferschein FROM rechnung WHERE id='$id' LIMIT 1");
      $lieferscheinid = $lieferschein;
      $lieferschein = $this->app->DB->Select("SELECT belegnr FROM lieferschein WHERE id='$lieferschein' LIMIT 1");
      $bestellbestaetigung = $this->app->DB->Select("SELECT bestellbestaetigung FROM rechnung WHERE id='$id' LIMIT 1");
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%d.%m.%Y') FROM rechnung WHERE id='$id' LIMIT 1");
      $belegnr = $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$id' LIMIT 1");
      $doppel = $this->app->DB->Select("SELECT doppel FROM rechnung WHERE id='$id' LIMIT 1");
      $freitext = $this->app->DB->Select("SELECT freitext FROM rechnung WHERE id='$id' LIMIT 1");
      $ustid = $this->app->DB->Select("SELECT ustid FROM rechnung WHERE id='$id' LIMIT 1");
      $keinsteuersatz = $this->app->DB->Select("SELECT keinsteuersatz FROM rechnung WHERE id='$id' LIMIT 1");
      $soll = $this->app->DB->Select("SELECT soll FROM rechnung WHERE id='$id' LIMIT 1");
      $ist = $this->app->DB->Select("SELECT ist FROM rechnung WHERE id='$id' LIMIT 1");
      $land = $this->app->DB->Select("SELECT land FROM rechnung WHERE id='$id' LIMIT 1");
      $mahnwesen_datum = $this->app->DB->Select("SELECT mahnwesen_datum FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungsweise = $this->app->DB->Select("SELECT zahlungsweise FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungsstatus = $this->app->DB->Select("SELECT zahlungsstatus FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszieltage = $this->app->DB->Select("SELECT zahlungszieltage FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszieltageskonto = $this->app->DB->Select("SELECT zahlungszieltageskonto FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszielskonto = $this->app->DB->Select("SELECT zahlungszielskonto FROM rechnung WHERE id='$id' LIMIT 1");

      $zahlungdatum = $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD(datum, INTERVAL $zahlungszieltage DAY),'%d.%m.%Y') FROM rechnung WHERE id='$id' LIMIT 1");
      $zahlungszielskontodatum = $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD(datum, INTERVAL $zahlungszieltageskonto DAY),'%d.%m.%Y') FROM rechnung WHERE id='$id' LIMIT 1");

      if(!$this->app->erp->RechnungMitUmsatzeuer($id)){
        $this->ust_befreit=true;
      }

      $zahlungsweise = strtolower($zahlungsweise);

      if($zahlungsweise=="rechnung"&&$zahlungsstatus!="bezahlt")
      {
			if($zahlungszieltage==0)
				 $zahlungsweisetext = "Rechnung zahlbar sofort.";
			else
				$zahlungsweisetext = "Rechnung zahlbar innerhalb $zahlungszieltage Tage bis zum $zahlungdatum netto.";

	if($zahlungszielskonto!=0)
	  $zahlungsweisetext .=" (Skonto $zahlungszielskonto % innerhalb $zahlungszieltageskonto Tage bis zum $zahlungszielskontodatum)";	
      } elseif($zahlungsweise=="bar")
      {
	$zahlungsweisetext = "Rechnung: Barzahlung";
      } elseif($zahlungsweise=="nachnahme")
      {
	$zahlungsweisetext = "Rechnung: Bezahlung per Nachnahme";
      } else {
	if($zahlungsstatus!="bezahlt")
	{
	  $zahlungsweisetext = "Die Rechnung muss per Vorkasse bezahlt werden. Zahlungsweise: ".ucfirst($zahlungsweise);
	}
	else
	{
	  $zahlungsweisetext = "Die Rechnung wurde per ".ucfirst($zahlungsweise)." bezahlt";
	}
      }

      if($belegnr<=0) $belegnr = "- Proforma";
			else {
				if($doppel==1 || $als=="doppel")
					$belegnr .= " (Doppel)";

			}
 
      if($als=="zahlungserinnerung") 
      $this->doctypeOrig="Zahlungserinnerung";
      else if($als=="mahnung1") 
      $this->doctypeOrig="1. Mahnung";
      else if($als=="mahnung2") 
      $this->doctypeOrig="2. Mahnung";
      else if($als=="mahnung3") 
      $this->doctypeOrig="3. Mahnung";
      else if($als=="inkasso") 
      $this->doctypeOrig="Inkasso-Mahnung";
      else
      $this->doctypeOrig="Rechnung $belegnr";

      if($rechnung=="") $rechnung = "-";
      if($kundennummer=="") $kundennummer= "-";

      if($auftrag==0) $auftrag = "-";
      if($lieferschein==0) $lieferschein= "-";


      $datumlieferschein = $this->app->DB->Select("SELECT DATE_FORMAT(datum, '%d.%m.%Y') FROM lieferschein WHERE id='$lieferscheinid' LIMIT 1");

	//$this->setCorrDetails(array("Auftrag"=>$auftrag,"Datum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer,"Lieferschein"=>$lieferschein,"Buchhaltung"=>$buchhaltung));
	if($lieferschein!='-')
	$this->setCorrDetails(array("Auftrag"=>$auftrag,"Rechnungsdatum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer,"Lieferschein"=>$lieferschein,"Lieferdatum"=>$datumlieferschein));
	else
	$this->setCorrDetails(array("Auftrag"=>$auftrag,"Datum"=>$datum,"Ihre Kunden-Nr."=>$kundennummer,"Lieferung"=>$datum));

      if(!$this->app->erp->RechnungMitUmsatzeuer($id) && $ustid!="" )
      {
	//$steuer = "\nSteuerfreie innergemeinschaftliche Lieferung. Ihre USt-IdNr. $ustid Land: $land";
        $this->ust_befreit=true;
	if($keinsteuersatz!="1")
	$steuer = "\nSteuerfrei nach § 4 Nr. 1b i.V.m. § 6 a UStG. Ihre USt-IdNr. $ustid Land: $land";
      }

      if($als!="")
      {
        $body = $this->app->erp->MahnwesenBody($id,$als);
	$footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      }
      else {
        $footer = "$freitext"."\n\n".$zahlungsweisetext."\n\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.\n$steuer";
         $body = "Sehr geehrte Damen und Herren,\n\nanbei Ihre Rechnung.";
      }
/*
      if($als=="zahlungserinnerung")
      {
	$body = $this->app->erp->GetKonfiguration("textz");
	$tage = $this->app->erp->GetKonfiguration("mahnwesen_m1_tage");
      } 
      else if($als=="mahnung1")
      {
	$body = $this->app->erp->GetKonfiguration("textm1");
	$mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m1_gebuehr");
	$tage = $this->app->erp->GetKonfiguration("mahnwesen_m2_tage");
	$footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      } 
      else if($als=="mahnung2")
      {
	$body = $this->app->erp->GetKonfiguration("textm2");
	$tage = $this->app->erp->GetKonfiguration("mahnwesen_m3_tage");
	$mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m2_gebuehr");
	$footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      } 
      else if($als=="mahnung3")
      {
	$body = $this->app->erp->GetKonfiguration("textm3");
	$tage = $this->app->erp->GetKonfiguration("mahnwesen_ik_tage");
	$mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_m3_gebuehr");
	$footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      } 
      else if($als=="inkasso")
      {
	$body = $this->app->erp->GetKonfiguration("texti");
	//$tage = $this->app->erp->GetKonfiguration("mahnwesen_ik_tage");
	$tage = 3; //eigentlich vorbei
	$mahngebuehr = $this->app->erp->GetKonfiguration("mahnwesen_ik_gebuehr");
	$footer = "Dieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.";
      } 
      else 
      {
	  $body = "Sehr geehrte Damen und Herren,\n\nanbei Ihre Rechnung.";
	  $footer = "$freitext"."\n\n".$zahlungsweisetext."\n\nDieses Formular wurde maschinell erstellt und ist ohne Unterschrift gültig.\n$steuer";
      } 
      $datummahnung= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$mahnwesen_datum', INTERVAL $tage DAY),'%d.%m.%Y')");
      $datumrechnungzahlungsziel= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$datum', INTERVAL $zahlungszieltage DAY),'%d.%m.%Y')");

      $tage_ze = $zahlungszieltage + $this->app->erp->GetKonfiguration("mahnwesen_m1_tage");
      $datumzahlungserinnerung= $this->app->DB->Select("SELECT DATE_FORMAT(DATE_ADD('$datum', INTERVAL $tage_ze DAY),'%d.%m.%Y')");


      // checkstamp $this->app->erp->CheckStamp("jhdskKUhsiusakiakuhsd"); // errechnet aus laufzeit und kundenid // wenn es nicht drinnen ist darf es nicht gehen


      if($mahngebuehr=="" || !is_numeric($mahngebuehr))
	$mahngebuehr = 0;

      $tage = 10;
      $offen= "11,23";


      $body = str_replace("{RECHNUNG}",$belegnr,$body);
      $body = str_replace("{DATUMRECHNUNG}",$datum,$body);
      $body = str_replace("{TAGE}",$tage,$body);
      $body = str_replace("{OFFEN}",number_format($soll - $ist,2),$body);
      $body = str_replace("{SOLL}",$soll,$body);
      $body = str_replace("{IST}",$ist,$body);
      $body = str_replace("{DATUM}",$datummahnung,$body);
      $body = str_replace("{MAHNGEBUEHR}",$mahngebuehr,$body);

      $body = str_replace("{DATUMZAHLUNGSERINNERUNG}",$datumzahlungserinnerung,$body);
      $body = str_replace("{DATUMRECHNUNGZAHLUNGSZIEL}",$datumrechnungzahlungsziel,$body);
*/

	$this->setTextDetails(array(
	  "body"=>$body,
	  "footer"=>$footer));



 
      $artikel = $this->app->DB->SelectArr("SELECT * FROM rechnung_position WHERE rechnung='$id' ORDER By sort");

      //$waehrung = $this->app->DB->Select("SELECT waehrung FROM rechnung_position WHERE rechnung='$id' LIMIT 1");
      foreach($artikel as $key=>$value)
      {
	//if($value[umsatzsteuer] == "" || $value[umsatzsteuer] == 0 || $value[umsatzsteuer] ==1 || $value[umsatzsteuer] =="normal) $value[umsatzsteuer] = "normal";
	if($value[umsatzsteuer] != "ermaessigt") $value[umsatzsteuer] = "normal";
//	if(!$this->app->erp->RechnungMitUmsatzeuer($id)) $value[umsatzsteuer] = ""; 

	$limit = 60;	
	$summary= $value[bezeichnung];
	if (strlen($summary) > $limit)
	{
	  $value[desc]= $value[bezeichnung];
	  $value[bezeichnung] = substr($summary, 0, strrpos(substr($summary, 0, $limit), ' ')) . '...';
	}
	//$value[bezeichnung] = str_replace("<br/>","\r\n",$value[bezeichnung]);

	$this->addItem(array('currency'=>$value[waehrung],'amount'=>$value[menge],'price'=>$value[preis],'tax'=>$value[umsatzsteuer],'itemno'=>$value[nummer], 'desc'=>$value[beschreibung],
	  "name"=>ltrim($value[bezeichnung])));
      }
      $summe = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE rechnung='$id'");

      $summeV = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE rechnung='$id' AND (umsatzsteuer!='ermaessigt')")/100 * 19;
      $summeR = $this->app->DB->Select("SELECT SUM(menge*preis) FROM rechnung_position WHERE rechnung='$id' AND umsatzsteuer='ermaessigt'")/100 * 7;
      
      if($this->app->erp->RechnungMitUmsatzeuer($id))
      {
	$this->setTotals(array("totalArticles"=>$summe,"total"=>$summe + $summeV + $summeR,"totalTaxV"=>$summeV,"totalTaxR"=>$summeR));
      } else

{
      $this->setTotals(array("totalArticles"=>$summe,"total"=>$summe));
}
      /* Dateiname */
      $datum = $this->app->DB->Select("SELECT DATE_FORMAT(datum,'%Y%m%d') FROM rechnung WHERE id='$id' LIMIT 1");
      $belegnr= $this->app->DB->Select("SELECT belegnr FROM rechnung WHERE id='$id' LIMIT 1");
      $tmp_name = str_replace(' ','',trim($this->recipient['enterprise']));
      $tmp_name = str_replace('.','',$tmp_name);

      if($als=="")
      $this->filename = $datum."_RE".$belegnr.".pdf";
      else
      $this->filename = $datum."_MA".$belegnr.".pdf";

      $this->setBarcode($belegnr);
  }


}
?>
